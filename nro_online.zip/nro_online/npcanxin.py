# File: npcanxin.py (AUTO SYNC + ICON NHỎ + FIX CLICK) - UPDATED: ICON GĂNG HOÀNG ĐẾ

import pygame
import sys
import os

# --- IMPORT MODULE QUẢN LÝ GIÁ TIỀN & ITEM ---
try:
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.join(current_dir, '..')
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)

    import qlgiatien
    from item_manager import ITEM_TEMPLATES
except Exception:
    qlgiatien = None
    ITEM_TEMPLATES = {}

# --- IMPORT ITEM VIP (nếu có) ---
try:
    import itemvip
    if hasattr(itemvip, "register_into"):
        itemvip.register_into(ITEM_TEMPLATES)
    elif hasattr(itemvip, "ITEM_VIP_TEMPLATES"):
        ITEM_TEMPLATES.update(itemvip.ITEM_VIP_TEMPLATES)
except Exception:
    pass

# --- CẤU HÌNH NPC ---
NPC_X_WORLD = 500
NPC_WIDTH = 40
NPC_HEIGHT = 50

# --- SHOP UI ---
SHOP_W = 600
SHOP_H = 400
SLOT_SIZE = 50
SLOT_MARGIN = 8

# khoảng ngang phụ để hiện giá (nhỏ hơn cho gọn)
PRICE_W = 26
X_STEP = SLOT_SIZE + SLOT_MARGIN + PRICE_W
Y_STEP = SLOT_SIZE + SLOT_MARGIN + 22
COLS_PER_ROW = 5

# DANH SÁCH VẬT PHẨM SHOP AN XIN (MẶC ĐỊNH)
# (LƯU Ý: biến SHOP_ITEMS sẽ được AUTO-CẬP NHẬT để click hoạt động đúng)
SHOP_ITEMS_DEFAULT = {
    "hp_potion_1": {"price": 10, "currency": "KIM_CUONG"},
    "ki_potion_1": {"price": 10, "currency": "KIM_CUONG"},
    "armor_1": {"price": 50, "currency": "KIM_CUONG"},
}
SHOP_ITEMS = dict(SHOP_ITEMS_DEFAULT)

# --- MÀU SẮC ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
C_VANG = (255, 215, 0)
RED_ERROR = (255, 0, 0)
AO_RACH = (100, 90, 80)
NON_RACH = (80, 70, 60)
DA_NGUOI = (255, 220, 170)

# --- FONT ---
font_small = None
font_big = None

def init_fonts():
    global font_small, font_big
    if font_small is None:
        try:
            font_small = pygame.font.SysFont("Arial", 16)
        except:
            font_small = pygame.font.SysFont(None, 16)
    if font_big is None:
        try:
            font_big = pygame.font.SysFont("Arial", 24, bold=True)
        except:
            font_big = pygame.font.SysFont(None, 24)

# ==========================
# AUTO SYNC: items_to_show
# ==========================
def resolve_shop_items():
    """
    - Ưu tiên qlgiatien.PRICE_DATA['ANXIN'] nếu có
    - Nếu không có: dùng SHOP_ITEMS_DEFAULT
    - Sau đó auto-add mọi item trong ITEM_TEMPLATES có shops['ANXIN']
    - Cuối cùng: cập nhật SHOP_ITEMS toàn cục (để MAIN click dùng SHOP_ITEMS là đúng)
    """
    base = dict(SHOP_ITEMS_DEFAULT)

    if qlgiatien and hasattr(qlgiatien, "PRICE_DATA"):
        base = dict(qlgiatien.PRICE_DATA.get("ANXIN", base))

    # auto add từ template (shops)
    for k, tmpl in (ITEM_TEMPLATES or {}).items():
        shops = tmpl.get("shops", {})
        if isinstance(shops, dict) and "ANXIN" in shops:
            info = shops.get("ANXIN", {})
            price = info.get("price", 0)
            currency = info.get("currency", "KIM_CUONG")
            if k not in base:
                base[k] = {"price": price, "currency": currency}

    # IMPORTANT: cập nhật global SHOP_ITEMS để main click lấy tmp = SHOP_ITEMS.get(k) ra được
    global SHOP_ITEMS
    SHOP_ITEMS = base
    return base

# ==========================
# ICON (NHỎ/GỌN)
# ==========================
def _rarity_color(item):
    rc = item.get("rarity", WHITE)
    if isinstance(rc, list):
        rc = tuple(rc)
    return rc

def draw_item_icon(surface, x, y, item_key):
    init_fonts()
    item = ITEM_TEMPLATES.get(item_key, {})
    rarity = _rarity_color(item)

    rect = pygame.Rect(x, y, SLOT_SIZE, SLOT_SIZE)
    pygame.draw.rect(surface, (20, 20, 20), rect, border_radius=6)
    pygame.draw.rect(surface, rarity, rect, 1, border_radius=6)

    cx, cy = rect.center
    key = (item_key or "").lower()
    name = (item.get("name", "") or "").lower()
    combo = key + " " + name

    # POTION
    if ("potion" in combo) or ("thuoc" in combo):
        color = (230, 0, 0) if (("hp" in combo) or ("mau" in combo)) else (0, 120, 255)
        pygame.draw.circle(surface, color, (cx, cy + 2), 6)
        pygame.draw.rect(surface, WHITE, (cx - 2, cy - 6, 4, 4))
        pygame.draw.rect(surface, (139, 69, 19), (cx - 3, cy - 8, 6, 2))

    # KIẾM
    elif ("sword" in combo) or ("kiem" in combo):
        pygame.draw.line(surface, (220, 220, 220), (cx - 6, cy + 6), (cx + 6, cy - 6), 3)
        pygame.draw.line(surface, (100, 100, 100), (cx - 6, cy + 6), (cx + 6, cy - 6), 1)
        pygame.draw.line(surface, (139, 69, 19), (cx - 6, cy + 6), (cx - 9, cy + 9), 3)

    # RADA
    elif ("radar" in combo) or ("rada" in combo):
        pygame.draw.circle(surface, (0, 255, 0), (cx, cy), 6, 1)
        pygame.draw.circle(surface, (0, 255, 0), (cx, cy), 2, 1)
        pygame.draw.line(surface, (0, 255, 0), (cx, cy), (cx + 4, cy - 4), 1)

    # GIÀY
    elif ("giay" in combo) or ("shoe" in combo) or ("boot" in combo):
        pygame.draw.rect(surface, rarity, (cx - 8, cy + 4, 16, 6), border_radius=2)   # đế
        pygame.draw.rect(surface, rarity, (cx - 6, cy + 0, 12, 5), border_radius=2)   # thân
        pygame.draw.rect(surface, (40, 40, 40), (cx - 8, cy + 8, 16, 2))

    # QUẦN
    elif ("quan" in combo) or ("pants" in combo):
        pygame.draw.rect(surface, rarity, (cx - 8, cy - 6, 16, 4), border_radius=2)   # cạp
        pygame.draw.rect(surface, rarity, (cx - 8, cy - 2, 7, 14), border_radius=2)   # ống trái
        pygame.draw.rect(surface, rarity, (cx + 1, cy - 2, 7, 14), border_radius=2)   # ống phải
        pygame.draw.rect(surface, (30, 30, 40), (cx - 1, cy - 2, 2, 10))

    # GĂNG
    elif ("gang" in combo) or ("glove" in combo):
        # --- Găng Hoàng Đế: 1 cái găng vàng ngầu ---
        if ("hoang de" in combo) or ("hoàng đế" in combo) or ("emperor" in combo):
            gold = (255, 215, 0)
            gold2 = (200, 160, 0)

            # thân găng (dạng boxing glove)
            pygame.draw.ellipse(surface, gold, (cx - 9, cy - 7, 18, 16))
            pygame.draw.ellipse(surface, gold2, (cx - 9, cy - 7, 18, 16), 1)

            # cổ tay
            pygame.draw.rect(surface, gold, (cx - 7, cy + 6, 14, 6), border_radius=3)
            pygame.draw.rect(surface, gold2, (cx - 7, cy + 6, 14, 6), 1, border_radius=3)

            # highlight bóng
            pygame.draw.circle(surface, (255, 245, 180), (cx - 3, cy - 1), 2)
            pygame.draw.circle(surface, (255, 245, 180), (cx + 2, cy + 1), 1)

            # ngôi sao nhỏ cho “VIP”
            pygame.draw.polygon(surface, (255, 255, 255), [
                (cx, cy - 6),
                (cx + 2, cy - 2),
                (cx + 6, cy - 2),
                (cx + 3, cy + 1),
                (cx + 4, cy + 6),
                (cx, cy + 3),
                (cx - 4, cy + 6),
                (cx - 3, cy + 1),
                (cx - 6, cy - 2),
                (cx - 2, cy - 2),
            ], 0)
        # --- găng thường ---
        else:
            pygame.draw.circle(surface, rarity, (cx, cy), 7)
            pygame.draw.circle(surface, (60, 60, 60), (cx, cy), 7, 1)
            pygame.draw.circle(surface, (30, 30, 30), (cx - 2, cy - 1), 1)
            pygame.draw.circle(surface, (30, 30, 30), (cx + 2, cy - 1), 1)

    # ÁO/GIÁP
    elif ("armor" in combo) or ("ao" in combo) or ("giap" in combo):
        pygame.draw.rect(surface, rarity, (cx - 6, cy - 7, 12, 14), border_radius=3)
        pygame.draw.rect(surface, rarity, (cx - 9, cy - 6, 3, 6), border_radius=2)
        pygame.draw.rect(surface, rarity, (cx + 6, cy - 6, 3, 6), border_radius=2)
        pygame.draw.rect(surface, (50, 50, 50), (cx - 6, cy + 1, 12, 2))

    else:
        txt = font_small.render("?", True, WHITE)
        surface.blit(txt, (cx - txt.get_width() // 2, cy - txt.get_height() // 2))

# ==========================
# NPC DRAW / CLICK
# ==========================
def draw_npc(screen, map_offset_x, ground_y):
    screen_x = NPC_X_WORLD - map_offset_x
    y = ground_y - NPC_HEIGHT

    if -50 < screen_x < 850:
        pygame.draw.rect(screen, AO_RACH, (screen_x + 5, y + 20, 30, 30))
        pygame.draw.circle(screen, DA_NGUOI, (screen_x + 20, y + 15), 12)
        pygame.draw.polygon(screen, NON_RACH, [(screen_x + 5, y + 15), (screen_x + 35, y + 15), (screen_x + 20, y - 5)])
        pygame.draw.arc(screen, (50, 50, 50), (screen_x + 30, y + 40, 15, 15), 3.14, 6.28, 2)

        init_fonts()
        txt_name = font_small.render("An Xin", True, WHITE)
        screen.blit(txt_name, (screen_x + 20 - txt_name.get_width()//2, y - 25))

def check_click(mouse_pos, map_offset_x, ground_y):
    screen_x = NPC_X_WORLD - map_offset_x
    npc_rect = pygame.Rect(screen_x, ground_y - NPC_HEIGHT, NPC_WIDTH, NPC_HEIGHT)
    return npc_rect.collidepoint(mouse_pos)

# ==========================
# SLOTS (FIX CLICK)
# ==========================
def get_item_slots(screen_width, screen_height):
    """
    Trả về dict:
      { item_key: {'rect': pygame.Rect(...), 'data': {'price':..,'currency':..}} }
    -> MAIN của em đang check r['rect'] nên click sẽ ăn chắc.
    """
    slots = {}

    menu_x = (screen_width - SHOP_W) // 2
    menu_y = (screen_height - SHOP_H) // 2
    start_x = menu_x + 28
    start_y = menu_y + 78

    items_to_show = resolve_shop_items()

    col = 0
    row = 0

    for key, data in items_to_show.items():
        x = start_x + col * X_STEP
        y = start_y + row * Y_STEP

        rect = pygame.Rect(x, y, SLOT_SIZE, SLOT_SIZE)
        slots[key] = {"rect": rect, "data": data}

        col += 1
        if col >= COLS_PER_ROW:
            col = 0
            row += 1

    return slots

# ==========================
# SHOP UI
# ==========================
def draw_shop_menu(screen, screen_width, screen_height):
    init_fonts()

    menu_x = (screen_width - SHOP_W) // 2
    menu_y = (screen_height - SHOP_H) // 2

    bg_rect = pygame.Rect(menu_x, menu_y, SHOP_W, SHOP_H)
    pygame.draw.rect(screen, (40, 40, 40), bg_rect, border_radius=10)
    pygame.draw.rect(screen, C_VANG, bg_rect, 3, border_radius=10)

    title = font_big.render("SHOP AN XIN (VIP)", True, RED_ERROR)
    screen.blit(title, (menu_x + SHOP_W//2 - title.get_width()//2, menu_y + 15))

    close_size = 30
    close_rect = pygame.Rect(menu_x + SHOP_W - close_size - 10, menu_y + 10, close_size, close_size)
    pygame.draw.rect(screen, RED_ERROR, close_rect, border_radius=5)
    txt_x = font_big.render("X", True, WHITE)
    screen.blit(txt_x, (close_rect.centerx - txt_x.get_width()//2, close_rect.centery - txt_x.get_height()//2))

    # LẤY ĐÚNG danh sách (đồng thời cập nhật SHOP_ITEMS để click hoạt động)
    items_to_show = resolve_shop_items()

    start_x = menu_x + 28
    start_y = menu_y + 78

    col = 0
    row = 0

    for key, data in items_to_show.items():
        x = start_x + col * X_STEP
        y = start_y + row * Y_STEP

        draw_item_icon(screen, x, y, key)

        price = data.get("price", 0)
        currency = data.get("currency", "VANG")
        price_color = C_VANG if currency == "VANG" else (0, 255, 255)
        txt_price = font_small.render(str(price), True, price_color)
        screen.blit(txt_price, (x + (SLOT_SIZE - txt_price.get_width())//2, y + SLOT_SIZE + 2))

        col += 1
        if col >= COLS_PER_ROW:
            col = 0
            row += 1

    return close_rect
