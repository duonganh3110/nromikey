# luonglongnhatthe.py
# Fusion feature: "luong long nhat the"
# - only if player has pet
# - 5 minutes duration (strict using pygame.time.get_ticks)
# - bonus stats = pet stats added to master
# - white flash + white silhouettes pose/merge/split
# - fused form overlay + aura + light lightning
# - timer text drawn BELOW the button

import pygame
import time
import random
import math

DEBUG_FUSION = False

FUSION_TOTAL_MS = 5 * 60 * 1000  # 5 minutes

# [PERSIST] wall-clock time để out game vào lại không reset
def _unix_now():
    try:
        return float(time.time())
    except Exception:
        return 0.0


FLASH_IN_MS = 140
POSE_MS = 750
MERGE_MS = 520
REVEAL_MS = 220

FLASH_OUT_MS = 160
SPLIT_MS = 520


def _now():
    return pygame.time.get_ticks()


def _ensure_info(info):
    if info is None:
        return None
    f = info.get("fusion")
    if not isinstance(f, dict):
        f = {}
        info["fusion"] = f
    f.setdefault("active", False)
    f.setdefault("phase", "")
    f.setdefault("phase_tick", 0)
    f.setdefault("start_tick", 0)
    f.setdefault("end_tick", 0)
    f.setdefault("total_ms", FUSION_TOTAL_MS)
    f.setdefault("merged", False)
    f.setdefault("bonus", {})
    f.setdefault("race", "")
    f.setdefault("flash_alpha", 0)
    f.setdefault("flash_hold", 0)
    return f



def _reset_fusion_state(info, f, now=None):
    """Reset fusion state để tránh bị kẹt sau khi out game/restart."""
    if now is None:
        now = _now()
    if isinstance(f, dict):
        f["active"] = False
        f["phase"] = ""
        f["phase_tick"] = int(now)
        f["start_tick"] = 0
        f["end_tick"] = 0
        f["start_unix"] = 0.0
        f["end_unix"] = 0.0
        f["paused_ms"] = 0
        f["total_ms"] = FUSION_TOTAL_MS
        f["merged"] = False
        f["bonus"] = {}
        f["race"] = ""
        f["flash_alpha"] = 0
        f["flash_hold"] = int(now)
    if isinstance(info, dict):
        info["fusion_need_refresh"] = True
        info["fusion_request"] = False
        info["_close_bag_menu"] = False
        # giữ render_mode mặc định
        info["fusion_render_mode"] = "replace"


def sanitize_fusion(info, now=None):
    """
    Fix các trạng thái hợp thể bị lỗi:
    - Thời gian đếm ngược nhảy lên 51 phút (do end_tick/start_tick cũ)
    - Out game/restart: nhân vật đã tách nhưng nút vẫn 'DANG HOP' -> kẹt không bấm được
    """
    if info is None:
        return
    if now is None:
        now = _now()

    f = info.get("fusion")
    if not isinstance(f, dict):
        return

    # luôn ép total_ms đúng 5 phút
    if _safe_int(f.get("total_ms", FUSION_TOTAL_MS), FUSION_TOTAL_MS) != FUSION_TOTAL_MS:
        f["total_ms"] = FUSION_TOTAL_MS

    if not f.get("active"):
        return

    start = _safe_int(f.get("start_tick", 0), 0)
    end = _safe_int(f.get("end_tick", 0), 0)

    paused_ms = f.get('paused_ms', None)
    try:
        paused_ms = int(paused_ms) if paused_ms is not None else None
    except Exception:
        paused_ms = None


    # [PERSIST] nếu có end_unix thì rebuild end_tick theo thời gian thực
    end_unix = f.get('end_unix', 0.0)
    try:
        end_unix = float(end_unix)
    except Exception:
        end_unix = 0.0
    if end_unix > 0.0:
        now_unix = _unix_now()
        remain_ms = int((end_unix - now_unix) * 1000.0)
        if remain_ms > (FUSION_TOTAL_MS):
            remain_ms = FUSION_TOTAL_MS
        if remain_ms <= 0:
            _reset_fusion_state(info, f, now)
            return
        f['start_tick'] = int(now)
        f['end_tick'] = int(now + remain_ms)
        # vào lại coi như đã merged (đỡ kẹt giữa animation)
        if not bool(f.get('merged')):
            f['merged'] = True
            f['phase'] = 'active'
            f['phase_tick'] = int(now)
        return


    # Case 0: phase/state mismatch (kẹt active nhưng phase sai) -> reset
    phase = str(f.get('phase', ''))
    merged = bool(f.get('merged'))
    valid_phases = {'', 'flash_in', 'pose', 'merge', 'reveal', 'active', 'flash_out', 'split'}
    if phase not in valid_phases:
        _reset_fusion_state(info, f, now)
        return
    if phase == '' and (start > 0 or end > 0 or merged):
        _reset_fusion_state(info, f, now)
        return
    if phase == 'active' and (not merged):
        _reset_fusion_state(info, f, now)
        return
    if merged and phase not in ('active', 'flash_out', 'split'):
        _reset_fusion_state(info, f, now)
        return

    # Case 1: pygame ticks reset sau restart (now nhỏ hơn start rất nhiều)
    if start > 0 and (now + 2000) < start:
        if paused_ms is not None and paused_ms > 0:
            f['start_tick'] = int(now)
            f['end_tick'] = int(now + min(paused_ms, FUSION_TOTAL_MS))
            f['paused_ms'] = 0
            if not bool(f.get('merged')):
                f['merged'] = True
                f['phase'] = 'active'
                f['phase_tick'] = int(now)
            return
        _reset_fusion_state(info, f, now)
        return

    # Case 2: end_tick invalid
    if end <= 0 or (start > 0 and end <= start):
        if paused_ms is not None and paused_ms > 0:
            f['start_tick'] = int(now)
            f['end_tick'] = int(now + min(paused_ms, FUSION_TOTAL_MS))
            f['paused_ms'] = 0
            if not bool(f.get('merged')):
                f['merged'] = True
                f['phase'] = 'active'
                f['phase_tick'] = int(now)
            return
        _reset_fusion_state(info, f, now)
        return

    # Case 3: duration quá lớn (ví dụ 51 phút)
    if start > 0 and (end - start) > (FUSION_TOTAL_MS + 10_000):
        # reset luôn để tránh kẹt
        _reset_fusion_state(info, f, now)
        return

    # Case 4: time-left quá lớn (end_tick từ bản cũ) -> reset
    if (end - now) > (FUSION_TOTAL_MS + 10_000):
        _reset_fusion_state(info, f, now)
        return

    # Case 5: đã hết giờ -> chuyển sang flash_out để tách (tránh kẹt nút)
    # (nếu đang flash_out/split thì để update_fusion xử lý tiếp)
    phase = str(f.get('phase', ''))
    if now >= end:
        if phase == 'active':
            f['phase'] = 'flash_out'
            f['phase_tick'] = int(now)
            try:
                _set_flash(f, 255)
            except Exception:
                f['flash_alpha'] = 255
                f['flash_hold'] = int(now)
            return
        if phase not in ('flash_out', 'split'):
            _reset_fusion_state(info, f, now)
            return

def is_fusion_active(info):
    f = _ensure_info(info)
    sanitize_fusion(info)
    if not f:
        return False
    return bool(f.get("active"))


def is_fusion_merged(info):
    f = _ensure_info(info)
    sanitize_fusion(info)
    if not f:
        return False
    return bool(f.get("active")) and bool(f.get("merged")) and (f.get("phase") == "active")


def ui_can_click(info):
    f = _ensure_info(info)
    sanitize_fusion(info)
    if not f:
        return True
    return not bool(f.get("active"))


def _safe_int(v, d=0):
    try:
        return int(v)
    except Exception:
        return int(d)


def _det_bonus(det):
    bonus = {}
    bonus["max_hp"] = _safe_int(getattr(det, "hp_max", getattr(det, "max_hp", 0)))
    bonus["max_ki"] = _safe_int(getattr(det, "ki_max", getattr(det, "max_ki", 0)))

    sd = getattr(det, "suc_danh", None)
    if sd is None:
        try:
            sd = int(getattr(det, "dmg_min", 0))
        except Exception:
            sd = 0
    bonus["suc_danh"] = _safe_int(sd)

    bonus["giap"] = _safe_int(getattr(det, "giap", 0))
    bonus["ne_tranh"] = _safe_int(getattr(det, "ne_tranh", 0))
    bonus["nhanh_nhen"] = _safe_int(getattr(det, "nhanh_nhen", 0))
    bonus["chi_mang"] = _safe_int(getattr(det, "chi_mang", 0))
    bonus["suc_manh"] = _safe_int(getattr(det, "suc_manh", 0))
    return bonus


def start_fusion(info, det_obj, race, now_tick=None):
    if info is None or det_obj is None:
        return False

    now = _now()  # strict pygame ticks
    f = _ensure_info(info)
    if not f:
        return False
    if f.get("active"):
        return False

    f["active"] = True
    f["phase"] = "flash_in"
    f["phase_tick"] = now
    f["start_tick"] = now
    f["total_ms"] = FUSION_TOTAL_MS
    f["end_tick"] = now + int(f["total_ms"])
    # [PERSIST]
    u = _unix_now()
    f["start_unix"] = float(u)
    f["end_unix"] = float(u + (FUSION_TOTAL_MS / 1000.0))
    # [NEW] mặc định: thay sprite (ẩn nhân vật gốc)
    info['fusion_render_mode'] = 'replace'
    f["merged"] = False
    f["bonus"] = _det_bonus(det_obj)
    f["race"] = str(race or "")
    f["flash_alpha"] = 255
    f["flash_hold"] = now

    info["fusion_need_refresh"] = False

    if DEBUG_FUSION:
        try:
            print("FUSION START now=", now, "end=", f["end_tick"], "total_ms=", f["total_ms"])
        except Exception:
            pass

    return True


def _set_flash(f, alpha):
    f["flash_alpha"] = max(0, min(255, int(alpha)))
    f["flash_hold"] = _now()


def update_fusion(info, now_tick=None):
    # returns True if main loop should refresh stats now
    if info is None:
        return False

    now = _now()  # strict pygame ticks

    sanitize_fusion(info, now)
    f = _ensure_info(info)
    if not f:
        return False

    need_refresh = bool(info.get("fusion_need_refresh", False))
    info["fusion_need_refresh"] = False

    if not f.get("active"):
        return need_refresh

    phase = f.get("phase", "")
    dt = now - _safe_int(f.get("phase_tick", now))

    if phase == "flash_in":
        a = 255 - int(255 * (dt / float(max(1, FLASH_IN_MS))))
        _set_flash(f, a)
        if dt >= FLASH_IN_MS:
            f["phase"] = "pose"
            f["phase_tick"] = now
            _set_flash(f, 180)

    elif phase == "pose":
        pulse = 110 + int(70 * math.sin(now / 60.0))
        _set_flash(f, pulse)
        if dt >= POSE_MS:
            f["phase"] = "merge"
            f["phase_tick"] = now
            _set_flash(f, 230)

    elif phase == "merge":
        a = 230 - int(200 * (dt / float(max(1, MERGE_MS))))
        _set_flash(f, a)
        if dt >= MERGE_MS:
            f["phase"] = "reveal"
            f["phase_tick"] = now
            _set_flash(f, 255)

    elif phase == "reveal":
        a = 255 - int(255 * (dt / float(max(1, REVEAL_MS))))
        _set_flash(f, a)
        if dt >= REVEAL_MS:
            f["phase"] = "active"
            f["phase_tick"] = now
            f["merged"] = True
            need_refresh = True

    elif phase == "active":
        _set_flash(f, 0)
        # [NEW] ép thời gian còn lại không vượt quá 5 phút (tránh bị giữ 9p từ bản cũ)
        try:
            if _safe_int(f.get("total_ms", FUSION_TOTAL_MS), FUSION_TOTAL_MS) != FUSION_TOTAL_MS:
                f["total_ms"] = FUSION_TOTAL_MS
            et = _safe_int(f.get("end_tick", 0), 0)
            st = _safe_int(f.get("start_tick", now), now)
            if et <= 0 or et > st + FUSION_TOTAL_MS:
                f["end_tick"] = st + FUSION_TOTAL_MS
        except Exception:
            pass
        if now >= _safe_int(f.get("end_tick", now)):
            f["phase"] = "flash_out"
            f["phase_tick"] = now
            _set_flash(f, 255)

    elif phase == "flash_out":
        a = 255 - int(255 * (dt / float(max(1, FLASH_OUT_MS))))
        _set_flash(f, a)
        if dt >= FLASH_OUT_MS:
            f["phase"] = "split"
            f["phase_tick"] = now
            _set_flash(f, 220)

    elif phase == "split":
        a = 220 - int(200 * (dt / float(max(1, SPLIT_MS))))
        _set_flash(f, a)
        if dt >= SPLIT_MS:
            f["active"] = False
            f["phase"] = ""
            f["phase_tick"] = now
            f["merged"] = False
            f["bonus"] = {}
            f["race"] = ""
            f["total_ms"] = FUSION_TOTAL_MS
            f["end_tick"] = 0
            f["start_unix"] = 0.0
            f["end_unix"] = 0.0
            _set_flash(f, 0)
            # [NEW] clear request flags when finished
            try:
                info["fusion_request"] = False
                info["_close_bag_menu"] = False
            except Exception:
                pass
            need_refresh = True

    return need_refresh


def get_bonus_if_active(info):
    f = _ensure_info(info)
    if not f:
        return {}
    if f.get("active") and f.get("merged") and f.get("phase") == "active":
        b = f.get("bonus") or {}
        return b if isinstance(b, dict) else {}
    return {}


def _fmt_ms(ms):
    ms = max(0, int(ms))
    s = ms // 1000
    m = s // 60
    s = s % 60
    return f"{m:02d}:{s:02d}"



def snapshot_for_save(info, now_tick=None):
    """
    Gọi trước khi save/out game để "đóng băng" thời gian còn lại.
    Vào lại sẽ tiếp tục đúng thời gian còn lại (không bị reset / không bị trôi).
    """
    if info is None:
        return
    if now_tick is None:
        now_tick = _now()
    f = info.get("fusion")
    if not isinstance(f, dict):
        return
    if not f.get("active"):
        return
    end_tick = _safe_int(f.get("end_tick", 0), 0)
    remain = end_tick - int(now_tick)
    if remain < 0:
        remain = 0
    if remain > FUSION_TOTAL_MS:
        remain = FUSION_TOTAL_MS
    f["paused_ms"] = int(remain)


def get_time_left_str(info, now_tick=None):
    f = _ensure_info(info)
    if not f or not f.get("active"):
        return ""
    now = _now()  # strict pygame ticks
    sanitize_fusion(info, now)
    end_tick = _safe_int(f.get("end_tick", 0))
    if end_tick <= 0:
        # fallback from start + total
        start = _safe_int(f.get("start_tick", now))
        total = _safe_int(f.get("total_ms", FUSION_TOTAL_MS))
        end_tick = start + total
    return _fmt_ms(end_tick - now)


def _draw_btn(screen, rect, text, font, disabled=False, active=False):
    if disabled:
        bg = (70, 70, 70)
        bd = (120, 120, 120)
        tx = (200, 200, 200)
    elif active:
        bg = (255, 170, 0)
        bd = (255, 240, 170)
        tx = (30, 20, 10)
    else:
        bg = (60, 60, 90)
        bd = (220, 220, 220)
        tx = (255, 255, 255)

    pygame.draw.rect(screen, bg, rect, border_radius=8)
    pygame.draw.rect(screen, bd, rect, 2, border_radius=8)
    t = font.render(text, True, tx)
    screen.blit(t, (rect.centerx - t.get_width() // 2, rect.centery - t.get_height() // 2))


def draw_fuse_button(screen, rect, has_pet, info, font_ui, font_tiny=None, now_tick=None):
    f = _ensure_info(info)
    sanitize_fusion(info)
    active = bool(f and f.get("active"))
    merged = bool(f and f.get("merged"))
    phase = str(f.get("phase", "")) if f else ""

    # [NEW] dùng hàm kiểm tra để tránh kẹt UI
    try:
        merged_active = is_fusion_merged(info)
    except Exception:
        merged_active = (active and merged and phase == "active")

    disabled = (not has_pet) or (info is None)
    can_click = (not disabled) and (not active)

    if merged_active:
        label = "DANG HOP"
    else:
        label = "HOP THE"

    _draw_btn(screen, rect, label, font_ui, disabled=disabled, active=bool(merged_active))

    # timer BELOW the button (small)
    if info is not None:
        t = get_time_left_str(info, now_tick=now_tick)
        if t:
            ft = font_tiny or font_ui
            s = ft.render(t, True, (255, 255, 255))
            screen.blit(s, (rect.centerx - s.get_width() // 2, rect.bottom + 2))

    return can_click


def _draw_lightning(screen, cx, cy, r0, r1, n=5):
    for _ in range(n):
        ang = random.uniform(0, math.tau)
        x0 = cx + math.cos(ang) * random.uniform(r0, r1)
        y0 = cy + math.sin(ang) * random.uniform(r0, r1)
        segs = random.randint(3, 5)
        pts = [(x0, y0)]
        for i in range(segs):
            ang2 = ang + random.uniform(-0.7, 0.7)
            step = random.uniform(10, 18)
            x0 += math.cos(ang2) * step
            y0 += math.sin(ang2) * step
            pts.append((x0, y0))
        col = (220, 255, 255)
        pygame.draw.lines(screen, col, False, pts, 2)


def _draw_aura(screen, cx, cy, base_r):
    aura = pygame.Surface((base_r * 4, base_r * 4), pygame.SRCALPHA)
    ax = base_r * 2
    ay = base_r * 2
    pygame.draw.circle(aura, (255, 255, 255, 40), (ax, ay), int(base_r * 1.55))
    pygame.draw.circle(aura, (160, 240, 255, 60), (ax, ay), int(base_r * 1.25))
    pygame.draw.circle(aura, (255, 240, 200, 80), (ax, ay), int(base_r * 1.00))
    pygame.draw.circle(aura, (255, 255, 255, 40), (ax, ay), int(base_r * 0.70))
    screen.blit(aura, (cx - ax, cy - ay))


def _draw_white_silhouette(screen, rect, arms_up=False):
    x, y, w, h = rect.x, rect.y, rect.w, rect.h
    cx = x + w // 2
    head_r = max(6, int(min(w, h) * 0.18))
    body_w = int(w * 0.55)
    body_h = int(h * 0.45)
    body_x = cx - body_w // 2
    body_y = y + head_r + 2

    col = (255, 255, 255)
    pygame.draw.circle(screen, col, (cx, y + head_r + 2), head_r)
    pygame.draw.rect(screen, col, (body_x, body_y, body_w, body_h), border_radius=6)

    leg_w = int(body_w * 0.38)
    leg_h = int(h * 0.35)
    pygame.draw.rect(screen, col, (body_x, body_y + body_h - 2, leg_w, leg_h), border_radius=6)
    pygame.draw.rect(screen, col, (body_x + body_w - leg_w, body_y + body_h - 2, leg_w, leg_h), border_radius=6)

    if arms_up:
        pygame.draw.line(screen, col, (body_x, body_y + 10), (body_x - 18, body_y - 18), 6)
        pygame.draw.line(screen, col, (body_x + body_w, body_y + 10), (body_x + body_w + 18, body_y - 18), 6)
    else:
        pygame.draw.line(screen, col, (body_x, body_y + 16), (body_x - 20, body_y + 26), 6)
        pygame.draw.line(screen, col, (body_x + body_w, body_y + 16), (body_x + body_w + 20, body_y + 26), 6)


def _lerp(a, b, t):
    return a + (b - a) * t


def _draw_fused_form_overlay(screen, player_rect, race, tick):
    r = player_rect
    cx = r.centerx
    cy = r.bottom - 6

    h = max(60, r.h + 40)
    w = int(h * 0.55)

    sx = cx - w // 2
    sy = cy - h

    race = (race or "").lower()
    is_namec = ("namec" in race) or ("nm" in race)
    if is_namec:
        skin = (70, 170, 190)
        gi = (80, 50, 120)
        pad = (230, 180, 80)
        sash = (160, 50, 50)
        hair = (20, 20, 20)
        boots = (30, 30, 30)
    else:
        skin = (235, 190, 150)
        vest = (40, 40, 50)
        shoulder = (200, 200, 80)
        sash = (40, 140, 170)
        pants = (230, 230, 235)
        boots = (30, 30, 30)
        hair = (20, 20, 20)

    leg_h = int(h * 0.38)
    leg_w = int(w * 0.36)
    hip_y = sy + int(h * 0.58)
    pants_col = gi if is_namec else pants

    pygame.draw.rect(screen, pants_col, (sx + int(w * 0.20), hip_y, leg_w, leg_h), border_radius=10)
    pygame.draw.rect(screen, pants_col, (sx + int(w * 0.44), hip_y, leg_w, leg_h), border_radius=10)

    pygame.draw.ellipse(screen, boots, (sx + int(w * 0.18), hip_y + leg_h - 10, leg_w + 10, 16))
    pygame.draw.ellipse(screen, boots, (sx + int(w * 0.42), hip_y + leg_h - 10, leg_w + 10, 16))

    torso_y = sy + int(h * 0.28)
    torso_h = int(h * 0.32)
    torso_w = int(w * 0.70)
    torso_x = cx - torso_w // 2
    pygame.draw.rect(screen, skin, (torso_x, torso_y, torso_w, torso_h), border_radius=10)

    if is_namec:
        pygame.draw.rect(screen, gi, (torso_x, torso_y + int(torso_h * 0.20), torso_w, int(torso_h * 0.75)), border_radius=10)
        pygame.draw.ellipse(screen, pad, (torso_x - 14, torso_y + 6, 28, 26))
        pygame.draw.ellipse(screen, pad, (torso_x + torso_w - 14, torso_y + 6, 28, 26))
    else:
        pygame.draw.polygon(screen, vest, [(torso_x, torso_y + 8), (cx, torso_y + int(torso_h * 0.5)), (torso_x, torso_y + torso_h - 4)])
        pygame.draw.polygon(screen, vest, [(torso_x + torso_w, torso_y + 8), (cx, torso_y + int(torso_h * 0.5)), (torso_x + torso_w, torso_y + torso_h - 4)])
        pygame.draw.ellipse(screen, shoulder, (torso_x - 14, torso_y + 4, 30, 26))
        pygame.draw.ellipse(screen, shoulder, (torso_x + torso_w - 16, torso_y + 4, 30, 26))

    sash_y = torso_y + torso_h - 10
    pygame.draw.rect(screen, sash, (torso_x - 8, sash_y, torso_w + 16, 10), border_radius=6)

    head_r = int(w * 0.18)
    head_cy = sy + int(h * 0.18)
    pygame.draw.circle(screen, skin, (cx, head_cy), head_r)

    if is_namec:
        pygame.draw.polygon(screen, (40, 120, 140), [(cx, head_cy - head_r - 12), (cx - 10, head_cy - head_r + 6), (cx + 10, head_cy - head_r + 6)])
        pygame.draw.polygon(screen, (40, 120, 140), [(cx - 16, head_cy - head_r - 4), (cx - 22, head_cy - head_r + 10), (cx - 10, head_cy - head_r + 8)])
        pygame.draw.polygon(screen, (40, 120, 140), [(cx + 16, head_cy - head_r - 4), (cx + 22, head_cy - head_r + 10), (cx + 10, head_cy - head_r + 8)])
    else:
        spikes = []
        top = head_cy - head_r - 22
        for k in range(7):
            px = cx + (k - 3) * int(w * 0.06)
            py = top + random.randint(-2, 2)
            spikes.append((px, py))
        spikes += [(cx + int(w * 0.22), head_cy - head_r + 2),
                   (cx + int(w * 0.10), head_cy - head_r + 18),
                   (cx - int(w * 0.10), head_cy - head_r + 18),
                   (cx - int(w * 0.22), head_cy - head_r + 2)]
        pygame.draw.polygon(screen, hair, spikes)




def _draw_fused_character_run_surface(surf, race, tick, moving, attacking=False, attack_power=0.0, face_right=True):
    """
    Vẽ nhân vật hợp thể (Gogeta / Namec) theo style "anime" hơn:
    - cơ bắp, thân gọn, mặt ngầu
    - chạy: tay/chân vung rõ (không đơ)
    - đánh: vung tay mạnh + vệt lực (motion streak)
    Lưu ý: vẽ bằng primitive (polygon/ellipse/line), không dùng sprite.
    """
    W, H = surf.get_width(), surf.get_height()
    cx = W // 2
    ground = H - 10

    race = (race or "").lower()
    is_namec = ("namec" in race) or ("nm" in race) or ("xanh" in race)

    # -------- palette --------
    if is_namec:
        skin = (70, 210, 175)
        skin2 = (48, 160, 132)
        gi = (95, 60, 165)          # tím
        gi2 = (60, 40, 110)
        pad = (245, 205, 95)        # vàng
        pad2 = (180, 140, 30)
        sash = (170, 55, 55)        # đỏ
        pants = gi
        pants2 = gi2
        boots = (18, 18, 18)
        boots2 = (190, 190, 190)
        eye = (18, 18, 18)
        hair = None
    else:
        skin = (240, 205, 165)
        skin2 = (205, 170, 132)
        vest_black = (25, 25, 30)
        vest2 = (12, 12, 16)
        pad = (252, 185, 45)        # cam/vàng gogeta
        pad2 = (180, 120, 30)
        sash = (35, 165, 185)       # xanh
        pants = (245, 245, 250)     # trắng
        pants2 = (215, 215, 220)
        boots = (18, 18, 18)
        boots2 = (205, 205, 205)
        wrist = (18, 18, 18)
        eye = (14, 14, 14)
        hair = (18, 18, 18)

    # -------- animation params --------
    # chạy mềm hơn: base sin/cos, amp phụ thuộc moving
    t = tick / 95.0
    s1 = math.sin(t)
    s2 = math.sin(t + math.pi)
    amp = 1.0 if moving else 0.18

    atk = 0.0
    if attacking:
        atk = max(0.0, min(1.0, float(attack_power)))
    # giật người khi đánh
    body_lean = int((6 if face_right else -6) * atk)

    # -------- coordinate helpers --------
    def X(x):
        # mirror by face
        return int(x) if face_right else int(W - x)

    def P(x, y):
        return (X(x), int(y))

    def poly(col, pts):
        pygame.draw.polygon(surf, col, [P(px, py) for px, py in pts])

    def ellipse(col, rect, width=0):
        x, y, w, h = rect
        if face_right:
            pygame.draw.ellipse(surf, col, (int(x), int(y), int(w), int(h)), width)
        else:
            # mirror ellipse by x
            pygame.draw.ellipse(surf, col, (int(W - (x + w)), int(y), int(w), int(h)), width)

    def rr(col, rect, rad=10, width=0):
        x, y, w, h = rect
        if face_right:
            pygame.draw.rect(surf, col, (int(x), int(y), int(w), int(h)), width, border_radius=int(rad))
        else:
            pygame.draw.rect(surf, col, (int(W - (x + w)), int(y), int(w), int(h)), width, border_radius=int(rad))

    def tapered(col, p0, p1, w0, w1, outline=None):
        # draw tapered quad from p0->p1
        x0, y0 = p0
        x1, y1 = p1
        dx, dy = (x1 - x0), (y1 - y0)
        L = max(1e-6, math.hypot(dx, dy))
        nx, ny = -dy / L, dx / L
        a = (x0 + nx * w0, y0 + ny * w0)
        b = (x0 - nx * w0, y0 - ny * w0)
        c = (x1 - nx * w1, y1 - ny * w1)
        d = (x1 + nx * w1, y1 + ny * w1)
        poly(col, [a, b, c, d])
        if outline:
            pts = [P(*a), P(*b), P(*c), P(*d)]
            pygame.draw.polygon(surf, outline, pts, 1)

    # -------- proportions (anime-ish) --------
    body_h = int(H * 0.90)
    head_r = max(12, int(W * 0.18))
    head_cy = int(H * 0.21) + body_lean
    neck_y = head_cy + int(head_r * 0.72)

    torso_top = int(H * 0.30) + body_lean
    torso_h = int(H * 0.30)
    torso_w = int(W * 0.58)

    hip_y = torso_top + torso_h - 4
    leg_len = int(H * 0.42)
    arm_len = int(H * 0.34)

    # Running swing angles
    leg_swing = int(10 * s1 * amp)
    arm_swing = int(12 * s2 * amp)

    # Attack pose: tay trước đấm
    punch = atk

    # -------- background shadow --------
    sh = pygame.Surface((W, H), pygame.SRCALPHA)
    pygame.draw.ellipse(sh, (0, 0, 0, 75), (int(W * 0.22), int(H * 0.20), int(W * 0.56), int(H * 0.70)))
    surf.blit(sh, (0, 0))

    # -------- legs (tapered + folds) --------
    crotch_x = cx
    # hip anchors
    l_hip = (cx - int(W * 0.12), hip_y)
    r_hip = (cx + int(W * 0.12), hip_y)

    # knee/foot positions
    step = int(8 * s1 * amp)
    l_knee = (l_hip[0] + leg_swing, hip_y + int(leg_len * 0.52))
    r_knee = (r_hip[0] - leg_swing, hip_y + int(leg_len * 0.52))
    l_foot = (l_hip[0] - step, ground)
    r_foot = (r_hip[0] + step, ground)

    # back leg first (depth)
    tapered(pants2, (r_hip[0], r_hip[1]), (r_knee[0], r_knee[1]), W * 0.055, W * 0.045, outline=(0, 0, 0))
    tapered(pants2, (r_knee[0], r_knee[1]), (r_foot[0], r_foot[1]), W * 0.048, W * 0.038, outline=(0, 0, 0))
    # boots
    rr(boots, (r_foot[0] - int(W * 0.09), ground - int(H * 0.065), int(W * 0.18), int(H * 0.075)), rad=10)
    rr(boots2, (r_foot[0] - int(W * 0.08), ground - int(H * 0.055), int(W * 0.06), int(H * 0.028)), rad=8)

    # front leg
    tapered(pants, (l_hip[0], l_hip[1]), (l_knee[0], l_knee[1]), W * 0.06, W * 0.05, outline=(0, 0, 0))
    tapered(pants, (l_knee[0], l_knee[1]), (l_foot[0], l_foot[1]), W * 0.052, W * 0.040, outline=(0, 0, 0))
    rr(boots, (l_foot[0] - int(W * 0.09), ground - int(H * 0.065), int(W * 0.18), int(H * 0.075)), rad=10)
    rr(boots2, (l_foot[0] - int(W * 0.08), ground - int(H * 0.055), int(W * 0.06), int(H * 0.028)), rad=8)

    # pants folds lines
    for k in range(2):
        y = hip_y + int(leg_len * (0.22 + 0.18 * k))
        pygame.draw.line(surf, (0, 0, 0), P(cx - W * 0.18, y), P(cx - W * 0.04, y + 2), 1)
        pygame.draw.line(surf, (0, 0, 0), P(cx + W * 0.04, y), P(cx + W * 0.18, y + 2), 1)

    # -------- torso base (muscle) --------
    torso_x0 = cx - torso_w // 2
    # chest skin under vest/gi
    rr(skin, (torso_x0, torso_top, torso_w, torso_h), rad=16)
    rr(skin2, (torso_x0 + int(torso_w * 0.55), torso_top + 6, int(torso_w * 0.40), torso_h - 12), rad=16)

    # abs lines (subtle)
    for i in range(3):
        yy = torso_top + int(torso_h * (0.55 + i * 0.12))
        pygame.draw.line(surf, (0, 0, 0), P(cx - torso_w * 0.10, yy), P(cx + torso_w * 0.10, yy), 1)

    # -------- outfit (Gogeta / Namec) --------
    if is_namec:
        # gi top
        rr(gi, (torso_x0 - 2, torso_top + int(torso_h * 0.18), torso_w + 4, int(torso_h * 0.86)), rad=16)
        rr(gi2, (torso_x0 + 6, torso_top + int(torso_h * 0.22), torso_w - 12, int(torso_h * 0.78)), rad=16)
    else:
        # black vest body with V opening
        rr(vest_black, (torso_x0, torso_top + int(torso_h * 0.20), torso_w, int(torso_h * 0.80)), rad=14)
        # V opening
        poly((0, 0, 0), [(cx - torso_w * 0.08, torso_top + torso_h * 0.26),
                         (cx, torso_top + torso_h * 0.70),
                         (cx + torso_w * 0.08, torso_top + torso_h * 0.26)])
        # inner shading
        rr(vest2, (torso_x0 + 10, torso_top + int(torso_h * 0.25), torso_w - 20, int(torso_h * 0.70)), rad=14)

    # shoulder pads (rounded)
    pad_w = int(W * 0.26)
    pad_h = int(H * 0.13)
    ellipse(pad, (torso_x0 - int(pad_w * 0.55), torso_top + int(torso_h * 0.03), pad_w, pad_h))
    ellipse(pad, (torso_x0 + torso_w - int(pad_w * 0.45), torso_top + int(torso_h * 0.03), pad_w, pad_h))
    ellipse(pad2, (torso_x0 - int(pad_w * 0.38), torso_top + int(torso_h * 0.06), int(pad_w * 0.55), int(pad_h * 0.55)))
    ellipse(pad2, (torso_x0 + torso_w - int(pad_w * 0.17), torso_top + int(torso_h * 0.06), int(pad_w * 0.55), int(pad_h * 0.55)))

    # sash / belt
    belt_h = int(H * 0.06)
    rr(sash, (torso_x0 - 12, hip_y - int(belt_h * 0.62), torso_w + 24, belt_h), rad=12)
    # knot
    rr((245, 245, 245), (cx - int(W * 0.08), hip_y - int(belt_h * 0.58), int(W * 0.16), int(belt_h * 0.92)), rad=8)

    # -------- arms (tapered) --------
    sh_y = torso_top + int(torso_h * 0.24)
    l_sh = (cx - int(torso_w * 0.60), sh_y)
    r_sh = (cx + int(torso_w * 0.60), sh_y)

    # base elbow and hand
    # running: swing opposite legs
    l_elb = (l_sh[0] + int(arm_swing), sh_y + int(arm_len * 0.45))
    r_elb = (r_sh[0] - int(arm_swing), sh_y + int(arm_len * 0.45))

    l_hand = (l_elb[0] + int(arm_swing * 0.35), sh_y + arm_len)
    r_hand = (r_elb[0] - int(arm_swing * 0.35), sh_y + arm_len)

    # attack: right arm punch forward
    if punch > 0.01:
        # bring right hand forward/up
        px = int(cx + (W * 0.28) * punch * (1 if face_right else -1))
        py = int(sh_y + arm_len * (0.50 - 0.20 * punch))
        r_elb = (int(cx + W * 0.10), int(sh_y + arm_len * 0.30))
        r_hand = (px, py)

    # back arms first (depth)
    tapered(skin2, (r_sh[0], r_sh[1]), (r_elb[0], r_elb[1]), W * 0.050, W * 0.042, outline=(0, 0, 0))
    tapered(skin2, (r_elb[0], r_elb[1]), (r_hand[0], r_hand[1]), W * 0.046, W * 0.036, outline=(0, 0, 0))
    # wristband/glove
    rr((wrist if not is_namec else sash), (r_hand[0] - int(W * 0.06), r_hand[1] - 10, int(W * 0.12), 12), rad=6)

    # front arm
    tapered(skin, (l_sh[0], l_sh[1]), (l_elb[0], l_elb[1]), W * 0.054, W * 0.044, outline=(0, 0, 0))
    tapered(skin, (l_elb[0], l_elb[1]), (l_hand[0], l_hand[1]), W * 0.048, W * 0.038, outline=(0, 0, 0))
    rr((wrist if not is_namec else sash), (l_hand[0] - int(W * 0.06), l_hand[1] - 10, int(W * 0.12), 12), rad=6)

    # motion streak when punching
    if punch > 0.05:
        streak = pygame.Surface((W, H), pygame.SRCALPHA)
        a = int(140 * punch)
        for i in range(3):
            off = i * 5
            pygame.draw.line(streak, (255, 255, 255, a), P(r_elb[0] - off, r_elb[1] + off), P(r_hand[0] - off, r_hand[1] + off), 3)
        surf.blit(streak, (0, 0))

    # -------- head / face --------
    head_cx = cx + int(body_lean * 0.6)
    ellipse(skin, (head_cx - head_r, head_cy - head_r, head_r * 2, head_r * 2))
    # jaw (polygon) for anime look
    poly(skin2, [(head_cx - head_r * 0.70, head_cy + head_r * 0.10),
                 (head_cx - head_r * 0.40, head_cy + head_r * 0.88),
                 (head_cx + head_r * 0.40, head_cy + head_r * 0.88),
                 (head_cx + head_r * 0.70, head_cy + head_r * 0.10)])

    # eyes / brows (ngầu)
    ey = head_cy + int(head_r * 0.10)
    ex = int(head_r * 0.55)
    ew = max(2, int(head_r * 0.55))
    eh = max(2, int(head_r * 0.18))
    ellipse((255, 255, 255), (head_cx - ex - ew // 2, ey, ew, eh))
    ellipse((255, 255, 255), (head_cx + ex - ew // 2, ey, ew, eh))
    pygame.draw.circle(surf, eye, P(head_cx - ex, ey + eh // 2), max(2, eh // 2))
    pygame.draw.circle(surf, eye, P(head_cx + ex, ey + eh // 2), max(2, eh // 2))
    pygame.draw.line(surf, eye, P(head_cx - ex - ew * 0.6, ey - 2), P(head_cx - ex + ew * 0.4, ey - 6), 3)
    pygame.draw.line(surf, eye, P(head_cx + ex - ew * 0.4, ey - 6), P(head_cx + ex + ew * 0.6, ey - 2), 3)

    # nose + mouth
    pygame.draw.line(surf, eye, P(head_cx, head_cy + head_r * 0.18), P(head_cx + (2 if face_right else -2), head_cy + head_r * 0.38), 2)
    pygame.draw.line(surf, eye, P(head_cx - head_r * 0.22, head_cy + head_r * 0.62), P(head_cx + head_r * 0.22, head_cy + head_r * 0.64), 2)

    # Namec antenna / ears
    if is_namec:
        pygame.draw.line(surf, (35, 130, 120), P(head_cx - head_r * 0.60, head_cy - head_r * 0.15),
                         P(head_cx - head_r * 0.90, head_cy - head_r * 0.95), 4)
        pygame.draw.line(surf, (35, 130, 120), P(head_cx + head_r * 0.60, head_cy - head_r * 0.15),
                         P(head_cx + head_r * 0.90, head_cy - head_r * 0.95), 4)
        # ear fins
        poly((35, 160, 150), [(head_cx - head_r * 1.05, head_cy + head_r * 0.10),
                              (head_cx - head_r * 0.85, head_cy + head_r * 0.32),
                              (head_cx - head_r * 1.10, head_cy + head_r * 0.45)])
        poly((35, 160, 150), [(head_cx + head_r * 1.05, head_cy + head_r * 0.10),
                              (head_cx + head_r * 0.85, head_cy + head_r * 0.32),
                              (head_cx + head_r * 1.10, head_cy + head_r * 0.45)])
    else:
        # hair spikes layered (stable)
        top = head_cy - head_r - int(head_r * 0.90)
        left = head_cx - int(head_r * 0.95)
        right = head_cx + int(head_r * 0.95)
        spikes = [(left, head_cy - head_r * 0.35)]
        nsp = 10
        for i in range(nsp):
            u = i / (nsp - 1)
            px = left + (right - left) * u
            py = top + (math.sin(u * 6.3) * 6)
            spikes.append((px, py))
        spikes.append((right, head_cy - head_r * 0.35))
        spikes += [(head_cx + head_r * 0.78, head_cy - head_r * 0.05),
                   (head_cx + head_r * 0.35, head_cy + head_r * 0.72),
                   (head_cx - head_r * 0.35, head_cy + head_r * 0.72),
                   (head_cx - head_r * 0.78, head_cy - head_r * 0.05)]
        poly(hair, spikes)
        # shine
        poly((60, 60, 60), [(head_cx - head_r * 0.15, top + 8),
                            (head_cx + head_r * 0.20, top + 2),
                            (head_cx + head_r * 0.55, head_cy - head_r * 0.25),
                            (head_cx - head_r * 0.05, head_cy - head_r * 0.15)])

    # -------- subtle aura sparks (đỡ robot, thêm vibe) --------
    aura = pygame.Surface((W, H), pygame.SRCALPHA)
    a = 55 if not attacking else int(55 + 70 * atk)
    ellipse((255, 255, 255, a), (int(W * 0.18), int(H * 0.24), int(W * 0.64), int(H * 0.62)), 2)
    if moving or attacking:
        for i in range(4):
            px = cx + int(math.sin(tick / 70.0 + i * 1.6) * (W * 0.30))
            py = int(H * 0.36 + math.cos(tick / 60.0 + i * 2.1) * (H * 0.18))
            pygame.draw.line(aura, (255, 255, 255, a), (int(px), int(py)), (int(px + (7 if face_right else -7)), int(py - 9)), 2)
    surf.blit(aura, (0, 0))

def draw_fused_character(screen, info, player_rect, is_moving=False, is_jumping=False, huong_phai=True, tick=None):
    """
    Vẽ nhân vật hợp thể THAY cho nhân vật gốc (không còn kiểu đè overlay).
    """
    if screen is None or player_rect is None:
        return
    f = _ensure_info(info)
    if not f or not (f.get("active") and f.get("merged") and f.get("phase") == "active"):
        return

    if tick is None:
        tick = _now()

    race = f.get("race", "")
    moving = bool(is_moving) or bool(is_jumping)


    # [NEW] Attack animation: lấy tick đánh từ game_loop nếu có
    attack_tick = None
    try:
        attack_tick = info.get('_fusion_attack_tick') if isinstance(info, dict) else None
    except Exception:
        attack_tick = None
    attacking = False
    attack_power = 0.0
    if isinstance(attack_tick, (int, float)):
        dt = tick - int(attack_tick)
        if 0 <= dt <= 240:
            attacking = True
            attack_power = max(0.0, 1.0 - (dt / 240.0))
    # fallback: nếu game có cờ đang đánh
    if not attacking:
        try:
            if isinstance(info, dict) and info.get('is_attacking'):
                attacking = True
                attack_power = 0.65
        except Exception:
            pass
    H = max(92, int(player_rect.h * 1.85))
    W = max(58, int(H * 0.62))
    surf = pygame.Surface((W, H), pygame.SRCALPHA)
    _draw_fused_character_run_surface(surf, race, tick, moving, attacking=attacking, attack_power=attack_power, face_right=bool(huong_phai))

    if not huong_phai:
        surf = pygame.transform.flip(surf, True, False)

    bx = player_rect.centerx - W // 2
    by = player_rect.bottom - H + 4
    screen.blit(surf, (bx, by))


def should_hide_master_sprite(info):
    try:
        sanitize_fusion(info)
    except Exception:
        pass
    return is_fusion_merged(info)

def draw_world_fx(screen, info, player_rect, det_rect=None, now_tick=None):
    if info is None or player_rect is None:
        return

    f = _ensure_info(info)
    if not f or not f.get("active"):
        return

    now = _now()
    phase = str(f.get("phase", ""))
    dt = now - _safe_int(f.get("phase_tick", now))

    if det_rect is None:
        det_rect = pygame.Rect(player_rect.x - 60, player_rect.y, player_rect.w, player_rect.h)

    if phase in ("pose", "merge", "split", "flash_in", "flash_out", "reveal"):
        r1 = player_rect.copy()
        r2 = det_rect.copy()

        if phase == "merge":
            t = min(1.0, dt / float(max(1, MERGE_MS)))
            midx = int((r1.centerx + r2.centerx) * 0.5)
            midy = int((r1.centery + r2.centery) * 0.5)
            r1.centerx = int(_lerp(r1.centerx, midx, t))
            r1.centery = int(_lerp(r1.centery, midy, t))
            r2.centerx = int(_lerp(r2.centerx, midx, t))
            r2.centery = int(_lerp(r2.centery, midy, t))
        elif phase == "split":
            t = min(1.0, dt / float(max(1, SPLIT_MS)))
            r1.centerx = int(_lerp(r1.centerx, player_rect.centerx, t))
            r2.centerx = int(_lerp(r2.centerx, det_rect.centerx, t))

        arms_up = (phase in ("pose", "merge", "reveal"))
        _draw_white_silhouette(screen, r1, arms_up=arms_up)
        _draw_white_silhouette(screen, r2, arms_up=arms_up)

        _draw_aura(screen, player_rect.centerx, player_rect.centery, max(40, player_rect.h))
        _draw_lightning(screen, player_rect.centerx, player_rect.centery, 40, 85, n=4)
        # [NEW] nhấp nháy trắng màn hình khi hợp thể
        draw_flash_overlay(screen, info)
        return

    if phase == "active":
        cx = player_rect.centerx
        cy = player_rect.centery
        base_r = max(45, player_rect.h)

        _draw_aura(screen, cx, cy, base_r)
        if now % 3 == 0:
            _draw_lightning(screen, cx, cy, base_r * 0.7, base_r * 1.35, n=4)

        # [NEW] Nếu thay sprite thì không vẽ overlay nữa
        render_mode = 'replace'
        try:
            render_mode = str(info.get('fusion_render_mode', 'replace'))
        except Exception:
            render_mode = 'replace'
        if render_mode != 'replace':
            _draw_fused_form_overlay(screen, player_rect, f.get('race', ''), now)

    # [NEW] nhấp nháy trắng màn hình khi hợp thể/tách
    draw_flash_overlay(screen, info)


def draw_flash_overlay(screen, info):
    if info is None:
        return
    f = _ensure_info(info)
    if not f:
        return
    a = _safe_int(f.get("flash_alpha", 0))
    if a <= 0:
        return
    w, h = screen.get_width(), screen.get_height()
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    s.fill((255, 255, 255, a))
    screen.blit(s, (0, 0))