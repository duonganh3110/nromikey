import pygame
import sys
import json
import os
import time
import random
import math 
import re 

# --- IMPORT SETUP ---
try:
    current_dir = os.path.dirname(os.path.abspath(__file__))
    game_modules_path = os.path.join(current_dir, 'game_modules')
    if game_modules_path not in sys.path:
        sys.path.append(game_modules_path)
except Exception as e:
    pass
    
# Import các module game
import tuido  
import textthongbao
import npclang  
import ngonngu
import vang
import npcbando
import item_editor
import item_buy_popup
import tinnhan_nhanvat
import npcanxin    
import mocnhan
import hieuungdanhtay
import tileroivang_kc
import bangthanhmau
import bufftiente
import hieuungso
import tinh_dame
import qlgiatien
import mothanhvien
import item_manager
# [TÍCH HỢP] Thêm import Bà Hạt Mít vào đây
import dapdo_nhanpham  

# [NEW] IMPORT MODULE DO HOA MAP
import dohoamap_langcuatoi
import quaicon_map2
import die
import nhiemvu
import trangbi
import buffsucmanh
import nangchiso
import boss_lon_loi
import itemvip

import npcolong
import bossbroly_super50 as bossbroly
 # <-- thêm dòng này
import kynang
import luonglongnhatthe
from kamejoko import KameJoko
kame = KameJoko()
try:
    from atomic import AtomicGoldSkill
except Exception:
    AtomicGoldSkill = None




# =========================================================================
# --- [PATCH] FIX ERROR: NPC ANXIN SHOP ITEMS ---
# =========================================================================
if not hasattr(npcanxin, 'SHOP_ITEMS'):
    npcanxin.SHOP_ITEMS = {}

# =========================================================================
# --- [PATCH] CẬP NHẬT SHOP: XÓA CŨ, THÊM KIẾM GỖ ---
# =========================================================================
try:
    npcbando.SHOP_DATA = {
        "Trai Dat": ["sword_1"],  
        "Namec": ["sword_1"],
        "Xayda": ["sword_1"]
    }
except Exception as e:
    print(f"[SYSTEM] Patch Shop Error: {e}")

# =========================================================================
# --- CONFIG ---
# =========================================================================
SCREEN_WIDTH = 800; SCREEN_HEIGHT = 600; FPS = 60
GRAVITY = 1; JUMP_STRENGTH = -18        

MENU_WIDTH = 300; MENU_SPEED = 20  

CHEST_POS_WORLD = 20;  
CHEST_HEIGHT = 50;  
CHEST_SIZE = 50;  
CHEST_INTERACT_DISTANCE = 80  
TOOLTIP_WIDTH = 250; TOOLTIP_HEIGHT = 100; TOOLTIP_OFFSET = 10


# TOA DO NPC
NPC_GOHAN_X = 200; NPC_BANDO_X = 350; NPC_ANXIN_X = 500
NPC_BHATMIT_X = NPC_ANXIN_X + 150      
NPC_INTERACT_RANGE = 130

# --- CẤU HÌNH CỔNG ĐI (GATEWAY) ---
GATEWAY_WIDTH = 80      
GATEWAY_HEIGHT = 110      

# Font chữ cho tên địa danh trên cổng
try:
    font_gateway = pygame.font.SysFont("Arial", 14, bold=True)
except:
    font_gateway = pygame.font.Font(None, 20)

# COLORS
WHITE = (255, 255, 255); BLACK = (0, 0, 0); GRAY = (200, 200, 200); DARK_GRAY = (50, 50, 50)
BLUE_UI = (0, 100, 255); RED_ERROR = (255, 0, 0); GREEN_SUCCESS = (0, 200, 0)
RED_TITLE = (255, 0, 0); ORANGE_LOADING = (255, 140, 0)
C_VANG = (255, 215, 0); C_HIGHLIGHT = (255, 255, 100); C_MAT_DAT = (34, 139, 34)
C_BTN_DEL = (200, 50, 50); C_CHEST = (139, 69, 19); C_BTN_RESET = (255, 165, 0)
C_BANNED = (150, 0, 0); C_UNBANNED = (0, 150, 0)

# HUD COLORS
C_HP_RED = (230, 0, 0); C_KI_BLUE = (0, 120, 255); C_BG_BAR = (50, 0, 0)
MAU_DA = (255, 220, 170); TOC_DEN = (20, 20, 20)
AO_CAM = (255, 80, 0); DAI_XANH = (0, 0, 150); GIAY_XANH = (0, 0, 120); DAY_GIAY_DO = (200, 0, 0)
XANH_NAMEC = (100, 200, 50); TIM_NAMEC = (100, 50, 150); DAI_NAMEC = (50, 150, 255); GIAY_NAU = (139, 69, 19)
AO_BO_XANH = (0, 0, 100); GIAP_TRANG = (240, 240, 240); GIAP_VANG = (218, 165, 32); GIAY_TRANG = (230, 230, 230); MAU_DUOI = (100, 50, 0)

pygame.init()
pygame.key.set_repeat()

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Ngoc Rong Mikey - Client v43.5 (Full Fix)")
clock = pygame.time.Clock()

font = pygame.font.SysFont("Arial", 24); font_small = pygame.font.SysFont("Arial", 16)
font_mini = pygame.font.SysFont("Arial", 12); font_big = pygame.font.SysFont("Arial", 50, bold=True) 
font_btn = pygame.font.SysFont("Arial", 20, bold=True)
font_tiny = pygame.font.SysFont("Arial", 10) 


THU_MUC_GAME = os.path.dirname(os.path.abspath(__file__))
DATA_ACC_FILE = os.path.join(THU_MUC_GAME, "du_lieu_acc.json")
DATA_CHAR_FILE = os.path.join(THU_MUC_GAME, "du_lieu_nhan_vat.json")
DATA_ITEM_FILE = os.path.join(THU_MUC_GAME, "du_lieu_vat_pham.json")
SAVED_LOGIN_FILE = os.path.join(THU_MUC_GAME, "saved_login.json")
PATH_BG = os.path.join(THU_MUC_GAME, "background_login.jpg"); PATH_ICON_TD = os.path.join(THU_MUC_GAME, "icon_td.png"); PATH_ICON_NM = os.path.join(THU_MUC_GAME, "icon_nm.png"); PATH_ICON_XD = os.path.join(THU_MUC_GAME, "icon_xd.png")
PATH_FLAG_VN = os.path.join(THU_MUC_GAME, "vietnam.jpg")
PATH_FLAG_JP = os.path.join(THU_MUC_GAME, "nhatban.jpg")

GLOBAL_BG_IMAGE = None; ICON_TD_IMAGE = None; ICON_NM_IMAGE = None; ICON_XD_IMAGE = None
FLAG_VN_IMAGE = None; FLAG_JP_IMAGE = None
GLOBAL_USERNAME = None
boss_death_time = 0
  

# --- DATA HANDLING ---
from item_manager import ITEM_TEMPLATES, save_item_data, create_random_item_stack
def load_item_templates_data(): return ITEM_TEMPLATES
# --- HÀM VẼ NGÔI SAO (Sử dụng logic từ dapdo_nhampham.py) ---
def load_json(filename):
    if not os.path.exists(filename): return {}
    try:
        with open(filename, "r") as f: return json.load(f)
    except: return {}

def save_json(filename, data):
    try:
        with open(filename, "w") as f: json.dump(data, f, indent=4)
    except Exception as e: print(f"Loi luu file: {e}")

def load_image_safe(path, size=None):
    try:
        if not os.path.exists(path): return None
        img = pygame.image.load(path).convert_alpha()
        if size: img = pygame.transform.scale(img, size)
        return img
    except Exception as e: return None

def load_all_resources():
    global GLOBAL_BG_IMAGE, ICON_TD_IMAGE, ICON_NM_IMAGE, ICON_XD_IMAGE, FLAG_VN_IMAGE, FLAG_JP_IMAGE
    try:
        if os.path.exists(PATH_BG): 
            img = pygame.image.load(PATH_BG).convert()
            GLOBAL_BG_IMAGE = pygame.transform.scale(img, (SCREEN_WIDTH, SCREEN_HEIGHT))
        else: GLOBAL_BG_IMAGE = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT)); GLOBAL_BG_IMAGE.fill(BLACK)
    except: GLOBAL_BG_IMAGE = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT)); GLOBAL_BG_IMAGE.fill(BLACK)
        
    ICON_TD_IMAGE = load_image_safe(PATH_ICON_TD, (100, 100)); 
    ICON_NM_IMAGE = load_image_safe(PATH_ICON_NM, (100, 100)); 
    ICON_XD_IMAGE = load_image_safe(PATH_ICON_XD, (100, 100))
    FLAG_VN_IMAGE = load_image_safe(PATH_FLAG_VN, (120, 120)); 
    FLAG_JP_IMAGE = load_image_safe(PATH_FLAG_JP, (120, 120))

def ve_nut_custom(screen, rect, mau, text, text_color=BLACK, font_custom=None):
    pygame.draw.rect(screen, mau, rect)
    pygame.draw.rect(screen, WHITE, rect, 2)
    font_use = font_custom if font_custom else font_small
    text_surf = font_use.render(text, True, text_color)
    text_rect = text_surf.get_rect(center=rect.center)
    screen.blit(text_surf, text_rect)

# --- CLASS CHECKBOX, INPUTBOX ---
class Checkbox:
    def __init__(self, x, y, text):
        self.rect = pygame.Rect(x, y, 20, 20); self.text = text; self.checked = False; self.color = WHITE
    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.rect); pygame.draw.rect(surface, BLACK, self.rect, 2)
        if self.checked:
            pygame.draw.line(surface, BLACK, (self.rect.x + 4, self.rect.y + 10), (self.rect.x + 8, self.rect.y + 16), 3)
            pygame.draw.line(surface, BLACK, (self.rect.x + 8, self.rect.y + 16), (self.rect.x + 16, self.rect.y + 4), 3)
        txt_surf = font_small.render(self.text, True, WHITE); surface.blit(txt_surf, (self.rect.x + 30, self.rect.y))
    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos): self.checked = not self.checked; return True
        return False

class InputBox:
    def __init__(self, x, y, w, h, text='', is_password=False):
        self.rect = pygame.Rect(x, y, w, h); self.color = GRAY; self.text = str(text); self.is_password = is_password
        self.txt_surface = font.render(self.text, True, BLACK); self.active = False; self.font = font 
    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos): self.active = not self.active
            else: self.active = False
            self.color = BLUE_UI if self.active else GRAY
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_RETURN: pass 
                elif event.key == pygame.K_BACKSPACE: self.text = self.text[:-1]
                elif event.key == pygame.K_TAB: pass
                else: self.text += event.unicode
                self.update()
    def update(self):
        txt_show = "*" * len(self.text) if self.is_password else self.text
        self.txt_surface = self.font.render(txt_show, True, BLACK)
        width = max(200, self.txt_surface.get_width() + 10); self.rect.w = width
    def draw(self, screen_surface):
        pygame.draw.rect(screen_surface, self.color, self.rect, 2)
        pygame.draw.rect(screen_surface, WHITE, (self.rect.x+2, self.rect.y+2, self.rect.width-4, self.rect.height-4))
        screen_surface.blit(self.txt_surface, (self.rect.x + 5, self.rect.y + 5))
        
class InputBoxLocal:
    def __init__(self, x, y, w, h, is_password=False, text=''):
        self.rect = pygame.Rect(x, y, w, h); self.color = GRAY; self.text = text; self.is_password = is_password; self.txt_surface = font.render(text, True, BLACK); self.active = False; self.font = font
    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos): self.active = True; self.color = BLUE_UI
            else: self.active = False; self.color = GRAY
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_RETURN: pass
                elif event.key == pygame.K_BACKSPACE: self.text = self.text[:-1]
                elif event.key == pygame.K_TAB: pass
                else: self.text += event.unicode
                txt_show = "*" * len(self.text) if self.is_password else self.text
                self.txt_surface = self.font.render(txt_show, True, BLACK)
    def draw(self, screen_surface):
        pygame.draw.rect(screen_surface, self.color, self.rect, 2)
        pygame.draw.rect(screen_surface, WHITE, (self.rect.x+2, self.rect.y+2, self.rect.width-4, self.rect.height-4))
        screen_surface.blit(self.txt_surface, (self.rect.x + 5, self.rect.y + 5))

def ve_nut_hanh_tinh_trong_suot(screen, rect, image, is_selected, text_label):
    if is_selected: pygame.draw.rect(screen, C_HIGHLIGHT, rect, 3) 
    if image: img_rect = image.get_rect(center=rect.center); screen.blit(image, img_rect)
    else: pygame.draw.rect(screen, GRAY, (rect.centerx-30, rect.centery-30, 60, 60))
    text_color = C_VANG if is_selected else WHITE; shadow_surf = font_btn.render(text_label, True, BLACK); shadow_rect = shadow_surf.get_rect(center=(rect.centerx + 2, rect.bottom - 20 + 2)); screen.blit(shadow_surf, shadow_rect); label_surf = font_btn.render(text_label, True, text_color); label_rect = label_surf.get_rect(center=(rect.centerx, rect.bottom - 20)); screen.blit(label_surf, label_rect)

def draw_menu_interface(u_box, p_box, btn_l, btn_r, msg, msg_color, chk_remember):
    global FLAG_VN_IMAGE, GLOBAL_BG_IMAGE
    if GLOBAL_BG_IMAGE is not None: screen.blit(GLOBAL_BG_IMAGE, (0, 0))
    else: screen.fill(BLACK)
    title = font_big.render("NGOC RONG MIKEY", True, RED_TITLE); screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 80)); 
    lbl_u = font_small.render("TAI KHOAN", True, WHITE); lbl_p = font_small.render("MAT KHAU", True, WHITE); 
    s = pygame.Surface((220, 200)); s.set_alpha(150); s.fill(BLACK); screen.blit(s, (290, 190)); screen.blit(lbl_u, (u_box.rect.x - 80, u_box.rect.y + 10)); screen.blit(lbl_p, (p_box.rect.x - 80, p_box.rect.y + 10)); u_box.draw(screen); p_box.draw(screen); 
    chk_rem_text = "Nho tai khoan"; chk_rem_surf = font_small.render(chk_rem_text, True, WHITE); 
    pygame.draw.rect(screen, chk_remember.color, chk_remember.rect); pygame.draw.rect(screen, BLACK, chk_remember.rect, 2)
    if chk_remember.checked: pygame.draw.line(screen, BLACK, (chk_remember.rect.x + 4, chk_remember.rect.y + 10), (chk_remember.rect.x + 8, chk_remember.rect.y + 16), 3)
    if chk_remember.checked: pygame.draw.line(screen, BLACK, (chk_remember.rect.x + 8, chk_remember.rect.y + 16), (chk_remember.rect.x + 16, chk_remember.rect.y + 4), 3)
    screen.blit(chk_rem_surf, (chk_remember.rect.x + 30, chk_remember.rect.y)); 
    pygame.draw.rect(screen, BLUE_UI, btn_l); txt_l = font_small.render("DANG NHAP", True, WHITE); screen.blit(txt_l, txt_l.get_rect(center=btn_l.center))
    pygame.draw.rect(screen, GRAY, btn_r); txt_r = font_small.render("DANG KY", True, BLACK); screen.blit(txt_r, txt_r.get_rect(center=btn_r.center)); 
    msg_surface = font_small.render(msg, True, msg_color); screen.blit(msg_surface, (300, 440))
    FLAG_SIZE = 120; MARGIN = 20; flag_y = SCREEN_HEIGHT - 30 - 10 - FLAG_SIZE 
    if FLAG_VN_IMAGE: vn_x = MARGIN; screen.blit(FLAG_VN_IMAGE, (vn_x, flag_y))
    if FLAG_JP_IMAGE: jp_x = SCREEN_WIDTH - FLAG_SIZE - MARGIN; screen.blit(FLAG_JP_IMAGE, (jp_x, flag_y))
    lbl_warning = font_small.render("Canh bao choi qua 180 phut gay hai cho suc khoe", True, WHITE); screen.blit(lbl_warning, (SCREEN_WIDTH//2 - lbl_warning.get_width()//2, SCREEN_HEIGHT - 30)); lbl_coder = font_small.render("User: duong anh", True, C_VANG); screen.blit(lbl_coder, (10, 10))

def man_hinh_khoi_dong(screen):
    width_bar = 500
    height_bar = 20
    x_bar = (SCREEN_WIDTH - width_bar) // 2
    y_bar = SCREEN_HEIGHT - 100
    percent = 0
    loading_texts = [
        "DANG TAI TAI NGUYEN...",
        "KIEM TRA CAP NHAT...",
        "KET NOI MAY CHU...",
        "HOAN TAT!"
    ]

    if GLOBAL_BG_IMAGE is None:
        screen.fill(BLACK)
    else:
        screen.blit(GLOBAL_BG_IMAGE, (0, 0))

    while percent <= 100:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill(BLACK)
        title = font_big.render("NGOC RONG MIKEY", True, RED_TITLE)
        screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 50))

        ver = font_small.render("Dev: Duong Anh - Client v43.4", True, GRAY)
        screen.blit(ver, (SCREEN_WIDTH // 2 - ver.get_width() // 2, SCREEN_HEIGHT // 2 + 10))

        idx = int((percent / 100) * (len(loading_texts) - 1))
        txt = loading_texts[min(idx, len(loading_texts) - 1)]
        lbl = font_small.render(txt, True, WHITE)
        screen.blit(lbl, (SCREEN_WIDTH // 2 - lbl.get_width() // 2, y_bar - 30))

        pygame.draw.rect(screen, WHITE, (x_bar, y_bar, width_bar, height_bar), 2)
        fill_w = int((percent / 100) * (width_bar - 6))
        pygame.draw.rect(screen, ORANGE_LOADING, (x_bar + 3, y_bar + 3, fill_w, height_bar - 6))

        pygame.display.flip()
        percent += random.randint(2, 5)
        clock.tick(60)

    time.sleep(0.3)


def hieu_ung_chuyen_canh(screen):
    width_bar = 400
    height_bar = 20
    x_bar = (SCREEN_WIDTH - width_bar) // 2
    y_bar = SCREEN_HEIGHT // 2 + 50
    percent = 0
    text_list = [
        "DANG KET NOI VU TRU...",
        "TAI DU LIEU BAN DO...",
        "DONG BO NHAN VAT...",
        "HOAN TAT!"
    ]

    while percent <= 100:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill(BLACK)
        title = font_big.render("DANG VAO GAME...", True, GREEN_SUCCESS)
        screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 50))

        if percent < 30:
            current_text = text_list[0]
        elif percent < 60:
            current_text = text_list[1]
        elif percent < 90:
            current_text = text_list[2]
        else:
            current_text = text_list[3]

        txt_surf = font_small.render(current_text, True, WHITE)
        screen.blit(txt_surf, (SCREEN_WIDTH // 2 - txt_surf.get_width() // 2, y_bar - 30))

        pygame.draw.rect(screen, WHITE, (x_bar, y_bar, width_bar, height_bar), 2)
        fill_width = int((percent / 100) * (width_bar - 4))
        pygame.draw.rect(screen, BLUE_UI, (x_bar + 2, y_bar + 2, fill_width, height_bar - 4))

        pygame.display.flip()
        percent += random.randint(3, 6)
        clock.tick(60)

    time.sleep(0.2)


def hieu_ung_load_logout(screen):
    width_bar = 400
    height_bar = 20
    x_bar = (SCREEN_WIDTH - width_bar) // 2
    y_bar = SCREEN_HEIGHT // 2 + 50
    percent = 0
    text_list = [
        "DANG LUU DU LIEU...",
        "DONG KET NOI...",
        "CHUYEN VE MENU...",
        "HOAN TAT!"
    ]

    while percent <= 100:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill(BLACK)
        title = font_big.render("DANG DANG XUAT...", True, RED_ERROR)
        screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 50))

        if percent < 30:
            current_text = text_list[0]
        elif percent < 60:
            current_text = text_list[1]
        elif percent < 90:
            current_text = text_list[2]
        else:
            current_text = text_list[3]

        txt_surf = font_small.render(current_text, True, WHITE)
        screen.blit(txt_surf, (SCREEN_WIDTH // 2 - txt_surf.get_width() // 2, y_bar - 30))

        pygame.draw.rect(screen, WHITE, (x_bar, y_bar, width_bar, height_bar), 2)
        fill_width = int((percent / 100) * (width_bar - 4))
        pygame.draw.rect(screen, RED_ERROR, (x_bar + 2, y_bar + 2, fill_width, height_bar - 4))

        pygame.display.flip()
        percent += random.randint(3, 6)
        clock.tick(60)

    time.sleep(0.2)

    
def ve_thanh_trang_thai(surface, ten, hanh_tinh, hp, max_hp, ki, max_ki,
                      vang_amount, kim_cuong_amount, vnd_amount, suc_manh_amount, is_vip, current_time):
    # Panel trạng thái (HUD)
    s = pygame.Surface((250, 190), pygame.SRCALPHA)

    # nền trên
    pygame.draw.rect(s, (0, 0, 0, 180), (0, 0, 250, 90), border_radius=5)
    pygame.draw.rect(s, WHITE, (0, 0, 250, 90), 2, border_radius=5)

    # avatar nhỏ
    avt_rect = pygame.Rect(10, 15, 60, 60)
    pygame.draw.rect(s, DARK_GRAY, avt_rect)
    pygame.draw.rect(s, WHITE, avt_rect, 1)

    cx, cy = 40, 45
    if hanh_tinh == "Trai Dat":
        pygame.draw.circle(s, MAU_DA, (cx, cy), 18)
        # tóc spike
        pts = [(cx, cy-10), (cx+8, cy-18), (cx+16, cy-10), (cx+12, cy),
               (cx, cy+3), (cx-12, cy), (cx-16, cy-10), (cx-8, cy-18)]
        pygame.draw.polygon(s, TOC_DEN, pts)
    elif hanh_tinh == "Namec":
        pygame.draw.circle(s, XANH_NAMEC, (cx, cy), 18)
        pygame.draw.rect(s, WHITE, (cx-14, cy-20, 28, 10), border_radius=5)
        pygame.draw.line(s, XANH_NAMEC, (cx-5, cy+4), (cx-9, cy-7), 2)
        pygame.draw.line(s, XANH_NAMEC, (cx+5, cy+4), (cx+9, cy-7), 2)
    elif hanh_tinh == "Xayda":
        pygame.draw.circle(s, MAU_DA, (cx, cy), 18)
        pts = [(cx, cy-4), (cx+6, cy-20), (cx+12, cy-28), (cx+18, cy-12),
               (cx+12, cy+2), (cx, cy+4), (cx-12, cy+2), (cx-18, cy-12),
               (cx-12, cy-28), (cx-6, cy-20)]
        pygame.draw.polygon(s, TOC_DEN, pts)

    ten_hien_thi = ten[:10] + "..." if len(ten) > 10 else ten
    lbl_ten = font_small.render(f"{ten_hien_thi} [{hanh_tinh}]", True, C_VANG)
    s.blit(lbl_ten, (80, 5))

    # HP/KI bars
    bar_w = 150
    bar_h = 15

    pygame.draw.rect(s, C_BG_BAR, (80, 30, bar_w, bar_h))
    ratio_hp = hp / max_hp if max_hp > 0 else 0
    pygame.draw.rect(s, C_HP_RED, (80, 30, int(bar_w * ratio_hp), bar_h))
    pygame.draw.rect(s, WHITE, (80, 30, bar_w, bar_h), 1)
    lbl_hp = font_mini.render(f"HP: {hp}/{max_hp}", True, WHITE)
    s.blit(lbl_hp, (85, 30))

    pygame.draw.rect(s, (0, 0, 50), (80, 55, bar_w, bar_h))
    ratio_ki = ki / max_ki if max_ki > 0 else 0
    pygame.draw.rect(s, C_KI_BLUE, (80, 55, int(bar_w * ratio_ki), bar_h))
    pygame.draw.rect(s, WHITE, (80, 55, bar_w, bar_h), 1)
    lbl_ki = font_mini.render(f"KI: {ki}/{max_ki}", True, WHITE)
    s.blit(lbl_ki, (85, 55))

    # nền dưới
    START_Y_CURRENCY = 90
    MARGIN_CURRENCY = 10
    ICON_SIZE = 16

    pygame.draw.rect(s, (0, 0, 0, 180), (0, START_Y_CURRENCY, 250, 95),
                     border_bottom_left_radius=5, border_bottom_right_radius=5)
    pygame.draw.line(s, WHITE, (0, START_Y_CURRENCY), (250, START_Y_CURRENCY), 1)

    VIP_X_OFFSET = 180

    text_vang = font_mini.render(f"{vang_amount:,}", True, C_VANG)
    vang.draw_currency_icon(s, MARGIN_CURRENCY + 8, START_Y_CURRENCY + 18, "VANG")
    s.blit(text_vang, (MARGIN_CURRENCY + ICON_SIZE + 5, START_Y_CURRENCY + 10))
    vang.draw_vip_symbol(s, VIP_X_OFFSET, START_Y_CURRENCY + 11, current_time, is_vip)

    C_DIAMOND = (0, 200, 255)
    text_kc = font_mini.render(f"{kim_cuong_amount:,}", True, C_DIAMOND)
    vang.draw_currency_icon(s, MARGIN_CURRENCY + 8, START_Y_CURRENCY + 38, "KIM_CUONG")
    s.blit(text_kc, (MARGIN_CURRENCY + ICON_SIZE + 5, START_Y_CURRENCY + 30))
    vang.draw_vip_symbol(s, VIP_X_OFFSET, START_Y_CURRENCY + 31, current_time, is_vip)

    C_VND = (0, 150, 0)
    text_vnd = font_mini.render(f"{vnd_amount:,}", True, C_VND)
    vang.draw_currency_icon(s, MARGIN_CURRENCY + 8, START_Y_CURRENCY + 58, "VND")
    s.blit(text_vnd, (MARGIN_CURRENCY + ICON_SIZE + 5, START_Y_CURRENCY + 50))
    vang.draw_vip_symbol(s, VIP_X_OFFSET, START_Y_CURRENCY + 51, current_time, is_vip)

    lbl_sm = font_mini.render("SM:", True, RED_TITLE)
    text_sm = font_mini.render(f"{suc_manh_amount:,}", True, WHITE)
    SM_Y_POS = START_Y_CURRENCY + 72
    s.blit(lbl_sm, (MARGIN_CURRENCY + 10, SM_Y_POS))
    s.blit(text_sm, (MARGIN_CURRENCY + 35, SM_Y_POS))

    surface.blit(s, (10, 10))


def draw_sidebar_menu(surface, current_x, ten_nv, hanh_tinh, hp, max_hp, ki, max_ki, current_stats, info=None):
    menu_rect = pygame.Rect(current_x, 0, MENU_WIDTH, SCREEN_HEIGHT)
    s = pygame.Surface((MENU_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA); s.fill((40, 40, 40, 240)); pygame.draw.rect(s, C_VANG, (0, 0, MENU_WIDTH, SCREEN_HEIGHT), 3)
    lbl_title = font.render("TRANG THAI CHI TIET", True, C_VANG); s.blit(lbl_title, (15, 5))
    avt_y = 50; avt_rect = pygame.Rect(10, avt_y, 80, 80); cx_avt, cy_avt = 50, avt_y + 40 
    pygame.draw.rect(s, DARK_GRAY, avt_rect); 
    if hanh_tinh == "Trai Dat": pygame.draw.circle(s, MAU_DA, (cx_avt, cy_avt), 18); pts = [(cx_avt, cy_avt-12), (cx_avt+5, cy_avt-18), (cx_avt+12, cy_avt-15), (cx_avt+18, cy_avt-5), (cx_avt+15, cy_avt+5), (cx_avt-15, cy_avt+5), (cx_avt-18, cy_avt-5), (cx_avt-12, cy_avt-15), (cx_avt-5, cy_avt-18)]; pygame.draw.polygon(s, TOC_DEN, pts)
    elif hanh_tinh == "Namec": pygame.draw.circle(s, XANH_NAMEC, (cx_avt, cy_avt), 18); pygame.draw.rect(s, WHITE, (cx_avt-14, cy_avt-20, 28, 10), border_radius=5); pygame.draw.polygon(s, XANH_NAMEC, [(cx_avt-18, cy_avt-5), (cx_avt-22, cy_avt-12), (cx_avt-15, cy_avt-15)]); pygame.draw.polygon(s, XANH_NAMEC, [(cx_avt+18, cy_avt-5), (cx_avt+22, cy_avt-12), (cx_avt+15, cy_avt-15)])
    elif hanh_tinh == "Xayda": pygame.draw.circle(s, MAU_DA, (cx_avt, cy_avt), 18); pts = [(cx_avt, cy_avt-5), (cx_avt+5, cy_avt-25), (cx_avt+12, cy_avt-35), (cx_avt+18, cy_avt-25), (cx_avt+15, cy_avt), (cx_avt-15, cy_avt), (cx_avt-18, cy_avt-25), (cx_avt-12, cy_avt-35), (cx_avt-5, cy_avt-25)]; pygame.draw.polygon(s, TOC_DEN, pts)
    lbl_name = font_small.render(f"Ten: {ten_nv}", True, WHITE); lbl_hp = font_small.render(f"HP: {max_hp}", True, C_HP_RED); lbl_ki = font_small.render(f"KI: {max_ki}", True, C_KI_BLUE)
    sm_val = current_stats.get("suc_manh", 0); lbl_sm = font_small.render(f"Suc Manh: {sm_val:,}", True, C_VANG); s.blit(lbl_sm, (100, avt_y + 65)); s.blit(lbl_name, (100, avt_y + 5)); s.blit(lbl_hp, (100, avt_y + 25)); s.blit(lbl_ki, (100, avt_y + 45))
    y_stats = 150; stat_labels = {"suc_danh": "Sat Thuong", "giap": "Giap", "ne_tranh": "Ne Tranh", "nhanh_nhen": "Nhanh Nhen", "chi_mang": "Chi Mang"}
    for key, label in stat_labels.items():
        value = current_stats.get(key, 0); lbl_stat = font_small.render(f"{label}:", True, C_VANG); lbl_value = font_small.render(str(value), True, WHITE); s.blit(lbl_stat, (15, y_stats)); s.blit(lbl_value, (MENU_WIDTH - 60, y_stats)); y_stats += 25
    y_quest = y_stats + 20; pygame.draw.line(s, GRAY, (10, y_quest), (MENU_WIDTH - 10, y_quest), 2); y_quest += 15
    lbl_quest_title = font.render("NHIEM VU", True, RED_TITLE); s.blit(lbl_quest_title, (MENU_WIDTH // 2 - lbl_quest_title.get_width() // 2, y_quest)); y_quest += 30
    quest_rect = pygame.Rect(10, y_quest, MENU_WIDTH - 20, 100); pygame.draw.rect(s, (0, 0, 0, 150), quest_rect, border_radius=5); pygame.draw.rect(s, C_VANG, quest_rect, 1, border_radius=5)
    
    # --- GỌI FILE NHIEMVU.PY ĐỂ VẼ ---
    if info:
        nhiemvu.draw_sidebar_quest(s, 20, y_quest + 10, info, font_small, hanh_tinh)
    
    surface.blit(s, (current_x, 0))
    btn_toggle_rect = pygame.Rect(current_x + MENU_WIDTH, SCREEN_HEIGHT // 2 - 40, 30, 80)
    pygame.draw.rect(surface, (0, 0, 0, 180), btn_toggle_rect, border_top_right_radius=10, border_bottom_right_radius=10)
    pygame.draw.rect(surface, C_VANG, btn_toggle_rect, 2, border_top_right_radius=10, border_bottom_right_radius=10)
    center_y = btn_toggle_rect.centery; center_x = btn_toggle_rect.centerx
    if current_x < 0: pts = [(center_x - 5, center_y - 10), (center_x - 5, center_y + 10), (center_x + 5, center_y)]
    else: pts = [(center_x + 5, center_y - 10), (center_x + 5, center_y + 10), (center_x - 5, center_y)]
    pygame.draw.polygon(surface, WHITE, pts); 
    return btn_toggle_rect, None


def ve_bong(surface, x, y):
    # Bóng mềm hơn (đậm ở giữa)
    shadow = pygame.Surface((40, 16), pygame.SRCALPHA)
    pygame.draw.ellipse(shadow, (0, 0, 0, 70), (0, 4, 40, 10))
    pygame.draw.ellipse(shadow, (0, 0, 0, 45), (6, 6, 28, 7))
    surface.blit(shadow, (x - 5, y + 44))


def ve_goku(surface, x, y, huong_phai, frame_index):
    # Goku (Trái Đất) - vẽ đẹp hơn + animation chạy (tay/chân)
    # frame_index: 0 idle, >0 chạy theo nhịp
    fd = 1 if huong_phai else -1
    f = int(frame_index) % 4
    # nhịp chạy
    step = [0, 2, 0, -2][f]
    bob = [0, 1, 0, 1][f]
    arm = [3, 1, -1, 1][f]
    leg = [-1, 1, 3, 1][f]

    y0 = y + bob
    cx = x + 15
    ve_bong(surface, x, y0)

    # --- chân ---
    # quần cam + giày xanh (có dây đỏ)
    # chân trái
    pygame.draw.rect(surface, AO_CAM, (cx - 10, y0 + 34 - leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_XANH, (cx - 11, y0 + 44 - leg, 11, 7), border_radius=3)
    pygame.draw.rect(surface, DAY_GIAY_DO, (cx - 10, y0 + 46 - leg, 8, 2), border_radius=2)
    # chân phải
    pygame.draw.rect(surface, AO_CAM, (cx + 1, y0 + 34 + leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_XANH, (cx, y0 + 44 + leg, 11, 7), border_radius=3)
    pygame.draw.rect(surface, DAY_GIAY_DO, (cx + 1, y0 + 46 + leg, 8, 2), border_radius=2)

    # --- thân ---
    # áo trong xanh đậm + áo cam + đai xanh
    pygame.draw.rect(surface, (20, 20, 25), (cx - 10, y0 + 20, 20, 14), border_radius=4)
    pygame.draw.rect(surface, AO_CAM, (cx - 12, y0 + 20, 24, 18), border_radius=5)
    pygame.draw.rect(surface, DAI_XANH, (cx - 12, y0 + 33, 24, 6), border_radius=4)

    # nếp áo/đổ bóng nhẹ
    pygame.draw.line(surface, (220, 60, 0), (cx - 6, y0 + 22), (cx - 6, y0 + 36), 2)
    pygame.draw.line(surface, (255, 120, 40), (cx + 5, y0 + 22), (cx + 5, y0 + 36), 2)

    # --- tay (swing) ---
    ax = cx - 13 * fd
    # tay trước
    pygame.draw.rect(surface, AO_CAM, (cx - 18 * fd, y0 + 22 + arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, MAU_DA, (cx - 15 * fd, y0 + 33 + arm), 4)
    # tay sau
    pygame.draw.rect(surface, AO_CAM, (cx + 12 * fd, y0 + 24 - arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, MAU_DA, (cx + 15 * fd, y0 + 35 - arm), 4)

    # --- đầu ---
    pygame.draw.circle(surface, MAU_DA, (cx, y0 + 12), 10)
    # mắt
    eye_x = cx + 4 * fd
    pygame.draw.ellipse(surface, WHITE, (eye_x - 3, y0 + 10, 6, 4))
    pygame.draw.circle(surface, BLACK, (eye_x, y0 + 12), 2)
    # mày
    pygame.draw.line(surface, BLACK, (eye_x - 4, y0 + 9), (eye_x + 2, y0 + 8), 2)
    # miệng
    pygame.draw.line(surface, BLACK, (cx - 2 * fd, y0 + 17), (cx + 3 * fd, y0 + 17), 1)

    # --- tóc (spike đẹp hơn) ---
    pts = [
        (cx, y0 - 3),
        (cx + 4*fd, y0 - 12),
        (cx + 12*fd, y0 - 18),
        (cx + 20*fd, y0 - 10),
        (cx + 24*fd, y0 - 2),
        (cx + 20*fd, y0 + 5),
        (cx + 10*fd, y0 + 2),
        (cx, y0 + 2),
        (cx - 10*fd, y0 + 2),
        (cx - 20*fd, y0 + 5),
        (cx - 24*fd, y0 - 2),
        (cx - 20*fd, y0 - 10),
        (cx - 12*fd, y0 - 18),
        (cx - 4*fd, y0 - 12),
    ]
    # nếu quay trái thì đảo theo fd đã tính
    if not huong_phai:
        pts = [(cx - (px - cx), py) for px, py in pts]
    pygame.draw.polygon(surface, TOC_DEN, pts)


def ve_piccolo(surface, x, y, huong_phai, frame_index):
    # Piccolo (Namec) - vẽ đẹp hơn + animation chạy
    fd = 1 if huong_phai else -1
    f = int(frame_index) % 4
    bob = [0, 1, 0, 1][f]
    arm = [3, 1, -1, 1][f]
    leg = [-1, 1, 3, 1][f]

    y0 = y + bob
    cx = x + 15
    ve_bong(surface, x, y0)

    # --- chân (quần tím) ---
    pygame.draw.rect(surface, TIM_NAMEC, (cx - 10, y0 + 34 - leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_NAU, (cx - 11, y0 + 44 - leg, 11, 7), border_radius=3)
    pygame.draw.rect(surface, TIM_NAMEC, (cx + 1, y0 + 34 + leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_NAU, (cx, y0 + 44 + leg, 11, 7), border_radius=3)

    # --- thân (áo tím + đai xanh) ---
    pygame.draw.rect(surface, TIM_NAMEC, (cx - 12, y0 + 20, 24, 19), border_radius=6)
    pygame.draw.rect(surface, DAI_NAMEC, (cx - 12, y0 + 33, 24, 7), border_radius=4)
    # áo choàng trắng (2 vạt)
    pygame.draw.polygon(surface, WHITE, [(cx - 12, y0 + 20), (cx - 22, y0 + 48), (cx - 6, y0 + 48)])
    pygame.draw.polygon(surface, WHITE, [(cx + 12, y0 + 20), (cx + 22, y0 + 48), (cx + 6, y0 + 48)])

    # --- tay (xanh) ---
    pygame.draw.rect(surface, XANH_NAMEC, (cx - 18 * fd, y0 + 22 + arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, XANH_NAMEC, (cx - 15 * fd, y0 + 33 + arm), 4)
    pygame.draw.rect(surface, XANH_NAMEC, (cx + 12 * fd, y0 + 24 - arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, XANH_NAMEC, (cx + 15 * fd, y0 + 35 - arm), 4)

    # --- đầu ---
    pygame.draw.circle(surface, XANH_NAMEC, (cx, y0 + 12), 10)
    # mũ/khăn trắng
    pygame.draw.rect(surface, WHITE, (cx - 10, y0 - 1, 20, 10), border_radius=6)
    # mắt
    eye_x = cx + 4 * fd
    pygame.draw.ellipse(surface, WHITE, (eye_x - 3, y0 + 10, 6, 4))
    pygame.draw.circle(surface, BLACK, (eye_x, y0 + 12), 2)
    # anten
    pygame.draw.line(surface, XANH_NAMEC, (cx - 4, y0 + 7), (cx - 8, y0 - 4), 2)
    pygame.draw.line(surface, XANH_NAMEC, (cx + 4, y0 + 7), (cx + 8, y0 - 4), 2)
    # tai nhọn
    pygame.draw.polygon(surface, XANH_NAMEC, [(cx - 10, y0 + 14), (cx - 15, y0 + 10), (cx - 10, y0 + 7)])
    pygame.draw.polygon(surface, XANH_NAMEC, [(cx + 10, y0 + 14), (cx + 15, y0 + 10), (cx + 10, y0 + 7)])


def ve_vegeta(surface, x, y, huong_phai, frame_index):
    # Vegeta (Xayda) - vẽ đẹp hơn + animation chạy
    fd = 1 if huong_phai else -1
    f = int(frame_index) % 4
    bob = [0, 1, 0, 1][f]
    arm = [3, 1, -1, 1][f]
    leg = [-1, 1, 3, 1][f]

    y0 = y + bob
    cx = x + 15
    ve_bong(surface, x, y0)

    # --- chân ---
    pygame.draw.rect(surface, AO_BO_XANH, (cx - 10, y0 + 34 - leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_TRANG, (cx - 11, y0 + 44 - leg, 11, 7), border_radius=3)
    pygame.draw.rect(surface, AO_BO_XANH, (cx + 1, y0 + 34 + leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_TRANG, (cx, y0 + 44 + leg, 11, 7), border_radius=3)

    # --- thân giáp ---
    pygame.draw.rect(surface, AO_BO_XANH, (cx - 12, y0 + 20, 24, 19), border_radius=6)
    pygame.draw.rect(surface, GIAP_TRANG, (cx - 13, y0 + 20, 26, 14), border_radius=5)
    pygame.draw.rect(surface, GIAP_VANG, (cx - 10, y0 + 21, 20, 12), 2, border_radius=4)
    pygame.draw.rect(surface, GIAP_TRANG, (cx - 11, y0 + 34, 22, 6), border_radius=4)
    # đuôi
    pygame.draw.ellipse(surface, MAU_DUOI, (cx - 13, y0 + 28, 26, 9))

    # --- tay ---
    pygame.draw.rect(surface, AO_BO_XANH, (cx - 18 * fd, y0 + 22 + arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, MAU_DA, (cx - 15 * fd, y0 + 33 + arm), 4)
    pygame.draw.rect(surface, AO_BO_XANH, (cx + 12 * fd, y0 + 24 - arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, MAU_DA, (cx + 15 * fd, y0 + 35 - arm), 4)

    # --- đầu ---
    pygame.draw.circle(surface, MAU_DA, (cx, y0 + 12), 10)
    # mắt
    eye_x = cx + 4 * fd
    pygame.draw.ellipse(surface, WHITE, (eye_x - 3, y0 + 10, 6, 4))
    pygame.draw.circle(surface, BLACK, (eye_x, y0 + 12), 2)
    # lông mày sắc
    pygame.draw.line(surface, BLACK, (eye_x - 4, y0 + 9), (eye_x + 3, y0 + 7), 2)
    # miệng
    pygame.draw.line(surface, BLACK, (cx - 2 * fd, y0 + 17), (cx + 3 * fd, y0 + 17), 1)
    # giọt đỏ (scouter glow nhỏ)
    glow = pygame.Surface((10, 8), pygame.SRCALPHA)
    glow.fill((255, 0, 0, 140))
    surface.blit(glow, (cx + (3 if huong_phai else -13), y0 + 9))

    # --- tóc (dáng Vegeta dựng đứng) ---
    pts = [
        (cx, y0 + 2),
        (cx + 4*fd, y0 - 16),
        (cx + 10*fd, y0 - 28),
        (cx + 16*fd, y0 - 18),
        (cx + 20*fd, y0 - 6),
        (cx + 12*fd, y0 + 2),
        (cx, y0 + 2),
        (cx - 12*fd, y0 + 2),
        (cx - 20*fd, y0 - 6),
        (cx - 16*fd, y0 - 18),
        (cx - 10*fd, y0 - 28),
        (cx - 4*fd, y0 - 16),
    ]
    if not huong_phai:
        pts = [(cx - (px - cx), py) for px, py in pts]
    pygame.draw.polygon(surface, TOC_DEN, pts)
def ve_goku(surface, x, y, huong_phai, frame_index):
    # Goku (Trái Đất) - vẽ đẹp hơn + animation chạy (tay/chân)
    # frame_index: 0 idle, >0 chạy theo nhịp
    fd = 1 if huong_phai else -1
    f = int(frame_index) % 4
    # nhịp chạy
    step = [0, 2, 0, -2][f]
    bob = [0, 1, 0, 1][f]
    arm = [3, 1, -1, 1][f]
    leg = [-1, 1, 3, 1][f]

    y0 = y + bob
    cx = x + 15
    ve_bong(surface, x, y0)

    # --- chân ---
    # quần cam + giày xanh (có dây đỏ)
    # chân trái
    pygame.draw.rect(surface, AO_CAM, (cx - 10, y0 + 34 - leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_XANH, (cx - 11, y0 + 44 - leg, 11, 7), border_radius=3)
    pygame.draw.rect(surface, DAY_GIAY_DO, (cx - 10, y0 + 46 - leg, 8, 2), border_radius=2)
    # chân phải
    pygame.draw.rect(surface, AO_CAM, (cx + 1, y0 + 34 + leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_XANH, (cx, y0 + 44 + leg, 11, 7), border_radius=3)
    pygame.draw.rect(surface, DAY_GIAY_DO, (cx + 1, y0 + 46 + leg, 8, 2), border_radius=2)

    # --- thân ---
    # áo trong xanh đậm + áo cam + đai xanh
    pygame.draw.rect(surface, (20, 20, 25), (cx - 10, y0 + 20, 20, 14), border_radius=4)
    pygame.draw.rect(surface, AO_CAM, (cx - 12, y0 + 20, 24, 18), border_radius=5)
    pygame.draw.rect(surface, DAI_XANH, (cx - 12, y0 + 33, 24, 6), border_radius=4)

    # nếp áo/đổ bóng nhẹ
    pygame.draw.line(surface, (220, 60, 0), (cx - 6, y0 + 22), (cx - 6, y0 + 36), 2)
    pygame.draw.line(surface, (255, 120, 40), (cx + 5, y0 + 22), (cx + 5, y0 + 36), 2)

    # --- tay (swing) ---
    ax = cx - 13 * fd
    # tay trước
    pygame.draw.rect(surface, AO_CAM, (cx - 18 * fd, y0 + 22 + arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, MAU_DA, (cx - 15 * fd, y0 + 33 + arm), 4)
    # tay sau
    pygame.draw.rect(surface, AO_CAM, (cx + 12 * fd, y0 + 24 - arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, MAU_DA, (cx + 15 * fd, y0 + 35 - arm), 4)

    # --- đầu ---
    pygame.draw.circle(surface, MAU_DA, (cx, y0 + 12), 10)
    # mắt
    eye_x = cx + 4 * fd
    pygame.draw.ellipse(surface, WHITE, (eye_x - 3, y0 + 10, 6, 4))
    pygame.draw.circle(surface, BLACK, (eye_x, y0 + 12), 2)
    # mày
    pygame.draw.line(surface, BLACK, (eye_x - 4, y0 + 9), (eye_x + 2, y0 + 8), 2)
    # miệng
    pygame.draw.line(surface, BLACK, (cx - 2 * fd, y0 + 17), (cx + 3 * fd, y0 + 17), 1)

    # --- tóc (spike đẹp hơn) ---
    pts = [
        (cx, y0 - 3),
        (cx + 4*fd, y0 - 12),
        (cx + 12*fd, y0 - 18),
        (cx + 20*fd, y0 - 10),
        (cx + 24*fd, y0 - 2),
        (cx + 20*fd, y0 + 5),
        (cx + 10*fd, y0 + 2),
        (cx, y0 + 2),
        (cx - 10*fd, y0 + 2),
        (cx - 20*fd, y0 + 5),
        (cx - 24*fd, y0 - 2),
        (cx - 20*fd, y0 - 10),
        (cx - 12*fd, y0 - 18),
        (cx - 4*fd, y0 - 12),
    ]
    # nếu quay trái thì đảo theo fd đã tính
    if not huong_phai:
        pts = [(cx - (px - cx), py) for px, py in pts]
    pygame.draw.polygon(surface, TOC_DEN, pts)


def ve_piccolo(surface, x, y, huong_phai, frame_index):
    # Piccolo (Namec) - vẽ đẹp hơn + animation chạy
    fd = 1 if huong_phai else -1
    f = int(frame_index) % 4
    bob = [0, 1, 0, 1][f]
    arm = [3, 1, -1, 1][f]
    leg = [-1, 1, 3, 1][f]

    y0 = y + bob
    cx = x + 15
    ve_bong(surface, x, y0)

    # --- chân (quần tím) ---
    pygame.draw.rect(surface, TIM_NAMEC, (cx - 10, y0 + 34 - leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_NAU, (cx - 11, y0 + 44 - leg, 11, 7), border_radius=3)
    pygame.draw.rect(surface, TIM_NAMEC, (cx + 1, y0 + 34 + leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_NAU, (cx, y0 + 44 + leg, 11, 7), border_radius=3)

    # --- thân (áo tím + đai xanh) ---
    pygame.draw.rect(surface, TIM_NAMEC, (cx - 12, y0 + 20, 24, 19), border_radius=6)
    pygame.draw.rect(surface, DAI_NAMEC, (cx - 12, y0 + 33, 24, 7), border_radius=4)
    # áo choàng trắng (2 vạt)
    pygame.draw.polygon(surface, WHITE, [(cx - 12, y0 + 20), (cx - 22, y0 + 48), (cx - 6, y0 + 48)])
    pygame.draw.polygon(surface, WHITE, [(cx + 12, y0 + 20), (cx + 22, y0 + 48), (cx + 6, y0 + 48)])

    # --- tay (xanh) ---
    pygame.draw.rect(surface, XANH_NAMEC, (cx - 18 * fd, y0 + 22 + arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, XANH_NAMEC, (cx - 15 * fd, y0 + 33 + arm), 4)
    pygame.draw.rect(surface, XANH_NAMEC, (cx + 12 * fd, y0 + 24 - arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, XANH_NAMEC, (cx + 15 * fd, y0 + 35 - arm), 4)

    # --- đầu ---
    pygame.draw.circle(surface, XANH_NAMEC, (cx, y0 + 12), 10)
    # mũ/khăn trắng
    pygame.draw.rect(surface, WHITE, (cx - 10, y0 - 1, 20, 10), border_radius=6)
    # mắt
    eye_x = cx + 4 * fd
    pygame.draw.ellipse(surface, WHITE, (eye_x - 3, y0 + 10, 6, 4))
    pygame.draw.circle(surface, BLACK, (eye_x, y0 + 12), 2)
    # anten
    pygame.draw.line(surface, XANH_NAMEC, (cx - 4, y0 + 7), (cx - 8, y0 - 4), 2)
    pygame.draw.line(surface, XANH_NAMEC, (cx + 4, y0 + 7), (cx + 8, y0 - 4), 2)
    # tai nhọn
    pygame.draw.polygon(surface, XANH_NAMEC, [(cx - 10, y0 + 14), (cx - 15, y0 + 10), (cx - 10, y0 + 7)])
    pygame.draw.polygon(surface, XANH_NAMEC, [(cx + 10, y0 + 14), (cx + 15, y0 + 10), (cx + 10, y0 + 7)])


def ve_vegeta(surface, x, y, huong_phai, frame_index, ssj_level=0):
    # Vegeta (Xayda) - vẽ đẹp hơn + animation chạy
    fd = 1 if huong_phai else -1
    f = int(frame_index) % 4
    bob = [0, 1, 0, 1][f]
    arm = [3, 1, -1, 1][f]
    leg = [-1, 1, 3, 1][f]

    y0 = y + bob
    cx = x + 15
    ve_bong(surface, x, y0)

    # --- chân ---
    pygame.draw.rect(surface, AO_BO_XANH, (cx - 10, y0 + 34 - leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_TRANG, (cx - 11, y0 + 44 - leg, 11, 7), border_radius=3)
    pygame.draw.rect(surface, AO_BO_XANH, (cx + 1, y0 + 34 + leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_TRANG, (cx, y0 + 44 + leg, 11, 7), border_radius=3)

    # --- thân giáp ---
    pygame.draw.rect(surface, AO_BO_XANH, (cx - 12, y0 + 20, 24, 19), border_radius=6)
    pygame.draw.rect(surface, GIAP_TRANG, (cx - 13, y0 + 20, 26, 14), border_radius=5)
    pygame.draw.rect(surface, GIAP_VANG, (cx - 10, y0 + 21, 20, 12), 2, border_radius=4)
    pygame.draw.rect(surface, GIAP_TRANG, (cx - 11, y0 + 34, 22, 6), border_radius=4)
    # đuôi
    pygame.draw.ellipse(surface, MAU_DUOI, (cx - 13, y0 + 28, 26, 9))

    # --- tay ---
    pygame.draw.rect(surface, AO_BO_XANH, (cx - 18 * fd, y0 + 22 + arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, MAU_DA, (cx - 15 * fd, y0 + 33 + arm), 4)
    pygame.draw.rect(surface, AO_BO_XANH, (cx + 12 * fd, y0 + 24 - arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, MAU_DA, (cx + 15 * fd, y0 + 35 - arm), 4)

    # --- đầu ---
    pygame.draw.circle(surface, MAU_DA, (cx, y0 + 12), 10)
    # mắt
    eye_x = cx + 4 * fd
    pygame.draw.ellipse(surface, WHITE, (eye_x - 3, y0 + 10, 6, 4))
    pygame.draw.circle(surface, BLACK, (eye_x, y0 + 12), 2)
    # lông mày sắc
    pygame.draw.line(surface, BLACK, (eye_x - 4, y0 + 9), (eye_x + 3, y0 + 7), 2)
    # miệng
    pygame.draw.line(surface, BLACK, (cx - 2 * fd, y0 + 17), (cx + 3 * fd, y0 + 17), 1)
    # giọt đỏ (scouter glow nhỏ)
    glow = pygame.Surface((10, 8), pygame.SRCALPHA)
    glow.fill((255, 0, 0, 140))
    surface.blit(glow, (cx + (3 if huong_phai else -13), y0 + 9))

    # --- tóc (dáng Vegeta dựng đứng) ---
    pts = [
        (cx, y0 + 2),
        (cx + 4*fd, y0 - 16),
        (cx + 10*fd, y0 - 28),
        (cx + 16*fd, y0 - 18),
        (cx + 20*fd, y0 - 6),
        (cx + 12*fd, y0 + 2),
        (cx, y0 + 2),
        (cx - 12*fd, y0 + 2),
        (cx - 20*fd, y0 - 6),
        (cx - 16*fd, y0 - 18),
        (cx - 10*fd, y0 - 28),
        (cx - 4*fd, y0 - 16),
    ]
    if not huong_phai:
        pts = [(cx - (px - cx), py) for px, py in pts]
    hair_col = TOC_DEN
    if ssj_level and int(ssj_level) >= 1:
        hair_col = (255, 245, 120)  # vàng sáng SSJ
        # viền tối + highlight để tóc nổi hơn
        pygame.draw.polygon(surface, (40, 40, 40), pts, 2)
    pygame.draw.polygon(surface, hair_col, pts)
    if ssj_level and int(ssj_level) >= 1:
        try:
            pygame.draw.lines(surface, (255, 255, 220), False, pts[1:6], 2)
        except Exception:
            pass
def ve_goku(surface, x, y, huong_phai, frame_index):
    # Goku (Trái Đất) - vẽ đẹp hơn + animation chạy (tay/chân)
    # frame_index: 0 idle, >0 chạy theo nhịp
    fd = 1 if huong_phai else -1
    f = int(frame_index) % 4
    # nhịp chạy
    step = [0, 2, 0, -2][f]
    bob = [0, 1, 0, 1][f]
    arm = [3, 1, -1, 1][f]
    leg = [-1, 1, 3, 1][f]

    y0 = y + bob
    cx = x + 15
    ve_bong(surface, x, y0)

    # --- chân ---
    # quần cam + giày xanh (có dây đỏ)
    # chân trái
    pygame.draw.rect(surface, AO_CAM, (cx - 10, y0 + 34 - leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_XANH, (cx - 11, y0 + 44 - leg, 11, 7), border_radius=3)
    pygame.draw.rect(surface, DAY_GIAY_DO, (cx - 10, y0 + 46 - leg, 8, 2), border_radius=2)
    # chân phải
    pygame.draw.rect(surface, AO_CAM, (cx + 1, y0 + 34 + leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_XANH, (cx, y0 + 44 + leg, 11, 7), border_radius=3)
    pygame.draw.rect(surface, DAY_GIAY_DO, (cx + 1, y0 + 46 + leg, 8, 2), border_radius=2)

    # --- thân ---
    # áo trong xanh đậm + áo cam + đai xanh
    pygame.draw.rect(surface, (20, 20, 25), (cx - 10, y0 + 20, 20, 14), border_radius=4)
    pygame.draw.rect(surface, AO_CAM, (cx - 12, y0 + 20, 24, 18), border_radius=5)
    pygame.draw.rect(surface, DAI_XANH, (cx - 12, y0 + 33, 24, 6), border_radius=4)

    # nếp áo/đổ bóng nhẹ
    pygame.draw.line(surface, (220, 60, 0), (cx - 6, y0 + 22), (cx - 6, y0 + 36), 2)
    pygame.draw.line(surface, (255, 120, 40), (cx + 5, y0 + 22), (cx + 5, y0 + 36), 2)

    # --- tay (swing) ---
    ax = cx - 13 * fd
    # tay trước
    pygame.draw.rect(surface, AO_CAM, (cx - 18 * fd, y0 + 22 + arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, MAU_DA, (cx - 15 * fd, y0 + 33 + arm), 4)
    # tay sau
    pygame.draw.rect(surface, AO_CAM, (cx + 12 * fd, y0 + 24 - arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, MAU_DA, (cx + 15 * fd, y0 + 35 - arm), 4)

    # --- đầu ---
    pygame.draw.circle(surface, MAU_DA, (cx, y0 + 12), 10)
    # mắt
    eye_x = cx + 4 * fd
    pygame.draw.ellipse(surface, WHITE, (eye_x - 3, y0 + 10, 6, 4))
    pygame.draw.circle(surface, BLACK, (eye_x, y0 + 12), 2)
    # mày
    pygame.draw.line(surface, BLACK, (eye_x - 4, y0 + 9), (eye_x + 2, y0 + 8), 2)
    # miệng
    pygame.draw.line(surface, BLACK, (cx - 2 * fd, y0 + 17), (cx + 3 * fd, y0 + 17), 1)

    # --- tóc (spike đẹp hơn) ---
    pts = [
        (cx, y0 - 3),
        (cx + 4*fd, y0 - 12),
        (cx + 12*fd, y0 - 18),
        (cx + 20*fd, y0 - 10),
        (cx + 24*fd, y0 - 2),
        (cx + 20*fd, y0 + 5),
        (cx + 10*fd, y0 + 2),
        (cx, y0 + 2),
        (cx - 10*fd, y0 + 2),
        (cx - 20*fd, y0 + 5),
        (cx - 24*fd, y0 - 2),
        (cx - 20*fd, y0 - 10),
        (cx - 12*fd, y0 - 18),
        (cx - 4*fd, y0 - 12),
    ]
    # nếu quay trái thì đảo theo fd đã tính
    if not huong_phai:
        pts = [(cx - (px - cx), py) for px, py in pts]
    hair_col = (255, 210, 40) if int(ssj_level) > 0 else TOC_DEN
    pygame.draw.polygon(surface, hair_col, pts)


def ve_piccolo(surface, x, y, huong_phai, frame_index):
    # Piccolo (Namec) - vẽ đẹp hơn + animation chạy
    fd = 1 if huong_phai else -1
    f = int(frame_index) % 4
    bob = [0, 1, 0, 1][f]
    arm = [3, 1, -1, 1][f]
    leg = [-1, 1, 3, 1][f]

    y0 = y + bob
    cx = x + 15
    ve_bong(surface, x, y0)

    # --- chân (quần tím) ---
    pygame.draw.rect(surface, TIM_NAMEC, (cx - 10, y0 + 34 - leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_NAU, (cx - 11, y0 + 44 - leg, 11, 7), border_radius=3)
    pygame.draw.rect(surface, TIM_NAMEC, (cx + 1, y0 + 34 + leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_NAU, (cx, y0 + 44 + leg, 11, 7), border_radius=3)

    # --- thân (áo tím + đai xanh) ---
    pygame.draw.rect(surface, TIM_NAMEC, (cx - 12, y0 + 20, 24, 19), border_radius=6)
    pygame.draw.rect(surface, DAI_NAMEC, (cx - 12, y0 + 33, 24, 7), border_radius=4)
    # áo choàng trắng (2 vạt)
    pygame.draw.polygon(surface, WHITE, [(cx - 12, y0 + 20), (cx - 22, y0 + 48), (cx - 6, y0 + 48)])
    pygame.draw.polygon(surface, WHITE, [(cx + 12, y0 + 20), (cx + 22, y0 + 48), (cx + 6, y0 + 48)])

    # --- tay (xanh) ---
    pygame.draw.rect(surface, XANH_NAMEC, (cx - 18 * fd, y0 + 22 + arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, XANH_NAMEC, (cx - 15 * fd, y0 + 33 + arm), 4)
    pygame.draw.rect(surface, XANH_NAMEC, (cx + 12 * fd, y0 + 24 - arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, XANH_NAMEC, (cx + 15 * fd, y0 + 35 - arm), 4)

    # --- đầu ---
    pygame.draw.circle(surface, XANH_NAMEC, (cx, y0 + 12), 10)
    # mũ/khăn trắng
    pygame.draw.rect(surface, WHITE, (cx - 10, y0 - 1, 20, 10), border_radius=6)
    # mắt
    eye_x = cx + 4 * fd
    pygame.draw.ellipse(surface, WHITE, (eye_x - 3, y0 + 10, 6, 4))
    pygame.draw.circle(surface, BLACK, (eye_x, y0 + 12), 2)
    # anten
    pygame.draw.line(surface, XANH_NAMEC, (cx - 4, y0 + 7), (cx - 8, y0 - 4), 2)
    pygame.draw.line(surface, XANH_NAMEC, (cx + 4, y0 + 7), (cx + 8, y0 - 4), 2)
    # tai nhọn
    pygame.draw.polygon(surface, XANH_NAMEC, [(cx - 10, y0 + 14), (cx - 15, y0 + 10), (cx - 10, y0 + 7)])
    pygame.draw.polygon(surface, XANH_NAMEC, [(cx + 10, y0 + 14), (cx + 15, y0 + 10), (cx + 10, y0 + 7)])


def ve_vegeta(surface, x, y, huong_phai, frame_index, ssj_level=0):
    # Vegeta (Xayda) - vẽ đẹp hơn + animation chạy
    fd = 1 if huong_phai else -1
    f = int(frame_index) % 4
    bob = [0, 1, 0, 1][f]
    arm = [3, 1, -1, 1][f]
    leg = [-1, 1, 3, 1][f]

    y0 = y + bob
    cx = x + 15
    ve_bong(surface, x, y0)

    # --- chân ---
    pygame.draw.rect(surface, AO_BO_XANH, (cx - 10, y0 + 34 - leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_TRANG, (cx - 11, y0 + 44 - leg, 11, 7), border_radius=3)
    pygame.draw.rect(surface, AO_BO_XANH, (cx + 1, y0 + 34 + leg, 9, 12), border_radius=3)
    pygame.draw.rect(surface, GIAY_TRANG, (cx, y0 + 44 + leg, 11, 7), border_radius=3)

    # --- thân giáp ---
    pygame.draw.rect(surface, AO_BO_XANH, (cx - 12, y0 + 20, 24, 19), border_radius=6)
    pygame.draw.rect(surface, GIAP_TRANG, (cx - 13, y0 + 20, 26, 14), border_radius=5)
    pygame.draw.rect(surface, GIAP_VANG, (cx - 10, y0 + 21, 20, 12), 2, border_radius=4)
    pygame.draw.rect(surface, GIAP_TRANG, (cx - 11, y0 + 34, 22, 6), border_radius=4)
    # đuôi
    pygame.draw.ellipse(surface, MAU_DUOI, (cx - 13, y0 + 28, 26, 9))

    # --- tay ---
    pygame.draw.rect(surface, AO_BO_XANH, (cx - 18 * fd, y0 + 22 + arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, MAU_DA, (cx - 15 * fd, y0 + 33 + arm), 4)
    pygame.draw.rect(surface, AO_BO_XANH, (cx + 12 * fd, y0 + 24 - arm, 6, 10), border_radius=3)
    pygame.draw.circle(surface, MAU_DA, (cx + 15 * fd, y0 + 35 - arm), 4)

    # --- đầu ---
    pygame.draw.circle(surface, MAU_DA, (cx, y0 + 12), 10)
    # mắt
    eye_x = cx + 4 * fd
    pygame.draw.ellipse(surface, WHITE, (eye_x - 3, y0 + 10, 6, 4))
    pygame.draw.circle(surface, BLACK, (eye_x, y0 + 12), 2)
    # lông mày sắc
    pygame.draw.line(surface, BLACK, (eye_x - 4, y0 + 9), (eye_x + 3, y0 + 7), 2)
    # miệng
    pygame.draw.line(surface, BLACK, (cx - 2 * fd, y0 + 17), (cx + 3 * fd, y0 + 17), 1)
    # giọt đỏ (scouter glow nhỏ)
    glow = pygame.Surface((10, 8), pygame.SRCALPHA)
    glow.fill((255, 0, 0, 140))
    surface.blit(glow, (cx + (3 if huong_phai else -13), y0 + 9))

    # --- tóc (dáng Vegeta dựng đứng) ---
    pts = [
        (cx, y0 + 2),
        (cx + 4*fd, y0 - 16),
        (cx + 10*fd, y0 - 28),
        (cx + 16*fd, y0 - 18),
        (cx + 20*fd, y0 - 6),
        (cx + 12*fd, y0 + 2),
        (cx, y0 + 2),
        (cx - 12*fd, y0 + 2),
        (cx - 20*fd, y0 - 6),
        (cx - 16*fd, y0 - 18),
        (cx - 10*fd, y0 - 28),
        (cx - 4*fd, y0 - 16),
    ]
    if not huong_phai:
        pts = [(cx - (px - cx), py) for px, py in pts]
    hair_col = (255, 210, 40) if int(ssj_level) > 0 else TOC_DEN
    pygame.draw.polygon(surface, hair_col, pts)
def game_loop(username_acc, ten_nv, hanh_tinh, map_id="Map_1_Lang_Hanh_Tinh", is_new_player=False):
    global GLOBAL_USERNAME, boss_death_time 
    GLOBAL_USERNAME = username_acc

    # [QUAN TRỌNG] Đăng ký Item VIP vào danh sách game ngay khi vào trận
    try:
        itemvip.register_into(ITEM_TEMPLATES)
    except:
        pass

    # [NEW] NPC Olong (thông báo boss)
    try:
        import npcolong
    except Exception:
        npcolong = None


    # [NEW] Đệ tử cơ bản (rơi khi hạ Super Broly)
    try:
        import detucoban
        try:
           
            detucoban.bind_owner(username_acc, ten_nv)
        except Exception:
            pass
    except Exception:
        detucoban = None


    # [NEW] Lưỡng long nhất thể (hợp thể)
    try:
        import luonglongnhatthe
    except Exception:
        luonglongnhatthe = None
    # --- [CẤU HÌNH FONT] ---
    try:
        font_timer = pygame.font.SysFont("Arial", 40, bold=True)
        font_huge = pygame.font.SysFont("Arial", 100, bold=True) 
    except:
        font_timer = pygame.font.Font(None, 40)
        font_huge = pygame.font.Font(None, 100)
    
    # --- [1. KHỞI TẠO MAP] ---
    hanh_tinh_key = ""
    npc_quest_name, _, _ = nhiemvu.get_npc_name_by_planet(hanh_tinh) 

    if hanh_tinh == "Trai Dat": 
        hanh_tinh_key = "TD"; planet_key_map = "traidat"
    elif hanh_tinh == "Namec": 
        hanh_tinh_key = "NM"; planet_key_map = "namec"
    elif hanh_tinh == "Xayda": 
        hanh_tinh_key = "XD"; planet_key_map = "xayda"
    else: 
        hanh_tinh_key = "TD"; planet_key_map = "traidat"
    
    MAP_2_KEY = f"Map_2_Khu_Vuc_{hanh_tinh_key}"
    is_map_1 = (map_id == "Map_1_Lang_Hanh_Tinh")
    is_map_2 = (map_id == MAP_2_KEY)
    
    if is_map_1:
        map_display_name = f"Lang {hanh_tinh}"
        TARGET_MAP_ID = MAP_2_KEY
        GATEWAY_POS_X = 2200; TARGET_GATEWAY_POS_X = 50; DEFAULT_HOME_X = 100
    elif is_map_2:
        map_display_name = f"Khu Vuc 2 {hanh_tinh_key}"
        TARGET_MAP_ID = "Map_1_Lang_Hanh_Tinh"
        GATEWAY_POS_X = 50; TARGET_GATEWAY_POS_X = 2200; DEFAULT_HOME_X = 100
    else:
        map_id = "Map_1_Lang_Hanh_Tinh"; map_display_name = f"Làng {hanh_tinh}"
        TARGET_MAP_ID = MAP_2_KEY; GATEWAY_POS_X = 2200; TARGET_GATEWAY_POS_X = 50; DEFAULT_HOME_X = 100

    # --- KHỞI TẠO MAP GRAPHICS ---
    game_map_bg = dohoamap_langcuatoi.GameMapGraphics(SCREEN_WIDTH, SCREEN_HEIGHT)
    game_map_bg.set_map_id(map_id)
    game_map_bg.set_planet(planet_key_map)
    game_map_bg.set_map_name(map_display_name)
    
    map_config = game_map_bg.get_map_config()
    GROUND_Y = map_config['GROUND_Y']
    MAP_WIDTH = map_config['MAP_WIDTH_REAL']
    GATEWAY_X_WORLD = GATEWAY_POS_X
    GATEWAY_Y_GROUND = GROUND_Y

    # [NEW] Đặt NPC Olong ở bên phải cổng Map 2 ~300
    if is_map_2 and npcolong:
        npcolong.set_gateway_x(GATEWAY_X_WORLD)                                       
    
    frame_index = 0; anim_timer = pygame.time.get_ticks()
    huong_phai = True; SPEED = 5; is_jumping = False; dy = 0
    countdown_timer = 0; COUNTDOWN_DURATION = 3000; is_transferring = False
    
    # --- [2. LOAD DỮ LIỆU] ---
    data_nv = load_json(DATA_CHAR_FILE)
    info = data_nv.get(username_acc, {}).get(ten_nv, {})

    # [FIX_ATOMIC_SKILLTAB] Đảm bảo có hành tinh/phái trong info để Tab KỸ NĂNG nhận đúng
    # (Nếu thiếu, kynang.py sẽ fallback về 'Trai Dat' => Mikey không thấy skill Xayda)
    if not info.get('hanh_tinh'):
        info['hanh_tinh'] = hanh_tinh
    if not info.get('phai'):
        info['phai'] = hanh_tinh
    if not info.get('planet'):
        info['planet'] = hanh_tinh

    
    defaults = {
        "vang": 10000, "kim_cuong": 20, "vnd": 0, "is_vip": False,
        "suc_manh": 2000, "suc_danh": 10, "chi_mang": 3,
        "tiem_nang": 0, 
        "hp": 100, "max_hp": 100, "ki": 100, "max_ki": 100,
        "map_id": "Map_1_Lang_Hanh_Tinh", "world_x": DEFAULT_HOME_X,
        "quest": {"id": 0, "progress": 0, "target": 5}
    }
    for k, v in defaults.items():
        if k not in info: info[k] = v
    if "inventory" not in info: info["inventory"] = create_random_item_stack(5) + [None] * 25
    if "chest" not in info: info["chest"] = [None] * 30
    
    trangbi.init_equipment_data(info)
    # [PERSIST] Phục hồi trạng thái hợp thể khi out game vào lại
    try:
        if 'luonglongnhatthe' in globals() and luonglongnhatthe and hasattr(luonglongnhatthe, 'sanitize_fusion'):
            luonglongnhatthe.sanitize_fusion(info)
    except Exception:
        pass

    # --- [KY NANG] Khởi tạo dữ liệu ô kỹ năng (slot 1-5) ---
    try:
        import kynang
        kynang.ensure_player_skill_data(info)
        try:
            if ui_gamepad and hasattr(ui_gamepad, 'bind_player_info'):
                ui_gamepad.bind_player_info(info)
        except Exception:
            pass
        # --- [KY NANG] Ép ô đòn đệ tử về ô ngoài cùng bên trái (index=0) ---
        try:
            if info.get('detu_skill_id') and info.get('detu_skill_slot', 0) != 0:
                info['detu_skill_slot'] = 0
        except Exception:
            pass
        # --- [KY NANG] Ép ô hiển thị đòn đệ tử về ô số 1 (index=0), kể cả đã lưu cũ ---
        try:
            if info.get('detu_skill_id') and info.get('detu_skill_slot', 0) != 0:
                info['detu_skill_slot'] = 0
        except Exception:
            pass
        # --- [KY NANG] Dữ liệu kỹ năng đệ tử ---
        if 'detu_skill_slot' not in info:
            info['detu_skill_slot'] = 0  # mặc định hàng 4 ô: ô số 1
    except Exception:
        pass
    
    is_dead_state = False
    respawn_screen = die.DieScreen(SCREEN_WIDTH, SCREEN_HEIGHT)

    player_world_x = max(0, min(info.get("world_x", 100), MAP_WIDTH - 30))
    map_offset_x = max(0, min(player_world_x - (SCREEN_WIDTH // 2), MAP_WIDTH - SCREEN_WIDTH))
    
    class PlayerRect(pygame.Rect):
        pass

    player_rect = PlayerRect(player_world_x - map_offset_x, GROUND_Y - 50, 30, 50)
    player_rect.y = GROUND_Y - player_rect.height
    player_rect.world_x = player_world_x 
    
    # --- LOGIC STUN & BOSS CALLBACKS ---
    is_stunned = False
    stun_end_time = 0
    
    def apply_stun(seconds):
        nonlocal is_stunned, stun_end_time
        is_stunned = True
        stun_end_time = pygame.time.get_ticks() + int(seconds * 1000)
        text_manager.add(player_world_x, player_rect.y - 60, "CHOÁNG!", (255, 255, 0))

    def apply_boss_combo(dmg_base):
        nonlocal player_last_damage_time
        
        final_1 = max(1, dmg_base - current_stats.get('giap', 0))
        info["hp"] = max(0, info["hp"] - final_1)
        text_manager.add(player_world_x - 20, player_rect.y - 80, f"-{final_1}", RED_ERROR)
        
        final_2 = max(1, dmg_base - current_stats.get('giap', 0))
        info["hp"] = max(0, info["hp"] - final_2)
        text_manager.add(player_world_x + 20, player_rect.y - 100, f"-{final_2}", RED_ERROR)
        
        effect_manager.add_monster_hit(player_rect.centerx, player_rect.centery)
        player_last_damage_time = pygame.time.get_ticks() 
        trigger_save_data()

    def apply_boss_single_hit(dmg_base):
        nonlocal player_last_damage_time 
        
        final = max(1, dmg_base - current_stats.get('giap', 0))
        info["hp"] = max(0, info["hp"] - final)
        text_manager.add(player_world_x, player_rect.y - 80, f"-{final}", RED_ERROR)
        effect_manager.add_monster_hit(player_rect.centerx, player_rect.centery)
        player_last_damage_time = pygame.time.get_ticks()
        trigger_save_data()

    player_rect.stun = apply_stun
    player_rect.boss_combo = apply_boss_combo
    player_rect.boss_single_hit = apply_boss_single_hit

    current_inventory = info["inventory"]; current_chest = info["chest"]
    sidebar_x = -MENU_WIDTH; sidebar_state = "CLOSED"
    bag_menu_open = False; bag_menu_tab = "TUI_DO"; bag_icon_rect = pygame.Rect(0, 0, 0, 0); menu_mode = "NORMAL"
    btn_toggle_rect = pygame.Rect(0,0,0,0)
    
    show_welcome = is_new_player; game_start_time = pygame.time.get_ticks()
    
    # ===== QUEST STATE =====
    show_quest_dialog = False
    quest_step = 0
    quest_btn_rect = None; quest_box_rect = None
    
    show_shop_dialog = False; show_anxin_shop = False
    npc_bhatmit = dapdo_nhanpham.BaHatMitNPC(NPC_BHATMIT_X, GROUND_Y - 10)
    show_vip_popup = False; show_vip_success_popup = False; vip_msg = ""
    selected_shop_item = None; bag_item_popup_data = None
    
    selected_sell_item = None
    selling_item_index = -1
    sell_price = 0
    dragging_item_index = -1; dragging_item_data = None; dragging_list_ref = None
    
    chat_system = tinnhan_nhanvat.ChatSystem(SCREEN_WIDTH, SCREEN_HEIGHT, font_small)

    list_moc_nhan = []
    list_quai_map_2 = []
    
    boss = None                     
    
    # --- [NEW] BOSS BROLY MANAGER INIT ---
    broly_manager = None
    # -------------------------------------

    if is_map_1:
        start_x_moc_nhan = NPC_BHATMIT_X + 200 
        for i in range(4): 
            list_moc_nhan.append(mocnhan.MocNhan(start_x_moc_nhan + (i * 100), GROUND_Y))
    elif is_map_2:
        list_quai_map_2 = quaicon_map2.create_all_monsters(map_id, GROUND_Y)
        start_x_heo = 700
        last_heo_pos = start_x_heo + (3) * 150 
        start_x_gau = last_heo_pos + 500
        time_since_death = pygame.time.get_ticks() - boss_death_time
        if boss_death_time == 0 or time_since_death > 60000:
            boss = boss_lon_loi.create_boss_for_map(map_id, GROUND_Y, start_x_gau)
            if boss:
                list_quai_map_2.append(boss)
        
        # [NEW] KHỞI TẠO MANAGER BROLY
        broly_manager = bossbroly.BrolyBossManager(MAP_WIDTH, GROUND_Y)

    last_attack_time = 0; ATTACK_COOLDOWN = 600; last_ki_spam_time = 0 
    target_auto_attack = None; effect_manager = hieuungdanhtay.EffectManager()
    drop_manager = tileroivang_kc.DropManager(); text_manager = hieuungso.TextManager()
    pickup_msg = ""; pickup_msg_timer = 0
    monster_ui = bangthanhmau.MonsterInfoPanel(SCREEN_WIDTH); ui_target_monster = None; ui_display_timer = 0
    last_quai_attack_time = 0; QUAI_ATTACK_COOLDOWN = 2000; player_last_damage_time = 0; PLAYER_COMBAT_TIMEOUT = 5000; PLAYER_REGEN_RATE = 0.05 
    last_player_regen_time = pygame.time.get_ticks(); is_being_knocked_back = False; knockback_velocity = 0
    current_shop_ui = None; current_anxin_ui = None; popup_rect_info = None; close_info_rect = None

    destination_name = ""
    if TARGET_MAP_ID.startswith("Map_2_Khu_Vuc_"):
        destination_name = "Làng Aru (Khu 2)" if hanh_tinh == "Trai Dat" else ("Làng Mori (Khu 2)" if hanh_tinh == "Namec" else "Làng Paint (Khu 2)")
    elif TARGET_MAP_ID == "Map_1_Lang_Hanh_Tinh":
        destination_name = "Nhà Gohan (1)" if hanh_tinh == "Trai Dat" else ("Làng Moomo (1)" if hanh_tinh == "Namec" else "Làng Vegeta (1)")
    else: 
        destination_name = "Vùng đất lạ"

    # =========================================================
    # [FIX 1] BỘ NHỚ ĐỆM CHỈ SỐ (CACHE) 
    # -> GIÚP HP TỔNG KHÔNG BỊ TỤT KHI HP HIỆN TẠI GIẢM
    # =========================================================
    current_stats = {}
    total_max_hp = 100
    total_max_ki = 100

    def refresh_player_stats():
        """
        Hàm này tính toán lại HP Tổng, KI Tổng và các chỉ số khác.
        Chỉ gọi hàm này khi: Vào game, Mặc/Tháo đồ, Hồi sinh, hoặc Nâng cấp.
        Không gọi trong vòng lặp while True để tránh lỗi tụt HP Max.
        """
        nonlocal current_stats, total_max_hp, total_max_ki
        
        base_hp = info.get("max_hp", 100)
        base_ki = info.get("max_ki", 100)
        base_sd = info.get("suc_danh", 10)
        base_cm = info.get("chi_mang", 1)
        base_giap = info.get("giap", 0)
        
        stats_bonus = trangbi.calculate_stats_bonus(info, ITEM_TEMPLATES)
        

        
        # [NEW] FUSION BONUS: cộng chỉ số đệ vào sư phụ khi đã hợp thể xong
        
        fusion_bonus = {}
        
        try:
        
            if luonglongnhatthe and info:
        
                merged_ok = False
        
                try:
        
                    merged_ok = bool(hasattr(luonglongnhatthe, 'is_fusion_merged') and luonglongnhatthe.is_fusion_merged(info))
        
                except Exception:
        
                    merged_ok = False
        
                if merged_ok:
        
                    if hasattr(luonglongnhatthe, 'get_bonus_if_active'):
        
                        fusion_bonus = luonglongnhatthe.get_bonus_if_active(info) or {}
        
                    else:
        
                        fusion_bonus = (info.get('fusion') or {}).get('bonus') or {}
        
        except Exception:
        
            fusion_bonus = {}

        total_max_hp = base_hp + stats_bonus.get('hp', 0) + int((fusion_bonus.get('max_hp', fusion_bonus.get('hp', 0)) or 0))
        total_max_ki = base_ki + stats_bonus.get('ki', 0) + int((fusion_bonus.get('max_ki', fusion_bonus.get('ki', 0)) or 0))
        current_stats = {
            'suc_danh': base_sd + stats_bonus.get("suc_danh", 0) + int((fusion_bonus.get("suc_danh", 0) or 0)),
            'suc_manh': info.get("suc_manh", 2000), 
            'giap': base_giap + stats_bonus.get("giap", 0) + int((fusion_bonus.get("giap", 0) or 0)),
            'ne_tranh': info.get("ne_tranh", 0) + stats_bonus.get("ne_tranh", 0) + int((fusion_bonus.get("ne_tranh", 0) or 0)),
            'nhanh_nhen': info.get("nhanh_nhen", 0), 
            'chi_mang': base_cm + stats_bonus.get("chi_mang", 0) + int((fusion_bonus.get("chi_mang", 0) or 0)),
            'hoi_mau': stats_bonus.get("hoi_mau", 0),
            'hoi_ki': stats_bonus.get("hoi_ki", 0),
            'vang': info.get("vang", 0), 
            'kim_cuong': info.get("kim_cuong", 0), 
            'vnd': info.get("vnd", 0)
        }
    
    # Gọi lần đầu tiên khi vào game để có chỉ số đúng ngay lập tức
    refresh_player_stats()

    def trigger_save_data():
        save_data = load_json(DATA_CHAR_FILE)
        if username_acc in save_data:
            info["world_x"] = player_world_x; info["map_id"] = map_id
            save_data[username_acc][ten_nv] = info; save_json(DATA_CHAR_FILE, save_data)

    def calculate_player_damage(base_sd, crit_stat):
        base_dame = base_sd * 3
        rand_percent = random.uniform(0, 100); damage_multiplier = 1.00; is_crit = False
        if random.uniform(0, 100) < (30 + crit_stat): is_crit = True
        if rand_percent <= 0.1: damage_multiplier = 1.60 
        elif rand_percent <= 0.5: damage_multiplier = 1.50
        elif rand_percent <= 1: damage_multiplier = 1.40
        elif rand_percent <= 5: damage_multiplier = 1.30
        elif rand_percent <= 10: damage_multiplier = 1.30
        elif rand_percent <= 20: damage_multiplier = 1.20
        elif rand_percent <= 50: damage_multiplier = 1.20
        elif rand_percent <= 80: damage_multiplier = 1.10
        final_damage = math.ceil(base_dame * damage_multiplier)
        return (final_damage * 2, True) if is_crit else (final_damage, False)

    # [NEW] Đệ tử dùng chung công thức dame tay của nhân vật
    if detucoban:
        try:
            def _detu_damage_calc(_suc_danh, _chi_mang):
                dmg, crit = calculate_player_damage(_suc_danh, _chi_mang)
                # --- [KY NANG] % sát thương theo đòn đệ đang có (Cấp 1: 100% = như đấm thường) ---
                try:
                    import kynang
                    _sid = info.get('detu_skill_id')
                    _sk = kynang.get_skill_by_id(_sid) if _sid else None
                    if _sk:
                        _pct = int(_sk.get('damage_pct', 100))
                        dmg = max(1, int(dmg * _pct / 100))
                except Exception:
                    pass
                return dmg, crit

            detucoban.set_damage_calc_func(_detu_damage_calc)
        except Exception:
            pass

    # =========================================================
    # [FIX 2] HỒI SINH & RESET TRẠNG THÁI (ĐỂ ĐÁNH ĐƯỢC)
    # =========================================================
    def revive_player(mode):
        nonlocal is_dead_state, player_world_x, map_offset_x, map_id
        nonlocal is_stunned, stun_end_time, is_being_knocked_back, knockback_velocity, target_auto_attack
        
        # 1. Tắt màn hình chết
        is_dead_state = False; respawn_screen.is_open = False
        
        # 2. [FIX QUAN TRỌNG] Reset trạng thái bất lợi để nhân vật cử động được
        # Lưu ý: Code logic choáng/đẩy lùi trong vòng lặp chính VẪN CÒN NGUYÊN.
        # Ở đây ta chỉ tắt nó đi (False) vì nhân vật đã sống lại, cơ thể phải bình thường.
        is_stunned = False          
        stun_end_time = 0
        is_being_knocked_back = False
        knockback_velocity = 0
        target_auto_attack = None   # Hủy mục tiêu cũ để tránh lỗi tự tìm đường
        
        # 3. Hồi đầy HP/KI
        info["hp"] = 1000000; info["ki"] = 1000000 
        refresh_player_stats() # Cập nhật lại các chỉ số

        if mode == 'home':
            map_id = "Map_1_Lang_Hanh_Tinh"; player_world_x = DEFAULT_HOME_X
            info["world_x"] = player_world_x; info["map_id"] = map_id; trigger_save_data(); return map_id 
        
        map_offset_x = max(0, min(player_world_x - (SCREEN_WIDTH // 2), MAP_WIDTH - SCREEN_WIDTH))
        player_rect.x = player_world_x - map_offset_x; trigger_save_data(); return False

    # --- MAIN LOOP ---
    # ====== [KAMEJOKO] SETUP (gồng 1.5s, tầm 200, hồi 2s) ======
    prev_tick = pygame.time.get_ticks()
    kame_attack_now = False
    try:
        from kamejoko import KameJoko
    except Exception:
        KameJoko = None
    kame_skill = KameJoko() if KameJoko else None
    # ====== [ATOMIC GOLD] SETUP (bấm J / click quái: tự gồng 0.5s rồi bắn, 1 lần dame) ======
    atomic_attack_now = False
    try:
        from atomic import AtomicGoldSkill
    except Exception:
        try:
            from atomic_v2 import AtomicGoldSkill
        except Exception:
            AtomicGoldSkill = None
    atomic_skill = AtomicGoldSkill() if AtomicGoldSkill else None
    # ====== [MASENKO] SETUP (Namec - quả cầu đỏ, gồng ngắn, hồi 1s) ======
    masenko_attack_now = False
    masenko_impact_pos = None
    try:
        from masenko import MasenkoSkill
    except Exception:
        MasenkoSkill = None
    masenko_skill = MasenkoSkill(damage_pct=100, cooldown_s=1.0) if MasenkoSkill else None

    # ====== [SSJ CAP 1] SETUP (Xayda - hào quang/glow + nổ rung đất như demo) ======
    try:
        import ssj2 as _ssj2
    except Exception:
        _ssj2 = None
    ssj_fx = _ssj2.SSJFX() if _ssj2 else None
    ssj_active = bool(info.get("ssj_active", False))
    ssj_charge = float(info.get("ssj_charge", 0.0))
    ssj_hold_off = float(info.get("ssj_hold_off", 0.0))
    skill_bar_rects = None

    last_atomic_fire_token = -1

    _map_offset_box = [map_offset_x]
    class _WorldTargetProxy:
        def __init__(self, target, box):
            self._t = target
            self._box = box
            self._real_target = target
        @property
        def rect(self):
            # target.rect đang là screen-x; cộng map_offset_x để ra world-x
            r = self._t.rect
            ox = int(self._box[0])
            return pygame.Rect(r.x + ox, r.y, r.width, r.height)

    # ====== [NUT DIEU KHIEN] SETUP (joystick trai + nut dam + nut chieu) ======
    try:
        import nutdieukhien as _nutdieukhien
    except Exception:
        _nutdieukhien = None
    ui_gamepad = _nutdieukhien.GamepadUI(SCREEN_WIDTH, SCREEN_HEIGHT) if _nutdieukhien else None

    while True:
        current_time = pygame.time.get_ticks() 
        dt = (current_time - prev_tick) / 1000.0
        prev_tick = current_time
        kame_attack_now = False
        atomic_attack_now = False
        masenko_attack_now = False
        masenko_impact_pos = None

        # ====== [NUT DIEU KHIEN] RESET PER-FRAME FLAGS ======
        if ui_gamepad:
            ui_gamepad.reset_frame_flags()

        # ====== [SSJ CAP 1] INPUT (2 cách: giữ LMB trên ô skill SSJ / giữ RMB khi đang chọn SSJ) ======
        ssj_trigger_hold = False
        if hanh_tinh == "Xayda" and _ssj2:
            try:
                import kynang as _kynang
                _kynang.ensure_player_skill_data(info)
                _slots = info.get("skill_slots", [None] * 5)
                _mx, _my = pygame.mouse.get_pos()
                _lmb = pygame.mouse.get_pressed(3)[0]
                _rmb = pygame.mouse.get_pressed(3)[2]
                # Cách 1: giữ LMB ngay trên ô chứa SSJ
                if _lmb and skill_bar_rects:
                    for _i in range(min(len(skill_bar_rects), len(_slots))):
                        if _slots[_i] == _ssj2.SSJ_SKILL_ID and skill_bar_rects[_i].collidepoint(_mx, _my):
                            ssj_trigger_hold = True
                            break
                # Cách 2: chọn SSJ làm active rồi giữ RMB
                if (not ssj_trigger_hold) and _rmb:
                    _sk = _kynang.get_active_skill(info)
                    if _sk and _sk.get("id") == _ssj2.SSJ_SKILL_ID:
                        ssj_trigger_hold = True
            except Exception:
                ssj_trigger_hold = False

            # Charge / Toggle
            if not ssj_active:
                if ssj_trigger_hold:
                    ssj_charge += dt
                    if ssj_charge >= _ssj2.CHARGE_TIME:
                        ssj_charge = _ssj2.CHARGE_TIME
                        ssj_active = True
                        info["ssj_active"] = True
                        info["ssj_charge"] = 0.0
                        ssj_hold_off = 0.0
                        info["ssj_hold_off"] = 0.0
                        # Nổ biến hình + rung đất (giống demo)
                        try:
                            if ssj_fx:
                                ssj_fx.trigger_transform(player_rect.centerx, player_rect.centery, player_rect.bottom + 4, power=1.0)
                        except Exception:
                            pass
                else:
                    ssj_charge = max(0.0, ssj_charge - dt * 1.4)
            else:
                # đang SSJ: giữ lại để tắt nhanh (tránh kẹt)
                if ssj_trigger_hold:
                    ssj_hold_off += dt
                    info["ssj_hold_off"] = ssj_hold_off
                    if ssj_hold_off >= _ssj2.TOGGLE_OFF_HOLD:
                        ssj_active = False
                        info["ssj_active"] = False
                        ssj_charge = 0.0
                        info["ssj_charge"] = 0.0
                        ssj_hold_off = 0.0
                        info["ssj_hold_off"] = 0.0
                        try:
                            if ssj_fx:
                                ssj_fx.trigger_power_down(player_rect.centerx, player_rect.centery, player_rect.bottom + 4)
                        except Exception:
                            pass
                else:
                    ssj_hold_off = 0.0
                    info["ssj_hold_off"] = 0.0

        # Max HP/KI hiệu lực theo SSJ (không làm tụt max vì không gọi refresh trong loop)
        ssj_mult_now = (_ssj2.SSJ_MULT if (hanh_tinh == "Xayda" and _ssj2 and ssj_active) else 1.0)
        total_max_hp_eff = int(total_max_hp * ssj_mult_now)
        total_max_ki_eff = int(total_max_ki * ssj_mult_now)
        atomic_key_req = False
        atomic_click_req = False
        atomic_click_target = None
        
        # [NEW] FUSION UPDATE + REQUEST START
        try:
            if luonglongnhatthe and info:
                # cập nhật phase hợp thể + chống kẹt trạng thái
                need_refresh = luonglongnhatthe.update_fusion(info, now_tick=current_time)
                if need_refresh:
                    try:
                        refresh_player_stats()
                    except Exception:
                        pass
        
                # nhận request từ UI (tuido)
                if info.get('fusion_request'):
                    det_obj = None
                    try:
                        det_obj = detucoban.get_det() if detucoban and hasattr(detucoban, 'get_det') else None
                    except Exception:
                        det_obj = None
        
                    if det_obj is not None and luonglongnhatthe.ui_can_click(info):
                        ok = luonglongnhatthe.start_fusion(info, det_obj, hanh_tinh, now_tick=current_time)
                        if ok:
                            info['_close_bag_menu'] = True
                        # clear request (dù ok hay fail) để tránh kẹt
                        info['fusion_request'] = False
                    else:
                        info['fusion_request'] = False
        except Exception:
            # tuyệt đối không để crash game loop
            try:
                if info:
                    info['fusion_request'] = False
            except Exception:
                pass
        # [NEW] FUSION UPDATE + REQUEST END

        # --- LOGIC CHOÁNG VẪN GIỮ NGUYÊN TẠI ĐÂY ---
        if is_stunned and current_time >= stun_end_time:
            is_stunned = False
        
        # Lấy chỉ số từ cache (đã fix lỗi tụt HP Max)
        vang_current = current_stats['vang']
        kim_cuong_current = current_stats['kim_cuong']
        vnd_current = current_stats['vnd']
        is_vip = info.get("is_vip", False)
        
        if info["hp"] > total_max_hp_eff: info["hp"] = total_max_hp_eff
        if info["ki"] > total_max_ki_eff: info["ki"] = total_max_ki_eff
        
        hp = info["hp"]
        ki = info["ki"]

        if hp <= 0 and not is_dead_state:
            is_dead_state = True
            respawn_screen.is_open = True

        if npc_bhatmit.show_upgrade_ui:
            # Cập nhật thông tin khi đang nâng cấp
            npc_bhatmit.upgrade_ui.handle_event(None, info, trigger_save_data)
        
        mouse_pos = pygame.mouse.get_pos()
        clock.tick(60)
        
        # --- [NEW] UPDATE BOSS BROLY ---
        if broly_manager:
            is_spawned = broly_manager.update(current_time, player_rect, player_world_x, map_offset_x)
            if is_spawned:
                boss_name = "BROLY"
                if broly_manager and getattr(broly_manager, "boss", None) is not None:
                    boss_name = getattr(broly_manager.boss, "name_display", boss_name)
                boss_name_upper = str(boss_name).upper()
                text_manager.add(player_world_x, player_rect.y - 150, f"CẢNH BÁO: {boss_name_upper} XUẤT HIỆN!", RED_TITLE)
                if npcolong:
                    npcolong.notify_boss_spawn(boss_name, current_time)
        # -------------------------------

        # --- HỒI MÁU/KI ---
        time_since_attack = current_time - last_attack_time
        time_since_hit = current_time - player_last_damage_time
        is_idle = (time_since_attack > 5000) and (time_since_hit > 5000)

        if not is_dead_state and (hp < total_max_hp_eff or ki < total_max_ki_eff):
            if is_idle:
                if current_time - last_player_regen_time >= 1000:
                    regen_hp_amount = int(total_max_hp_eff * PLAYER_REGEN_RATE) + current_stats.get("hoi_mau", 0)
                    regen_ki_amount = int(total_max_ki_eff * PLAYER_REGEN_RATE) + current_stats.get("hoi_ki", 0)
                    new_hp = min(total_max_hp_eff, hp + max(1, regen_hp_amount))
                    new_ki = min(total_max_ki_eff, ki + max(1, regen_ki_amount))
                    if new_hp > hp or new_ki > ki:
                        info["hp"] = new_hp; info["ki"] = new_ki
                        regen_txt = ""
                        if new_hp > hp: regen_txt += f"+{new_hp-hp} "
                        if new_ki > ki: regen_txt += f"+{new_ki-ki}"
                        if regen_txt:
                            text_manager.add(player_world_x + 15, player_rect.y - 100, regen_txt.strip(), (0, 255, 255))
                        trigger_save_data()
                    last_player_regen_time = current_time 
        
        game_map_bg.set_map_name(map_display_name)
        game_map_bg.draw(screen, map_offset_x)
        
        if is_map_1:
            cx = CHEST_POS_WORLD - map_offset_x; cy = GROUND_Y - CHEST_HEIGHT
            chest_rect_screen = pygame.Rect(cx - CHEST_SIZE // 2, cy, CHEST_SIZE, CHEST_HEIGHT)
            pygame.draw.rect(screen, C_CHEST, chest_rect_screen)
            pygame.draw.rect(screen, C_VANG, (chest_rect_screen.x, chest_rect_screen.y, CHEST_SIZE, 5))

        event_list = pygame.event.get()

        is_upgrading = False
        if getattr(tuido, 'upgrade_manager', None) and tuido.upgrade_manager.show_popup:
            is_upgrading = True

        is_ui_open = (
            bag_menu_open or show_welcome or show_quest_dialog or show_shop_dialog or
            show_anxin_shop or selected_shop_item or selected_sell_item or
            bag_item_popup_data or chat_system.is_open or show_vip_popup or
            show_vip_success_popup or npc_bhatmit.show_dialog or npc_bhatmit.show_upgrade_ui or
            respawn_screen.is_open or is_upgrading or (npcolong and npcolong.is_open())
        )

        # ====== EVENT LOOP ======
        for event in event_list:
            if ui_gamepad:
                ui_gamepad.handle_event(event)
            # [ATOMIC INPUT] Nhấn J là tự gồng 0.5s rồi bắn (không cần READY)
            if event.type == pygame.KEYDOWN and event.key == pygame.K_j:
                if (not is_dead_state) and (not is_ui_open) and (not is_stunned):
                    atomic_key_req = True
            if event.type == pygame.QUIT: 
                info["inventory"] = current_inventory; info["chest"] = current_chest
                # [PERSIST] lưu HP/KI hiện tại để vào lại y như lúc out
                try:
                    info["hp"] = int(hp)
                    info["ki"] = int(ki)
                    # [PERSIST] đóng băng thời gian hợp thể để vào lại y như lúc out
                    try:
                        if 'luonglongnhatthe' in globals() and luonglongnhatthe and hasattr(luonglongnhatthe, 'snapshot_for_save'):
                            luonglongnhatthe.snapshot_for_save(info)
                    except Exception:
                        pass
                except Exception:
                    pass

                info["world_x"] = player_world_x; info["map_id"] = map_id
                data_nv = load_json(DATA_CHAR_FILE)
                data_nv.setdefault(username_acc, {})[ten_nv] = info
                save_json(DATA_CHAR_FILE, data_nv)
                pygame.quit(); sys.exit()
            
            if npc_bhatmit.show_upgrade_ui or npc_bhatmit.show_dialog:
                if npc_bhatmit.handle_event(event, info, player_world_x, trigger_save_data):
                    refresh_player_stats() # Cập nhật chỉ số sau khi nâng cấp
                    continue
            
            # [NEW] NPC Olong - bảng THONG BAO BOSS (ưu tiên xử lý trước chat)
            if is_map_2 and npcolong:
                if npcolong.handle_event(event, map_offset_x, GROUND_Y, player_world_x, broly_manager, current_time):
                    continue

            # [NEW] Đệ tử: mở/đóng tab (phím Y). Tránh ăn phím khi chat đang mở.
            if detucoban and not getattr(chat_system, 'is_open', False):
                detucoban.handle_event(event)

            if chat_system.handle_event(event):
                continue
            
            # ===== RESPAWN =====
            if respawn_screen.is_open and event.type == pygame.MOUSEBUTTONDOWN:
                action = respawn_screen.handle_click(event.pos)
                if action == 'revive':
                    if info["kim_cuong"] >= 2:
                        info["kim_cuong"] -= 2
                        res = revive_player('revive')
                        # Lưu ý: revive_player đã gọi refresh_player_stats() bên trong rồi
                        if res is not False:
                            return res
                    else:
                        text_manager.add(player_world_x + 15, player_rect.y - 80, "Khong du Kim Cuong!", RED_ERROR)
                    continue
                elif action == 'home':
                    hieu_ung_load_logout(screen)
                    res = revive_player('home')
                    if res is not False: 
                        return res
                    continue 

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos

                if show_quest_dialog and quest_btn_rect and quest_box_rect:
                    if (not quest_box_rect.collidepoint(mx, my)) and (not quest_btn_rect.collidepoint(mx, my)):
                        show_quest_dialog = False
                        quest_step = 0
                        continue
                    if quest_btn_rect.collidepoint(mx, my):
                        q_data = info.get("quest", {"id": 0})
                        current_q_id = q_data.get("id", 0)
                        if current_q_id == 0: 
                            if quest_step == 1: quest_step = 2 
                            elif quest_step == 2: 
                                info["quest"] = {"id": 1, "progress": 0, "target": 5}
                                trigger_save_data(); show_quest_dialog = False; quest_step = 0
                        elif current_q_id == 1: 
                            is_done, next_step = nhiemvu.complete_mission(info)
                            if is_done: trigger_save_data(); show_quest_dialog = False; quest_step = 0
                            else: show_quest_dialog = False
                        elif current_q_id == 2: 
                            if quest_step == 1: quest_step = 2
                            elif quest_step == 2: 
                                info["quest"] = {"id": 3, "progress": 0, "target": 10}
                                trigger_save_data(); show_quest_dialog = False; quest_step = 0
                        elif current_q_id == 3: 
                            is_done, next_step = nhiemvu.complete_mission(info)
                            if is_done: trigger_save_data(); show_quest_dialog = False; quest_step = 0
                            else: show_quest_dialog = False
                        elif current_q_id == 4:
                            if quest_step == 1:
                                quest_step = 2
                            elif quest_step == 2:
                                info["quest"] = {"id": 5, "progress": 0, "target": 1}
                                trigger_save_data()
                                show_quest_dialog = False
                                quest_step = 0
                        elif current_q_id == 5:
                            is_done, next_step = nhiemvu.complete_mission(info)
                            if is_done: trigger_save_data(); show_quest_dialog = False; quest_step = 0
                            else: show_quest_dialog = False
                        elif current_q_id == 6:
                            show_quest_dialog = False
                            quest_step = 0
                        continue

                if bag_menu_open and bag_menu_tab in ["TUI_DO", "RUONG"]:
                    if getattr(tuido, 'upgrade_manager', None):
                        handled = tuido.upgrade_manager.handle_event(event, info, trigger_save_data)
                        if handled: 
                            refresh_player_stats() # Update stats nếu nâng cấp item thành công
                            continue 

                if show_shop_dialog and current_shop_ui:
                    cr, tr, slots, current_tab = current_shop_ui
                    if cr.collidepoint(mx, my): 
                        show_shop_dialog = False; selected_sell_item = None; selected_shop_item = None; 
                        continue
                    for k, r in tr.items(): 
                        if r.collidepoint(mx, my): 
                            npcbando.current_shop_tab = k; selected_sell_item = None; selected_shop_item = None
                    if selected_sell_item:
                        popup_w, popup_h = 250, 180
                        popup_x = (SCREEN_WIDTH - popup_w) // 2
                        popup_y = (SCREEN_HEIGHT - popup_h) // 2
                        btn_sell_rect = pygame.Rect(popup_x + 30, popup_y + 110, 80, 40)
                        btn_cancel_rect = pygame.Rect(popup_x + 140, popup_y + 110, 80, 40)
                        if btn_sell_rect.collidepoint(mx, my):
                            if 0 <= selling_item_index < len(current_inventory):
                                current_inventory[selling_item_index] = None 
                                info["vang"] += sell_price
                                text_manager.add(player_world_x, player_rect.y - 50, f"+{sell_price:,} Vàng", C_VANG)
                                trigger_save_data()
                                refresh_player_stats() # Update lại số vàng
                            selected_sell_item = None; 
                            continue
                        elif btn_cancel_rect.collidepoint(mx, my):
                            selected_sell_item = None; 
                            continue
                    if not selected_sell_item and not selected_shop_item:
                        for k, d in slots.items():
                            if d['rect'].collidepoint(mx, my):
                                if current_tab == "BAN_DO":
                                    item_data = d['data']; item_key = item_data['key']
                                    shop_price, _ = qlgiatien.get_item_price("BANDO", item_key)
                                    sell_price = shop_price // 2 if shop_price else 2000000
                                    selected_sell_item = item_data; selling_item_index = k 
                                else:
                                    if k in ITEM_TEMPLATES:
                                        selected_shop_item = ITEM_TEMPLATES[k].copy()
                                        selected_shop_item.update({'key': k, 'shop_key': 'BANDO'})
                                        p, c = qlgiatien.get_item_price("BANDO", k)
                                        selected_shop_item.update({"price": p or 0, "currency": c or "VANG"})

                if selected_shop_item:
                    PW=450; PH=300; PX=(SCREEN_WIDTH-PW)//2; PY=(SCREEN_HEIGHT-PH)//2
                    if pygame.Rect(PX+PW-35, PY+10, 25, 25).collidepoint(mx, my): 
                        selected_shop_item = None; 
                        continue
                    elif pygame.Rect(PX+100, PY+230, 100, 40).collidepoint(mx, my):
                        if item_buy_popup.handle_buy_transaction(info, selected_shop_item, current_inventory): 
                            selected_shop_item = None; trigger_save_data(); refresh_player_stats()
                        continue

                if bag_item_popup_data:
                    px, py = SCREEN_WIDTH // 2 - 225, SCREEN_HEIGHT // 2 - 175
                    btn_action_rect = pygame.Rect(px + 175, py + 240, 100, 40)
                    if btn_action_rect.collidepoint(mx, my):
                        msg = ""; suc = False
                        if bag_item_popup_data.get('is_equipped'):
                            slot_idx = bag_item_popup_data.get('slot_index')
                            msg, suc = trangbi.handle_unequip_action(info, slot_idx)
                        else:
                            inv_idx = bag_item_popup_data.get('inventory_index', -1)
                            if inv_idx != -1:
                                msg, suc = trangbi.handle_equip_action(info, inv_idx, ITEM_TEMPLATES)
                        if msg:
                            text_manager.add(player_rect.centerx, player_rect.y - 50, msg, GREEN_SUCCESS if suc else RED_ERROR)
                            trigger_save_data()
                            refresh_player_stats() # [FIX] Cập nhật stats ngay khi mặc/tháo đồ
                            bag_item_popup_data = None 
                        continue 
                    if (close_info_rect and close_info_rect.collidepoint(mx, my)) or (popup_rect_info and not popup_rect_info.collidepoint(mx, my)): 
                        bag_item_popup_data = None; 
                        continue
                
                if show_anxin_shop and current_anxin_ui:
                    if current_anxin_ui[0].collidepoint(mx, my): 
                        show_anxin_shop = False; 
                        continue
                    for k, r in current_anxin_ui[1].items():
                        rr = r['rect'] if isinstance(r, dict) else r
                        if hasattr(rr, 'collidepoint') and rr.collidepoint(mx, my):
                            tmp = getattr(npcanxin, 'SHOP_ITEMS', {}).get(k)
                            if tmp:
                                selected_shop_item = tmp.copy()
                                selected_shop_item.update({'key': k, 'shop_key': 'ANXIN'})
                                p, c = qlgiatien.get_item_price("ANXIN", k)
                                selected_shop_item.update({"price": p or 0, "currency": c or "VND"})
                                show_anxin_shop = False

                elif show_vip_success_popup:
                    if pygame.Rect((SCREEN_WIDTH-400)//2 + 150, (SCREEN_HEIGHT-200)//2 + 130, 100, 40).collidepoint(mx, my): 
                        show_vip_success_popup = False; show_anxin_shop = True

                elif show_vip_popup:
                    cr, br, cb = mothanhvien.draw_vip_popup(screen, SCREEN_WIDTH, SCREEN_HEIGHT, font, font_small, info, mouse_pos)
                    if cr.collidepoint(mx, my): 
                        show_vip_popup = False; vip_msg = ""
                    elif br.collidepoint(mx, my) and cb:
                        suc, msg = mothanhvien.handle_buy_vip(info, cb)
                        if suc: 
                            show_vip_popup = False; show_vip_success_popup = True; vip_msg = msg; trigger_save_data(); refresh_player_stats()
                        else: 
                            vip_msg = msg

                elif bag_menu_open:
                    if bag_menu_tab == "TUI_DO" and menu_mode == "NORMAL":
                        ui_x = (SCREEN_WIDTH - tuido.UI_WIDTH) // 2
                        ui_y = (SCREEN_HEIGHT - tuido.UI_HEIGHT) // 2
                        equip_rects = trangbi.get_slot_rects(ui_x, ui_y, tuido.UI_WIDTH, tuido.UI_HEIGHT)
                        clicked_equip = False
                        for i, eq_rect in enumerate(equip_rects):
                            if eq_rect.collidepoint(mx, my):
                                clicked_equip = True
                                item_eq = info["equipment"][i]
                                if item_eq:
                                    ik = item_eq.get('key')
                                    if ik in ITEM_TEMPLATES:
                                        pd = ITEM_TEMPLATES[ik].copy(); pd.update(item_eq)
                                        pd['is_equipped'] = True; pd['slot_index'] = i
                                        bag_item_popup_data = pd
                                break
                        if clicked_equip: 
                            continue

                    idx = tuido.get_slot_index_from_pos(event.pos, SCREEN_WIDTH, SCREEN_HEIGHT)
                    if bag_menu_tab != "CAI_DAT" and idx != -1:
                        tl = current_inventory if bag_menu_tab == "TUI_DO" else current_chest
                        if idx < len(tl) and tl[idx]: 
                            dragging_item_index = idx; dragging_item_data = tl[idx]; dragging_list_ref = tl
                    
                    tr, cr, _ = tuido.draw_main_menu_full(screen, bag_menu_tab, SCREEN_WIDTH, SCREEN_HEIGHT, mode=menu_mode, data_list=[], ITEM_TEMPLATES=ITEM_TEMPLATES, player_info=info)
                    for k, r in tr.items():
                        rr = r['rect'] if isinstance(r, dict) else r
                        if hasattr(rr, 'collidepoint') and rr.collidepoint(mx, my): 
                            bag_menu_tab = k
                    if cr.collidepoint(mx, my): 
                        bag_menu_open = False

                    if bag_menu_tab == "CAI_DAT":
                        logout_btn_rect = pygame.Rect(SCREEN_WIDTH//2-50, SCREEN_HEIGHT//2+100, 100, 40)
                        if logout_btn_rect.collidepoint(mx, my):
                            info["inventory"] = current_inventory; info["chest"] = current_chest
                            info["world_x"] = player_world_x; info["map_id"] = map_id
                            d_sv = load_json(DATA_CHAR_FILE)
                            d_sv.setdefault(username_acc, {})[ten_nv] = info
                            save_json(DATA_CHAR_FILE, d_sv)
                            hieu_ung_load_logout(screen)
                            return "LOGOUT"

                elif not is_ui_open:
                    bt, _ = draw_sidebar_menu(screen, sidebar_x, ten_nv, hanh_tinh, hp, total_max_hp_eff, ki, total_max_ki_eff, current_stats, info=info)
                    if bt.collidepoint(mx, my): 
                        sidebar_state = "OPENING" if sidebar_state in ["CLOSED", "CLOSING"] else "CLOSING"

                    if bag_icon_rect.collidepoint(mx, my): 
                        bag_menu_open = True; menu_mode = "NORMAL"; bag_menu_tab = "TUI_DO"

                    if is_map_1:
                        if chest_rect_screen.collidepoint(mx, my) and abs(player_world_x - CHEST_POS_WORLD) <= CHEST_INTERACT_DISTANCE: 
                            bag_menu_open = True; menu_mode = "CHEST"; bag_menu_tab = "RUONG"

                        target_npc_x = 200
                        screen_npc_x = target_npc_x - map_offset_x
                        npc_hitbox = pygame.Rect(screen_npc_x - 30, GROUND_Y - 90, 60, 90)

                        if npc_hitbox.collidepoint(mx, my) and abs(player_world_x - target_npc_x) <= 150:
                            q_data = info.get("quest", {})
                            q_id = q_data.get("id", 0)
                            show_quest_dialog = True
                            if q_id in [0, 2, 4]:
                                quest_step = 1
                            else:
                                quest_step = 2

                        if npcbando.check_click(event.pos, map_offset_x, GROUND_Y) and abs(player_world_x - NPC_BANDO_X) <= NPC_INTERACT_RANGE: 
                            show_shop_dialog = True
                        if npcanxin.check_click(event.pos, map_offset_x, GROUND_Y) and abs(player_world_x - NPC_ANXIN_X) <= NPC_INTERACT_RANGE:
                            if is_vip: show_anxin_shop = True
                            else: show_vip_popup = True
                        if pygame.Rect(npc_bhatmit.rect.x, npc_bhatmit.rect.y, npc_bhatmit.rect.width, npc_bhatmit.rect.height).collidepoint(mx, my) and abs(player_world_x - NPC_BHATMIT_X) <= NPC_INTERACT_RANGE: 
                            npc_bhatmit.show_dialog = True
                    
                    # [FIX CLICK BROLY] Thêm Broly vào danh sách quái có thể click
                    all_mobs = list_moc_nhan + list_quai_map_2[:] # Copy list để không ảnh hưởng list gốc
                    if broly_manager and broly_manager.boss and not broly_manager.boss.is_dead:
                        all_mobs.append(broly_manager.boss)

                    clicked_target = None

                    mx_click, my_click = mx, my

                    for mn in all_mobs:

                        try:

                            if getattr(mn, 'is_dead', False):

                                continue

                            r = getattr(mn, 'rect', None)

                            if r is None:

                                continue

                            # [FIX] Không update quái ngay lúc click (tránh rect nhảy -> miss target)

                            # Tính rect click theo world_x để đúng với map_offset_x hiện tại

                            wx = getattr(mn, 'world_x', None)

                            if wx is None:

                                rect_click = r

                            else:

                                rect_click = pygame.Rect(int(wx - map_offset_x), int(r.y), int(r.width), int(r.height))

                            if rect_click.collidepoint(mx_click, my_click):

                                clicked_target = mn

                                break

                        except Exception:

                            # fallback an toàn

                            try:

                                if mn.rect.collidepoint(mx_click, my_click) and not getattr(mn, 'is_dead', False):

                                    clicked_target = mn

                                    break

                            except Exception:

                                pass

                    target_auto_attack = clicked_target
                    # [ATOMIC INPUT] Click vào quái -> tự gồng 0.5s rồi bắn (lock mục tiêu)
                    if clicked_target is not None:
                        atomic_click_req = True
                        atomic_click_target = clicked_target

            if event.type == pygame.MOUSEBUTTONUP and dragging_item_index != -1:
                t_idx = tuido.get_slot_index_from_pos(event.pos, SCREEN_WIDTH, SCREEN_HEIGHT)
                if t_idx == dragging_item_index:
                    ik = dragging_item_data.get('key')
                    if ik in ITEM_TEMPLATES: 
                        pd = ITEM_TEMPLATES[ik].copy()
                        pd.update(dragging_item_data)
                        pd['inventory_index'] = dragging_item_index
                        bag_item_popup_data = pd
                    else: 
                        bag_item_popup_data = dragging_item_data
                        bag_item_popup_data['inventory_index'] = dragging_item_index
                elif t_idx != -1 and t_idx < len(dragging_list_ref):
                    dragging_list_ref[dragging_item_index], dragging_list_ref[t_idx] = dragging_list_ref[t_idx], dragging_list_ref[dragging_item_index]
                dragging_item_index = -1; dragging_item_data = None; dragging_list_ref = None

        # ====== UPDATE ======
        chat_system.update()
        effect_manager.update()
        drop_manager.update()
        text_manager.update()

        for item in drop_manager.check_pickup(player_rect, player_world_x):
            if item['type'] == "VANG":
                info["vang"] += item['amount']
                pickup_msg = f"Ban nhan duoc {int(item['amount'])} Vang"
            elif item['type'] == "KIM_CUONG":
                info["kim_cuong"] += item['amount']
                pickup_msg = f"Ban nhan duoc {int(item['amount'])} Ngoc"
            elif item['type'] == "VND":
                info["vnd"] += item['amount']
                pickup_msg = f"Ban nhan duoc {int(item['amount'])} VND"
            elif item['type'] == "ITEM":
                item_data = item.get('data', {})
                added = False
                if isinstance(item_data, dict):
                    # Normalize field names for tui do
                    if 'stars' not in item_data and 'star' in item_data:
                        item_data['stars'] = item_data.get('star')
                    # Optional stack/count support
                    if 'count' not in item_data:
                        if 'quantity' in item_data:
                            item_data['count'] = item_data.get('quantity')
                        elif 'amount' in item_data:
                            item_data['count'] = item_data.get('amount')
                    try:
                        if 'count' in item_data:
                            item_data['count'] = max(1, int(item_data['count']))
                    except Exception:
                        item_data.pop('count', None)
                    new_item = dict(item_data)
                    # Remove legacy 'star' key to avoid confusion
                    if 'star' in new_item and 'stars' in new_item:
                        new_item.pop('star', None)
                    # Add to inventory (first empty slot)
                    for i in range(len(current_inventory)):
                        if current_inventory[i] is None:
                            current_inventory[i] = new_item
                            added = True
                            break
                if added:
                    pickup_msg = f"Ban nhan duoc {item_data.get('key', 'Vat pham')}"
                else:
                    pickup_msg = "Hanh trang day!"
            pickup_msg_timer = pygame.time.get_ticks(); trigger_save_data()

        keys = pygame.key.get_pressed()
        # ====== [NUT DIEU KHIEN] JOYSTICK => PHIM DIEU HUONG ======
        joy_left = False
        joy_right = False
        joy_jump = False
        if ui_gamepad:
            _jx, _jy, _jmag = ui_gamepad.get_move()
            if _jmag > 0.05:
                joy_left = (_jx < -0.35)
                joy_right = (_jx > 0.35)
                joy_jump = (_jy < -0.55)

        # ====== [NUT DIEU KHIEN] NUT CHIEU => DOI ACTIVE SLOT (1..5) ======
        if ui_gamepad and (not is_ui_open):
            _slot = ui_gamepad.consume_skill_change()
            if _slot is not None:
                info["active_skill_slot"] = int(_slot)

        dx = 0; is_moving = False; should_attack = False 
        
        # --- MOVEMENT ---
        # LOGIC CHOÁNG/ĐẨY LÙI VẪN HOẠT ĐỘNG BÌNH THƯỜNG Ở ĐÂY
        if is_dead_state: 
            dx = 0; is_moving = False; is_jumping = False; dy = 0
        elif is_stunned:
            dx = 0; is_moving = False
        else:
            if is_being_knocked_back:
                knockback_velocity *= 0.8; 
                if abs(knockback_velocity) < 0.5: is_being_knocked_back = False
                dx = 0
            if not is_being_knocked_back and (keys[pygame.K_LEFT] or keys[pygame.K_RIGHT] or keys[pygame.K_UP] or keys[pygame.K_SPACE] or joy_left or joy_right or joy_jump): 
                # [FIX] Giữ mục tiêu khi tự di chuyển (click boss rồi chạy tới vẫn đánh)
                if is_transferring:
                    if countdown_timer != 0: text_manager.add(player_world_x + 15, player_rect.y - 40, "Đã Hủy Dịch Chuyển!", (255, 100, 100))
                    is_transferring = False; countdown_timer = 0
            if not is_ui_open and not is_being_knocked_back: 
                if keys[pygame.K_LEFT] or joy_left: dx = -SPEED; huong_phai = False; is_moving = True
                if keys[pygame.K_RIGHT] or joy_right: dx = SPEED; huong_phai = True; is_moving = True
                if (keys[pygame.K_UP] or keys[pygame.K_SPACE] or joy_jump) and not is_jumping:
                    is_jumping = True; dy = JUMP_STRENGTH
            
            if is_jumping or dy != 0:
                player_rect.y += dy; dy += GRAVITY
                if player_rect.y >= GROUND_Y - player_rect.height:
                    player_rect.y = GROUND_Y - player_rect.height; dy = 0; is_jumping = False
            else:
                player_rect.y = GROUND_Y - player_rect.height
            
            player_world_x += dx
            player_world_x = max(0, min(player_world_x, MAP_WIDTH - player_rect.width))
            map_offset_x = player_world_x - (SCREEN_WIDTH // 2)
            map_offset_x = max(0, min(map_offset_x, MAP_WIDTH - SCREEN_WIDTH))
            _map_offset_box[0] = map_offset_x  # cập nhật cho proxy Kamejoko
            player_rect.x = player_world_x - map_offset_x
            
            player_rect.world_x = player_world_x 
            # ====== [SSJ CAP 1] FX STEP (spawn/decay particles) ======
            if hanh_tinh == "Xayda" and _ssj2 and ssj_fx:
                try:
                    _charge_t = (ssj_charge / _ssj2.CHARGE_TIME) if (not ssj_active and ssj_charge > 0) else 0.0
                    ssj_fx.step(dt, player_rect.centerx, player_rect.centery, player_rect.bottom + 4,
                               charge_t=_charge_t, active=bool(ssj_active))
                except Exception:
                    pass

            if sidebar_state == "OPENING":
                sidebar_x += MENU_SPEED; sidebar_x = 0 if sidebar_x >= 0 else sidebar_x
                sidebar_state = "OPEN" if sidebar_x == 0 else sidebar_state
            elif sidebar_state == "CLOSING":
                sidebar_x -= MENU_SPEED; sidebar_x = -MENU_WIDTH if sidebar_x <= -MENU_WIDTH else sidebar_x
                sidebar_state = "CLOSED" if sidebar_x == -MENU_WIDTH else sidebar_state

        # ====== [KAMEJOKO] UPDATE FX + FIRE EVENT ======
        if kame_skill:
            # tay (hand) ở world coord để beam đúng với map_offset_x
            hand_sx = player_rect.centerx + (18 if huong_phai else -18)
            hand_sy = player_rect.y + 22
            kame_origin_world = pygame.Vector2(hand_sx + map_offset_x, hand_sy)
            if target_auto_attack and not target_auto_attack.is_dead:
                tpos = pygame.Vector2(target_auto_attack.rect.centerx + map_offset_x, target_auto_attack.rect.centery)
                d = tpos - kame_origin_world
                kame_aim_dir = d.normalize() if d.length_squared() > 1e-6 else pygame.Vector2(1 if huong_phai else -1, 0)
            else:
                kame_aim_dir = pygame.Vector2(1 if huong_phai else -1, 0)
        
            kame_skill.update(dt, kame_origin_world, kame_aim_dir)
            # Khi vừa bắn xong (hết gồng) -> kích hoạt hit logic của game (dùng attack_rect tầm 200)
            if kame_skill.consume_fire():
                kame_attack_now = True
                should_attack = True
                # ép vượt cooldown đấm để chạy block damage/drops/quest như bình thường
                last_attack_time = current_time - ATTACK_COOLDOWN - 1

        # ====== [MASENKO] UPDATE FX + IMPACT EVENT ======
        if masenko_skill:
            hand_sx = player_rect.centerx + (18 if huong_phai else -18)
            hand_sy = player_rect.y + 22
            masenko_origin_world = pygame.Vector2(hand_sx + map_offset_x, hand_sy)
            if target_auto_attack and not target_auto_attack.is_dead:
                tpos = pygame.Vector2(target_auto_attack.rect.centerx + map_offset_x, target_auto_attack.rect.centery)
                d = tpos - masenko_origin_world
                masenko_aim_dir = d.normalize() if d.length_squared() > 1e-6 else pygame.Vector2(1 if huong_phai else -1, 0)
            else:
                masenko_aim_dir = pygame.Vector2(1 if huong_phai else -1, 0)

            masenko_skill.update(dt, masenko_origin_world, masenko_aim_dir)
            if masenko_skill.consume_fire():
                masenko_attack_now = True
                try:
                    masenko_impact_pos = masenko_skill.get_last_impact_screen(map_offset_x)
                except Exception:
                    masenko_impact_pos = None

        # ====== [SSJ CAP 1] INPUT (2 cách: giữ LMB trên ô skill SSJ / giữ RMB khi đang chọn SSJ) ======
        ssj_trigger_hold = False
        if hanh_tinh == "Xayda" and _ssj2:
            try:
                import kynang as _kynang
                _kynang.ensure_player_skill_data(info)
                _slots = info.get("skill_slots", [None] * 5)
                _mx, _my = pygame.mouse.get_pos()
                _lmb = pygame.mouse.get_pressed(3)[0]
                _rmb = pygame.mouse.get_pressed(3)[2]
                # Cách 1: giữ LMB ngay trên ô chứa SSJ
                if _lmb and skill_bar_rects:
                    for _i in range(min(len(skill_bar_rects), len(_slots))):
                        if _slots[_i] == _ssj2.SSJ_SKILL_ID and skill_bar_rects[_i].collidepoint(_mx, _my):
                            ssj_trigger_hold = True
                            break
                # Cách 2: chọn SSJ làm active rồi giữ RMB
                if (not ssj_trigger_hold) and _rmb:
                    _sk = _kynang.get_active_skill(info)
                    if _sk and _sk.get("id") == _ssj2.SSJ_SKILL_ID:
                        ssj_trigger_hold = True
            except Exception:
                ssj_trigger_hold = False

            # Charge / Toggle
            if not ssj_active:
                if ssj_trigger_hold:
                    ssj_charge += dt
                    if ssj_charge >= _ssj2.CHARGE_TIME:
                        ssj_charge = _ssj2.CHARGE_TIME
                        ssj_active = True
                        info["ssj_active"] = True
                        info["ssj_charge"] = 0.0
                        ssj_hold_off = 0.0
                        info["ssj_hold_off"] = 0.0
                        # Nổ biến hình + rung đất (giống demo)
                        try:
                            if ssj_fx:
                                ssj_fx.trigger_transform(player_rect.centerx, player_rect.centery, player_rect.bottom + 4, power=1.0)
                        except Exception:
                            pass
                else:
                    ssj_charge = max(0.0, ssj_charge - dt * 1.4)
            else:
                # đang SSJ: giữ lại để tắt nhanh (tránh kẹt)
                if ssj_trigger_hold:
                    ssj_hold_off += dt
                    info["ssj_hold_off"] = ssj_hold_off
                    if ssj_hold_off >= _ssj2.TOGGLE_OFF_HOLD:
                        ssj_active = False
                        info["ssj_active"] = False
                        ssj_charge = 0.0
                        info["ssj_charge"] = 0.0
                        ssj_hold_off = 0.0
                        info["ssj_hold_off"] = 0.0
                        try:
                            if ssj_fx:
                                ssj_fx.trigger_power_down(player_rect.centerx, player_rect.centery, player_rect.bottom + 4)
                        except Exception:
                            pass
                else:
                    ssj_hold_off = 0.0
                    info["ssj_hold_off"] = 0.0

        # Max HP/KI hiệu lực theo SSJ (không làm tụt max vì không gọi refresh trong loop)
        ssj_mult_now = (_ssj2.SSJ_MULT if (hanh_tinh == "Xayda" and _ssj2 and ssj_active) else 1.0)
        total_max_hp_eff = int(total_max_hp * ssj_mult_now)
        total_max_ki_eff = int(total_max_ki * ssj_mult_now)
        # --- ATTACK ---
        if not is_dead_state and not is_ui_open and not is_stunned:
            if keys[pygame.K_j] or (ui_gamepad and ui_gamepad.consume_punch()): should_attack = True
            if target_auto_attack and not target_auto_attack.is_dead: 
                should_attack = True
                huong_phai = (target_auto_attack.rect.centerx > player_rect.centerx)
            else:
                target_auto_attack = None
                

        # ====== [KAMEJOKO] START CHARGE (chỉ khi đang chọn skill kamejoko) ======
        try:
            import kynang
            kynang.ensure_player_skill_data(info)
            _act = kynang.get_active_skill(info)
            _act_id = _act.get('id') if _act else None
        except Exception:
            _act_id = None
        
                # ====== [ATOMIC GOLD] CAST (bấm J / click quái: tự gồng 0.5s rồi bắn) ======

        if _act_id == 'atomic_gold' and atomic_skill:

            # chặn đấm thường/auto attack khi đang chọn Atomic

            should_attack = False



            hand_sx = player_rect.centerx + (18 if huong_phai else -18)

            hand_sy = player_rect.y + 22

            atomic_origin_world = pygame.Vector2(hand_sx + map_offset_x, hand_sy)



            if target_auto_attack and not target_auto_attack.is_dead:

                tpos = pygame.Vector2(target_auto_attack.rect.centerx + map_offset_x, target_auto_attack.rect.centery)

                d = tpos - atomic_origin_world

                atomic_aim_dir = d.normalize() if d.length_squared() > 1e-6 else pygame.Vector2(1 if huong_phai else -1, 0)

            else:

                atomic_aim_dir = pygame.Vector2(1 if huong_phai else -1, 0)



            if not is_dead_state and not is_ui_open and not is_stunned:

                # Ưu tiên: click quái (lock mục tiêu). Nếu không có click thì dùng target_auto_attack hiện tại.

                if atomic_key_req or atomic_click_req:

                    if info.get('ki', 0) < 2:

                        if current_time - last_ki_spam_time > 3000:

                            text_manager.add(player_world_x + 15, player_rect.y - 120, "Hết KI!", RED_ERROR)

                            last_ki_spam_time = current_time

                    else:

                        _proxy = None

                        try:

                            _t = atomic_click_target if atomic_click_req else target_auto_attack

                            if _t and (not getattr(_t, 'is_dead', False)):

                                _proxy = _WorldTargetProxy(_t, _map_offset_box)

                        except Exception:

                            _proxy = None



                        started = False

                        # API mới (atomic_v2): cast + consume_fire_token

                        try:

                            if _proxy is not None:

                                started = atomic_skill.cast(atomic_origin_world, target_obj=_proxy, aim_dir=atomic_aim_dir)

                            else:

                                started = atomic_skill.cast(atomic_origin_world, aim_dir=atomic_aim_dir)

                        except Exception:

                            # fallback API cũ (nếu Mikey chưa thay atomic.py bản mới)

                            try:

                                atomic_skill.set_ready(True)

                                if _proxy is not None:

                                    started = atomic_skill.request_cast(atomic_origin_world, target_obj=_proxy, aim_dir=atomic_aim_dir)

                                else:

                                    started = atomic_skill.request_cast(atomic_origin_world, aim_dir=atomic_aim_dir)

                            except Exception:

                                started = False



                        if started:

                            info['ki'] = max(0, info['ki'] - 2)

                            trigger_save_data()



            atomic_skill.update(dt, atomic_origin_world, atomic_aim_dir)



            # Khi vừa bắt đầu bắn -> kích hoạt hit logic của game (dùng attack_rect tầm 260)

            tok = None

            try:

                tok = atomic_skill.consume_fire_token()

            except Exception:

                tok = None

                try:

                    if atomic_skill.consume_fire():

                        tok = current_time  # giả token để không lặp liên tục

                except Exception:

                    tok = None



            if (tok is not None) and (tok != last_atomic_fire_token):

                last_atomic_fire_token = tok

                atomic_attack_now = True

                should_attack = True

                # ép vượt cooldown đấm để chạy block damage/drops/quest như bình thường

                last_attack_time = current_time - ATTACK_COOLDOWN - 1


        if _act_id == 'kamejoko' and kame_skill and not kame_attack_now:
            # nếu đang chọn Kamejoko -> gồng 1.5s rồi mới gây dame (beam tầm 200)
            # => chặn đấm thường trong lúc gồng/cooldown
            hand_sx = player_rect.centerx + (18 if huong_phai else -18)
            hand_sy = player_rect.y + 22
            kame_origin_world = pygame.Vector2(hand_sx + map_offset_x, hand_sy)
            if target_auto_attack and not target_auto_attack.is_dead:
                tpos = pygame.Vector2(target_auto_attack.rect.centerx + map_offset_x, target_auto_attack.rect.centery)
                d = tpos - kame_origin_world
                kame_aim_dir = d.normalize() if d.length_squared() > 1e-6 else pygame.Vector2(1 if huong_phai else -1, 0)
            else:
                kame_aim_dir = pygame.Vector2(1 if huong_phai else -1, 0)

            if should_attack:
                if info['ki'] < 2:
                    if current_time - last_ki_spam_time > 3000:
                        text_manager.add(player_world_x + 15, player_rect.y - 120, 'Hết KI!', RED_ERROR)
                        last_ki_spam_time = current_time
                else:
                    if target_auto_attack and not target_auto_attack.is_dead:
                        _proxy = _WorldTargetProxy(target_auto_attack, _map_offset_box)
                        started = kame_skill.request_cast(kame_origin_world, target_obj=_proxy)
                    else:
                        started = kame_skill.request_cast(kame_origin_world, aim_dir=kame_aim_dir)
                    if started:
                        info['ki'] = max(0, info['ki'] - 2)
                        trigger_save_data()
            should_attack = False


        # ====== [MASENKO] START CHARGE (chỉ khi đang chọn skill masenko) ======
        if _act_id == 'masenko' and masenko_skill and not masenko_attack_now:
            hand_sx = player_rect.centerx + (18 if huong_phai else -18)
            hand_sy = player_rect.y + 22
            masenko_origin_world = pygame.Vector2(hand_sx + map_offset_x, hand_sy)

            if target_auto_attack and not target_auto_attack.is_dead:
                tpos = pygame.Vector2(target_auto_attack.rect.centerx + map_offset_x, target_auto_attack.rect.centery)
                d = tpos - masenko_origin_world
                masenko_aim_dir = d.normalize() if d.length_squared() > 1e-6 else pygame.Vector2(1 if huong_phai else -1, 0)
            else:
                masenko_aim_dir = pygame.Vector2(1 if huong_phai else -1, 0)

            if should_attack:
                if info.get('ki', 0) < 2:
                    if current_time - last_ki_spam_time > 3000:
                        text_manager.add(player_world_x + 15, player_rect.y - 120, 'Hết KI!', RED_ERROR)
                        last_ki_spam_time = current_time
                else:
                    started = False
                    try:
                        if target_auto_attack and not target_auto_attack.is_dead:
                            _proxy = _WorldTargetProxy(target_auto_attack, _map_offset_box)
                            started = masenko_skill.request_cast(masenko_origin_world, target_obj=_proxy, aim_dir=masenko_aim_dir)
                        else:
                            started = masenko_skill.request_cast(masenko_origin_world, aim_dir=masenko_aim_dir)
                    except Exception:
                        started = False

                    if started:
                        info['ki'] = max(0, info.get('ki', 0) - 2)
                        trigger_save_data()

            should_attack = False

        if should_attack and current_time - last_attack_time > ATTACK_COOLDOWN and not is_dead_state:
            if info["ki"] < 2 and not kame_attack_now and not atomic_attack_now:
                if current_time - last_ki_spam_time > 3000:
                    text_manager.add(player_world_x + 15, player_rect.y - 120, "Hết KI!", RED_ERROR)
                    last_ki_spam_time = current_time
                should_attack = False
            else:
                if kame_attack_now:
                    # [KAMEJOKO] bắn theo beam: không trừ KI ở đây (đã trừ khi bắt đầu gồng)
                    kame_attack_now = False
                    last_attack_time = current_time
                    attack_range = 200
                    attack_rect = pygame.Rect(
                        player_rect.right if huong_phai else player_rect.left - attack_range,
                        player_rect.y - 10,
                        attack_range, 80
                    )
                elif atomic_attack_now:
                    # [ATOMIC GOLD] bắn beam ngắn: không trừ KI ở đây (đã trừ khi bắt đầu gồng)
                    atomic_attack_now = False
                    last_attack_time = current_time

                    attack_range = 260
                    attack_rect = pygame.Rect(
                        player_rect.right if huong_phai else player_rect.left - attack_range,
                        player_rect.y - 18,
                        attack_range, 96
                    )

                elif masenko_attack_now:
                    # [MASENKO] quả cầu đỏ nổ tại điểm impact: không trừ KI ở đây (đã trừ khi bắt đầu gồng)
                    masenko_attack_now = False
                    last_attack_time = current_time

                    if masenko_impact_pos is not None:
                        ix, iy = masenko_impact_pos
                        try:
                            ix = int(ix); iy = int(iy)
                        except Exception:
                            ix = int(player_rect.centerx); iy = int(player_rect.centery)
                        attack_rect = pygame.Rect(ix - 60, iy - 60, 120, 120)
                    else:
                        attack_range = 200
                        attack_rect = pygame.Rect(
                            player_rect.right if huong_phai else player_rect.left - attack_range,
                            player_rect.y - 10,
                            attack_range, 80
                        )

                else:
                    info["ki"] = max(0, info["ki"] - 2)
                    trigger_save_data()
                    last_attack_time = current_time
                    effect_manager.add_fist(player_world_x, player_rect.y, huong_phai)
                
                    attack_range = 60
                    attack_rect = pygame.Rect(
                        player_rect.right if huong_phai else player_rect.left - attack_range,
                        player_rect.y - 5,
                        attack_range, 60
                    )
                _sd_eff = int(current_stats['suc_danh'] * ssj_mult_now) if (hanh_tinh == 'Xayda' and ssj_active) else int(current_stats['suc_danh'])
                calc_dmg, is_crit = calculate_player_damage(_sd_eff, current_stats['chi_mang'])
                
                # --- [KY NANG] Áp dụng % sát thương theo kỹ năng đang chọn ---
                # (Cấp 1: 100% = như đấm thường; sau này Mikey nâng cấp chỉ cần tăng damage_pct)
                try:
                    import kynang
                    kynang.ensure_player_skill_data(info)
                    _sk = kynang.get_active_skill(info)
                    if _sk:
                        _pct = int(_sk.get('damage_pct', 100))
                        calc_dmg = max(1, int(calc_dmg * _pct / 100))
                except Exception:
                    pass

                targets = [target_auto_attack] if target_auto_attack and not target_auto_attack.is_dead else list_moc_nhan + [q for q in list_quai_map_2 if not q.is_dead]
                
                # [NEW] Thêm Broly vào danh sách đánh
                if broly_manager and broly_manager.boss and not broly_manager.boss.is_dead:
                    targets.append(broly_manager.boss)
                
                for target in targets:
                    if target in list_quai_map_2 or (broly_manager and target == broly_manager.boss):
                        if hasattr(target, 'name_display'): 
                            target.update(map_offset_x, player_rect, player_world_x)
                        else: 
                            target.update(map_offset_x, False)
                    else: 
                        target.update(map_offset_x)

                    if target.rect.inflate(30, 30).colliderect(attack_rect):
                        is_mn = (target in list_moc_nhan)
                        m_type = "MOC_NHAN" if is_mn else "QUAI_MAP2"

                        if is_mn: 
                            dmg = calc_dmg; tnsm = 1; crit_show = is_crit; target.take_damage(dmg) 
                            if hasattr(target, 'level'): target.level = 1 
                        else: 
                            hp_truoc_khi_danh = target.hp
                            target.take_damage(calc_dmg)
                            real_hp_lost = min(calc_dmg, hp_truoc_khi_danh)
                            real_hp_lost = max(0, real_hp_lost)

                            dmg = calc_dmg 
                            bonus_multiplier = 2 if random.randint(1, 100) <= 30 else 1
                            tnsm = int(real_hp_lost * bonus_multiplier)
                            crit_show = is_crit
                            if hasattr(target, 'last_hit_time'): target.last_hit_time = current_time
                        
                        effect_manager.add_slash(target.rect.x + map_offset_x, target.rect.y, target.rect.width, target.rect.height)
                        d_col = (255, 255, 0) if crit_show else RED_ERROR
                        text_manager.add(target.rect.centerx + map_offset_x, target.rect.y - 20, f"{'!' if crit_show else '-'}{dmg}", d_col)
                        
                        info["suc_manh"] += tnsm
                        info["tiem_nang"] += tnsm 
                        text_manager.add(player_world_x + 15, player_rect.y - 40, f"+{tnsm}", (0, 255, 0))
                        trigger_save_data()
                        is_broly = False
                        if target.hp <= 0:
                        # --- 1. KIỂM TRA XEM CÓ PHẢI BROLY KHÔNG ---
                        # Dùng hasattr để tránh lỗi crash nếu quái không có tên
                            boss_type = getattr(target, "boss_type", None)
                            boss_name_display = getattr(target, "name_display", "")
                            is_broly = (boss_type in ("broly", "superbroly")) or (boss_name_display in ("Broly", "Super Broly"))
                            if is_broly:
                                # [NEW] Nhận đệ khi hạ Super Broly (nếu chưa có đệ)
                                if detucoban:
                                    try:
                                        bt = str(boss_type).lower() if boss_type is not None else ""
                                        bn = str(boss_name_display)
                                        is_super = ("super" in bt) or (bn == "Super Broly") or ("Super" in bn and "Broly" in bn)
                                        if is_super:
                                            detucoban.on_superbroly_defeated(player_rect, player_world_x, GROUND_Y, current_time)
                                    except Exception:
                                        pass
                                # [DROP BROLY]
                                drops = target.get_drops()
                                for drop in drops:
                                    if drop.get('type') == 'ITEM':
                                        drop_manager.add_item(target.rect.centerx + map_offset_x, target.rect.bottom, drop['data'])
                                    else:
                                        drop_manager.add_gold(target.rect.centerx + map_offset_x, target.rect.bottom, drop['amount'])
                                text_manager.add(player_world_x, player_rect.y - 100, f"{str(boss_name_display).upper()} ĐÃ BỊ HẠ GỤC!", GREEN_SUCCESS)
                            else:
                                # [DROP THƯỜNG]
                                drop_manager.generate_drop(target.rect.x + map_offset_x, target.rect.bottom, m_type)

                            # --- 2. TÍNH NHIỆM VỤ (QUEST) ---
                            is_boss = hasattr(target, 'name_display') # Kiểm tra xem có phải Boss bất kỳ không

                            if is_boss:
                                if not is_broly: # Nếu là Boss Lỗi (không phải Broly)
                                    boss_death_time = pygame.time.get_ticks()
                                    if nhiemvu.check_mission_progress(info, "BOSS"):
                                        trigger_save_data()
                            else:
                                # Quái thường (Không phải Boss)
                                if is_mn: # Mộc nhân
                                    if nhiemvu.check_mission_progress(info, "MOC_NHAN"): trigger_save_data()
                                else: # Quái Map 2 (Heo, Gấu...)
                                    # [ĐÃ SỬA LỖI] Không cần check name_display != Broly ở đây nữa
                                    if nhiemvu.check_mission_progress(info, "QUAI_MAP2"): trigger_save_data()

                            if target == target_auto_attack:
                                target_auto_attack = None
                        ui_target_monster = target
                        ui_display_timer = current_time
                        break

        # ====== DRAW WORLD ======
        if is_map_1:
            npclang.draw_npc(screen, map_offset_x, GROUND_Y, hanh_tinh)
            npcbando.draw_npc(screen, map_offset_x, GROUND_Y, hanh_tinh)
            npcanxin.draw_npc(screen, map_offset_x, GROUND_Y)
            npc_bhatmit.rect.x = NPC_BHATMIT_X - map_offset_x
            npc_bhatmit.draw(screen, map_offset_x)

        # [NEW] NPC Olong (chỉ Map 2)
        if is_map_2 and npcolong:
            npcolong.draw_npc(screen, map_offset_x, GROUND_Y, current_time=current_time)
        
        # [NEW] Đệ tử: AI theo trạng thái (Đi theo / Bảo vệ / Tấn công / Về nhà)
        # + tự hồi HP khi rảnh (logic nằm trong detucoban)
        if detucoban:
            try:
                boss_list = []
                try:
                    if broly_manager and getattr(broly_manager, "boss", None) is not None:
                        boss_list.append(broly_manager.boss)
                except Exception:
                    pass
                try:
                    if is_map_2 and 'boss' in locals() and boss is not None:
                        boss_list.append(boss)
                except Exception:
                    pass

                # --- [KY NANG] Đệ tử random học 1 trong 3 đấm NGAY KHI BẮT ĐƯỢC ĐỆ (1 lần / 1 con) ---
                # -> có đệ mới (hoặc bắt lại) thì roll lại; chưa có đệ thì xóa đòn đệ để khỏi hiện lung tung
                try:
                    _det_tmp = detucoban.get_det() if hasattr(detucoban, 'get_det') else None

                    if _det_tmp is None:
                        info.pop('detu_skill_id', None)
                        info.pop('_detu_skill_roll_key', None)
                    else:
                        _pet_key = (
                            f"{int(getattr(_det_tmp, 'hp_max', 0))}|"
                            f"{int(getattr(_det_tmp, 'ki_max', 0))}|"
                            f"{int(getattr(_det_tmp, 'suc_danh', 0))}|"
                            f"{int(getattr(_det_tmp, 'tiem_nang', 0))}|"
                            f"{int(getattr(_det_tmp, 'suc_manh', 0))}"
                        )
                        if info.get('_detu_skill_roll_key') != _pet_key:
                            _sid = random.choice(['td_galick_1', 'xd_dragon_1', 'nm_demon_1'])
                            info['detu_skill_id'] = _sid
                            info['detu_skill_slot'] = 0  # hàng 4 ô, ô số 1 (index=0)
                            info['_detu_skill_roll_key'] = _pet_key

                            # thông báo cho "hồi hộp" như NRO
                            try:
                                import kynang
                                _sk = kynang.get_skill_by_id(_sid) if hasattr(kynang, 'get_skill_by_id') else None
                                _nm = _sk.get('name') if (_sk and isinstance(_sk, dict)) else _sid
                                text_manager.add(player_world_x, player_rect.y - 70, f"Đệ học: {_nm}!", (255, 255, 0))
                            except Exception:
                                pass
                except Exception:
                    pass



                # [FIX] Khi đang hợp thể: không update AI của đệ để tránh hiện dame đệ
                fusion_active_now = False
                try:
                    fusion_active_now = bool(luonglongnhatthe and info and luonglongnhatthe.is_fusion_active(info))
                except Exception:
                    fusion_active_now = False

                if fusion_active_now:
                    # cố gắng tắt đệ gây dame (nếu detucoban có hỗ trợ)
                    try:
                        if hasattr(detucoban, 'set_attack_enabled'):
                            detucoban.set_attack_enabled(False)
                        if hasattr(detucoban, 'pause_ai'):
                            detucoban.pause_ai(True)
                        if hasattr(detucoban, 'set_enabled'):
                            detucoban.set_enabled(False)
                        if hasattr(detucoban, 'set_invulnerable'):
                            detucoban.set_invulnerable(True)
                    except Exception:
                        pass
                else:
                    # bật lại (nếu module có)
                    try:
                        if hasattr(detucoban, 'set_attack_enabled'):
                            detucoban.set_attack_enabled(True)
                        if hasattr(detucoban, 'pause_ai'):
                            detucoban.pause_ai(False)
                        if hasattr(detucoban, 'set_enabled'):
                            detucoban.set_enabled(True)
                        if hasattr(detucoban, 'set_invulnerable'):
                            detucoban.set_invulnerable(False)
                    except Exception:
                        pass

                    detucoban.update_ai(
                    player_rect=player_rect,
                    player_world_x=player_world_x,
                    ground_y=GROUND_Y,
                    map_offset_x=map_offset_x,
                    current_time=current_time,
                    mobs=list_quai_map_2 if is_map_2 else [],
                    moc_nhan_list=list_moc_nhan,
                    boss_list=boss_list,
                    text_manager=text_manager,
                    effect_manager=effect_manager,
                )
            except Exception:
                # fallback: nếu detucoban phiên bản cũ (nhưng đang hợp thể thì không update đệ)
                _fusion_block = False
                try:
                    _fusion_block = bool(luonglongnhatthe and info and luonglongnhatthe.is_fusion_active(info))
                except Exception:
                    _fusion_block = False
                if not _fusion_block:
                    try:
                        detucoban.update_follow(player_rect, player_world_x, GROUND_Y)
                    except Exception:
                        detucoban.update_follow(player_rect)
            # [NEW] khi hợp thể: ẩn đệ (tránh vẽ đè)
            try:
                if not (luonglongnhatthe and info and luonglongnhatthe.is_fusion_active(info)):
                    detucoban.draw_det(screen, map_offset_x)
            except Exception:
                detucoban.draw_det(screen, map_offset_x)
        drop_manager.draw(screen, map_offset_x)

        for mn in list_moc_nhan: 
            mn.update(map_offset_x)
            if hasattr(mn, 'level'): mn.level = 1 
            mn.draw(screen)
        if target_auto_attack and target_auto_attack in list_moc_nhan:
            target_auto_attack.draw_target_indicator(screen)

        # --- QUÁI ĐÁNH NGƯỜI ---
        can_take_damage = (current_time - last_quai_attack_time > QUAI_ATTACK_COOLDOWN)
        
        for quai in list_quai_map_2:
            in_range = abs(quai.world_x - player_world_x) <= 400 
            is_boss = hasattr(quai, 'name_display') 
            if is_boss:
                quai.update(map_offset_x, player_rect, player_world_x)
            else:
                quai.update(map_offset_x, in_range, player_rect)
            
            if not quai.is_dead:
                quai.draw(screen)
                if quai == target_auto_attack:
                    quai.draw_target_indicator(screen)
                
                if not is_boss and can_take_damage and not is_dead_state:
                    attack_hitbox = quai.rect.inflate(20, 10)
                    if attack_hitbox.colliderect(player_rect):
                        q_dmg = quai.calculate_attack_damage()
                        final_q_dmg = max(1, q_dmg - current_stats.get('giap', 0))
                        
                        if random.randint(1, 100) < current_stats.get('ne_tranh', 0):
                            text_manager.add(player_world_x, player_rect.y - 80, "Hụt", (200, 200, 200))
                        else:
                            if max(0, info["hp"] - final_q_dmg) < info["hp"]:
                                player_last_damage_time = current_time 
                            info["hp"] = max(0, info["hp"] - final_q_dmg)
                            effect_manager.add_monster_hit(player_rect.centerx, player_rect.centery)
                            text_manager.add(player_world_x, player_rect.y - 80, f"-{final_q_dmg}", RED_ERROR)
                            trigger_save_data()
                        last_quai_attack_time = current_time 
                        can_take_damage = False 

        # [NEW] BROLY ĐÁNH NGƯỜI
        if broly_manager and not is_dead_state:
            # Boss Broly tự có cooldown đánh trong class của nó, ta chỉ cần check
            broly_dmg = broly_manager.check_attack(player_rect)
            if broly_dmg > 0:
                final_dmg = max(1, broly_dmg - current_stats.get('giap', 0))
                # Né tránh
                if random.randint(1, 100) < current_stats.get('ne_tranh', 0):
                    text_manager.add(player_world_x, player_rect.y - 80, "Hụt", (200, 200, 200))
                else:
                    info["hp"] = max(0, info["hp"] - final_dmg)
                    player_last_damage_time = current_time
                    effect_manager.add_monster_hit(player_rect.centerx, player_rect.centery)
                    text_manager.add(player_world_x, player_rect.y - 80, f"-{final_dmg}", RED_ERROR)
                    trigger_save_data()
        
        # --- ANIMATION ---
        if is_moving or is_jumping:
            if pygame.time.get_ticks() - anim_timer > 120:
                frame_index += 1
                anim_timer = pygame.time.get_ticks()
        else:
            frame_index = 0
        
        if is_dead_state:
        
            die.draw_ghost(screen, player_rect, huong_phai, frame_index)
        
        else:
        
            # [NEW] Ưu tiên vẽ hợp thể (thay thế nhân vật gốc)
        
            if luonglongnhatthe and info and luonglongnhatthe.is_fusion_active(info):
        
                try:
        
                    # lưu trạng thái move/jump để anim mượt
        
                    info['_fusion_is_moving'] = bool(is_moving)
        
                    info['_fusion_is_jumping'] = bool(is_jumping)
        
                    info['_fusion_face_right'] = bool(huong_phai)
        
                except Exception:
        
                    pass
        
        
        
                if luonglongnhatthe.is_fusion_merged(info):
        
                    # đã merged -> vẽ nhân vật hợp thể
        
                    luonglongnhatthe.draw_fused_character(
        
                        screen, info, player_rect,
        
                        is_moving=is_moving, is_jumping=is_jumping,
        
                        huong_phai=huong_phai,
        
                        tick=current_time,
        
                    )
        
                else:
        
                    # đang hiệu ứng -> KHÔNG vẽ nhân vật gốc (fx sẽ vẽ bóng trắng + flash)
        
                    pass
        
            else:
        
                # bình thường -> vẽ nhân vật gốc
                # ====== [SSJ CAP 1] AURA (glow + boom + dust/wave) - vẽ TRƯỚC nhân vật để không che người ======
                _sx = _sy = 0
                if hanh_tinh == "Xayda" and _ssj2 and ssj_fx:
                    try:
                        _sx, _sy = ssj_fx.get_shake_offset()
                        _charge_t = (ssj_charge / _ssj2.CHARGE_TIME) if (not ssj_active and ssj_charge > 0) else 0.0
                        ssj_fx.render_under(screen, player_rect.centerx + _sx, player_rect.centery + _sy, player_rect.bottom + 4 + _sy,
                                            charge_t=_charge_t, active=bool(ssj_active))
                    except Exception:
                        _sx = _sy = 0
        
                if hanh_tinh == "Trai Dat": ve_goku(screen, player_rect.x, player_rect.y, huong_phai=huong_phai, frame_index=frame_index)
        
                elif hanh_tinh == "Namec": ve_piccolo(screen, player_rect.x, player_rect.y, huong_phai=huong_phai, frame_index=frame_index)
        
                elif hanh_tinh == "Xayda": ve_vegeta(screen, player_rect.x + _sx, player_rect.y + _sy, huong_phai=huong_phai, frame_index=frame_index, ssj_level=(1 if ssj_active else 0))
                try:
                    if hanh_tinh == "Xayda" and _ssj2 and ssj_fx:
                        ssj_fx.render_flash(screen)
                except Exception:
                    pass

        
        
        
            # [NEW] FX hợp thể (nháy trắng màn hình + bóng trắng)
        
            try:
        
                if luonglongnhatthe and info:
        
                    _det_rect = None
        
                    try:
        
                        _det_rect = detucoban.get_rect(player_rect) if detucoban and hasattr(detucoban, 'get_rect') else None
        
                    except Exception:
        
                        _det_rect = None
        
                    luonglongnhatthe.draw_world_fx(screen, info, player_rect, det_rect=_det_rect, now_tick=current_time)
        
            except Exception:
        
                pass
            if is_stunned:
                star_cx = player_rect.centerx
                star_cy = player_rect.top - 15
                for i in range(3):
                    angle = (current_time * 0.01 + i * 2) 
                    sx = star_cx + math.cos(angle) * 15
                    sy = star_cy + math.sin(angle) * 5
                    pygame.draw.circle(screen, (255, 255, 0), (int(sx), int(sy)), 4)

        # [NEW] VẼ BOSS BROLY
        if broly_manager:
            broly_manager.draw(screen, map_offset_x)
            if broly_manager and getattr(broly_manager, 'boss', None) is not None and broly_manager and getattr(broly_manager, 'boss', None) is not None and target_auto_attack and target_auto_attack== broly_manager.boss:
                broly_manager.boss.draw_target_indicator(screen)
        # -------------------

        # --- GATEWAY ---
        gsx = GATEWAY_X_WORLD - map_offset_x
        if -GATEWAY_WIDTH < gsx < SCREEN_WIDTH:
            g_s = pygame.Surface((GATEWAY_WIDTH, GATEWAY_HEIGHT), pygame.SRCALPHA)
            pygame.draw.ellipse(g_s, (0, 200, 255, 150), (0, 0, GATEWAY_WIDTH, GATEWAY_HEIGHT))
            pygame.draw.ellipse(g_s, (100, 255, 255), (5, 5, GATEWAY_WIDTH - 10, GATEWAY_HEIGHT - 10), 3) 
            screen.blit(g_s, (gsx, GATEWAY_Y_GROUND - GATEWAY_HEIGHT))
            ts = font_gateway.render(destination_name, True, (255, 255, 0))
            s_bg = pygame.Surface((ts.get_width() + 8, ts.get_height() + 8), pygame.SRCALPHA)
            s_bg.fill((0, 0, 0, 160))
            screen.blit(s_bg, (gsx + (GATEWAY_WIDTH - ts.get_width())//2 - 4, GATEWAY_Y_GROUND - GATEWAY_HEIGHT - 29))
            screen.blit(ts, (gsx + (GATEWAY_WIDTH - ts.get_width())//2, GATEWAY_Y_GROUND - GATEWAY_HEIGHT - 25))

        p_wr = pygame.Rect(player_world_x - player_rect.width//2, player_rect.y, player_rect.width, player_rect.height)
        g_wr = pygame.Rect(GATEWAY_X_WORLD, GATEWAY_Y_GROUND - GATEWAY_HEIGHT, GATEWAY_WIDTH, GATEWAY_HEIGHT)
        if p_wr.colliderect(g_wr) and not is_dead_state:
            if not is_transferring: 
                is_transferring = True
                countdown_timer = current_time
                text_manager.add(player_world_x + 15, player_rect.y - 40, "Bắt đầu dịch chuyển...", (0, 255, 255))
            tl = COUNTDOWN_DURATION - (current_time - countdown_timer)
            sl = max(0, math.ceil(tl / 1000))
            if sl > 0 and (current_time - last_attack_time) > 200: 
                text_manager.add(player_world_x + 15, player_rect.y - 80, str(sl), (255, 255, 0))
                last_attack_time = current_time 
            if tl <= 0:
                info["inventory"] = current_inventory
                info["chest"] = current_chest
                info["world_x"] = TARGET_GATEWAY_POS_X
                info["map_id"] = TARGET_MAP_ID
                d_sv = load_json(DATA_CHAR_FILE)
                d_sv.setdefault(username_acc, {})[ten_nv] = info
                save_json(DATA_CHAR_FILE, d_sv)
                return TARGET_MAP_ID
        elif is_transferring: 
            is_transferring = False
            countdown_timer = 0
            text_manager.add(player_world_x + 15, player_rect.y - 40, "Đã Hủy Dịch Chuyển!", (255, 100, 100))
        
        # ====== HUD / UI ======
        # [KAMEJOKO] DRAW (beam + pose gồng 2 tay)
        if kame_skill:
            kame_skill.draw(screen, kame_origin_world, kame_aim_dir, cam=(map_offset_x, 0), player_rect=player_rect, facing_right=huong_phai)

        # [ATOMIC GOLD] DRAW
        if atomic_skill:
            atomic_skill.draw(screen, cam_off=pygame.Vector2(-map_offset_x, 0))


        # [MASENKO] DRAW
        if masenko_skill:
            masenko_skill.draw(screen, cam_off=pygame.Vector2(-map_offset_x, 0))

        effect_manager.draw(screen, map_offset_x)
        text_manager.draw(screen, map_offset_x)
        chat_system.draw_messages_above_head(screen, player_rect)

        ve_thanh_trang_thai(
            screen, ten_nv, hanh_tinh, hp, total_max_hp_eff, ki, total_max_ki_eff,
            vang_current, kim_cuong_current, vnd_current,
            current_stats.get('suc_manh', 0), is_vip, current_time
        ) 
        
        # --- BOSS TIMER (Boss Lỗi cũ) ---
        if is_map_2 and boss and boss.is_dead:
            THOI_GIAN_HOI_SINH = 60000 
            time_passed = current_time - boss_death_time
            remaining = max(0, (THOI_GIAN_HOI_SINH - time_passed) // 1000)

            if remaining > 0:
                screen_timer_x = boss.home_x - map_offset_x + 20
                screen_timer_y = GROUND_Y - 200
                txt_str = str(remaining)
                txt_outline = font_huge.render(txt_str, True, BLACK)
                offsets = [(-2, -2), (-2, 0), (-2, 2), (0, -2), (0, 2), (2, -2), (2, 0), (2, 2)]
                for ox, oy in offsets:
                    screen.blit(txt_outline, (screen_timer_x + ox, screen_timer_y + oy))
                txt_main = font_huge.render(txt_str, True, RED_TITLE)
                screen.blit(txt_main, (screen_timer_x, screen_timer_y))

        if pygame.time.get_ticks() - pickup_msg_timer < 1500 and pickup_msg != "":
            ts = font_small.render(pickup_msg, True, (255, 255, 0))
            screen.blit(ts, (player_rect.centerx - ts.get_width()//2, player_rect.y - 40))

        if ui_target_monster and (current_time - ui_display_timer < 3000) and not is_dead_state:
            if ui_target_monster.hp > 0: 
                if ui_target_monster in list_quai_map_2: 
                    if hasattr(ui_target_monster, 'name_display'): ui_target_monster.update(map_offset_x, None) 
                    else: ui_target_monster.update(map_offset_x, False)
                elif broly_manager and getattr(broly_manager, 'boss', None) is not None and broly_manager and ui_target_monster== broly_manager.boss:
                    # Broly UI update
                    pass
                else:
                    ui_target_monster.update(map_offset_x)
                monster_ui.draw(screen, ui_target_monster)
            else:
                ui_target_monster = None

        btn_toggle_rect_out, _ = draw_sidebar_menu(screen, sidebar_x, ten_nv, hanh_tinh, hp, total_max_hp_eff, ki, total_max_ki_eff, current_stats, info=info)
        # --- [KY NANG] Thanh kỹ năng NHÂN VẬT (vẽ TRƯỚC các bảng để bảng/UI đè lên) ---
        try:
            import kynang
            kynang.ensure_player_skill_data(info)
            skill_bar_rects = (ui_gamepad.get_skill_slot_rects() if ui_gamepad else None)  # moved to right-side slots
        except Exception:
            pass

        bag_icon_rect = tuido.draw_bag_icon(screen, 320, 10) 
        


        # [NEW] Auto close bag menu khi bấm HỢP THỂ (đóng 1 lần, không khóa túi đồ)

        try:

            if info and info.get('_close_bag_menu'):

                bag_menu_open = False

                info['_close_bag_menu'] = False

        except Exception:

            pass

        if bag_menu_open: 
            ds = current_inventory if bag_menu_tab == "TUI_DO" else current_chest if bag_menu_tab == "RUONG" else []
            tuido.draw_main_menu_full(screen, bag_menu_tab, SCREEN_WIDTH, SCREEN_HEIGHT, mode=menu_mode, data_list=ds, ITEM_TEMPLATES=ITEM_TEMPLATES, dragging_index=dragging_item_index, player_info=info)
            
            if bag_menu_tab == "TUI_DO" and menu_mode == "NORMAL":
                ui_x = (SCREEN_WIDTH - tuido.UI_WIDTH) // 2
                ui_y = (SCREEN_HEIGHT - tuido.UI_HEIGHT) // 2
                trangbi.draw_equipment_slots(screen, info, ui_x, ui_y, tuido.UI_WIDTH, tuido.UI_HEIGHT, ITEM_TEMPLATES, font_tiny)
            
            if getattr(tuido, 'upgrade_manager', None) and tuido.upgrade_manager.show_popup:
                tuido.upgrade_manager.draw_popup(screen, info)

        if show_welcome and pygame.time.get_ticks() - game_start_time > 500:
            if textthongbao.draw_notification_box_manual(screen, f"CHAO MUNG TRO LAI, {ten_nv}!", "Mikey chuc ban choi game vui ve!", "(Dev Duong Anh)", SCREEN_WIDTH, SCREEN_HEIGHT, event_list): 
                show_welcome = False 

        if show_quest_dialog:
            q_data = info.get("quest", {"id": 0})
            current_q_id = q_data.get("id", 0)

            quest_btn_rect, quest_box_rect = nhiemvu.draw_quest_dialog(
                screen, SCREEN_WIDTH, SCREEN_HEIGHT,
                hanh_tinh, quest_step,
                font, font_small,
                current_q_id, info
            )
        else:
            quest_btn_rect, quest_box_rect = None, None

        if show_shop_dialog:
            current_shop_ui = npcbando.draw_shop_menu(screen, SCREEN_WIDTH, SCREEN_HEIGHT, ITEM_TEMPLATES_REF=ITEM_TEMPLATES, player_inventory=current_inventory)
            if selected_sell_item:
                popup_w, popup_h = 250, 180
                popup_x = (SCREEN_WIDTH - popup_w) // 2
                popup_y = (SCREEN_HEIGHT - popup_h) // 2
                pygame.draw.rect(screen, (40, 40, 50), (popup_x, popup_y, popup_w, popup_h), border_radius=10)
                pygame.draw.rect(screen, C_VANG, (popup_x, popup_y, popup_w, popup_h), 2, border_radius=10)
                template = ITEM_TEMPLATES.get(selected_sell_item['key'])
                name = template['name'] if template else "Vật phẩm lạ"
                t_surf = font_small.render(name, True, (0, 255, 255))
                screen.blit(t_surf, (popup_x + (popup_w - t_surf.get_width())//2, popup_y + 10))
                q_surf = font_small.render("Bạn có muốn bán vật phẩm?", True, WHITE)
                screen.blit(q_surf, (popup_x + 20, popup_y + 40))
                p_surf = font_small.render(f"Giá: {sell_price:,} Vàng", True, C_VANG)
                screen.blit(p_surf, (popup_x + (popup_w - p_surf.get_width())//2, popup_y + 65))
                btn_sell_rect = pygame.Rect(popup_x + 30, popup_y + 110, 80, 40)
                ve_nut_custom(screen, btn_sell_rect, GREEN_SUCCESS, "BÁN", WHITE)
                btn_cancel_rect = pygame.Rect(popup_x + 140, popup_y + 110, 80, 40)
                ve_nut_custom(screen, btn_cancel_rect, RED_ERROR, "HỦY", WHITE)

        if show_anxin_shop: 
            current_anxin_ui = (npcanxin.draw_shop_menu(screen, SCREEN_WIDTH, SCREEN_HEIGHT), npcanxin.get_item_slots(SCREEN_WIDTH, SCREEN_HEIGHT))

        if selected_shop_item: 
            item_buy_popup.draw_buy_popup(screen, selected_shop_item, ITEM_TEMPLATES, SCREEN_WIDTH, SCREEN_HEIGHT, font, font_small, vang_current, kim_cuong_current, vnd_current)
        
        if bag_item_popup_data: 
            popup_rect_info, close_info_rect = dapdo_nhanpham.draw_item_info_popup(screen, bag_item_popup_data, SCREEN_WIDTH // 2 - 225, SCREEN_HEIGHT // 2 - 175)
            px, py = SCREEN_WIDTH // 2 - 225, SCREEN_HEIGHT // 2 - 175
            btn_action_rect = pygame.Rect(px + 175, py + 240, 100, 40)
            is_equipped = bag_item_popup_data.get('is_equipped', False)
            btn_text = "THÁO" if is_equipped else "TRANG BỊ"
            btn_color = trangbi.RED_BTN if is_equipped else trangbi.GREEN_BTN
            template_check = ITEM_TEMPLATES.get(bag_item_popup_data.get('key'))
            is_gear = trangbi.get_target_slot_index(template_check) != -1
            if is_gear or is_equipped:
                trangbi.ve_nut_custom_local(screen, btn_action_rect, btn_color, btn_text, WHITE, font_btn)

        if show_vip_popup: 
            mothanhvien.draw_vip_popup(screen, SCREEN_WIDTH, SCREEN_HEIGHT, font, font_small, info, mouse_pos)

        if show_vip_success_popup:
            s = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            s.fill((0, 0, 0, 180))
            screen.blit(s, (0,0))
            pygame.draw.rect(screen, DARK_GRAY, ((SCREEN_WIDTH-400)//2, (SCREEN_HEIGHT-200)//2, 400, 200), border_radius=10)
            l = font_small.render("CHUC MUNG! MO THANH VIEN THANH CONG!", True, GREEN_SUCCESS)
            screen.blit(l, (SCREEN_WIDTH//2 - l.get_width()//2, (SCREEN_HEIGHT-200)//2 + 60))
            ve_nut_custom(screen, pygame.Rect((SCREEN_WIDTH-400)//2 + 150, (SCREEN_HEIGHT-200)//2 + 130, 100, 40), BLUE_UI, "DONG", WHITE)

        if npc_bhatmit.show_upgrade_ui: 
            npc_bhatmit.upgrade_ui.draw(screen)

        respawn_screen.draw(screen)
        dapdo_nhanpham.toast_manager.draw(screen)
        chat_system.draw_ui(screen)

       
        # [NEW] UI Olong (vẽ trên cùng)
        if is_map_2 and npcolong:
            npcolong.draw_ui_if_open(screen, broly_manager, current_time=current_time)

        # ====== [NUT DIEU KHIEN] DRAW OVERLAY ======
        if ui_gamepad:
            ui_gamepad.draw(screen, player_info=info)

        pygame.display.flip()


# --- ADMIN PANEL FUNCTION (FIXED) ---
def admin_panel(screen):
    running = True; current_tab = "ACCOUNTS"; current_sub_tab = "VU_KHI" 
    mk_user_input = InputBox(350, 70, 150, 30, text=""); admin_mk_new_input = InputBox(520, 550, 150, 30, text="", is_password=True); btn_change_admin_mk = pygame.Rect(680, 550, 110, 30)
    key_input_box_vp = InputBox(170, 500, 450, 30, text=""); msg_vp = ""; msg_color_vp = WHITE; btn_confirm_rect_vp = pygame.Rect(0,0,0,0)
    key_input_box_price = InputBox(200, 540, 200, 30, text=""); msg_price = ""; msg_color_price = WHITE; btn_confirm_rect_price = pygame.Rect(0,0,0,0)
    popup_item_key = None; popup_close_rect = None
    
    price_tab = "BANDO"; selected_price_item_key = None; selected_stats_item_key = None 
    sidebar_scroll_y = 0; SIDEBAR_AREA = pygame.Rect(0, 50, 150, 500); TAB_HEIGHT = 35; TAB_MARGIN = 5  
    ADMIN_TABS = [
        {"id": "ACCOUNTS", "label": "QL TAI KHOAN", "color_active": BLUE_UI},
        {"id": "ITEMS", "label": "QL VAT PHAM", "color_active": BLUE_UI},
        {"id": "BUFF", "label": "BUFF TIEN TE", "color_active": (0, 150, 0)},
        {"id": "PRICE", "label": "QL GIA TIEN", "color_active": (255, 140, 0)},
        {"id": "SUC_MANH", "label": "SUC MANH", "color_active": (200, 0, 200)} # <--- THÊM DÒNG NÀY
    ]
    # --- [FIX] KHỞI TẠO BUFF MANAGER ---
    # Cố gắng khởi tạo từ module bufftiente, nếu lỗi thì dùng class giả để không crash
    try:
        # Import class InputBox để truyền vào cho bufftiente dùng
        # Lưu ý: InputBox phải là class toàn cục đã khai báo ở đầu file main.py
        buff_manager = bufftiente.BuffManager(DATA_CHAR_FILE, font, font_small, InputBox)
        print("[SYSTEM] Da khoi tao BuffManager thanh cong.")
    except Exception as e:
        print(f"[SYSTEM] Warning: Khong the khoi tao BuffManager ({e}). Kiem tra file bufftiente.py.")
    try:
        # InputBox được truyền vào là class InputBox đã có trong main.py
        sm_manager = buffsucmanh.BuffSucManhManager(DATA_CHAR_FILE, font, font_small, InputBox)
    except Exception as e:
        print(f"Lỗi khởi tạo Buff SM: {e}")
        class DummySM: 
            def draw(self, s): pass
            def handle_event(self, e): pass
        sm_manager = DummySM()
        
        # Class giả lập (Dummy) phòng trường hợp vẫn lỗi để không crash game
        class DummyBuff:
            def __init__(self): self.btn_rect = pygame.Rect(0,0,0,0)
            def draw(self, s): 
                ts = font_small.render(f"Loi module Buff: {e}", True, RED_ERROR)
                s.blit(ts, (200, 100))
            def handle_event(self, e): pass
            def reload_data(self): pass
        buff_manager = DummyBuff()
    # -----------------------------------

    def parse_stats_shorthand(shorthand_text):
        stats = {}; shorthand_text = shorthand_text.strip()
        if shorthand_text.startswith('{'):
             import json
             try: return json.loads(shorthand_text)
             except json.JSONDecodeError as e: raise ValueError(f"Lỗi JSON: {e}")
        tokens = shorthand_text.upper().replace('%', '').split()
        MAPPINGS = [(r'^SD(\d+)$', 'suc_danh'), (r'^SDP(\d+)$', 'suc_danh_percent'), (r'^GIA(\d+)$', 'giap'), (r'^CM(\d+)$', 'chi_mang'), (r'^NE(\d+)$', 'ne_tranh'), (r'^NN(\d+)$', 'nhanh_nhen'), (r'^HP(\d+)$', 'max_hp'), (r'^KI(\d+)$', 'max_ki'), (r'^HM(\d+)$', 'hoi_mau'), (r'^HK(\d+)$', 'hoi_ki')]
        for token in tokens:
            found = False; 
            if not token: continue
            for regex, key_name in MAPPINGS:
                match = re.fullmatch(regex, token); 
                if match: stats[key_name] = int(match.group(1)); found = True; break
            if not found: raise ValueError(f"Token '{token}' không hợp lệ.")
        if not stats: raise ValueError("Chưa nhập chỉ số.")
        return stats
    
    def reset_user_to_creation_state(user):
        data_char = load_json(DATA_CHAR_FILE)
        if user in data_char: del data_char[user]; save_json(DATA_CHAR_FILE, data_char); return True
        return False
    def delete_all_users():
        data_acc = load_json(DATA_ACC_FILE); data_char = load_json(DATA_CHAR_FILE); users_to_keep = ["admin"]
        new_data_acc = {k: v for k, v in data_acc.items() if k in users_to_keep}; save_json(DATA_ACC_FILE, new_data_acc)
        new_data_char = {k: v for k, v in data_char.items() if k in users_to_keep}; save_json(DATA_CHAR_FILE, new_data_char)
    def reset_all_characters():
        data_char = load_json(DATA_CHAR_FILE); users_to_keep = ["admin"]
        new_data_char = {k: v for k, v in data_char.items() if k in users_to_keep}; save_json(DATA_CHAR_FILE, new_data_char)
    def ban_unban_user(user, ban_status):
        data_acc = load_json(DATA_ACC_FILE)
        if user in data_acc:
            if not isinstance(data_acc[user], dict): data_acc[user] = {"password": data_acc[user], "is_banned": False}
            data_acc[user]["is_banned"] = ban_status; save_json(DATA_ACC_FILE, data_acc)
    def change_admin_password(new_password):
        data_acc = load_json(DATA_ACC_FILE)
        if "admin" in data_acc:
             if isinstance(data_acc["admin"], dict): data_acc["admin"]["password"] = new_password
             else: data_acc["admin"] = new_password 
             save_json(DATA_ACC_FILE, data_acc)
    
    while running:
        item_click_rects = {}; btn_sub_rects = {}; price_tab_rects = {}; price_item_rects = {}
        btn_reset_all = None; btn_delete_all = None; list_actions = []
        
        # --- BẮT ĐẦU VẼ ADMIN PANEL ---
        if GLOBAL_BG_IMAGE: screen.blit(GLOBAL_BG_IMAGE, (0, 0)); 
        else: screen.fill(BLACK)

        dark = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT)); dark.set_alpha(180); dark.fill(BLACK); 
        screen.blit(dark, (0,0)); # <--- Đảm bảo phủ nền mờ lên trên

        pygame.draw.rect(screen, DARK_GRAY, (0, 0, 150, SCREEN_HEIGHT)); # Sidebar nền cứng
        
        original_clip = screen.get_clip(); screen.set_clip(SIDEBAR_AREA); 
        tab_rects_map = {}; start_y = SIDEBAR_AREA.y - sidebar_scroll_y
        for tab in ADMIN_TABS:
            rect = pygame.Rect(10, start_y, 130, TAB_HEIGHT); is_active = (current_tab == tab["id"]); col = tab["color_active"] if is_active else GRAY; text_color = BLACK; 
            if is_active and tab["id"] != "PRICE": text_color = WHITE
            ve_nut_custom(screen, rect, col, tab["label"], text_color, font_small); tab_rects_map[tab["id"]] = rect; start_y += TAB_HEIGHT + TAB_MARGIN
        screen.set_clip(original_clip) 
        btn_logout = pygame.Rect(10, 550, 130, 40); ve_nut_custom(screen, btn_logout, RED_ERROR, "DANG XUAT", WHITE); title = font_big.render("ADMIN PANEL", True, RED_TITLE); screen.blit(title, (300, 10))
        
        if current_tab == "ACCOUNTS":
             lbl_mk_admin = font_small.render("DOI MK ADMIN:", True, WHITE); screen.blit(lbl_mk_admin, (400, 525)); admin_mk_new_input.rect.x = 520; admin_mk_new_input.rect.y = 520; btn_change_admin_mk.x = 680; btn_change_admin_mk.y = 520; admin_mk_new_input.draw(screen); ve_nut_custom(screen, btn_change_admin_mk, C_VANG, "Doi MK", BLACK)
             lbl_hd = font_small.render("Nhap MK Moi/Ly do ban:", True, WHITE); screen.blit(lbl_hd, (160, 75)); mk_user_input.draw(screen); y_start = 120; pygame.draw.line(screen, WHITE, (160, y_start), (790, y_start), 1); headers = ["Tai khoan", "Trang Thai", "Ten NV", "Hanh Tinh", "Chuc Nang"]; xs = [170, 280, 380, 480, 600]
             for idx, h in enumerate(headers): screen.blit(font_small.render(h, True, C_VANG), (xs[idx], y_start - 20))
             data_acc = load_json(DATA_ACC_FILE); data_char = load_json(DATA_CHAR_FILE); list_users = list(data_acc.keys()); index_row = 0
             for u in list_users:
                 if u == "admin": continue
                 if index_row > 10: break 
                 row_y = y_start + 10 + (index_row * 40); acc_info = data_acc.get(u); is_banned = False
                 if not isinstance(acc_info, dict): acc_info = {"password": acc_info, "is_banned": False}
                 is_banned = acc_info.get("is_banned", False); status_color = C_BANNED if is_banned else C_UNBANNED; status_text = "BANNED" if is_banned else "ACTIVE"; char_name = "Chua tao"; char_phai = "---"
                 char_entries = data_char.get(u, {}); char_data = None
                 if char_entries and isinstance(char_entries, dict): first_char_name = next(iter(char_entries.keys()), "Loi"); char_data = char_entries.get(first_char_name); 
                 if isinstance(char_data, dict): char_name = char_data.get("ten", "Loi"); char_phai = char_data.get("phai", "Loi");
                 screen.blit(font_small.render(str(u), True, WHITE), (170, row_y)); screen.blit(font_small.render(status_text, True, status_color), (280, row_y)); screen.blit(font_small.render(char_name, True, (100, 200, 50)), (380, row_y)); screen.blit(font_small.render(char_phai, True, WHITE), (480, row_y)); btn_reset_user = pygame.Rect(590, row_y, 70, 25); btn_edit = pygame.Rect(670, row_y, 70, 25); btn_ban = pygame.Rect(750, row_y, 40, 25); ve_nut_custom(screen, btn_reset_user, C_BTN_RESET, "RESET"); ve_nut_custom(screen, btn_edit, (255, 140, 0), "DOI MK"); ve_nut_custom(screen, btn_ban, C_BANNED if not is_banned else C_UNBANNED, "BAN" if not is_banned else "UNBAN", WHITE); list_actions.append({"type": "reset", "rect": btn_reset_user, "user": u}); list_actions.append({"type": "edit", "rect": btn_edit, "user": u}); list_actions.append({"type": "ban_unban", "rect": btn_ban, "user": u, "status": is_banned}); index_row += 1
             btn_reset_all = pygame.Rect(160, 480, 150, 40); btn_delete_all = pygame.Rect(320, 480, 150, 40); ve_nut_custom(screen, btn_reset_all, C_BTN_RESET, "RESET ALL NV", BLACK); ve_nut_custom(screen, btn_delete_all, C_BTN_DEL, "XOA ALL TK", WHITE)
        elif current_tab == "ITEMS":
             title_text = "QL VẬT PHẨM VÀ CHỈ SỐ"; lbl_item_title = font.render(title_text, True, C_VANG); screen.blit(lbl_item_title, (160, 50))
             # Tab con phân loại
             tab_keys_map = ["VU_KHI", "GIAP", "TIEU_HAO", "DAC_BIET", "LINH_TINH"]
             tab_labels = ["VU KHI", "TRANG BI", "TIEU HAO", "DAC BIET", "KHAC"]
             start_x_sub = 160
             for i, t_key in enumerate(tab_keys_map):
                 r = pygame.Rect(160 + i * 110, 80, 100, 30); color = BLUE_UI if current_sub_tab == t_key else GRAY; label = tab_labels[i] if i < len(tab_labels) else "KHAC"
                 ve_nut_custom(screen, r, color, label, WHITE if current_sub_tab == t_key else BLACK); btn_sub_rects[t_key] = r
             
             # Khung hiển thị item
             item_display_rect = pygame.Rect(160, 120, 630, 330); pygame.draw.rect(screen, DARK_GRAY, item_display_rect, border_radius=5); pygame.draw.rect(screen, GRAY, item_display_rect, 2)
             
             # Lọc và SẮP XẾP vật phẩm (Sort by ID)
             filtered_keys = []
             for k, v in ITEM_TEMPLATES.items():
                 itype = v.get("type", "KHAC"); 
                 if current_sub_tab == "VU_KHI" and itype == "Vu Khi": filtered_keys.append(k)
                 elif current_sub_tab == "GIAP" and itype == "Giap": filtered_keys.append(k)
                 elif current_sub_tab == "TIEU_HAO" and itype == "Tieu Hao": filtered_keys.append(k)
                 elif current_sub_tab == "DAC_BIET" and itype == "Dac Biet": filtered_keys.append(k)
                 elif current_sub_tab == "LINH_TINH" and itype not in ["Vu Khi", "Giap", "Tieu Hao", "Dac Biet"]: filtered_keys.append(k)
                 
             # Sắp xếp danh sách key theo item_id (nếu có) hoặc tên
             filtered_keys.sort(key=lambda k: ITEM_TEMPLATES[k].get('item_id', 9999))

             slots_per_row = 12; grid_size = 40 + 5; start_x = item_display_rect.x + 10; start_y = item_display_rect.y + 10
             for i, key in enumerate(filtered_keys):
                 item_template = ITEM_TEMPLATES[key]; row = i // slots_per_row; col = i % slots_per_row; slot_rect = pygame.Rect(start_x + col * grid_size, start_y + row * grid_size, 40, 40)
                 border_col = C_HIGHLIGHT if (key == selected_stats_item_key) else item_template.get('rarity', WHITE); pygame.draw.rect(screen, (30, 30, 30), slot_rect, border_radius=3); pygame.draw.rect(screen, border_col, slot_rect, 1, border_radius=3)
                 cx, cy = slot_rect.centerx, slot_rect.centery; rarity = item_template.get('rarity', WHITE)
                 if "potion" in key: pygame.draw.circle(screen, rarity, (cx, cy + 2), 8)
                 elif "sword" in key: pygame.draw.line(screen, rarity, (cx - 8, cy + 8), (cx + 8, cy - 8), 2)
                 else: pygame.draw.circle(screen, rarity, (cx, cy), 5) 
                 item_id = item_template.get('item_id', '??'); name_surf = font_tiny.render(f"ID{item_id}", True, WHITE); screen.blit(name_surf, (slot_rect.x + 2, slot_rect.bottom - 10)); item_click_rects[key] = slot_rect 
             
             key_input_box_vp.rect.x = 170; key_input_box_vp.rect.y = 500; key_input_box_vp.update(); key_input_box_vp.draw(screen)
             btn_confirm_rect_vp = pygame.Rect(630, 500, 150, 30); ve_nut_custom(screen, btn_confirm_rect_vp, GREEN_SUCCESS, "LUU CHI SO", BLACK, font_small)
             
             sel_name = ITEM_TEMPLATES.get(selected_stats_item_key, {}).get('name', 'Chua chon') if selected_stats_item_key else 'Chua chon'; sel_id = ITEM_TEMPLATES.get(selected_stats_item_key, {}).get('item_id', '??')
             lbl_hd = font_small.render(f"Sửa ID {sel_id}: {sel_name} (VD: SD5)", True, msg_color_vp); screen.blit(lbl_hd, (170, 475))
             if msg_vp: msg_s = font_small.render(msg_vp, True, msg_color_vp); screen.blit(msg_s, (170, 535))
        
        elif current_tab == "BUFF": 
            # --- [FIX] SỬ DỤNG buff_manager ĐÃ KHỞI TẠO Ở TRÊN ---
            buff_manager.draw(screen); btn_buff_rect = buff_manager.btn_rect 

        elif current_tab == "PRICE": 
             btn_confirm_rect_price = pygame.Rect(0,0,0,0)
             price_tab_rects, items_on_sale, price_item_rects = qlgiatien.draw_giatien_tab(screen, price_tab, ITEM_TEMPLATES, font_small, font_tiny, selected_price_item_key, msg_price, msg_color_price, InputBox)
             
             Y_INPUT_FIXED = 540; key_input_box_price.rect.x = 200; key_input_box_price.rect.y = Y_INPUT_FIXED; key_input_box_price.update(); key_input_box_price.draw(screen)
             btn_confirm_rect_price = pygame.Rect(key_input_box_price.rect.right + 10, Y_INPUT_FIXED, 100, 30); ve_nut_custom(screen, btn_confirm_rect_price, GREEN_SUCCESS, "CAP NHAT", BLACK, font_small)
        elif current_tab == "SUC_MANH": # <--- THÊM ĐOẠN NÀY
             sm_manager.draw(screen)
        
        if popup_item_key: popup_close_rect = item_editor.draw_item_detail_popup(screen, popup_item_key, ITEM_TEMPLATES, SCREEN_WIDTH, SCREEN_HEIGHT, font, font_small)

        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.MOUSEWHEEL: sidebar_scroll_y -= event.y * 15; max_scroll = max(0, len(ADMIN_TABS) * (TAB_HEIGHT + TAB_MARGIN) - SIDEBAR_AREA.height); sidebar_scroll_y = max(0, min(sidebar_scroll_y, max_scroll))
            if current_tab == "SUC_MANH": sm_manager.handle_event(event)
            if current_tab == "BUFF": buff_manager.handle_event(event)
            else:
                if current_tab == "ITEMS" and 'key_input_box_vp' in locals(): key_input_box_vp.handle_event(event)
                elif current_tab == "ACCOUNTS": 
                     if 'mk_user_input' in locals(): mk_user_input.handle_event(event)
                     if 'admin_mk_new_input' in locals(): admin_mk_new_input.handle_event(event) 
                elif current_tab == "PRICE" and 'key_input_box_price' in locals(): key_input_box_price.handle_event(event) 
            
            if popup_item_key:
                if event.type == pygame.MOUSEBUTTONDOWN and popup_close_rect.collidepoint(event.pos): popup_item_key = None
                continue
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos
                if SIDEBAR_AREA.collidepoint(mx, my):
                    for t_id, rect in tab_rects_map.items():
                        if rect.collidepoint(mx, my):
                            current_tab = t_id; popup_item_key = None; selected_stats_item_key = None; selected_price_item_key = None; 
                            # --- [FIX] GỌI reload_data() AN TOÀN ---
                            if current_tab == "BUFF": buff_manager.reload_data()
                            break
                if current_tab == "ITEMS":
                    if 80 <= my <= 110:
                        for t_key, r in btn_sub_rects.items():
                            if r.collidepoint(mx, my): current_sub_tab = t_key; item_click_rects = {}; break
                    if 120 <= my <= 450:
                        for key, r in item_click_rects.items():
                            if r.collidepoint(mx, my): 
                                selected_stats_item_key = key; popup_item_key = key; stats = ITEM_TEMPLATES[key].get('stats', {}); import json; 
                                try:
                                    shorthand = ""
                                    if 'suc_danh' in stats: shorthand += f"SD{stats['suc_danh']} "
                                    key_input_box_vp.text = shorthand.strip() or json.dumps(stats)
                                except: key_input_box_vp.text = json.dumps(stats)
                                key_input_box_vp.update(); msg_vp = ""; break
                if current_tab == "PRICE":
                    for p_key, r in price_tab_rects.items():
                        if r.collidepoint(mx, my): price_tab = p_key; selected_price_item_key = None; msg_price = ""; break
                    for i_key, r in price_item_rects.items():
                        if r.collidepoint(mx, my): 
                            selected_price_item_key = i_key
                            # Lấy giá an toàn
                            p, c = qlgiatien.get_item_price(price_tab, i_key)
                            if p is not None: 
                                key_input_box_price.text = f"{p} {c}"
                                key_input_box_price.update()
                            msg_price = f"Đang chọn: {ITEM_TEMPLATES.get(i_key, {}).get('name', i_key)}"; 
                            break
                    if 'btn_confirm_rect_price' in locals() and btn_confirm_rect_price.collidepoint(mx, my):
                        msg, color, new_sel = qlgiatien.handle_giatien_event(event, price_tab, key_input_box_price, ITEM_TEMPLATES, RED_ERROR, GREEN_SUCCESS, selected_price_item_key, btn_confirm_rect_price)
                        msg_price = msg; msg_color_price = color; selected_price_item_key = new_sel if new_sel is not None else selected_price_item_key
                        if msg_color_price == GREEN_SUCCESS: key_input_box_price.text = ""; key_input_box_price.update()
                
                if current_tab == "ITEMS" and 'btn_confirm_rect_vp' in locals() and btn_confirm_rect_vp.collidepoint(mx, my):
                    if selected_stats_item_key:
                        try:
                            new_stats = parse_stats_shorthand(key_input_box_vp.text)
                            if isinstance(new_stats, dict): ITEM_TEMPLATES[selected_stats_item_key]['stats'] = new_stats; save_item_data(); msg_vp = f"Đã lưu chỉ số {selected_stats_item_key}!"; msg_color_vp = GREEN_SUCCESS; popup_item_key = None
                            else: raise ValueError("Lỗi parse.")
                        except (ValueError, json.JSONDecodeError, AttributeError) as e: msg_vp = f"Lỗi cú pháp: {e}"; msg_color_vp = RED_ERROR
                    else: msg_vp = "Chưa chọn vật phẩm!"; msg_color_vp = RED_ERROR

                if btn_logout.collidepoint(mx, my): return "LOGOUT"
                if btn_change_admin_mk.collidepoint(mx, my): 
                    admin_new_pass = admin_mk_new_input.text; 
                    if admin_new_pass: change_admin_password(admin_new_pass); print("Đã đổi MK Admin"); admin_mk_new_input.text = "" 
                
                if current_tab == "ACCOUNTS":
                    if btn_reset_all and btn_reset_all.collidepoint(mx, my): reset_all_characters()
                    elif btn_delete_all and btn_delete_all.collidepoint(mx, my): delete_all_users()
                    elif 'list_actions' in locals():
                        for action in list_actions:
                            if action["rect"].collidepoint(mx, my):
                                u_act = action["user"]
                                if action["type"] == "edit": 
                                    user_new_pass = mk_user_input.text; 
                                    if user_new_pass: data_acc_act = load_json(DATA_ACC_FILE); isinstance(data_acc_act.get(u_act), dict) and data_acc_act[u_act].update({"password": user_new_pass}) or data_acc_act.update({u_act: user_new_pass}); save_json(DATA_ACC_FILE, data_acc_act)
                                elif action["type"] == "reset": reset_user_to_creation_state(u_act)
                                elif action["type"] == "ban_unban": ban_unban_user(u_act, not action["status"]) 
                                break
        pygame.display.flip(); clock.tick(60)

# --- MENU SCREEN FUNCTION (Fixes integrated here) ---

def chay_man_hinh_tao_nv(screen, username):
    # Cấu hình Font
    font_large = pygame.font.SysFont("Arial", 24)
    font_small = pygame.font.SysFont("Arial", 16)

    # --- 1. LOAD ẢNH NỀN AN TOÀN ---
    bg_image = None
    try:
        # Tự động tìm đường dẫn file, bất kể chạy từ đâu
        base_path = os.path.dirname(os.path.abspath(__file__))
        img_path = os.path.join(base_path, "background_login.jpg")
        
        if os.path.exists(img_path):
            loaded_img = pygame.image.load(img_path)
            bg_image = pygame.transform.scale(loaded_img, (SCREEN_WIDTH, SCREEN_HEIGHT))
        else:
            print("CẢNH BÁO: Không tìm thấy file 'background_login.jpg'. Sử dụng nền đen.")
    except Exception as e:
        print(f"Lỗi load ảnh: {e}")
        bg_image = None # Dùng nền đen nếu lỗi

    # Cấu hình giao diện
    input_box = pygame.Rect(SCREEN_WIDTH // 2 - 100, 200, 200, 40)
    color_inactive = pygame.Color('lightskyblue3')
    color_active = pygame.Color('dodgerblue2')
    color = color_inactive
    active = False
    text = ''
    
    selected_planet = "Trai Dat"
    
    btn_td = pygame.Rect(SCREEN_WIDTH // 2 - 160, 300, 100, 40)
    btn_nm = pygame.Rect(SCREEN_WIDTH // 2 - 50, 300, 100, 40)
    btn_xd = pygame.Rect(SCREEN_WIDTH // 2 + 60, 300, 100, 40)
    btn_create = pygame.Rect(SCREEN_WIDTH // 2 - 60, 400, 120, 50)

    while True:
        # --- 2. VẼ NỀN ---
        if bg_image:
            screen.blit(bg_image, (0, 0))
            # Vẽ lớp đen mờ lên trên để chữ dễ đọc (Độ trong suốt 150)
            s = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            s.fill((0, 0, 0, 150))
            screen.blit(s, (0,0))
        else:
            screen.fill(BLACK) # Nền đen nếu thiếu ảnh
        
        # Tiêu đề & Hướng dẫn
        t_surf = font_large.render("TAO NHAN VAT MOI", True, WHITE)
        screen.blit(t_surf, (SCREEN_WIDTH // 2 - t_surf.get_width() // 2, 100))
        
        p_surf = font_small.render(f"Tai khoan: {username} - Nhap ten nhan vat:", True, WHITE)
        screen.blit(p_surf, (SCREEN_WIDTH // 2 - 100, 170))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                # Xử lý click ô nhập tên
                if input_box.collidepoint(event.pos):
                    active = not active
                else:
                    active = False
                color = color_active if active else color_inactive
                
                # Xử lý chọn hành tinh
                if btn_td.collidepoint(event.pos): selected_planet = "Trai Dat"
                elif btn_nm.collidepoint(event.pos): selected_planet = "Namec"
                elif btn_xd.collidepoint(event.pos): selected_planet = "Xayda"
                
                # Xử lý nút Tạo
                elif btn_create.collidepoint(event.pos):
                    if len(text) > 0:
                        return text, selected_planet 

            if event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN: pass
                    elif event.key == pygame.K_BACKSPACE: text = text[:-1]
                    else: 
                        if len(text) < 10: text += event.unicode

        # Vẽ ô nhập tên
        txt_s = font_large.render(text, True, color)
        input_box.w = max(200, txt_s.get_width()+10)
        screen.blit(txt_s, (input_box.x+5, input_box.y+5))
        pygame.draw.rect(screen, color, input_box, 2)

        # Vẽ nút chọn hành tinh (Xanh lá nếu đang chọn)
        for btn, name, p_key in [(btn_td, "Trai Dat", "Trai Dat"), (btn_nm, "Namec", "Namec"), (btn_xd, "Xayda", "Xayda")]:
            c = GREEN_SUCCESS if selected_planet == p_key else GRAY
            pygame.draw.rect(screen, c, btn, border_radius=5)
            lbl = font_small.render(name, True, WHITE)
            screen.blit(lbl, (btn.centerx - lbl.get_width()//2, btn.centery - lbl.get_height()//2))

        # Vẽ nút Tạo
        pygame.draw.rect(screen, (255, 165, 0), btn_create, border_radius=5)
        lbl_c = font_large.render("TAO NGAY", True, WHITE)
        screen.blit(lbl_c, (btn_create.centerx - lbl_c.get_width()//2, btn_create.centery - lbl_c.get_height()//2))

        pygame.display.flip()

# --- HÀM MENU CHÍNH (Đã tích hợp Logic Đăng Nhập & Tạo NV) ---
def menu_screen():
    global GLOBAL_USERNAME
    
    # Khởi tạo font và load resource
    font = pygame.font.SysFont("Arial", 24)
    try:
        load_all_resources() 
        man_hinh_khoi_dong(screen)
    except: pass
    
    # Class InputBox (để cục bộ để tránh lỗi phạm vi)
    class InputBoxLocal:
        def __init__(self, x, y, w, h, is_password=False, text=''):
            self.rect = pygame.Rect(x, y, w, h); self.color = GRAY; self.text = text; self.is_password = is_password; self.txt_surface = font.render(text, True, BLACK); self.active = False; self.font = font
        def handle_event(self, event):
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.rect.collidepoint(event.pos): self.active = True; self.color = BLUE_UI
                else: self.active = False; self.color = GRAY
            if event.type == pygame.KEYDOWN:
                if self.active:
                    if event.key == pygame.K_RETURN: pass
                    elif event.key == pygame.K_BACKSPACE: self.text = self.text[:-1]
                    elif event.key == pygame.K_TAB: pass
                    else: self.text += event.unicode
                    txt_show = "*" * len(self.text) if self.is_password else self.text
                    self.txt_surface = self.font.render(txt_show, True, BLACK)
        def draw(self, screen_surface):
            pygame.draw.rect(screen_surface, self.color, self.rect, 2)
            pygame.draw.rect(screen_surface, WHITE, (self.rect.x+2, self.rect.y+2, self.rect.width-4, self.rect.height-4))
            screen_surface.blit(self.txt_surface, (self.rect.x + 5, self.rect.y + 5))

    # UI Elements
    username_box = InputBoxLocal(300, 200, 200, 40)
    password_box = InputBoxLocal(300, 260, 200, 40, is_password=True)
    username_box.active = True; username_box.color = BLUE_UI
    input_boxes = [username_box, password_box]
    
    message = ""; message_color = BLACK
    btn_login = pygame.Rect(300, 360, 100, 40)
    btn_reg = pygame.Rect(410, 360, 100, 40)
    chk_remember = Checkbox(300, 310, "Nho tai khoan")
    
    # Load saved login
    if os.path.exists(SAVED_LOGIN_FILE):
        try:
            saved_data = load_json(SAVED_LOGIN_FILE)
            if saved_data: 
                username_box.text = saved_data.get("username", ""); password_box.text = saved_data.get("password", "")
                username_box.txt_surface = font.render(username_box.text, True, BLACK)
                password_box.txt_surface = font.render("*" * len(password_box.text), True, BLACK)
                chk_remember.checked = True
        except: pass
        
    while True: 
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            
            # Tab navigation
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_TAB:
                    active_index = -1
                    for i, box in enumerate(input_boxes):
                        if box.active: active_index = i; box.active = False; box.color = GRAY; break
                    next_index = (active_index + 1) % len(input_boxes)
                    input_boxes[next_index].active = True; input_boxes[next_index].color = BLUE_UI
            
            for box in input_boxes: box.handle_event(event)
            chk_remember.handle_event(event)
            
            # Login / Register
            if event.type == pygame.MOUSEBUTTONDOWN or (event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN):
                u = username_box.text; p = password_box.text
                data_acc = load_json(DATA_ACC_FILE)
                
                is_login_attempt = btn_login.collidepoint(event.pos) if event.type == pygame.MOUSEBUTTONDOWN else (event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN)
                is_reg_attempt = btn_reg.collidepoint(event.pos) if event.type == pygame.MOUSEBUTTONDOWN else False

                if is_login_attempt:
                    acc_entry = data_acc.get(u, None); actual_password = None; is_banned = False
                    if isinstance(acc_entry, dict): actual_password = acc_entry.get("password"); is_banned = acc_entry.get("is_banned", False)
                    elif isinstance(acc_entry, str): actual_password = acc_entry
                    
                    if acc_entry and actual_password == p:
                        if is_banned: message = "Tai khoan da bi cam!"; message_color = C_BANNED
                        elif u == "admin": 
                            message = "Admin Login OK!"; message_color = GREEN_SUCCESS
                            draw_menu_interface(username_box, password_box, btn_login, btn_reg, message, message_color, chk_remember)
                            pygame.display.flip(); pygame.time.delay(1000); admin_panel(screen); continue 
                        else:
                            if chk_remember.checked: save_json(SAVED_LOGIN_FILE, {"username": u, "password": p})
                            else: 
                                if os.path.exists(SAVED_LOGIN_FILE): os.remove(SAVED_LOGIN_FILE)
                            
                            message = "Dang nhap thanh cong!"; message_color = GREEN_SUCCESS
                            draw_menu_interface(username_box, password_box, btn_login, btn_reg, message, message_color, chk_remember)
                            pygame.display.flip(); pygame.time.delay(500)
                            
                            # --- VÀO GAME ---
                            GLOBAL_USERNAME = u
                            data_nv = load_json(DATA_CHAR_FILE)
                            char_data_for_user = data_nv.get(u)
                            
                            # TẠO NHÂN VẬT MỚI
                            if not isinstance(char_data_for_user, dict) or not char_data_for_user:
                                ten_moi, hanh_tinh_moi = chay_man_hinh_tao_nv(screen, u)
                                if ten_moi:
                                    data_nv = load_json(DATA_CHAR_FILE)
                                    if u not in data_nv: data_nv[u] = {}
                                    
                                    # [CẬP NHẬT CHỈ SỐ Ở ĐÂY - ĐÃ SỬA]
                                    data_nv[u][ten_moi] = {
                                        "suc_manh": 2000, "tiem_nang": 2000,
                                        "hp": 100, "max_hp": 100,      # <--- HP 100/100
                                        "ki": 100, "max_ki": 100,      # <--- KI 100/100
                                        "suc_danh": 10,                # <--- SD 10
                                        "giap": 0, "chi_mang": 1, 
                                        "vang": 10000, "kim_cuong": 20, # <--- Vàng 10k, KC 20
                                        "inventory": [None] * 30, "chest": [None] * 30, 
                                        "phai": hanh_tinh_moi,
                                        "map_id": "Map_1_Lang_Hanh_Tinh", 
                                        "world_x": 200, 
                                        "is_new": True
                                    }
                                    save_json(DATA_CHAR_FILE, data_nv)
                                    
                                    ten_nv_dau_tien = ten_moi; current_map_id = "Map_1_Lang_Hanh_Tinh"
                                else:
                                    message = "Huy tao nhan vat."; message_color = RED_ERROR; continue
                            else:
                                ten_nv_dau_tien = next(iter(char_data_for_user.keys()), "Goku")
                                current_map_id = char_data_for_user.get(ten_nv_dau_tien, {}).get("map_id", "Map_1_Lang_Hanh_Tinh")
                            
                            # GAME LOOP & CHUYỂN MAP
                            while True:
                                data_nv_updated = load_json(DATA_CHAR_FILE)
                                info_updated = data_nv_updated.get(u, {}).get(ten_nv_dau_tien, {})
                                current_map_id = info_updated.get("map_id", current_map_id)
                                
                                hieu_ung_chuyen_canh(screen)
                                
                                ket_qua_loop = game_loop(u, ten_nv_dau_tien, info_updated.get("phai", "Trai Dat"), map_id=current_map_id, is_new_player=False)
                                
                                if ket_qua_loop == "LOGOUT": break 
                                elif isinstance(ket_qua_loop, str) and ket_qua_loop != current_map_id:
                                    current_map_id = ket_qua_loop; continue
                                break
                            
                            continue 
                            
                    else: message = "Sai tai khoan hoac mat khau!"; message_color = RED_ERROR
                
                elif is_reg_attempt:
                    if u == "" or p == "": message = "Nhap du thong tin!"; message_color = RED_ERROR
                    elif u in data_acc: message = "Tai khoan da ton tai!"; message_color = RED_ERROR
                    else: 
                        data_acc[u] = {"password": p, "is_banned": False}; save_json(DATA_ACC_FILE, data_acc); 
                        message = "Dang ky thanh cong!"; message_color = GREEN_SUCCESS
                        
        draw_menu_interface(username_box, password_box, btn_login, btn_reg, message, message_color, chk_remember)
        pygame.display.flip(); clock.tick(30)

# --- KHỐI CHẠY CHÍNH (MAIN BLOCK) ---
if __name__ == "__main__":
    try:
        # Khởi tạo Pygame trước tiên
        pygame.init()
        
        # Cấu hình màn hình nếu chưa có
        if 'screen' not in globals():
            SCREEN_WIDTH = 800; SCREEN_HEIGHT = 600
            screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
            pygame.display.set_caption("NRO Game")
            clock = pygame.time.Clock()
            font = pygame.font.SysFont("Arial", 24)
            
        # Load dữ liệu giá (nếu có)
        try: qlgiatien.load_price_data()
        except: pass
        
        # Chạy Menu
        menu_screen()
        
    except Exception as e:
        # Bắt lỗi crash để in ra màn hình console thay vì tắt bụp
        print(f"CRASH REPORT: {e}")
        import traceback
        traceback.print_exc()
        pygame.quit()
        input("Nhan Enter de thoat...")