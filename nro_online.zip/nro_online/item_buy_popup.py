import pygame
import sys
import os

# --- IMPORT MAIN MODULE (Chỉ để truy cập ITEM_TEMPLATES nếu cần) ---
main = None
try:
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.join(current_dir, "..")
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)
    import main as _main
    main = _main
except Exception:
    main = None

# --- TRY IMPORT qlgiatien để lấy giá nếu thiếu ---
qlgiatien = None
try:
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)
    import qlgiatien as _qlgiatien
    qlgiatien = _qlgiatien
except Exception:
    qlgiatien = None


# --- CẤU HÌNH ---
POPUP_W = 450
POPUP_H = 300
COLOR_BG = (30, 30, 40)
COLOR_BORDER = (255, 215, 0)
WHITE = (255, 255, 255)
C_BTN_BUY = (0, 180, 0)
C_BTN_CANCEL = (180, 50, 50)
C_VANG = (255, 215, 0)
C_DIAMOND = (0, 200, 255)
C_VND = (0, 150, 0)
BLACK = (0, 0, 0)
C_SUCCESS = (100, 255, 100)


# =========================
# FIX: RESOLVE PRICE (fallback nếu price = 0)
# =========================
def _resolve_price_and_currency(shop_item_data, item_key):
    """
    Ưu tiên:
    1) shop_item_data['price'] hoặc ['cost']
    2) hỏi qlgiatien.get_item_price(shop_key, item_key) nếu có
    3) fallback theo tên key (rada/quần/giày)
    """
    # 1) lấy từ data truyền vào
    cost = shop_item_data.get("price", None)
    if cost is None:
        cost = shop_item_data.get("cost", 0)
    try:
        cost = int(cost or 0)
    except Exception:
        cost = 0

    currency = shop_item_data.get("currency", None) or "VANG"

    # 2) nếu cost = 0 thì thử hỏi qlgiatien (nếu có)
    if cost <= 0 and qlgiatien and hasattr(qlgiatien, "get_item_price"):
        shop_key = shop_item_data.get("shop_key", "BANDO") or "BANDO"
        try:
            p, c = qlgiatien.get_item_price(shop_key, item_key)
            if p is not None and int(p) > 0:
                cost = int(p)
                currency = (c or currency or "VANG")
        except Exception:
            pass

    # 3) fallback “cứng” cho mấy món hay bị thiếu giá
    if cost <= 0:
        k = str(item_key).lower()

        # rada / radar
        if ("rada" in k) or ("radar" in k):
            cost = 250
            currency = "VANG"

        # quần / giày vải
        elif ("quan" in k) or ("pant" in k) or ("pants" in k):
            cost = 250
            currency = "VANG"
        elif ("giay" in k) or ("shoe" in k) or ("shoes" in k) or ("boot" in k):
            cost = 250
            currency = "VANG"

        # potion nếu em muốn tránh 0 luôn
        elif "potion" in k:
            cost = 50
            currency = "VANG"

    return cost, currency


# --- HELPER: FORMAT CHỈ SỐ ---
def format_custom_stats(item_template):
    if "stats" in item_template and item_template["stats"]:
        stats_data = item_template["stats"]
    elif "custom_stats" in item_template and item_template["custom_stats"]:
        stats_data = item_template["custom_stats"]
    else:
        return item_template.get("desc", "Không có chỉ số")

    stats_list = []
    for k, v in stats_data.items():
        stat_name = (
            k.replace("suc_danh", "SĐ")
            .replace("max_hp", "HP")
            .replace("max_ki", "KI")
            .replace("giap", "GIÁP")
            .replace("chi_mang", "CM")
            .replace("ne_tranh", "NÉ")
        )

        val_str = f"+{v}"
        if "percent" in k or stat_name in ["CM", "NÉ", "Né"]:
            val_str = f"+{v}%"

        stats_list.append(f"{stat_name}: {val_str}")
    return " | ".join(stats_list)


# --- VẼ ICON TRONG POPUP ---
def draw_popup_icon(screen, x, y, item_template):
    rect = pygame.Rect(x, y, 50, 50)
    pygame.draw.rect(screen, BLACK, rect, border_radius=5)

    rarity_color = item_template.get("rarity", WHITE)
    if isinstance(rarity_color, list):
        rarity_color = tuple(rarity_color)

    pygame.draw.rect(screen, rarity_color, rect, 2, border_radius=5)

    cx, cy = rect.center
    item_key = (item_template.get("key", "") or "").lower()

    if "sword" in item_key or "kiem" in item_key:
        pygame.draw.line(screen, (200, 200, 200), (cx - 10, cy + 10), (cx + 10, cy - 10), 4)
        pygame.draw.line(screen, (139, 69, 19), (cx - 10, cy + 10), (cx - 14, cy + 14), 4)

    elif "potion" in item_key:
        color = (255, 0, 0) if "hp" in item_key else (0, 0, 255)
        pygame.draw.circle(screen, color, (cx, cy + 5), 12)
        pygame.draw.rect(screen, WHITE, (cx - 5, cy - 10, 10, 6))

    elif "armor" in item_key or "ao" in item_key or "giap" in item_key:
        pygame.draw.rect(screen, rarity_color, (cx - 9, cy - 6, 18, 20), border_radius=2)
        pygame.draw.rect(screen, rarity_color, (cx - 14, cy - 3, 6, 10), border_radius=2)
        pygame.draw.rect(screen, rarity_color, (cx + 8, cy - 3, 6, 10), border_radius=2)

    elif "quan" in item_key:
        pygame.draw.rect(screen, rarity_color, (cx - 10, cy - 8, 20, 6), border_radius=2)
        pygame.draw.rect(screen, rarity_color, (cx - 10, cy - 2, 9, 18), border_radius=2)
        pygame.draw.rect(screen, rarity_color, (cx + 1, cy - 2, 9, 18), border_radius=2)
        pygame.draw.rect(screen, (30, 30, 40), (cx - 1, cy - 2, 2, 12))

    elif "giay" in item_key:
        pygame.draw.rect(screen, rarity_color, (cx - 10, cy + 6, 20, 7), border_radius=2)
        pygame.draw.rect(screen, rarity_color, (cx - 7, cy + 1, 14, 7), border_radius=2)

    elif "rada" in item_key or "radar" in item_key:
        pygame.draw.circle(screen, (0, 255, 0), (cx, cy), 11, 1)
        pygame.draw.circle(screen, (0, 255, 0), (cx, cy), 4, 1)
        pygame.draw.line(screen, (0, 255, 0), (cx, cy), (cx + 7, cy - 7), 1)

    elif "dragon" in item_key:
        pygame.draw.circle(screen, (255, 140, 0), (cx, cy), 12)
        pygame.draw.circle(screen, (255, 0, 0), (cx, cy), 3)

    elif "zenkai" in item_key:
        pygame.draw.ellipse(screen, (0, 200, 0), (cx - 10, cy - 5, 20, 10))


# --- VẼ ICON TIỀN TỆ NHỎ ---
def draw_currency_small(screen, x, y, currency):
    RADIUS = 6
    if currency == "VANG":
        pygame.draw.circle(screen, C_VANG, (x, y), RADIUS + 1)
        pygame.draw.circle(screen, (200, 150, 0), (x, y), RADIUS, 1)
    elif currency == "KIM_CUONG":
        pts = [(x, y - RADIUS), (x + RADIUS, y), (x, y + RADIUS), (x - RADIUS, y)]
        pygame.draw.polygon(screen, C_DIAMOND, pts)
    elif currency == "VND":
        RECT_W, RECT_H = 14, 8
        pygame.draw.rect(screen, C_VND, (x - RECT_W // 2, y - RECT_H // 2, RECT_W, RECT_H), 0, border_radius=1)
        pygame.draw.rect(screen, WHITE, (x - RECT_W // 2, y - RECT_H // 2, RECT_W, RECT_H), 1)


def draw_buy_popup(screen, shop_item_data, ITEM_TEMPLATES, screen_w, screen_h, font, font_small, player_vang, player_kc, player_vnd):
    item_key = shop_item_data.get("key", "unknown")
    item_template = ITEM_TEMPLATES.get(item_key, {}).copy()

    # để icon/format dùng được key
    item_template.setdefault("key", item_key)

    # FIX: resolve giá nếu 0
    cost, currency = _resolve_price_and_currency(shop_item_data, item_key)

    overlay = pygame.Surface((screen_w, screen_h), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    screen.blit(overlay, (0, 0))

    x = (screen_w - POPUP_W) // 2
    y = (screen_h - POPUP_H) // 2
    popup_rect = pygame.Rect(x, y, POPUP_W, POPUP_H)
    pygame.draw.rect(screen, COLOR_BG, popup_rect, border_radius=10)
    pygame.draw.rect(screen, COLOR_BORDER, popup_rect, 3, border_radius=10)

    name = item_template.get("name", "Unknown")
    item_id = item_template.get("item_id", "?")

    draw_popup_icon(screen, x + 30, y + 30, item_template)

    lbl_name = font.render(f"{name} (ID: {item_id})", True, COLOR_BORDER)
    screen.blit(lbl_name, (x + 90, y + 35))

    stats_display = format_custom_stats(item_template)
    lbl_desc = font_small.render(f"Chi so: {stats_display}", True, WHITE)
    screen.blit(lbl_desc, (x + 30, y + 100))

    confirm_y = y + 150

    unit_text = ""
    current_amount = 0
    if currency == "VANG":
        unit_text = "Vàng"
        current_amount = player_vang
    elif currency == "KIM_CUONG":
        unit_text = "Ngọc"
        current_amount = player_kc
    elif currency == "VND":
        unit_text = "VND"
        current_amount = player_vnd

    can_afford = current_amount >= cost

    ask_text_prefix = font_small.render("Bạn muốn mua item này với giá:", True, WHITE)
    screen.blit(ask_text_prefix, (x + 30, confirm_y))

    price_color = C_SUCCESS if can_afford else C_BTN_CANCEL
    lbl_price = font.render(f"{cost:,}", True, price_color)

    price_x = x + 30
    price_y = y + 180
    screen.blit(lbl_price, (price_x, price_y))

    icon_unit_x = price_x + lbl_price.get_width() + 10
    icon_unit_y = price_y + lbl_price.get_height() // 2
    draw_currency_small(screen, icon_unit_x, icon_unit_y, currency)

    lbl_unit = font_small.render(unit_text, True, price_color)
    screen.blit(lbl_unit, (icon_unit_x + 10, price_y + 5))

    btn_w, btn_h = 100, 40
    btn_buy_rect = pygame.Rect(x + 100, y + 230, btn_w, btn_h)
    color_btn = C_BTN_BUY if can_afford else (100, 100, 100)

    pygame.draw.rect(screen, color_btn, btn_buy_rect, border_radius=5)
    if not can_afford:
        lbl_buy = font.render("THIẾU TIỀN", True, (200, 200, 200))
    else:
        lbl_buy = font.render("MUA", True, WHITE)
    screen.blit(lbl_buy, lbl_buy.get_rect(center=btn_buy_rect.center))

    close_rect = pygame.Rect(x + POPUP_W - 35, y + 10, 25, 25)
    pygame.draw.rect(screen, C_BTN_CANCEL, close_rect, border_radius=3)
    lbl_x = font_small.render("X", True, WHITE)
    screen.blit(lbl_x, lbl_x.get_rect(center=close_rect.center))

    return close_rect, btn_buy_rect


def draw_info_popup(screen, item_data, ITEM_TEMPLATES, screen_w, screen_h, font, font_small):
    item_key = item_data.get("key", "unknown")
    item_template = ITEM_TEMPLATES.get(item_key, {}).copy()
    item_template.setdefault("key", item_key)

    overlay = pygame.Surface((screen_w, screen_h), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    screen.blit(overlay, (0, 0))

    x = (screen_w - POPUP_W) // 2
    y = (screen_h - POPUP_H) // 2
    popup_rect = pygame.Rect(x, y, POPUP_W, POPUP_H)
    pygame.draw.rect(screen, COLOR_BG, popup_rect, border_radius=10)
    pygame.draw.rect(screen, COLOR_BORDER, popup_rect, 3, border_radius=10)

    name = item_template.get("name", "Unknown")
    item_id = item_template.get("item_id", "?")

    draw_popup_icon(screen, x + 30, y + 30, item_template)

    lbl_name = font.render(f"{name} (ID: {item_id})", True, COLOR_BORDER)
    screen.blit(lbl_name, (x + 90, y + 35))

    count = item_data.get("count", 1)
    lbl_count = font_small.render(f"So luong hien co: {count}", True, C_VANG)
    screen.blit(lbl_count, (x + 90, y + 70))

    stats_display = format_custom_stats(item_template)
    lbl_desc = font_small.render(f"Chi so: {stats_display}", True, WHITE)
    screen.blit(lbl_desc, (x + 30, y + 110))

    close_rect = pygame.Rect(x + POPUP_W - 35, y + 10, 25, 25)
    pygame.draw.rect(screen, C_BTN_CANCEL, close_rect, border_radius=3)
    lbl_x = font_small.render("X", True, WHITE)
    screen.blit(lbl_x, lbl_x.get_rect(center=close_rect.center))

    return close_rect


def handle_buy_transaction(player_data, shop_item_data, inventory):
    """Xử lý trừ tiền và thêm đồ (FIX: nếu price=0 thì resolve lại giá, rada không còn free)"""
    ITEM_TEMPLATES = main.ITEM_TEMPLATES if main and hasattr(main, "ITEM_TEMPLATES") else {}

    item_key = shop_item_data.get("key", "unknown")

    # FIX: resolve giá nếu 0
    cost, currency = _resolve_price_and_currency(shop_item_data, item_key)

    money_key = currency.lower()  # vang / kim_cuong / vnd
    player_money = int(player_data.get(money_key, 0) or 0)

    if cost < 0:
        print(f"[WARNING] Item {item_key} has invalid cost ({cost}). Deny transaction.")
        return False

    if player_money < cost:
        print(f"[ERROR] Transaction failed: Player {money_key} ({player_money}) < Cost ({cost})")
        return False

    # trừ tiền
    if cost > 0:
        player_data[money_key] = player_money - cost

    # thêm item
    try:
        item_template = ITEM_TEMPLATES.get(item_key, {})
        is_stackable = (item_template.get("type") == "Tieu Hao")

        added = False

        if is_stackable:
            for i, slot in enumerate(inventory):
                if slot and slot.get("key") == item_key and slot.get("count", 0) < 99:
                    inventory[i]["count"] = slot.get("count", 0) + 1
                    added = True
                    break

        if not added:
            empty_idx = inventory.index(None)
            inventory[empty_idx] = {"key": item_key, "count": 1, "stars": 0}
            added = True

        return True

    except ValueError:
        # túi đầy -> hoàn tiền
        player_data[money_key] = int(player_data.get(money_key, 0) or 0) + cost
        print(f"[ERROR] Transaction failed: Inventory full. Refunding {cost} {currency}")
        return False
