
# ssj2_v3fx.py / ssj2_game_fix.py
# FX hào quang + nổ biến hình kiểu "glow bao quanh người" (GIỐNG demo aura glow)
# - Glow mềm bao quanh người (không phải vòng viền)
# - Có hạt + lửa nhẹ + boom + bụi + wave
#
# Nếu dùng cho GAME: main.py có thể đọc SSJ_MULT để buff.
#
import math
import random
import pygame

# ====== THÔNG SỐ BUFF (main.py cần SSJ_MULT) ======
SSJ_MULT = 1.30          # +30% HP/KI/SĐ
SSJ_CHARGE_TIME = 1.10   # thời gian giữ để biến hình
SSJ_TRANSFORM_DUR = 0.55 # duration hiệu ứng nổ/phồng

def _clamp(x, a, b):
    return a if x < a else b if x > b else x

def _lerp(a, b, t):
    return a + (b - a) * t

def _lerp_color(c1, c2, t):
    t = _clamp(t, 0.0, 1.0)
    return (
        int(_lerp(c1[0], c2[0], t)),
        int(_lerp(c1[1], c2[1], t)),
        int(_lerp(c1[2], c2[2], t)),
    )

def _ease_out_cubic(t):
    t = _clamp(t, 0.0, 1.0)
    return 1.0 - (1.0 - t) ** 3

# Charge palette (xanh -> vàng)
AURA_BLUE = (120, 210, 255)
AURA_BLUE_LIGHT = (210, 245, 255)
AURA_YELLOW = (255, 230, 110)
AURA_YELLOW_LIGHT = (255, 250, 210)

# SSJ palette
SSJ_GLOW = (255, 235, 150)
SSJ_DARK = (190, 130, 10)

GROUND_DUST = (120, 120, 135)

class AuraParticle:
    __slots__ = ("x","y","vx","vy","life","age","r","col","spin")
    def __init__(self, x, y, vx, vy, life, r, col):
        self.x = float(x); self.y = float(y)
        self.vx = float(vx); self.vy = float(vy)
        self.life = float(life); self.age = 0.0
        self.r = float(r); self.col = col
        self.spin = random.uniform(-6.0, 6.0)
    def update(self, dt):
        self.age += dt
        if self.age >= self.life:
            return False
        t = self.age / self.life
        self.vx += math.sin(self.age * 12.0 + self.spin) * 3.5 * (1.0 - t)
        self.vx *= 0.93
        self.vy *= 0.94
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.r = max(0.0, self.r - 9.0 * dt)
        return True

class Dust:
    __slots__=("x","y","vx","vy","life","age","r","col")
    def __init__(self, x, y, vx, vy, life, r, col):
        self.x=float(x); self.y=float(y)
        self.vx=float(vx); self.vy=float(vy)
        self.life=float(life); self.age=0.0
        self.r=float(r); self.col=col
    def update(self, dt):
        self.age += dt
        if self.age >= self.life:
            return False
        self.vx *= 0.90
        self.vy *= 0.92
        self.x += self.vx*dt
        self.y += self.vy*dt
        self.r = max(0.0, self.r - 10.0*dt)
        return True

class GroundWave:
    __slots__=("x","y","r","dr","life","age")
    def __init__(self, x, y, r0, dr, life):
        self.x=float(x); self.y=float(y)
        self.r=float(r0); self.dr=float(dr)
        self.life=float(life); self.age=0.0
    def update(self, dt):
        self.age += dt
        if self.age >= self.life:
            return False
        self.r += self.dr*dt
        return True

class BoomParticle:
    __slots__ = ("x","y","vx","vy","life","age","r","col","drag")
    def __init__(self, x, y, vx, vy, life, r, col, drag=0.90):
        self.x=float(x); self.y=float(y)
        self.vx=float(vx); self.vy=float(vy)
        self.life=float(life); self.age=0.0
        self.r=float(r); self.col=col; self.drag=float(drag)
    def update(self, dt):
        self.age += dt
        if self.age >= self.life:
            return False
        self.vx *= self.drag
        self.vy *= self.drag
        self.x += self.vx*dt
        self.y += self.vy*dt
        self.r = max(0.0, self.r - 16.0*dt)
        return True

class ShockRing:
    __slots__=("x","y","r","dr","life","age","thick","col")
    def __init__(self, x, y, r0, dr, life, thick, col):
        self.x=float(x); self.y=float(y)
        self.r=float(r0); self.dr=float(dr)
        self.life=float(life); self.age=0.0
        self.thick=float(thick); self.col=col
    def update(self, dt):
        self.age += dt
        if self.age >= self.life:
            return False
        self.r += self.dr*dt
        return True

def _aura_cols(t):
    t2 = _ease_out_cubic(t)
    core = _lerp_color(AURA_BLUE, AURA_YELLOW, t2)
    light = _lerp_color(AURA_BLUE_LIGHT, AURA_YELLOW_LIGHT, t2)
    dark = _lerp_color((20, 90, 140), (200, 140, 20), t2)
    return core, light, dark

def _spawn_aura(ps, cx, cy, t, dt, ssj=False, size_scale=1.0):
    if t <= 0.001:
        return
    if ssj:
        core = AURA_YELLOW
        light = SSJ_GLOW
        rate = (24 + 56 * t) * size_scale
    else:
        core, light, _ = _aura_cols(t)
        rate = (20 + 52 * t) * size_scale

    want = rate * dt
    n = int(want)
    if random.random() < (want - n):
        n += 1

    spread = 20 * size_scale
    for _ in range(n):
        ox = random.uniform(-spread, spread)
        oy = random.uniform(-20*size_scale, 14*size_scale)
        x = cx + ox
        y = cy + oy
        vx = random.uniform(-45, 45) * (0.7 + 0.6*t)
        vy = random.uniform(-210, -120) * (0.7 + 0.7*t)
        life = random.uniform(0.16, 0.30)
        r = random.uniform(4, 10) * (0.75 + 0.6*t)
        col = light if random.random() < 0.35 else core
        ps.append(AuraParticle(x, y, vx, vy, life, r, col))

def _draw_soft_aura_glow(surf, cx, cy, t, tick, ps, ssj=False, size_scale=1.0, pulse=0.0):
    if t <= 0.001:
        return
    sw, sh = surf.get_width(), surf.get_height()

    if ssj:
        core = AURA_YELLOW
        light = SSJ_GLOW
        dark = SSJ_DARK
    else:
        core, light, dark = _aura_cols(t)

    a = pygame.Surface((sw, sh), pygame.SRCALPHA)

    s = (1.12 * size_scale) + pulse
    s = max(0.85, s)

    # Glow mềm bao quanh người (KHÔNG vẽ vòng viền)
    base_w = int(56 * s)
    base_h = int(96 * s)

    layers = 7
    for i in range(layers):
        k = 1.0 - (i / max(1, layers-1))
        w = int(base_w * (0.92 + 0.18*k))
        h = int(base_h * (0.92 + 0.18*k))
        x = cx - w//2
        y = cy - int(76*s) - (base_h - h)//3
        alpha = int((16 + 46*t) * (0.30 + 0.70*k))
        col = light if k > 0.55 else core
        pygame.draw.ellipse(a, (*col, alpha), (x, y, w, h))

    # Lửa nhẹ
    flame_count = int((10 + 12 * t) * s)
    fw = (24 + 12*t) * s
    fh = (46 + 18*t) * s
    jitter = math.sin(tick * 0.10) * 1.4
    for i in range(flame_count):
        ang = (i / max(1, flame_count)) * math.tau
        rx = fw + 7 * math.sin(tick*0.05 + i) * t
        ry = fh + 6 * math.cos(tick*0.04 + i) * t
        x = cx + math.cos(ang) * rx
        y = cy - 10 + math.sin(ang) * ry * 0.70
        up = (18 + 36*t) * (0.35 + 0.65 * (1.0 - max(0.0, math.sin(ang)))) * (0.92 + 0.08*s)
        y -= up
        pw = (8 + 10*t) * (0.92 + 0.08*s)
        ph = (18 + 18*t) * (0.92 + 0.08*s)
        alpha = int((26 + 62*t) * (0.55 + 0.45*random.random()))
        col = light if random.random() < 0.25 else core
        pygame.draw.ellipse(a, (*col, alpha), (x - pw/2 + jitter, y - ph/2, pw, ph))
        if random.random() < 0.05:
            pygame.draw.ellipse(a, (*dark, int(28*t)), (x - pw/2 + jitter, y - ph/2, pw, ph), 1)

    # Particles
    for p in ps:
        k = 1.0 - (p.age / p.life)
        alpha = int(150 * k * (0.6 + 0.4*t))
        if alpha <= 0:
            continue
        pygame.draw.circle(a, (p.col[0], p.col[1], p.col[2], alpha), (int(p.x), int(p.y)), max(1, int(p.r)))

    surf.blit(a, (0, 0), special_flags=pygame.BLEND_ADD)

def _spawn_quake_fx(dust_list, wave_list, x, ground_y, power=1.0):
    wave_list.append(GroundWave(x, ground_y, 18, 820*power, 0.34))
    wave_list.append(GroundWave(x, ground_y, 30, 520*power, 0.42))
    for _ in range(int(42*power)):
        ang = random.uniform(-math.pi*0.12, math.pi*1.12)
        spd = random.uniform(180, 520)*power
        vx = math.cos(ang)*spd
        vy = -abs(math.sin(ang)*spd) * random.uniform(0.5, 1.0)
        life = random.uniform(0.22, 0.46)
        r = random.uniform(3.0, 7.8)
        dust_list.append(Dust(x, ground_y+2, vx, vy, life, r, GROUND_DUST))

def _draw_quake_fx(surf, dust_list, wave_list):
    sw, sh = surf.get_width(), surf.get_height()
    a = pygame.Surface((sw, sh), pygame.SRCALPHA)

    for wv in wave_list:
        t = wv.age / wv.life if wv.life > 1e-9 else 1.0
        alpha = int(140 * (1.0 - t))
        if alpha <= 0:
            continue
        r = wv.r
        rect = pygame.Rect(0, 0, int(r*2.0), int(r*0.55))
        rect.center = (int(wv.x), int(wv.y))
        pygame.draw.ellipse(a, (255, 240, 210, alpha), rect, 2)

    for d in dust_list:
        t = d.age / d.life if d.life > 1e-9 else 1.0
        alpha = int(150 * (1.0 - t))
        if alpha <= 0:
            continue
        pygame.draw.circle(a, (d.col[0], d.col[1], d.col[2], alpha), (int(d.x), int(d.y)), max(1, int(d.r)))

    surf.blit(a, (0, 0), special_flags=pygame.BLEND_ADD)

def _spawn_transform_boom(particles, rings, x, y, power=1.0):
    rings.append(ShockRing(x, y, 10, 820*power, 0.22, 5, (255, 245, 220)))
    rings.append(ShockRing(x, y, 18, 560*power, 0.28, 3, (255, 220, 140)))
    rings.append(ShockRing(x, y, 26, 420*power, 0.33, 2, (255, 170, 90)))
    for _ in range(int(52*power)):
        ang = random.random()*math.tau
        spd = random.uniform(220, 640)*power
        vx = math.cos(ang)*spd
        vy = math.sin(ang)*spd
        life = random.uniform(0.16, 0.32)
        r = random.uniform(2.5, 6.5)
        col = (255, random.randint(200, 250), random.randint(130, 200))
        particles.append(BoomParticle(x, y, vx, vy, life, r, col, drag=0.88))

def _draw_boom_fx(surf, particles, rings):
    sw, sh = surf.get_width(), surf.get_height()
    a = pygame.Surface((sw, sh), pygame.SRCALPHA)

    for ring in rings:
        t = ring.age / ring.life if ring.life > 1e-9 else 1.0
        alpha = int(200*(1.0-t))
        if alpha <= 0:
            continue
        pygame.draw.circle(a, (*ring.col, alpha), (int(ring.x), int(ring.y)), int(ring.r), max(1, int(ring.thick)))

    for p in particles:
        t = p.age / p.life if p.life > 1e-9 else 1.0
        alpha = int(200*(1.0-t))
        if alpha <= 0:
            continue
        pygame.draw.circle(a, (p.col[0], p.col[1], p.col[2], alpha), (int(p.x), int(p.y)), max(1, int(p.r)))

    surf.blit(a, (0, 0), special_flags=pygame.BLEND_ADD)

class SSJFX:
    def __init__(self):
        self.aura_ps = []
        self.boom_ps = []
        self.boom_rings = []
        self.dust_ps = []
        self.wave_fx = []
        self.flash = 0.0
        self.shake = 0.0
        self._tick = 0

    def reset(self):
        self.aura_ps.clear()
        self.boom_ps.clear()
        self.boom_rings.clear()
        self.dust_ps.clear()
        self.wave_fx.clear()
        self.flash = 0.0
        self.shake = 0.0
        self._tick = 0

    def trigger_transform(self, cx, cy, ground_y, power=1.15):
        _spawn_transform_boom(self.boom_ps, self.boom_rings, int(cx), int(cy-2), power=1.25)
        _spawn_quake_fx(self.dust_ps, self.wave_fx, int(cx), int(ground_y), power=power)
        self.flash = 0.22
        self.shake = max(self.shake, 0.32)

    def update(self, dt, cx, cy, charge_t=0.0, ssj_active=False, state="IDLE"):
        self._tick += 1

        if state == "CHARGING":
            _spawn_aura(self.aura_ps, cx, cy, charge_t, dt, ssj=False, size_scale=1.10)
        elif ssj_active and state != "TRANSFORM":
            _spawn_aura(self.aura_ps, cx, cy, 0.95, dt, ssj=True, size_scale=1.08)
        elif state == "TRANSFORM":
            burst = 0.85 + 0.15*math.sin(_clamp(charge_t, 0.0, 1.0)*math.pi)
            _spawn_aura(self.aura_ps, cx, cy, burst, dt, ssj=True, size_scale=1.22)

        self.aura_ps = [p for p in self.aura_ps if p.update(dt)]
        self.boom_ps = [p for p in self.boom_ps if p.update(dt)]
        self.boom_rings = [r for r in self.boom_rings if r.update(dt)]
        self.dust_ps = [d for d in self.dust_ps if d.update(dt)]
        self.wave_fx = [w for w in self.wave_fx if w.update(dt)]

        if self.flash > 0:
            self.flash = max(0.0, self.flash - dt)
        if self.shake > 0:
            self.shake = max(0.0, self.shake - dt * 0.9)

    def get_shake_offset(self):
        if self.shake <= 0:
            return 0, 0
        s = int(11 * (self.shake / 0.32))
        dx = random.randint(-s, s)
        dy = random.randint(-s, s) + int(3 * math.sin(self._tick*0.9) * (self.shake/0.32))
        return dx, dy

    def draw(self, screen, cx, cy, charge_t=0.0, ssj_active=False, state="IDLE"):
        tick = self._tick
        _draw_quake_fx(screen, self.dust_ps, self.wave_fx)

        if state == "CHARGING":
            _draw_soft_aura_glow(screen, cx, cy, charge_t, tick, self.aura_ps, ssj=False, size_scale=1.10)
        elif ssj_active and state != "TRANSFORM":
            _draw_soft_aura_glow(screen, cx, cy, 0.95, tick, self.aura_ps, ssj=True, size_scale=1.08)
        elif state == "TRANSFORM":
            pulse = 0.55 * math.sin(math.pi * _clamp(charge_t, 0.0, 1.0))
            _draw_soft_aura_glow(screen, cx, cy, 0.95, tick, self.aura_ps, ssj=True, size_scale=1.08, pulse=pulse)

        _draw_boom_fx(screen, self.boom_ps, self.boom_rings)

        if self.flash > 0:
            sw, sh = screen.get_width(), screen.get_height()
            a = int(120 * (self.flash / 0.22))
            overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
            overlay.fill((255, 245, 220, a))
            screen.blit(overlay, (0, 0), special_flags=pygame.BLEND_ADD)
