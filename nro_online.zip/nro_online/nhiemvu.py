import pygame

# --- CẤU HÌNH MÀU SẮC & CONST ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED_TITLE = (255, 0, 0)
GREEN_SUCCESS = (0, 200, 0)
C_VANG = (255, 215, 0)
BLUE_UI = (0, 100, 255)
GRAY = (200, 200, 200)

def get_npc_name_by_planet(hanh_tinh):
    """Trả về tên NPC và tên quái nhiệm vụ theo hành tinh"""
    if hanh_tinh == "Trai Dat": return "Ong Gohan", "Lang Aru", "Khung Long"
    elif hanh_tinh == "Namec": return "Ong Moori", "Lang Moori", "Quai Dat"
    elif hanh_tinh == "Xayda": return "Vua Vegeta", "Lang Vegeta", "Heo Rung"
    return "NPC", "Lang", "Quai Vat"

def check_mission_progress(info, mob_type):
    """Kiểm tra tiến độ nhiệm vụ: 'MOC_NHAN', 'QUAI_MAP2', hoặc 'BOSS'"""
    quest = info.get("quest", {"id": 0, "progress": 0, "target": 5})
    
    # NV1: Mộc nhân
    if quest["id"] == 1 and mob_type == "MOC_NHAN":
        if quest["progress"] < quest["target"]:
            info["quest"]["progress"] += 1
            return True 

    # NV2: Quái Map 2
    if quest["id"] == 3 and mob_type == "QUAI_MAP2":
        if quest["progress"] < quest["target"]:
            info["quest"]["progress"] += 1
            return True

    # NV3: Boss Lợn Lòi Mẹ
    if quest["id"] == 5 and mob_type == "BOSS":
        if quest["progress"] < quest["target"]:
            info["quest"]["progress"] += 1
            return True

    return False

def complete_mission(info):
    """Hoàn thành nhiệm vụ và nhận thưởng"""
    quest = info.get("quest", {})
    
    # --- Xong NV 1 ---
    if quest.get("id") == 1 and quest.get("progress") >= quest.get("target"):
        info["vang"] += 100000
        info["suc_manh"] += 2000
        info["tiem_nang"] += 2000
        info["quest"] = {"id": 2, "progress": 0, "target": 0} 
        return True, "NV1"

    # --- Xong NV 2 ---
    if quest.get("id") == 3 and quest.get("progress") >= quest.get("target"):
        info["vang"] += 5000
        info["suc_manh"] += 10000
        info["tiem_nang"] += 10000
        info["quest"] = {"id": 4, "progress": 0, "target": 0} 
        return True, "NV2"

    # --- Xong NV 3: Boss ---
    if quest.get("id") == 5 and quest.get("progress") >= quest.get("target"):
        info["vang"] += 15000  # Phần thưởng 15k vàng
        info["suc_manh"] += 20000 # Thưởng 20k SM
        info["tiem_nang"] += 20000 # Thưởng 20k TN
        info["quest"] = {"id": 6, "progress": 0, "target": 0} 
        return True, "NV3"
        
    return False, None

def draw_sidebar_quest(surface, x, y, info, font_small, hanh_tinh):
    """Vẽ thông tin nhiệm vụ lên thanh Sidebar"""
    quest_data = info.get("quest", {"id": 0, "progress": 0, "target": 5})
    q_id = quest_data.get("id", 0)
    q_prog = quest_data.get("progress", 0)
    q_target = quest_data.get("target", 5)
    
    npc_name, _, mob_name = get_npc_name_by_planet(hanh_tinh)

    if q_id == 0:
        surface.blit(font_small.render(f"Gap {npc_name} nhan NV.", True, WHITE), (x, y))
    elif q_id == 1:
        color = (0, 255, 0) if q_prog >= q_target else WHITE
        surface.blit(font_small.render(f"Danh Moc Nhan: {q_prog}/{q_target}", True, color), (x, y))
    elif q_id == 2:
        surface.blit(font_small.render(f"Gap {npc_name} tra NV1.", True, C_VANG), (x, y))
    elif q_id == 3:
        color = (0, 255, 0) if q_prog >= q_target else WHITE
        surface.blit(font_small.render(f"Diet {mob_name}: {q_prog}/{q_target}", True, color), (x, y))
    elif q_id == 4:
        surface.blit(font_small.render(f"Gap {npc_name} nhan NV3.", True, C_VANG), (x, y))
    elif q_id == 5:
        boss_name = f"Boss Lon Loi {hanh_tinh}"
        color = (0, 255, 0) if q_prog >= q_target else WHITE
        surface.blit(font_small.render(f"Diet {boss_name}: {q_prog}/1", True, color), (x, y))
    elif q_id == 6:
        surface.blit(font_small.render("Da xong tat ca NV!", True, GREEN_SUCCESS), (x, y))

def ve_nut_custom_local(screen, rect, mau, text, text_color, font):
    pygame.draw.rect(screen, mau, rect, border_radius=5)
    pygame.draw.rect(screen, WHITE, rect, 2, border_radius=5)
    text_surf = font.render(text, True, text_color)
    text_rect = text_surf.get_rect(center=rect.center)
    screen.blit(text_surf, text_rect)

def draw_quest_dialog(screen, width, height, hanh_tinh, step, font_title, font_content, q_id_current, info):
    """Ve bang hoi thoai nhiem vu (KHONG DAU) + tra ve (btn_rect, box_rect)"""
    s = pygame.Surface((width, height), pygame.SRCALPHA)
    s.fill((0, 0, 0, 150))
    screen.blit(s, (0, 0))

    box_w, box_h = 600, 220
    box_rect = pygame.Rect((width - box_w)//2, (height - box_h)//2, box_w, box_h)
    pygame.draw.rect(screen, (40, 40, 40), box_rect, border_radius=10)
    pygame.draw.rect(screen, C_VANG, box_rect, 2, border_radius=10)

    npc_name, lang_name, mob_name = get_npc_name_by_planet(hanh_tinh)
    name_surf = font_title.render(npc_name, True, RED_TITLE)
    screen.blit(name_surf, (box_rect.x + 20, box_rect.y + 15))

    q = info.get("quest", {"id": 0, "progress": 0, "target": 0})
    q_prog = q.get("progress", 0)
    q_target = q.get("target", 0)

    txt_lines = []
    curr_sm = info.get("suc_manh", 0)
    required_sm = 20000
    can_accept_nv3 = curr_sm >= required_sm

    if q_id_current == 0:
        if step == 1:
            txt_lines = [f"Con hay luyen tap voi dam Moc Nhan o {lang_name} di."]
        elif step == 2:
            txt_lines = [
                "Con hay danh duoc 5 con Moc Nhan roi quay lai day.",
                "Thuong: 100k Vang, 2000 SM-TN"
            ]

    elif q_id_current == 1:
        if q_prog < q_target:
            txt_lines = [
                "Nhiem vu cua con la: Danh Moc Nhan",
                f"Tien do: {q_prog}/{q_target}",
                "Xong roi hay quay ve bao cao voi ta."
            ]
        else:
            txt_lines = [
                "Nhiem vu thanh cong!",
                "Nhan NHAN THUONG de hoan tat.",
                f"Tien do: {q_prog}/{q_target}"
            ]

    elif q_id_current == 2:
        if step == 1:
            txt_lines = [
                "Tot lam! Bay gio con hay ra khoi lang.",
                f"Tim va tieu diet 10 con {mob_name} (400 HP)."
            ]
        elif step == 2:
            txt_lines = [
                "Luu y: Chung kha manh day.",
                "Thuong: 5000 Vang, 10,000 SM-TN"
            ]

    elif q_id_current == 3:
        if q_prog < q_target:
            txt_lines = [
                f"Nhiem vu cua con la: Diet {mob_name}",
                f"Tien do: {q_prog}/{q_target}",
                "Xong roi hay quay ve bao cao voi ta."
            ]
        else:
            txt_lines = [
                "Gioi lam! Con da hoan thanh nhiem vu.",
                "Nhan NHAN THUONG de hoan tat.",
                f"Tien do: {q_prog}/{q_target}"
            ]

    elif q_id_current == 4:
        if not can_accept_nv3:
            txt_lines = [
                "Con chua du suc manh roi,",
                "khi nao manh hon hay gap ta nhe.",
                f"Yeu cau {required_sm:,} sm"
            ]
        else:
            if step == 1:
                txt_lines = [
                    f"Thach thuc cuoi cung: Hay di diet Boss Lon Loi Me {hanh_tinh}.",
                    "No dang tan pha khu vuc Map 2."
                ]
            elif step == 2:
                txt_lines = [
                    "Luu y: No co the tu hoi phuc mau rat nhanh!",
                    "Thuong: 15,000 Vang, 20,000 SM-TN"
                ]

    elif q_id_current == 5:
        boss_name = f"Boss Lon Loi Me {hanh_tinh}"
        if q_prog < q_target:
            txt_lines = [
                f"Nhiem vu cua con la: Diet {boss_name}",
                f"Tien do: {q_prog}/{q_target}",
                "Xong roi hay quay ve bao cao voi ta."
            ]
        else:
            txt_lines = [
                "That phi thuong! Con da ha guc duoc Boss.",
                "Nhan NHAN THUONG de hoan tat.",
                f"Tien do: {q_prog}/{q_target}"
            ]

    elif q_id_current == 6:
        txt_lines = [
            "Con da hoan thanh tat ca nhiem vu!",
            "Hay tu minh ren luyen de manh hon nhe."
        ]

    # Ve chu
    start_y = box_rect.y + 55
    for i, line in enumerate(txt_lines):
        screen.blit(font_content.render(line, True, WHITE), (box_rect.x + 20, start_y + i * 26))

    # Nut bam
    btn_w, btn_h = 150, 40
    btn_rect = pygame.Rect(box_rect.centerx - btn_w//2, box_rect.bottom - 55, btn_w, btn_h)

    lbl_btn = "DONG"
    if q_id_current in [1, 3, 5]:
        lbl_btn = "NHAN THUONG" if (q_target > 0 and q_prog >= q_target) else "DONG"
    elif q_id_current == 4 and not can_accept_nv3:
        lbl_btn = "DONG"
    elif (q_id_current in [0, 2, 4]) and step == 1:
        lbl_btn = "TIEP"
    elif (q_id_current in [0, 2, 4]) and step == 2:
        lbl_btn = "NHAN"

    ve_nut_custom_local(screen, btn_rect, BLUE_UI, lbl_btn, WHITE, font_content)
    return btn_rect, box_rect