import pygame
import math

# --- CẤU HÌNH ---
COLOR_TEXT = (255, 255, 255)
COLOR_VALUE = (0, 255, 0) 
COLOR_BTN_BG = (0, 100, 200)
COLOR_BTN_BORDER = (255, 215, 0)
RED_ERROR = (255, 0, 0)

# Giới hạn Max mới theo tính toán của bạn
MAX_HP = 220000
MAX_KI = 220000
MAX_SD = 12000

# Chỉ số mặc định
DEFAULT_HP = 100
DEFAULT_KI = 100
DEFAULT_SD = 10

class UpgradeManager:
    def __init__(self, screen_width, screen_height, font_ui, font_small):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.font = font_ui
        self.font_small = font_small
        
        self.show_popup = False
        self.selected_stat_type = None 
        self.rect_list = {} 
        self.popup_rect = pygame.Rect(0, 0, 0, 0)
        self.popup_buttons = []

    def calculate_cost(self, stat_type, current_value, increase_amount):
        """
        Tính tiêu hao tiềm năng theo các mốc phân tầng (Tier).
        """
        cost_per_unit = 0
        
        if stat_type in ["HP", "KI"]:
            # Tính dựa trên mốc 20 điểm như yêu cầu
            if current_value < 20000:
                cost_per_20_pts = 1000
            elif current_value < 100000:
                cost_per_20_pts = 20000
            elif current_value < 180000:
                cost_per_20_pts = 200000
            elif current_value < 200000:
                cost_per_20_pts = 1000000
            else: # 200k -> 220k
                cost_per_20_pts = 5000000
            
            # Giá của 1 điểm HP/KI
            cost_per_unit = cost_per_20_pts / 20

        else: # Sức Đánh (SD)
            if current_value < 500:
                cost_per_unit = 2000
            elif current_value < 5000:
                cost_per_unit = 50000
            elif current_value < 10000:
                cost_per_unit = 300000
            else: # 10000 -> 12000
                cost_per_unit = 1500000

        total_cost = increase_amount * cost_per_unit
        return int(total_cost)

    def format_number(self, num):
        """Rút gọn số: 1.000.000 -> 1Tr, 1.000.000.000 -> 1 Tỷ"""
        if num >= 1000000000:
            return f"{num/1000000000:.1f} Tỷ".replace('.0', '')
        if num >= 1000000:
            return f"{num/1000000:.1f}Tr".replace('.0', '')
        if num >= 1000:
            return f"{num/1000:.1f}K".replace('.0', '')
        return str(int(num))

    def draw_left_panel(self, screen, x, y, width, info):
        tiem_nang = info.get("tiem_nang", 0)
        hp = info.get("max_hp", DEFAULT_HP)
        ki = info.get("max_ki", DEFAULT_KI)
        sd = info.get("suc_danh", DEFAULT_SD)
        
        start_y = y + 20
        line_height = 40
        
        # Tiềm năng
        tn_str = f"Tiềm năng: {self.format_number(tiem_nang)}"
        lbl_tn = self.font_small.render(tn_str, True, (255, 255, 0))
        screen.blit(lbl_tn, (x + 10, start_y))
        
        # Các dòng chỉ số
        stats = [
            ("HP gốc", hp, COLOR_VALUE, "HP"),
            ("KI gốc", ki, (0, 150, 255), "KI"),
            ("Sức đánh gốc", sd, (255, 50, 50), "SD")
        ]

        mouse_pos = pygame.mouse.get_pos()
        for i, (label, val, color, key) in enumerate(stats):
            rect = pygame.Rect(x + 5, start_y + line_height * (i+1), width - 10, 30)
            if rect.collidepoint(mouse_pos) and not self.show_popup:
                pygame.draw.rect(screen, (50, 50, 60), rect, border_radius=5)
            
            txt = self.font_small.render(f"{label}: {val:,}", True, color)
            screen.blit(txt, (x + 10, rect.y + 5))
            pygame.draw.rect(screen, COLOR_BTN_BORDER, (x + width - 30, rect.y + 10, 10, 10))
            self.rect_list[key] = rect

    def draw_popup(self, screen, info):
        if not self.show_popup: return
        
        overlay = pygame.Surface((self.screen_width, self.screen_height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        screen.blit(overlay, (0,0))
        
        panel_h = 160
        panel_y = self.screen_height - panel_h
        self.popup_rect = pygame.Rect(0, panel_y, self.screen_width, panel_h)
        pygame.draw.rect(screen, (25, 25, 35), self.popup_rect)
        pygame.draw.line(screen, COLOR_BTN_BORDER, (0, panel_y), (self.screen_width, panel_y), 3)
        
        t_name = "SỨC ĐÁNH" if self.selected_stat_type == "SD" else self.selected_stat_type
        title = self.font.render(f"NÂNG CẤP {t_name}", True, (255, 255, 255))
        screen.blit(title, (self.screen_width//2 - title.get_width()//2, panel_y + 10))
        
        options = [10, 100, 1000, 10000] if self.selected_stat_type in ["HP", "KI"] else [1, 10, 100, 1000]
        
        btn_w, btn_h, gap = 130, 70, 15
        total_w = len(options) * btn_w + (len(options)-1) * gap
        start_x = (self.screen_width - total_w) // 2
        
        self.popup_buttons = []
        current_val = info.get("max_hp" if self.selected_stat_type=="HP" else ("max_ki" if self.selected_stat_type=="KI" else "suc_danh"), 0)
        max_val = MAX_HP if self.selected_stat_type in ["HP", "KI"] else MAX_SD

        for i, amount in enumerate(options):
            rect = pygame.Rect(start_x + i * (btn_w + gap), panel_y + 55, btn_w, btn_h)
            cost = self.calculate_cost(self.selected_stat_type, current_val, amount)
            can_buy = info.get("tiem_nang", 0) >= cost
            is_max = current_val >= max_val
            
            color = COLOR_BTN_BG if (can_buy and not is_max) else (70, 70, 70)
            pygame.draw.rect(screen, color, rect, border_radius=10)
            pygame.draw.rect(screen, COLOR_BTN_BORDER, rect, 2, border_radius=10)
            
            txt_amt = self.font.render(f"+{amount:,}", True, (255, 255, 255))
            screen.blit(txt_amt, (rect.centerx - txt_amt.get_width()//2, rect.y + 10))
            
            cost_txt = "MAX" if is_max else self.format_number(cost)
            cost_col = RED_ERROR if (not can_buy and not is_max) else (255, 255, 0)
            txt_cost = self.font_small.render(cost_txt, True, cost_col)
            screen.blit(txt_cost, (rect.centerx - txt_cost.get_width()//2, rect.y + 40))
            
            self.popup_buttons.append({"rect": rect, "amount": amount, "cost": cost})

    def handle_event(self, event, info, trigger_save):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = event.pos
            if self.show_popup:
                for btn in self.popup_buttons:
                    if btn["rect"].collidepoint(mx, my):
                        if info["tiem_nang"] >= btn["cost"]:
                            key = "max_hp" if self.selected_stat_type=="HP" else ("max_ki" if self.selected_stat_type=="KI" else "suc_danh")
                            max_limit = MAX_HP if self.selected_stat_type in ["HP", "KI"] else MAX_SD
                            
                            if info[key] < max_limit:
                                info[key] = min(max_limit, info[key] + btn["amount"])
                                info["tiem_nang"] -= btn["cost"]
                                if self.selected_stat_type in ["HP", "KI"]:
                                    # Cập nhật thanh HP/KI hiện tại khi tăng giới hạn
                                    info[self.selected_stat_type.lower()] += btn["amount"]
                                trigger_save()
                        return True
                if not self.popup_rect.collidepoint(mx, my):
                    self.show_popup = False
                    return True
            else:
                for stat_key, rect in self.rect_list.items():
                    if rect.collidepoint(mx, my):
                        self.selected_stat_type = stat_key
                        self.show_popup = True
                        return True
        return False