import pygame

# --- CẤU HÌNH ---
WIDTH = 200
HEIGHT = 60
COLOR_BG = (0, 0, 0, 180) # Màu đen trong suốt
COLOR_BORDER = (255, 215, 0) # Viền vàng
COLOR_HP_BG = (50, 0, 0)    # Nền thanh máu (đỏ thẫm)
COLOR_HP = (255, 0, 0)      # Thanh máu (đỏ tươi)
COLOR_TEXT = (255, 255, 255)
COLOR_AVATAR_DEFAULT = (100, 50, 0) # Mặc định (Màu nâu Mộc Nhân)

font_name = None
font_hp = None

def init_fonts():
    global font_name, font_hp
    if font_name is None:
        # Đảm bảo pygame.font.init() được gọi ở đâu đó trước khi sử dụng
        pygame.font.init()
        font_name = pygame.font.SysFont("Arial", 12, bold=True)
    if font_hp is None:
        font_hp = pygame.font.SysFont("Arial", 10, bold=True)

class MonsterInfoPanel:
    def __init__(self, screen_width):
        # Vị trí: Góc phải trên, cách lề phải 80px (để né icon chat), cách lề trên 10px
        self.rect = pygame.Rect(screen_width - 80 - WIDTH, 10, WIDTH, HEIGHT)
        
    def draw(self, screen, monster):
        init_fonts()
        
        if monster is None or monster.hp <= 0:
            return

        # --- LẤY THÔNG TIN ĐỘNG TỪ OBJECT MONSTER (FIX) ---
        
        # Lấy các thuộc tính HP động (sử dụng giá trị mặc định an toàn nếu không có)
        current_hp = monster.hp
        if current_hp < 0: current_hp = 0
        
        # Lấy tên và cấp độ
        name = getattr(monster, 'name', "Unknown Monster")
        level = f"Lv {getattr(monster, 'level', 1)}"
        
        # Lấy max_hp (Nếu không có, dùng 10 cho MocNhan hoặc 500 cho Quái Map 2)
        if name == "Moc Nhan":
            max_hp = getattr(monster, 'max_hp', 10)
            avatar_color = COLOR_AVATAR_DEFAULT
        else:
            # Giả định các quái khác là Quái Map 2 (Lợn Lòi, Mèo Xanh, Khỉ Đột)
            max_hp = getattr(monster, 'max_hp', 500)
            # Lấy màu quái nếu có, nếu không thì dùng màu mặc định
            avatar_color = getattr(monster, 'color', (50, 50, 50)) 

        # Đảm bảo max_hp không phải 0 để tránh lỗi chia cho 0
        if max_hp <= 0: return
        
        # 1. Vẽ nền bảng
        s = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        pygame.draw.rect(s, COLOR_BG, (0, 0, WIDTH, HEIGHT), border_radius=5)
        pygame.draw.rect(s, COLOR_BORDER, (0, 0, WIDTH, HEIGHT), 1, border_radius=5)

        # 2. Avatar quái (Hình tròn nhỏ bên trái)
        pygame.draw.circle(s, avatar_color, (25, 30), 18) 
        pygame.draw.circle(s, COLOR_BORDER, (25, 30), 18, 1)

        # 3. Tên và Level
        txt_name = font_name.render(f"{name} [{level}]", True, COLOR_BORDER)
        s.blit(txt_name, (50, 8))

        # 4. Thanh máu
        bar_x = 50
        bar_y = 30
        bar_w = 140
        bar_h = 15
        
        ratio = current_hp / max_hp
        
        # Vẽ nền thanh máu
        pygame.draw.rect(s, COLOR_HP_BG, (bar_x, bar_y, bar_w, bar_h))
        # Vẽ máu hiện tại
        pygame.draw.rect(s, COLOR_HP, (bar_x, bar_y, bar_w * ratio, bar_h))
        # Vẽ khung thanh máu
        pygame.draw.rect(s, (200, 200, 200), (bar_x, bar_y, bar_w, bar_h), 1)
        
        # 5. Chỉ số máu X/Y
        txt_hp = font_hp.render(f"{current_hp}/{max_hp}", True, COLOR_TEXT)
        # Căn giữa chữ vào thanh máu
        txt_rect = txt_hp.get_rect(center=(bar_x + bar_w//2, bar_y + bar_h//2))
        s.blit(txt_hp, txt_rect)

        # Vẽ lên màn hình chính
        screen.blit(s, self.rect)