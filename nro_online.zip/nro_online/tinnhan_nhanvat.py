import pygame
import time

# --- CẤU HÌNH ---
CHAT_ICON_SIZE = 40
PANEL_WIDTH = 250
MESSAGE_DURATION = 4000  # Tăng lên 4 giây cho dễ đọc
COLOR_BG_PANEL = (30, 30, 40, 220) 
COLOR_BORDER = (255, 215, 0)       
COLOR_TEXT = (255, 255, 255)       
COLOR_ICON = (200, 200, 200)       

class ChatSystem:
    def __init__(self, screen_width, screen_height, font_ui):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.font = font_ui
        
        self.is_open = False
        self.input_text = ""
        self.active_messages = [] 
        
        self.icon_rect = pygame.Rect(screen_width - CHAT_ICON_SIZE - 10, 10, CHAT_ICON_SIZE, CHAT_ICON_SIZE)
        
        panel_h = screen_height - 100
        panel_y = (screen_height - panel_h) // 2
        self.panel_rect = pygame.Rect(10, panel_y, PANEL_WIDTH, panel_h)
        self.input_box_rect = pygame.Rect(self.panel_rect.x + 10, self.panel_rect.bottom - 40, PANEL_WIDTH - 20, 30)

    def handle_event(self, event):
        current_time = pygame.time.get_ticks()
        
        # 1. Xử lý bàn phím
        if event.type == pygame.KEYDOWN:
            
            # [LOGIC MỚI] Chỉ mở bằng phím R khi đang đóng
            if not self.is_open:
                if event.key == pygame.K_r:
                    self.is_open = True
                    self.input_text = "" # Xóa text cũ khi mở mới
                    return True # Đã xử lý sự kiện, không truyền tiếp

            # Xử lý nhập liệu khi bảng đang mở
            if self.is_open:
                if event.key == pygame.K_RETURN:
                    if self.input_text.strip():
                        # Gửi tin nhắn
                        self.active_messages.append({
                            'text': self.input_text,
                            'start_time': current_time
                        })
                        self.input_text = "" 
                        self.is_open = False # Gửi xong thì đóng
                    return True
                elif event.key == pygame.K_BACKSPACE:
                    self.input_text = self.input_text[:-1]
                    return True
                else:
                    # Nhập ký tự thường (bao gồm cả chữ r)
                    if len(self.input_text) < 50:
                        self.input_text += event.unicode
                    return True

        # 2. Xử lý click chuột
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse_pos = event.pos
            
            # Click vào icon -> Toggle (Vẫn giữ click icon để đóng/mở)
            if self.icon_rect.collidepoint(mouse_pos):
                self.is_open = not self.is_open
                return True

            # Click ra ngoài bảng khi bảng đang mở -> Đóng bảng
            if self.is_open and not self.panel_rect.collidepoint(mouse_pos):
                self.is_open = False
                return True
                
        return False

    def update(self):
        current_time = pygame.time.get_ticks()
        self.active_messages = [msg for msg in self.active_messages if current_time - msg['start_time'] < MESSAGE_DURATION]

    def draw_icon_bubble(self, screen, rect, color):
        pygame.draw.ellipse(screen, color, rect)
        pygame.draw.ellipse(screen, (50, 50, 50), rect, 2) 
        tail_pts = [(rect.centerx - 5, rect.bottom - 5), (rect.centerx + 5, rect.bottom - 5), (rect.centerx - 10, rect.bottom + 5)]
        pygame.draw.polygon(screen, color, tail_pts)
        pygame.draw.polygon(screen, (50, 50, 50), tail_pts, 2)
        dot_y = rect.centery
        pygame.draw.circle(screen, (50, 50, 50), (rect.centerx - 8, dot_y), 3)
        pygame.draw.circle(screen, (50, 50, 50), (rect.centerx, dot_y), 3)
        pygame.draw.circle(screen, (50, 50, 50), (rect.centerx + 8, dot_y), 3)

    def draw_ui(self, screen):
        # Vẽ Icon
        self.draw_icon_bubble(screen, self.icon_rect, COLOR_ICON)

        # Vẽ Bảng nhập liệu
        if self.is_open:
            panel_surf = pygame.Surface((self.panel_rect.width, self.panel_rect.height), pygame.SRCALPHA)
            panel_surf.fill(COLOR_BG_PANEL)
            screen.blit(panel_surf, self.panel_rect.topleft)
            pygame.draw.rect(screen, COLOR_BORDER, self.panel_rect, 2, border_radius=10)

            title_surf = self.font.render("KÊNH THẾ GIỚI", True, COLOR_BORDER)
            screen.blit(title_surf, (self.panel_rect.centerx - title_surf.get_width()//2, self.panel_rect.y + 10))
            
            hint_surf = self.font.render("[Enter] gửi, [Click ngoài] đóng", True, (150, 150, 150))
            screen.blit(hint_surf, (self.panel_rect.centerx - hint_surf.get_width()//2, self.input_box_rect.y - 25))

            pygame.draw.rect(screen, (255, 255, 255), self.input_box_rect, border_radius=5)
            pygame.draw.rect(screen, COLOR_BORDER, self.input_box_rect, 2, border_radius=5)
            
            display_text = self.input_text + ("|" if (pygame.time.get_ticks() // 500) % 2 == 0 else "")
            text_surf = self.font.render(display_text, True, (0, 0, 0))
            screen.set_clip(self.input_box_rect.inflate(-10, -5)) 
            screen.blit(text_surf, (self.input_box_rect.x + 5, self.input_box_rect.y + 5))
            screen.set_clip(None)

    def draw_messages_above_head(self, screen, player_rect):
        if not self.active_messages: return

        start_y = player_rect.top - 10 
        for msg in reversed(self.active_messages):
            text = msg['text']
            text_surf = self.font.render(text, True, COLOR_TEXT)
            text_w = text_surf.get_width()
            text_h = text_surf.get_height()
            
            bg_rect = pygame.Rect(player_rect.centerx - text_w // 2 - 10, start_y - text_h - 5, text_w + 20, text_h + 10)
            
            s = pygame.Surface((bg_rect.width, bg_rect.height), pygame.SRCALPHA)
            s.fill((0, 0, 0, 150))
            screen.blit(s, bg_rect.topleft)
            pygame.draw.rect(screen, COLOR_BORDER, bg_rect, 1, border_radius=5)
            screen.blit(text_surf, (bg_rect.x + 10, bg_rect.y + 5))
            start_y -= (text_h + 15)