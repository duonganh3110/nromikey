import pygame

# --- MÀU SẮC ---
WHITE = (255, 255, 255)
GREEN_SUCCESS = (0, 200, 0)
C_VANG = (255, 215, 0)
BLACK = (0, 0, 0)
GRAY_TEXT = (200, 200, 200)

# Biến lưu font
font_notification = None
font_close_btn = None 

def draw_notification_box_manual(screen, msg_line1, msg_line2, msg_line3, screen_width, screen_height, event_list=None):
    """
    Vẽ hộp thông báo 3 dòng (dòng 3 căn giữa dưới cùng).
    """
    global font_notification, font_close_btn

    # Khởi tạo font nếu chưa có
    if font_notification is None:
        if not pygame.font.get_init():
            pygame.font.init()
        font_notification = pygame.font.SysFont("Arial", 16)
    
    if font_close_btn is None:
        font_close_btn = pygame.font.SysFont("Arial", 18, bold=True)

    # 1. Render nội dung text
    text_surf_1 = font_notification.render(msg_line1, True, GREEN_SUCCESS)
    text_surf_2 = font_notification.render(msg_line2, True, C_VANG)
    text_surf_3 = font_notification.render(msg_line3, True, GRAY_TEXT) # Dòng dev màu xám nhạt

    # 2. Tính toán kích thước
    padding = 10
    # Chiều rộng box là dòng dài nhất trong 3 dòng
    total_text_width = max(text_surf_1.get_width(), text_surf_2.get_width(), text_surf_3.get_width())
    
    # Chiều cao box = tổng chiều cao 3 dòng + padding
    box_height = text_surf_1.get_height() + text_surf_2.get_height() + text_surf_3.get_height() + padding * 4
    box_width = total_text_width + padding * 6 # Thêm chiều ngang rộng hơn chút
    
    # Vị trí: Dưới mép màn hình 80px, căn giữa
    box_x = (screen_width - box_width) // 2
    box_y = screen_height - box_height - 80 

    # 3. Vẽ hộp
    box_rect = pygame.Rect(box_x, box_y, box_width, box_height)
    
    # Nền đen trong suốt
    overlay = pygame.Surface((box_width, box_height), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180)) 
    screen.blit(overlay, box_rect)
    
    # Viền vàng
    pygame.draw.rect(screen, C_VANG, box_rect, 2, border_radius=5)

    # 4. Vẽ chữ (Tất cả đều căn giữa box)
    center_x = box_rect.centerx
    
    # Dòng 1
    rect1 = text_surf_1.get_rect(centerx=center_x, top=box_y + padding)
    screen.blit(text_surf_1, rect1)
    
    # Dòng 2 (Cách dòng 1 một chút)
    rect2 = text_surf_2.get_rect(centerx=center_x, top=rect1.bottom + padding)
    screen.blit(text_surf_2, rect2)

    # Dòng 3 (Dev - Cách dòng 2 một chút)
    rect3 = text_surf_3.get_rect(centerx=center_x, top=rect2.bottom + padding)
    screen.blit(text_surf_3, rect3)

    # 5. Vẽ nút đóng (X)
    close_text = font_close_btn.render("X", True, WHITE)
    close_rect = close_text.get_rect(topright=(box_rect.right - 10, box_rect.top + 5))
    screen.blit(close_text, close_rect)

    # Xử lý click
    if event_list:
        for event in event_list:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if close_rect.collidepoint(event.pos):
                    return True 
    
    return False