import pygame
import sys
import math
import os
import random
import json
import unicodedata

# --- IMPORT MAIN MODULE ---
try:
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.join(current_dir, '..')
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)
    import main
except Exception as e:
    class DummyMain:
        SCREEN_WIDTH = 800; SCREEN_HEIGHT = 600
        WHITE = (255, 255, 255); BLACK = (0, 0, 0); GRAY = (100, 100, 100)
        RED_ERROR = (255, 0, 0); GREEN_SUCCESS = (0, 200, 0); STAR_COLOR = (255, 255, 0)
        C_VANG = (255, 215, 0); NPC_INTERACT_RANGE = 150
        ITEM_TEMPLATES = {}
        def __init__(self):
            pygame.init()
            self.font = pygame.font.SysFont("Arial", 24); self.font_small = pygame.font.SysFont("Arial", 16)
    main = DummyMain()

# --- CONFIG & COLORS ---
SCREEN_WIDTH = main.SCREEN_WIDTH
SCREEN_HEIGHT = main.SCREEN_HEIGHT
WHITE = main.WHITE; BLACK = main.BLACK; GRAY = main.GRAY
LIGHT_GRAY = (200, 200, 200); BLUE_CRYSTAL = (0, 200, 255)
SKIN_COLOR = (255, 220, 177); CLOTH_COLOR = (139, 69, 19)
STAR_COLOR = main.C_VANG
GREEN = (0, 255, 0); RED = (255, 0, 0)
INFO_BOX_BG = (50, 50, 50); DARK_GRAY = (50, 50, 50)
RED_ERROR = main.RED_ERROR; GREEN_SUCCESS = main.GREEN_SUCCESS
FONT_NAME_SIZE = 16; FONT_STATS_SIZE = 14
C_VANG = main.C_VANG
NPC_INTERACT_RANGE = main.NPC_INTERACT_RANGE if hasattr(main, 'NPC_INTERACT_RANGE') else 150

# --- TỈ LỆ VÀ CHI PHÍ ---
UPGRADE_RATES = {0: 80, 1: 50, 2: 40, 3: 20, 4: 10, 5: 5, 6: 1}
UPGRADE_COSTS = {0: 500000, 1: 2000000, 2: 5000000, 3: 15000000, 4: 50000000, 5: 100000000, 6: 200000000}

# --- TOAST MESSAGE ---
class ToastManager:
    def __init__(self):
        self.messages = []
        self.font = pygame.font.SysFont("Arial", 18, bold=True)
        self.duration = 1000

    def add_message(self, text, color):
        self.messages.append({'text': text, 'color': color, 'start_time': pygame.time.get_ticks()})

    def draw(self, screen):
        current_time = pygame.time.get_ticks()
        self.messages = [m for m in self.messages if current_time - m['start_time'] < self.duration]
        y_offset = 10
        sw = screen.get_width()
        for msg in self.messages:
            text_surf = self.font.render(msg['text'], True, msg['color'])
            box_w, box_h = text_surf.get_width() + 40, text_surf.get_height() + 10
            box_x = (sw - box_w) // 2
            s = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
            s.fill((0, 0, 0, 180))
            screen.blit(s, (box_x, y_offset))
            screen.blit(text_surf, (box_x + 20, y_offset + 5))
            y_offset += box_h + 5

toast_manager = ToastManager()

def draw_star(surface, center_x, center_y, size, color):
    pts = []
    angle_offset = -90
    for j in range(5):
        angle = math.pi / 180 * (j * 72 + angle_offset)
        pts.append((center_x + math.cos(angle) * (size // 2),
                    center_y + math.sin(angle) * (size // 2)))
    if color != (50, 50, 50):
        pygame.draw.polygon(surface, color, pts)
        pygame.draw.polygon(surface, STAR_COLOR, pts, 1)
    else:
        pygame.draw.circle(surface, color, (center_x, center_y), size // 3, 1)

# =========================
# ICON STYLE (GIỐNG TÚI ĐỒ)
# =========================
def _norm_txt(s: str) -> str:
    s = str(s or "")
    s = unicodedata.normalize("NFD", s)
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    return s.lower()

def draw_icon_like_bag(surface, rect, item_key, item_name, rarity_color):
    """
    Vẽ icon giống tuido.py (kiếm / áo / quần / giày / rada / potion)
    + [NEW] găng hoàng đế: icon găng màu vàng ngầu giống shop An Xin
    """
    cx, cy = rect.center
    key_norm = _norm_txt(item_key)
    name_norm = _norm_txt(item_name)
    combo = key_norm + " " + name_norm

    # POTION
    if ("potion" in combo) or ("thuoc" in combo):
        color = (230, 0, 0) if ("hp" in combo or "mau" in combo) else (0, 120, 255)
        pygame.draw.circle(surface, color, (cx, cy + 3), 9)
        pygame.draw.rect(surface, WHITE, (cx - 3, cy - 8, 6, 6))
        pygame.draw.rect(surface, (139, 69, 19), (cx - 4, cy - 10, 8, 3))
        pygame.draw.circle(surface, (255, 255, 255), (cx + 3, cy), 2)
        return

    # SWORD / KIEM
    if ("sword" in combo) or ("kiem" in combo):
        pygame.draw.line(surface, (220, 220, 220), (cx - 8, cy + 8), (cx + 8, cy - 8), 4)
        pygame.draw.line(surface, (100, 100, 100), (cx - 8, cy + 8), (cx + 8, cy - 8), 1)
        pygame.draw.line(surface, (139, 69, 19), (cx - 8, cy + 8), (cx - 12, cy + 12), 4)
        pygame.draw.line(surface, (255, 215, 0), (cx - 5, cy + 5), (cx - 10, cy + 10), 6)
        return

    # RADA
    if ("radar" in combo) or ("rada" in combo):
        pygame.draw.circle(surface, (0, 255, 0), (cx, cy), 8, 1)
        pygame.draw.circle(surface, (0, 255, 0), (cx, cy), 3, 1)
        pygame.draw.line(surface, (0, 255, 0), (cx, cy), (cx + 5, cy - 5), 1)
        return

    # GIÀY
    if ("giay" in combo) or ("shoe" in combo) or ("boot" in combo):
        pygame.draw.rect(surface, rarity_color, (cx - 10, cy + 6, 20, 7), border_radius=2)  # đế
        pygame.draw.rect(surface, rarity_color, (cx - 7, cy + 1, 14, 7), border_radius=2)   # thân
        pygame.draw.rect(surface, (50, 50, 50), (cx - 10, cy + 11, 20, 2))
        return

    # QUẦN
    if ("quan" in combo) or ("pants" in combo):
        pygame.draw.rect(surface, rarity_color, (cx - 10, cy - 8, 20, 6), border_radius=2)  # cạp
        pygame.draw.rect(surface, rarity_color, (cx - 10, cy - 2, 9, 18), border_radius=2)  # ống trái
        pygame.draw.rect(surface, rarity_color, (cx + 1, cy - 2, 9, 18), border_radius=2)   # ống phải
        pygame.draw.rect(surface, (30, 30, 40), (cx - 1, cy - 2, 2, 12))
        return

    # [NEW] GĂNG / VŨ KHÍ GĂNG
    if ("gang" in combo) or ("glove" in combo):
        is_hoang_de = (
            ("gang_hoang_de" in combo) or
            ("hoang_de" in combo) or
            (("hoang" in combo) and ("de" in combo))
        )

        # găng hoàng đế: vàng đúng kiểu shop An Xin
        if is_hoang_de:
            gcol = (255, 215, 0)   # vàng
            ocol = (60, 60, 60)    # viền tối
            # hình găng: giống npcanxin (circle + outline + 2 chấm)
            pygame.draw.circle(surface, gcol, (cx, cy), 10)
            pygame.draw.circle(surface, ocol, (cx, cy), 10, 2)
            pygame.draw.circle(surface, (30, 30, 30), (cx - 3, cy - 1), 2)
            pygame.draw.circle(surface, (30, 30, 30), (cx + 3, cy - 1), 2)
            # highlight cho “ngầu”
            pygame.draw.circle(surface, (255, 255, 255), (cx + 3, cy - 4), 2)
        else:
            # găng thường: giữ rarity_color
            pygame.draw.circle(surface, rarity_color, (cx, cy), 9)
            pygame.draw.circle(surface, (60, 60, 60), (cx, cy), 9, 1)
            pygame.draw.circle(surface, (30, 30, 30), (cx - 2, cy - 1), 1)
            pygame.draw.circle(surface, (30, 30, 30), (cx + 2, cy - 1), 1)
        return

    # ÁO / GIÁP (fallback gear)
    if any(t in combo for t in ["armor", "ao", "giap", "giap"]):
        pygame.draw.rect(surface, rarity_color, (cx - 8, cy - 10, 16, 18), border_radius=3)
        pygame.draw.rect(surface, rarity_color, (cx - 12, cy - 8, 4, 8), border_radius=2)
        pygame.draw.rect(surface, rarity_color, (cx + 8, cy - 8, 4, 8), border_radius=2)
        pygame.draw.rect(surface, (50, 50, 50), (cx - 8, cy + 2, 16, 3))
        return

    # fallback
    pygame.draw.circle(surface, (100, 100, 100), (cx, cy), 5)

# --- CLASS ITEM ---
class Item:
    def __init__(self, name, category, icon_color, stats_data=None):
        self.name = name
        self.category = category
        self.icon_color = icon_color
        self.stars = 0
        self.stats = stats_data or {}
        self.key = ""  # [MỚI] để vẽ đúng theo key nếu có

    def draw(self, surface, x, y, size=40):
        # nền ô
        pygame.draw.rect(surface, (30, 30, 30), (x, y, size, size))

        # viền theo rarity/icon_color
        rarity_color = self.icon_color
        pygame.draw.rect(surface, rarity_color, (x, y, size, size), 2)

        rect = pygame.Rect(x, y, size, size)

        # VẼ ICON THEO STYLE TÚI ĐỒ
        draw_icon_like_bag(surface, rect, self.key, self.name, rarity_color)

        # sao
        for i in range(self.stars):
            draw_star(surface, x + (i * 8) + 5, y + 5, 6, STAR_COLOR)

# --- POPUP INFO ---
def draw_item_info_popup(screen, item_data, x, y):
    ITEM_TEMPLATES = main.ITEM_TEMPLATES if main and hasattr(main, 'ITEM_TEMPLATES') else {}
    item_key = item_data.get('key', 'unknown')
    item_template = ITEM_TEMPLATES.get(item_key, {})

    item_name = item_template.get('name', 'Vật phẩm không tên')
    item_stats = item_data.get('stats', item_template.get('stats', {}))
    item_stars = item_data.get('stars', 0)

    font_name = pygame.font.SysFont("Arial", FONT_NAME_SIZE, bold=True)
    font_stats = pygame.font.SysFont("Arial", FONT_STATS_SIZE)

    lines = [(item_name, font_name, STAR_COLOR), ("", font_stats, WHITE)]
    if item_stats:
        for k, v in item_stats.items():
            lines.append((f"+ {v} {k.replace('_', ' ').upper()}", font_stats, GREEN))
    lines.append(("", font_stats, WHITE))
    lines.append(("Pha Lê Hóa:", font_stats, (255, 140, 0)))

    max_width = max([line[1].size(line[0])[0] for line in lines]) if lines else 100
    box_width = max(max_width + 90, 380)
    box_height = max((len(lines) * 18) + 75, 260)

    popup_rect = pygame.Rect(x, y, box_width, box_height)
    pygame.draw.rect(screen, INFO_BOX_BG, popup_rect, border_radius=5)

    rarity_color = item_template.get('rarity', WHITE)
    rarity_color = tuple(rarity_color) if isinstance(rarity_color, list) else rarity_color
    pygame.draw.rect(screen, rarity_color, popup_rect, 1, border_radius=5)

    # icon giống túi đồ ở góc trái
    icon_rect = pygame.Rect(popup_rect.x + 10, popup_rect.y + 10, 40, 40)
    pygame.draw.rect(screen, (30, 30, 30), icon_rect, border_radius=4)
    pygame.draw.rect(screen, rarity_color, icon_rect, 2, border_radius=4)
    draw_icon_like_bag(screen, icon_rect, item_key, item_name, rarity_color)

    cy = popup_rect.y + 10
    for txt, fnt, col in lines[:-1]:
        screen.blit(fnt.render(txt, True, col), (popup_rect.x + 60, cy))
        cy += 18

    # sao pha lê
    for i in range(7):
        draw_star(
            screen,
            popup_rect.x + 20 + (i * 30),
            cy + 12,
            15,
            STAR_COLOR if i < item_stars else (100, 100, 100)
        )

    close_rect = pygame.Rect(popup_rect.right - 25, popup_rect.y + 5, 20, 20)
    pygame.draw.circle(screen, RED_ERROR, close_rect.center, 10)
    screen.blit(font_stats.render("X", True, WHITE), (close_rect.centerx - 4, close_rect.centery - 7))

    return popup_rect, close_rect

# --- UPGRADE INTERFACE ---
class UpgradeInterface:
    def __init__(self):
        self.w, self.h = 600, 400
        self.x = (SCREEN_WIDTH - self.w)//2
        self.y = (SCREEN_HEIGHT - self.h)//2 + 30

        self.btn_close = pygame.Rect(0,0,0,0)
        self.btn_smash = pygame.Rect(0,0,0,0)
        self.input_slot_rect = pygame.Rect(0,0,0,0)
        self.output_slot_rect = pygame.Rect(0,0,0,0)
        self.inventory_display_area = pygame.Rect(0,0,0,0)

        self.input_item = None
        self.output_item = None
        self.full_inventory_ref = []
        self.filtered_inventory = []
        self.inventory_slots = []

        self.slot_size = 40
        self.padding = 5
        self.scroll_y = 0
        self.max_scroll = 0

        self.font = pygame.font.SysFont("Arial", 12)
        self.font_large = pygame.font.SysFont("Arial", 16, bold=True)
        self.last_upgrade_time = 0
        self.UPGRADE_COOLDOWN = 1500

        self.is_processing = False
        self.process_start_time = 0
        self.PROCESS_DURATION = 2000

        self.pending_player_info = None
        self.pending_save_cb = None

    def update_rects(self):
        sw, sh = pygame.display.get_surface().get_size()
        self.x = (sw - self.w)//2
        self.y = (sh - self.h)//2 + 30
        self.btn_close = pygame.Rect(self.x + self.w - 35, self.y + 10, 25, 25)
        self.input_slot_rect = pygame.Rect(self.x + 50, self.y + 100, 60, 60)
        self.output_slot_rect = pygame.Rect(self.x + 190, self.y + 100, 60, 60)
        self.btn_smash = pygame.Rect(self.x + 80, self.y + 250, 120, 40)
        grid_x = self.x + self.w // 2 + 20
        grid_y = self.y + 60
        grid_w = self.w // 2 - 40
        grid_h = self.h - 80
        self.inventory_display_area = pygame.Rect(grid_x, grid_y, grid_w, grid_h)
        self.grid_params = (grid_x, grid_y, grid_w, grid_h)

    def sync_inventory(self, full_inv):
        self.full_inventory_ref = full_inv
        self.filtered_inventory = []
        ITEM_TEMPLATES = main.ITEM_TEMPLATES if main and hasattr(main, 'ITEM_TEMPLATES') else {}

        # cho phép cả phụ kiện/rada
        ALLOWED_TYPES = ['Vu Khi', 'Giap', 'Ao', 'Quan', 'Giay', 'Gang', 'Rada', 'Phu Kien', 'Phu_Kien', 'PhuKien']

        for item in full_inv:
            if item:
                tmpl = ITEM_TEMPLATES.get(item.get('key'))
                if tmpl:
                    itype = tmpl.get('type')
                    if itype in ALLOWED_TYPES and item.get('stars', 0) < 7:
                        self.filtered_inventory.append(item)

        self.update_rects()
        slots_row = max(1, (self.grid_params[2] - 2 * self.padding) // (self.slot_size + self.padding))
        rows = math.ceil(len(self.filtered_inventory) / slots_row)
        content_h = rows * (self.slot_size + self.padding)
        self.max_scroll = max(0, content_h - self.grid_params[3])
        self.scroll_y = min(self.scroll_y, self.max_scroll)

    def update_item_stats(self, item, stars):
        """
        [FIX] Giảm 70% = chỉ tăng 30%/sao cho công (sức đánh) để đỡ lỗi.
        - SD / cong / các dạng % công: nhân (1 + 0.30*stars)
        - giáp giữ như cũ (1 + 0.30*stars)
        - các chỉ số khác giữ logic cũ (v * (stars + 1))
        """
        ITEM_TEMPLATES = main.ITEM_TEMPLATES if main and hasattr(main, 'ITEM_TEMPLATES') else {}
        tmpl = ITEM_TEMPLATES.get(item.get('key'))
        if not tmpl:
            return

        base_stats = tmpl.get('stats', {})
        new_stats = {}

        for k, v in base_stats.items():
            k_low = str(k).strip().lower()

            # công / sức đánh (kể cả % công)
            if (
                k_low in ("suc_danh", "sd", "cong") or
                ("suc_danh_percent" in k_low) or ("sd_percent" in k_low) or ("cong_percent" in k_low) or
                ("percent_suc_danh" in k_low) or ("percent_sd" in k_low) or ("percent_cong" in k_low)
            ):
                new_stats[k] = int(float(v) * (1 + 0.30 * stars))

            # giáp
            elif k_low == "giap":
                new_stats[k] = int(float(v) * (1 + 0.30 * stars))

            # còn lại giữ nguyên
            else:
                try:
                    new_stats[k] = float(v) * (stars + 1)
                    # nếu là số nguyên thì ép int cho gọn
                    if isinstance(v, int):
                        new_stats[k] = int(new_stats[k])
                except Exception:
                    new_stats[k] = v

        item['stats'] = new_stats

    def draw(self, screen):
        self.update_rects()
        current_time = pygame.time.get_ticks()

        if self.is_processing:
            elapsed = current_time - self.process_start_time
            if elapsed % 100 < 50:
                s = pygame.Surface(pygame.display.get_surface().get_size(), pygame.SRCALPHA)
                s.fill((255, 255, 200, 80))
                screen.blit(s, (0,0))
            if elapsed >= self.PROCESS_DURATION:
                self.finalize_upgrade()
                self.is_processing = False

        pygame.draw.rect(screen, (50, 50, 60), (self.x, self.y, self.w, self.h), border_radius=10)
        pygame.draw.rect(screen, LIGHT_GRAY, (self.x, self.y, self.w, self.h), 3, border_radius=10)

        screen.blit(pygame.font.SysFont("Arial", 20, bold=True).render("Pha Lê Hóa Trang Bị", True, WHITE), (self.x + 20, self.y + 15))
        pygame.draw.rect(screen, RED_ERROR, self.btn_close, border_radius=5)
        pygame.draw.line(screen, WHITE, (self.btn_close.x+6, self.btn_close.y+6), (self.btn_close.right-6, self.btn_close.bottom-6), 2)
        pygame.draw.line(screen, WHITE, (self.btn_close.x+6, self.btn_close.bottom-6), (self.btn_close.right-6, self.btn_close.y+6), 2)

        pygame.draw.rect(screen, BLACK, self.input_slot_rect)
        pygame.draw.rect(screen, WHITE, self.input_slot_rect, 2)
        screen.blit(self.font.render("Input", True, LIGHT_GRAY), (self.input_slot_rect.x, self.input_slot_rect.y - 15))

        ITEM_TEMPLATES = main.ITEM_TEMPLATES if main and hasattr(main, 'ITEM_TEMPLATES') else {}
        cur_stars = 0

        if self.input_item:
            tmpl = ITEM_TEMPLATES.get(self.input_item.get('key'))
            if tmpl:
                cur_stars = self.input_item.get('stars', 0)
                col = tmpl.get('rarity', WHITE)
                col = tuple(col) if isinstance(col, list) else col
                t = Item(tmpl.get('name'), tmpl.get('type'), col)
                t.key = self.input_item.get('key', '')
                t.stars = cur_stars
                t.draw(screen, self.input_slot_rect.x, self.input_slot_rect.y, 60)

        pygame.draw.rect(screen, BLACK, self.output_slot_rect)
        pygame.draw.rect(screen, STAR_COLOR, self.output_slot_rect, 2)
        screen.blit(self.font.render("Output", True, LIGHT_GRAY), (self.output_slot_rect.x, self.output_slot_rect.y - 15))

        if self.output_item:
            tmpl = ITEM_TEMPLATES.get(self.output_item.get('key'))
            if tmpl:
                col = tmpl.get('rarity', WHITE)
                col = tuple(col) if isinstance(col, list) else col
                t = Item(tmpl.get('name'), tmpl.get('type'), col)
                t.key = self.output_item.get('key', '')
                t.stars = self.output_item.get('stars', 0)
                t.draw(screen, self.output_slot_rect.x, self.output_slot_rect.y, 60)
        elif (not self.is_processing) and self.input_item and cur_stars < 7:
            tmpl = ITEM_TEMPLATES.get(self.input_item.get('key'))
            if tmpl:
                col = tmpl.get('rarity', WHITE)
                col = tuple(col) if isinstance(col, list) else col
                t = Item(tmpl.get('name'), tmpl.get('type'), col)
                t.key = self.input_item.get('key', '')
                t.stars = cur_stars + 1
                s_ghost = pygame.Surface((60, 60), pygame.SRCALPHA)
                t.draw(s_ghost, 0, 0, 60)
                s_ghost.set_alpha(100)
                screen.blit(s_ghost, (self.output_slot_rect.x, self.output_slot_rect.y))

        cost = UPGRADE_COSTS.get(cur_stars, 0)
        rate = UPGRADE_RATES.get(cur_stars, 0)
        screen.blit(self.font_large.render(f"Tỉ lệ: {rate}%", True, (0, 255, 255)), (self.x + 50, self.y + 180))

        c_v = self.pending_player_info.get("vang", 0) if self.pending_player_info else 0
        col_cost = GREEN_SUCCESS if c_v >= cost else RED_ERROR
        screen.blit(self.font.render(f"Giá: {cost:,} Vàng", True, col_cost), (self.x + 50, self.y + 205))

        can_smash = self.input_item and cur_stars < 7
        on_cd = (current_time - self.last_upgrade_time) < self.UPGRADE_COOLDOWN
        b_col = (255, 165, 0) if self.is_processing else (GREEN_SUCCESS if can_smash and not on_cd else DARK_GRAY)
        pygame.draw.rect(screen, b_col, self.btn_smash, border_radius=5)
        btn_txt = "ĐANG ĐẬP..." if self.is_processing else (f"Chờ {1 + (self.UPGRADE_COOLDOWN - (current_time - self.last_upgrade_time))//1000}s" if on_cd else "PHA LÊ HÓA")
        ts = self.font_large.render(btn_txt, True, BLACK)
        screen.blit(ts, (self.btn_smash.centerx - ts.get_width()//2, self.btn_smash.centery - ts.get_height()//2))

        gx, gy, gw, gh = self.grid_params
        pygame.draw.rect(screen, INFO_BOX_BG, self.inventory_display_area, border_radius=5)
        clip = screen.get_clip()
        screen.set_clip(self.inventory_display_area)

        slots_row = max(1, (gw - 2*self.padding) // (self.slot_size + self.padding))
        self.inventory_slots = []

        for i, item in enumerate(self.filtered_inventory):
            tmpl = ITEM_TEMPLATES.get(item.get('key'))
            if not tmpl:
                continue
            r = i // slots_row
            c = i % slots_row
            rx = gx + self.padding + c*(self.slot_size + self.padding)
            ry = gy + self.padding + r*(self.slot_size + self.padding) - self.scroll_y
            rect = pygame.Rect(rx, ry, self.slot_size, self.slot_size)
            self.inventory_slots.append((rect, item))

            if ry + self.slot_size > gy and ry < gy + gh:
                pygame.draw.rect(screen, (30, 30, 30), rect)
                pygame.draw.rect(screen, GRAY, rect, 1)

                col = tmpl.get('rarity', WHITE)
                col = tuple(col) if isinstance(col, list) else col
                t = Item(tmpl.get('name'), tmpl.get('type'), col)
                t.key = item.get('key', '')
                t.stars = item.get('stars', 0)
                t.draw(screen, rx + 2, ry + 2, self.slot_size - 4)

        screen.set_clip(clip)

    def handle_event(self, event, player_info, save_cb=None):
        self.update_rects()

        if event is None:
            return "STAY"

        mp = pygame.mouse.get_pos()
        if self.is_processing:
            return "STAY"

        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = event.pos

            if self.btn_close.collidepoint(mx, my):
                if self.input_item:
                    player_info["inventory"].append(self.input_item)
                if self.output_item:
                    player_info["inventory"].append(self.output_item)
                self.input_item = None
                self.output_item = None
                return "CLOSE"

            if self.btn_smash.collidepoint(mx, my):
                curr = pygame.time.get_ticks()
                stars = self.input_item.get('stars', 0) if self.input_item else 0
                cost = UPGRADE_COSTS.get(stars, 0)

                if not self.input_item:
                    toast_manager.add_message("Chưa bỏ đồ vào!", RED_ERROR)
                elif stars >= 7:
                    toast_manager.add_message("Max cấp rồi!", RED_ERROR)
                elif player_info.get("vang", 0) < cost:
                    toast_manager.add_message("Không đủ vàng!", RED_ERROR)
                elif (curr - self.last_upgrade_time) < self.UPGRADE_COOLDOWN:
                    pass
                else:
                    self.is_processing = True
                    self.process_start_time = curr
                    self.pending_player_info = player_info
                    self.pending_save_cb = save_cb
                    player_info["vang"] -= cost
                    if save_cb:
                        save_cb()
                    toast_manager.add_message("Úm ba la xì bùa...", (255, 140, 0))
                return "STAY"

            if self.input_slot_rect.collidepoint(mx, my) and self.input_item:
                player_info["inventory"].append(self.input_item)
                self.input_item = None
                self.sync_inventory(player_info["inventory"])
                return "STAY"

            if self.output_slot_rect.collidepoint(mx, my) and self.output_item:
                player_info["inventory"].append(self.output_item)
                self.output_item = None
                self.sync_inventory(player_info["inventory"])
                return "STAY"

            if self.inventory_display_area.collidepoint(mx, my):
                for r, item in self.inventory_slots:
                    if r.collidepoint(mx, my):
                        if not self.input_item:
                            self.input_item = item
                            if item in player_info["inventory"]:
                                player_info["inventory"].remove(item)
                            self.output_item = None
                            self.sync_inventory(player_info["inventory"])
                        return "STAY"
                return "STAY"

            if pygame.Rect(self.x, self.y, self.w, self.h).collidepoint(mx, my):
                return "STAY"

        if event.type == pygame.MOUSEWHEEL and self.inventory_display_area.collidepoint(mp):
            self.scroll_y = max(0, min(self.scroll_y - event.y * 20, self.max_scroll))
            return "STAY"

        return "NONE"

    def finalize_upgrade(self):
        player_info = self.pending_player_info
        save_cb = self.pending_save_cb
        self.last_upgrade_time = pygame.time.get_ticks()

        stars = self.input_item.get('stars', 0)
        rate = UPGRADE_RATES.get(stars, 0)

        if random.randint(1, 100) <= rate:
            new_stars = stars + 1
            self.input_item['stars'] = new_stars
            self.update_item_stats(self.input_item, new_stars)
            toast_manager.add_message(f"Lên +{new_stars} thành công!", GREEN_SUCCESS)
            self.output_item = self.input_item
            self.input_item = None
        else:
            toast_manager.add_message("Thất bại rồi con ơi!", RED_ERROR)
            self.output_item = None

        if save_cb:
            save_cb()
        self.sync_inventory(player_info["inventory"])

# --- NPC BÀ HẠT MÍT ---
class BaHatMitNPC:
    def __init__(self, x_world, y_ground):
        self.x_world = x_world
        self.y_ground = y_ground
        self.width = 30
        self.height = 50
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.show_dialog = False
        self.show_upgrade_ui = False
        self.upgrade_ui = UpgradeInterface()
        self.dialog_rect = pygame.Rect(0,0,0,0)
        self.btn_choice_rect = pygame.Rect(0,0,0,0)
        self.btn_close_dialog = pygame.Rect(0,0,0,0)

    def draw(self, screen, map_offset_x):
        self.rect.x = self.x_world - map_offset_x
        self.rect.y = self.y_ground - self.height

        sx, sy = self.rect.x, self.rect.y
        pygame.draw.ellipse(screen, (0, 0, 0, 100), (sx + 5, sy + 40, 20, 10))
        pygame.draw.circle(screen, BLUE_CRYSTAL, (sx + 15, sy + 35), 15)
        pygame.draw.circle(screen, (200, 240, 255), (sx + 10, sy + 30), 4)
        pygame.draw.ellipse(screen, CLOTH_COLOR, (sx + 3, sy + 10, 24, 25))
        pygame.draw.circle(screen, SKIN_COLOR, (sx + 15, sy + 5), 10)
        pygame.draw.circle(screen, (220, 220, 220), (sx + 15, sy - 5), 5)

        f = pygame.font.SysFont("Arial", 12, bold=True)
        t = f.render("Bà Hạt Mít", True, WHITE)
        screen.blit(t, (self.rect.centerx - t.get_width()//2, self.rect.y - 15))

        if self.show_dialog:
            self.draw_dialog(screen)

    def draw_dialog(self, screen):
        dx = self.rect.x - 60
        dy = self.rect.y - 100
        self.dialog_rect = pygame.Rect(dx, dy, 160, 80)
        pygame.draw.rect(screen, WHITE, self.dialog_rect, border_radius=10)
        pygame.draw.rect(screen, BLACK, self.dialog_rect, 1, border_radius=10)
        f = pygame.font.SysFont("Arial", 12)
        screen.blit(f.render("Ngươi muốn gì?", True, BLACK), (dx + 10, dy + 10))
        self.btn_choice_rect = pygame.Rect(dx + 10, dy + 35, 140, 25)
        pygame.draw.rect(screen, LIGHT_GRAY, self.btn_choice_rect, border_radius=5)
        screen.blit(f.render("> Pha Lê Hóa", True, BLACK), (dx + 15, dy + 40))
        self.btn_close_dialog = pygame.Rect(dx + 135, dy + 5, 20, 20)
        pygame.draw.rect(screen, RED_ERROR, self.btn_close_dialog, border_radius=3)
        screen.blit(pygame.font.SysFont("Arial", 14, bold=True).render("X", True, WHITE), (dx + 140, dy + 6))

    def handle_event(self, event, player_info, player_world_x, save_cb=None):
        if event is None and self.show_upgrade_ui:
            self.upgrade_ui.handle_event(None, player_info, save_cb)
            return False

        if self.show_upgrade_ui:
            res = self.upgrade_ui.handle_event(event, player_info, save_cb)
            if res == "CLOSE":
                self.show_upgrade_ui = False
            return True

        if self.show_dialog:
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos
                if self.btn_close_dialog.collidepoint(mx, my):
                    self.show_dialog = False
                    return True
                if self.btn_choice_rect.collidepoint(mx, my):
                    self.show_dialog = False
                    self.show_upgrade_ui = True
                    self.upgrade_ui.sync_inventory(player_info["inventory"])
                    return True
                if not self.dialog_rect.collidepoint(mx, my):
                    self.show_dialog = False
                    return True
            return True

        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                if abs(player_world_x - self.x_world) < NPC_INTERACT_RANGE:
                    self.show_dialog = True
                    return True

        return False
