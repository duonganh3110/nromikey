# game_modules/ngonngu.py

# =========================================================================
# KHỞI TẠO NGÔN NGỮ MẶC ĐỊNH VÀ HÀM TRUY CẬP
# =========================================================================

CURRENT_LANGUAGE = "VI"  # Mặc định là tiếng Việt (VI)

def set_language(lang_code):
    """Thiết lập ngôn ngữ hiện tại (VI hoặc JP)"""
    global CURRENT_LANGUAGE
    if lang_code in ["VI", "JP"]:
        CURRENT_LANGUAGE = lang_code
        # Lưu ý: Cần thêm logic lưu trạng thái nếu muốn ngôn ngữ được ghi nhớ
    # else: print("Mã ngôn ngữ không hợp lệ.") # Bỏ dòng này để tránh lỗi nếu cần

def get_string(key):
    """Lấy chuỗi văn bản dựa trên key và ngôn ngữ hiện tại"""
    # Nếu key tồn tại, trả về ngôn ngữ hiện tại. Nếu ngôn ngữ hiện tại không có, mặc định là VI.
    if key in LANGUAGE_STRINGS:
        return LANGUAGE_STRINGS[key].get(CURRENT_LANGUAGE, LANGUAGE_STRINGS[key]["VI"])
    return key # Trả về key nếu không tìm thấy trong từ điển

# =========================================================================
# TỪ ĐIỂN CHUỖI VĂN BẢN (STRING DICTIONARY)
# =========================================================================

LANGUAGE_STRINGS = {
    # --- UI Tiêu đề ---
    "NGOC_RONG_MIKEY": {
        "VI": "NGOC RONG MIKEY",
        "JP": "ドラゴンボール マイキー"
    },
    
    # --- UI Đăng nhập/Đăng ký ---
    "USER_ACCOUNT": {
        "VI": "Tai khoan:",
        "JP": "ユーザー名:"
    },
    "USER_PASSWORD": {
        "VI": "Mat khau:",
        "JP": "パスワード:"
    },
    "REMEMBER_ACCOUNT": {
        "VI": "Nho tai khoan",
        "JP": "アカウントを記憶"
    },
    "BUTTON_LOGIN": {
        "VI": "Dang Nhap",
        "JP": "ログイン"
    },
    "BUTTON_REGISTER": {
        "VI": "Dang Ky",
        "JP": "新規登録"
    },
    "STATUS_LOGIN_SUCCESS": {
        "VI": "Dang nhap thanh cong!",
        "JP": "ログイン成功!"
    },
    "STATUS_INVALID_CREDENTIALS": {
        "VI": "Sai tai khoan hoac mat khau!",
        "JP": "アカウントまたはパスワードが間違っています!"
    },
    "STATUS_EMPTY_FIELD": {
        "VI": "Khong duoc de trong!",
        "JP": "空欄を埋めてください!"
    },
    "STATUS_ACCOUNT_EXISTS": {
        "VI": "Tai khoan da ton tai!",
        "JP": "アカウントは既に存在します!"
    },
    "STATUS_REGISTER_SUCCESS": {
        "VI": "Dang ky thanh cong!",
        "JP": "新規登録が完了しました!"
    },
    "STATUS_BANNED": {
        "VI": "TAI KHOAN DA BI CAM!",
        "JP": "アカウントはBANされています!"
    },

    # --- Cảnh báo Sức khỏe ---
    # CHUỖI TIẾNG VIỆT (Dùng cho cả 2 dòng)
    "HEALTH_WARNING_VI": {
        "VI": "Choi qua 180 phut mot ngay se anh huong xau den suc khoe",
        "JP": "一日180分を超えてプレイすることは健康に悪影響を与えます" 
    },
    
    # --- Tiêu đề Admin Panel ---
    "ADMIN_PANEL_TITLE": {
        "VI": "ADMIN PANEL",
        "JP": "管理パネル"
    },
    "QL_ACCOUNTS": {"VI": "QL TAI KHOAN", "JP": "アカウント管理"},
    "QL_ITEMS": {"VI": "QL VAT PHAM", "JP": "アイテム管理"},
    "QL_STATS": {"VI": "QL CHI SO VP", "JP": "ステータス管理"},
    "LOGOUT_BUTTON": {"VI": "DANG XUAT", "JP": "ログアウト"},
    "ITEM_TEMPLATES_TITLE": {"VI": "DANH SÁCH VẬT PHẨM MẪU", "JP": "アイテムテンプレートリスト"},
    "VU_KHI": {"VI": "Vu Khi", "JP": "武器"},
    "HANH_TRANG": {"VI": "Hanh Trang", "JP": "防具・服"},
    "HP_KI": {"VI": "Hom HP/KI", "JP": "HP/KIパック"},
    "NGOC_RONG": {"VI": "Ngoc Rong", "JP": "ドラゴンボール"},
    "LINH_TINH": {"VI": "Linh Tinh", "JP": "その他"},
    "UNDER_DEVELOPMENT": {"VI": "Dang cap nhat...", "JP": "現在、開発中です..."},

    
    # --- Hội thoại Game ---
    "WELCOME_BACK": {
        "VI": "Chào mừng trở lại",
        "JP": "おかえりなさい"
    },
    "MIKEY_WISHES": {
        "VI": "Mikey chuc ban trai nghiem game vui ve",
        "JP": "マイキーが楽しいゲーム体験をお祈りします"
    },
    "NPC_DIALOG_ERROR": {
        "VI": "Xin loi dang duoc cap nhat",
        "JP": "申し訳ありません、現在アップデート中です"
    },
    "NPC_DIALOG_ERROR_CODE": {
        "VI": "(loi 1)",
        "JP": "(エラー1)"
    }
}