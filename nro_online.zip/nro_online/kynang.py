# kynang.py
# Tab KỸ NĂNG + thanh ô kỹ năng (1-5) kiểu NRO
# - Hỗ trợ gắn skill vào slot 1..5
# - Chiêu 2 (Trái Đất): Kamejoko = 110% sát thương

import pygame
import unicodedata
from typing import Dict, List, Optional, Any, Tuple

# -----------------------------
# DATA
# -----------------------------
SLOT_COUNT = 5

# Canonical planet keys: "Trai Dat", "Xayda", "Namec"
SKILLS_BY_PLANET: Dict[str, List[Dict[str, Any]]] = {
    "Trai Dat": [
        {
            "id": "td_galick_1",
            "name": "Đấm Galick Cấp 1",
            "damage_pct": 100,
            "desc": "Sát thương: 100%",
        },
        {
            "id": "kamejoko",
            "name": "Kamejoko",
            "damage_pct": 125,
            "desc": "Sát thương: 125% (Chiêu 2)",
        },
],
    "Xayda": [
        {
            "id": "xd_dragon_1",
            "name": "Đấm Dragon Cấp 1",
            "damage_pct": 100,
            "desc": "Sát thương: 100%",
        },
        {
            "id": "atomic_gold",
            "name": "Atomic GOLD",
            "damage_pct": 15,
            "desc": "Sát thương: 15% (Atomic GOLD)",
        },
        {
            "id": "ssj_cap_1",
            "name": "SSJ Cấp 1",
            "damage_pct": 100,
            "cooldown_s": 1.0,
            "type": "transform",
            "buff": {"hp": 1.3, "ki": 1.3, "suc_danh": 1.3},
            "desc": "Biến hình SSJ: +30% HP/KI/SĐ (giữ chuột để kích hoạt)",
        }
],
    "Namec": [
        {
            "id": "nm_demon_1",
            "name": "Đấm Demon Cấp 1",
            "damage_pct": 100,
            "desc": "Sát thương: 100%",
        },
        {
            "id": "masenko",
            "name": "Masenko",
            "damage_pct": 100,
            "cooldown_s": 1.0,
            "type": "projectile",
            "desc": "Sát thương: 100% | Hồi chiêu: 1s (Masenko)",
        }
],
}

# -----------------------------
# INTERNAL UI STATE
# -----------------------------
_selected_skill_id: Optional[str] = None
_prev_mouse_down: bool = False

# thanh ô kỹ năng (hud)
_active_slot: int = 0


# -----------------------------
# HELPERS
# -----------------------------
def _strip_accents(s: str) -> str:
    # bỏ dấu tiếng Việt + chuyển đ/Đ -> d/D để map hành tinh chuẩn
    s = unicodedata.normalize("NFD", s)
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    s = s.replace("đ", "d").replace("Đ", "D")
    return s


def _norm(s: str) -> str:
    return _strip_accents(str(s or "")).lower().strip()


def _planet_key(planet: str) -> str:
    p = _norm(planet)
    # nếu rỗng thì mặc định Trái Đất
    if not p:
        return "Trai Dat"

    # chấp nhận nhiều cách viết
    if p in ("trai dat", "traidat", "trai_dat", "earth", "human", "nguoi"):
        return "Trai Dat"
    if p in ("xayda", "xay da", "xay_da", "xay-da", "saiyan", "sayda"):
        return "Xayda"
    if p in ("namec", "namek", "nam ec", "nam_ec", "nemec"):
        return "Namec"

    # fallback: nếu key tồn tại đúng (sau normalize) thì dùng key đó
    for k in SKILLS_BY_PLANET.keys():
        if _norm(k) == p:
            return k

    # không nhận ra -> trả planet nguyên bản (để get_available_skills() không lỡ trả list Trái Đất)
    return str(planet)


def ensure_player_skill_data(player_info: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Đảm bảo player_info có:
      - skill_slots: list độ dài 5 (mỗi phần tử là skill_id hoặc None)
      - active_skill_slot: index 0..4
    """
    if player_info is None:
        player_info = {}

    slots = player_info.get("skill_slots")
    if not isinstance(slots, list):
        slots = []
    # chuẩn hoá độ dài
    slots = (slots[:SLOT_COUNT] + [None] * SLOT_COUNT)[:SLOT_COUNT]
    player_info["skill_slots"] = slots

    a = player_info.get("active_skill_slot", 0)
    try:
        a = int(a)
    except Exception:
        a = 0
    a = max(0, min(SLOT_COUNT - 1, a))
    player_info["active_skill_slot"] = a
    return player_info


def get_available_skills(planet: str) -> List[Dict[str, Any]]:
    return SKILLS_BY_PLANET.get(_planet_key(planet), [])


def get_skill_by_id(skill_id: str) -> Optional[Dict[str, Any]]:
    if not skill_id:
        return None
    for lst in SKILLS_BY_PLANET.values():
        for sk in lst:
            if sk.get("id") == skill_id:
                return sk
    return None


def _get_fonts(font_ui=None, font_tiny=None):
    if font_ui is None:
        try:
            font_ui = pygame.font.SysFont("arial", 18)
        except Exception:
            font_ui = pygame.font.Font(None, 18)
    if font_tiny is None:
        try:
            font_tiny = pygame.font.SysFont("arial", 14)
        except Exception:
            font_tiny = pygame.font.Font(None, 14)
    return font_ui, font_tiny


# -----------------------------
# TAB: KỸ NĂNG
# -----------------------------
def draw_skill_tab(
    screen: pygame.Surface,
    x: int,
    y: int,
    w: int,
    h: int,
    player_info: Optional[Dict[str, Any]] = None,
    planet: Optional[str] = None,
    font_ui=None,
    font_tiny=None,
):
    """
    Vẽ nội dung tab KỸ NĂNG trong khung (x,y,w,h) của túi đồ.
    - Click vào skill => hiện nút "Thêm ô 1..5"
    - Click nút => gán skill vào slot tương ứng
    """
    global _selected_skill_id, _prev_mouse_down

    font_ui, font_tiny = _get_fonts(font_ui, font_tiny)
    player_info = ensure_player_skill_data(player_info)

    if planet is None:
        # trong dự án của Mikey hay dùng key "phai"/"hanh_tinh" để lưu hành tinh
        planet = player_info.get("hanh_tinh") or player_info.get("phai") or "Trai Dat"
    planet_key = _planet_key(planet)

    # AUTO DEFAULT: nếu slot trống hết và là Trái Đất, tự gắn ô 1 + ô 2
    slots_tmp = player_info.get("skill_slots", [None] * SLOT_COUNT)
    if planet_key == "Trai Dat" and isinstance(slots_tmp, list) and all(s is None for s in slots_tmp):
        skills_tmp = get_available_skills(planet_key)
        if skills_tmp:
            player_info["skill_slots"][0] = skills_tmp[0].get("id")
        if get_skill_by_id("kamejoko") is not None:
            player_info["skill_slots"][1] = "kamejoko"
        player_info["active_skill_slot"] = 0

    # vùng content (chừa phần tab trên)
    pad = 10
    header_h = 50
    content_rect = pygame.Rect(x + pad, y + header_h, w - pad * 2, h - header_h - pad)

    # tiêu đề
    title = font_ui.render("KỸ NĂNG", True, (255, 255, 0))
    screen.blit(title, (x + w // 2 - title.get_width() // 2, y + 10))
    sub = font_tiny.render(f"Hành tinh: {planet_key}", True, (220, 220, 220))
    screen.blit(sub, (x + pad, y + 30))

    # chia 2 cột: danh sách / chi tiết
    list_w = int(content_rect.width * 0.45)
    list_rect = pygame.Rect(content_rect.x, content_rect.y, list_w, content_rect.height)
    detail_rect = pygame.Rect(
        content_rect.x + list_w + 10,
        content_rect.y,
        content_rect.width - list_w - 10,
        content_rect.height,
    )

    pygame.draw.rect(screen, (25, 25, 35), list_rect, border_radius=8)
    pygame.draw.rect(screen, (25, 25, 35), detail_rect, border_radius=8)
    pygame.draw.rect(screen, (255, 215, 0), list_rect, 2, border_radius=8)
    pygame.draw.rect(screen, (255, 215, 0), detail_rect, 2, border_radius=8)

    skills = get_available_skills(planet_key)

    # danh sách skill
    item_h = 42
    item_pad = 8
    item_rects: List[Tuple[pygame.Rect, str]] = []
    y_cursor = list_rect.y + 10
    for sk in skills:
        r = pygame.Rect(list_rect.x + 10, y_cursor, list_rect.width - 20, item_h)
        item_rects.append((r, sk["id"]))
        is_sel = (_selected_skill_id == sk["id"])
        pygame.draw.rect(screen, (0, 100, 255) if is_sel else (55, 55, 65), r, border_radius=8)
        pygame.draw.rect(screen, (255, 215, 0), r, 1, border_radius=8)

        name = sk.get("name", sk["id"])
        txt = font_tiny.render(name, True, (255, 255, 255))
        screen.blit(txt, (r.x + 10, r.y + (r.height - txt.get_height()) // 2))

        y_cursor += item_h + item_pad

    if not skills:
        txt = font_tiny.render("Chưa có kỹ năng.", True, (200, 200, 200))
        screen.blit(txt, (list_rect.x + 12, list_rect.y + 12))

    # click chọn skill trong list (luôn cho phép)
    mx, my = pygame.mouse.get_pos()
    mouse_down = pygame.mouse.get_pressed(3)[0]
    if mouse_down and (not _prev_mouse_down):
        for r, sid in item_rects:
            if r.collidepoint(mx, my):
                _selected_skill_id = sid
                break

    # chi tiết + nút thêm vào ô 1..5
    detail_title = font_tiny.render("Chi tiết", True, (255, 255, 255))
    screen.blit(detail_title, (detail_rect.x + 10, detail_rect.y + 10))

    sel = get_skill_by_id(_selected_skill_id) if _selected_skill_id else None
    if sel:
        line1 = font_ui.render(sel.get("name", sel.get("id", "Skill")), True, (255, 255, 255))
        screen.blit(line1, (detail_rect.x + 10, detail_rect.y + 35))

        line2 = font_tiny.render(sel.get("desc", ""), True, (220, 220, 220))
        screen.blit(line2, (detail_rect.x + 10, detail_rect.y + 62))

        # 5 nút thêm ô 1..5
        btn_w = 110
        btn_h = 34
        btn_gap = 10
        btns: List[Tuple[int, pygame.Rect]] = []
        bx = detail_rect.x + 10
        by = detail_rect.y + 95
        for i in range(SLOT_COUNT):
            rr = pygame.Rect(bx, by + i * (btn_h + btn_gap), btn_w, btn_h)
            btns.append((i, rr))
            pygame.draw.rect(screen, (80, 80, 90), rr, border_radius=8)
            pygame.draw.rect(screen, (255, 215, 0), rr, 1, border_radius=8)
            t = font_tiny.render(f"Thêm ô {i+1}", True, (255, 255, 255))
            screen.blit(t, (rr.x + 10, rr.y + (rr.height - t.get_height()) // 2))

        # hiển thị slot hiện tại
        slots = player_info.get("skill_slots", [None] * SLOT_COUNT)
        slot_y = detail_rect.bottom - 90
        label = font_tiny.render("Ô đang gắn:", True, (220, 220, 220))
        screen.blit(label, (detail_rect.x + 10, slot_y))
        slot_y += 18
        for i in range(SLOT_COUNT):
            sid = slots[i]
            sk = get_skill_by_id(sid) if sid else None
            sname = sk.get("name") if sk else "Trống"
            t = font_tiny.render(f"{i+1}. {sname}", True, (210, 210, 210))
            screen.blit(t, (detail_rect.x + 10, slot_y + i * 14))

        # xử lý click nút add
        if mouse_down and (not _prev_mouse_down):
            for i, rr in btns:
                if rr.collidepoint(mx, my):
                    player_info["skill_slots"][i] = sel.get("id")
                    player_info["active_skill_slot"] = i
                    break


    else:
        txt = font_tiny.render("Chọn 1 kỹ năng bên trái.", True, (200, 200, 200))
        screen.blit(txt, (detail_rect.x + 10, detail_rect.y + 40))

    _prev_mouse_down = mouse_down


# -----------------------------
# HUD: 5 Ô KỸ NĂNG DƯỚI MÀN HÌNH
# -----------------------------
def draw_skill_bar(
    screen: pygame.Surface,
    screen_w: int,
    screen_h: int,
    player_info: Optional[Dict[str, Any]] = None,
    font_tiny=None,
    allow_click: bool = True,
    always_on_top: bool = True,
):
    """
    Vẽ 5 ô kỹ năng dưới màn hình như NRO.
    - Click ô nào => active_skill_slot = ô đó
    (Để không bị che khi mở bảng, hãy gọi hàm này SAU CÙNG trong game_loop, sau khi vẽ mọi UI khác.)
    """
    global _active_slot, _prev_mouse_down
    _, font_tiny = _get_fonts(None, font_tiny)
    player_info = ensure_player_skill_data(player_info)

    slots = player_info.get("skill_slots", [None] * SLOT_COUNT)
    active = int(player_info.get("active_skill_slot", 0))
    active = max(0, min(SLOT_COUNT - 1, active))
    _active_slot = active

    slot_size = 48
    gap = 7
    total_w = SLOT_COUNT * slot_size + (SLOT_COUNT - 1) * gap
    base_x = (screen_w - total_w) // 2
    base_y = screen_h - slot_size - 10

    mx, my = pygame.mouse.get_pos()
    mouse_down = pygame.mouse.get_pressed(3)[0]

    for i in range(SLOT_COUNT):
        r = pygame.Rect(base_x + i * (slot_size + gap), base_y, slot_size, slot_size)

        pygame.draw.rect(screen, (25, 25, 35), r, border_radius=10)
        if i == active:
            pygame.draw.rect(screen, (0, 160, 255), r, 3, border_radius=10)
        else:
            pygame.draw.rect(screen, (255, 215, 0), r, 2, border_radius=10)

        num = font_tiny.render(str(i + 1), True, (255, 255, 255))
        screen.blit(num, (r.x + 4, r.y + 2))

        sid = slots[i]
        sk = get_skill_by_id(sid) if sid else None
        if sk:
            name = sk.get("name", "Skill")
            short = name.replace("Cấp 1", "").strip()
            txt = font_tiny.render(short, True, (230, 230, 230))
            screen.blit(txt, (r.centerx - txt.get_width() // 2, r.bottom - txt.get_height() - 4))
        else:
            txt = font_tiny.render("Trống", True, (160, 160, 160))
            screen.blit(txt, (r.centerx - txt.get_width() // 2, r.centery - txt.get_height() // 2))

        if allow_click and mouse_down and (not _prev_mouse_down) and r.collidepoint(mx, my):
            player_info["active_skill_slot"] = i
            _active_slot = i

    _prev_mouse_down = mouse_down


def get_active_skill(player_info: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Lấy skill đang active theo active_skill_slot."""
    player_info = ensure_player_skill_data(player_info)
    slots = player_info.get("skill_slots", [None] * SLOT_COUNT)
    idx = int(player_info.get("active_skill_slot", 0))
    idx = max(0, min(SLOT_COUNT - 1, idx))
    sid = slots[idx]
    return get_skill_by_id(sid) if sid else None
