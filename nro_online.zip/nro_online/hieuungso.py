import pygame
import random

font_damage = None
font_crit = None # Font to cho chi mang

def init_fonts():
    global font_damage, font_crit
    if font_damage is None:
        font_damage = pygame.font.SysFont("Arial", 16, bold=True)
    if font_crit is None:
        font_crit = pygame.font.SysFont("Arial", 24, bold=True) # To hon

class FloatingText:
    def __init__(self, x, y, text, color, is_crit=False):
        self.x = x
        self.y = y
        self.text = str(text)
        self.color = color
        self.is_crit = is_crit
        
        if is_crit:
            self.timer = 90 # Ton tai lau hon (1.5s)
            self.y_velocity = -1 # Bay cham hon de de nhin
            self.color = (255, 255, 0) # Mau Vang
        else:
            self.timer = 60
            self.y_velocity = -2
            
        self.alpha = 255

    def update(self):
        self.y += self.y_velocity
        self.timer -= 1
        if self.timer < 20:
            self.alpha = max(0, int((self.timer / 20) * 255))

    def draw(self, screen, map_offset_x):
        init_fonts()
        if self.timer > 0:
            # Chon font dua theo loai
            font_use = font_crit if self.is_crit else font_damage
            
            text_surf = font_use.render(self.text, True, self.color)
            
            # Neu la Crit, them vien den cho noi
            if self.is_crit:
                outline_surf = font_use.render(self.text, True, (0, 0, 0))
                draw_x = self.x - map_offset_x
                # Ve vien
                screen.blit(outline_surf, (draw_x - 1, self.y))
                screen.blit(outline_surf, (draw_x + 1, self.y))
                screen.blit(outline_surf, (draw_x, self.y - 1))
                screen.blit(outline_surf, (draw_x, self.y + 1))
                # Ve chu chinh
                screen.blit(text_surf, (draw_x, self.y))
            else:
                text_surf.set_alpha(self.alpha)
                draw_x = self.x - map_offset_x
                screen.blit(text_surf, (draw_x, self.y))

class TextManager:
    def __init__(self):
        self.texts = []

    def add(self, x, y, text, color, is_crit=False):
        offset_x = random.randint(-15, 15)
        offset_y = random.randint(-10, 10)
        self.texts.append(FloatingText(x + offset_x, y + offset_y, text, color, is_crit))

    def update(self):
        for t in self.texts:
            t.update()
        self.texts = [t for t in self.texts if t.timer > 0]

    def draw(self, screen, map_offset_x):
        for t in self.texts:
            t.draw(screen, map_offset_x)