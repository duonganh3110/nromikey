# kame_fx.py
# FX Kame (procedural) cho Pygame: charge ball + beam + impact + particles + screen shake
# Không dùng asset. Dùng được để ghép vào game sau này.

import math
import random
import pygame


def clamp(x, a, b):
    return a if x < a else b if x > b else x


def lerp(a, b, t):
    return a + (b - a) * t


def ease_out_cubic(t):
    t = clamp(t, 0.0, 1.0)
    return 1 - (1 - t) ** 3


def _norm(v: pygame.Vector2) -> pygame.Vector2:
    if v.length_squared() < 1e-8:
        return pygame.Vector2(1, 0)
    return v.normalize()


def _vec_from_angle(rad: float) -> pygame.Vector2:
    return pygame.Vector2(math.cos(rad), math.sin(rad))


def draw_glow_circle(surf: pygame.Surface, pos, radius: int, color, intensity: float = 1.0):
    """Glow bằng nhiều vòng tròn alpha, blit add."""
    x, y = int(pos[0]), int(pos[1])
    r = int(radius)
    if r <= 1:
        return
    size = r * 2 + 6
    tmp = pygame.Surface((size, size), pygame.SRCALPHA)
    cx, cy = size // 2, size // 2

    for i in range(8):
        t = i / 7.0
        rr = int(lerp(r, max(2, r * 0.2), t))
        a = int(lerp(10, 120, 1 - t) * intensity)
        pygame.draw.circle(tmp, (*color, a), (cx, cy), rr)

    surf.blit(tmp, (x - cx, y - cy), special_flags=pygame.BLEND_RGBA_ADD)


class Particle:
    __slots__ = ("pos", "vel", "life", "max_life", "radius", "color")

    def __init__(self, pos, vel, life, radius, color):
        self.pos = pygame.Vector2(pos)
        self.vel = pygame.Vector2(vel)
        self.life = float(life)
        self.max_life = float(life)
        self.radius = float(radius)
        self.color = color

    def update(self, dt: float):
        self.life -= dt
        self.pos += self.vel * dt
        self.vel *= (0.92 ** (dt * 60))

    def draw(self, screen: pygame.Surface, cam=(0, 0)):
        if self.life <= 0:
            return
        t = clamp(self.life / self.max_life, 0.0, 1.0)
        r = max(1, int(self.radius * lerp(0.6, 1.0, t)))
        intensity = lerp(0.2, 1.0, t)
        draw_glow_circle(screen, (self.pos.x - cam[0], self.pos.y - cam[1]), r * 3, self.color, intensity=intensity)


class KameFX:
    """
    API:
      - start_charge()
      - release_fire(origin, aim_dir)  # nếu đang lock -> bắn vào target
      - fire_at(origin, target_pos, charge_level=1.0)
      - lock_target(pos), clear_lock()
      - update(dt, origin, aim_dir)
      - draw(screen, origin, aim_dir, cam=(cam_x, cam_y))
      - get_shake() -> Vector2

    NOTE (đã chỉnh để BẮN TRÚNG MỤC TIÊU):
      - Khi bắn vào target, beam sẽ có độ dài đúng bằng khoảng cách tới target (không overshoot).
      - Hướng bắn/impact được "đóng băng" trong suốt thời gian firing để không bị lệch nếu target di chuyển.
    """

    def __init__(self):
        self.state = "idle"          # idle / charging / firing
        self.charge = 0.0            # 0..1
        self.fire_t = 0.0
        self.fire_len = 0.0

        self.locked = False
        self.target = pygame.Vector2(0, 0)

        self.particles = []
        self.impact_t = 0.0
        self.impact_pos = pygame.Vector2(0, 0)

        self.shake = 0.0

        # tuning
        self.charge_time = 1.15
        self.fire_duration = 0.75
        self.max_len = 900
        self.base_thickness = 18

        # colors
        self.color_edge = (90, 180, 255)
        self.color_glow = (170, 240, 255)
        self.color_core = (240, 255, 255)
        self.color_impact = (255, 255, 255)

        # --- shot cache (để beam luôn trúng) ---
        self._shot_dir = pygame.Vector2(1, 0)   # hướng bắn cố định trong lúc firing
        self._shot_len = 0.0                    # độ dài beam mục tiêu (clamp theo max_len)

    def reset(self):
        self.state = "idle"
        self.charge = 0.0
        self.fire_t = 0.0
        self.fire_len = 0.0
        self.particles.clear()
        self.impact_t = 0.0
        self.shake = 0.0
        self._shot_dir.update(1, 0)
        self._shot_len = 0.0

    def lock_target(self, pos):
        self.locked = True
        self.target = pygame.Vector2(pos)

    def clear_lock(self):
        self.locked = False

    def start_charge(self):
        if self.state == "idle":
            self.state = "charging"

    def release_fire(self, origin, aim_dir):
        """Thả bắn sau khi đang charging."""
        if self.state != "charging":
            return
        if self.charge < 0.12:
            self.state = "idle"
            self.charge = 0.0
            return

        origin = pygame.Vector2(origin)
        if self.locked:
            self.fire_at(origin, self.target, charge_level=self.charge)
        else:
            self._fire_dir(origin, _norm(pygame.Vector2(aim_dir)), charge_level=self.charge)

    def fire_at(self, origin, target_pos, charge_level=1.0):
        """Bắn thẳng vào 1 điểm world."""
        origin = pygame.Vector2(origin)
        target_pos = pygame.Vector2(target_pos)
        aim_dir = _norm(target_pos - origin)
        self._fire_dir(origin, aim_dir, charge_level=charge_level, impact_pos=target_pos)

    def update(self, dt: float, origin, aim_dir):
        origin = pygame.Vector2(origin)
        aim_dir = _norm(pygame.Vector2(aim_dir))

        # Nếu đang firing, KHÓA hướng bắn để không bị lệch khi target di chuyển
        if self.state == "firing":
            aim_dir = self._shot_dir
        else:
            if self.locked:
                aim_dir = _norm(self.target - origin)

        if self.state == "charging":
            self.charge = clamp(self.charge + dt / self.charge_time, 0.0, 1.0)

            for _ in range(2 + int(self.charge * 4)):
                ang = random.random() * math.tau
                ring_r = lerp(10, 44, self.charge) + random.uniform(-6, 6)
                p0 = origin + pygame.Vector2(math.cos(ang), math.sin(ang)) * ring_r
                v = (origin - p0) * lerp(4.0, 9.0, self.charge) + pygame.Vector2(
                    random.uniform(-30, 30), random.uniform(-30, 30)
                )
                self.particles.append(
                    Particle(p0, v, life=random.uniform(0.25, 0.55),
                             radius=random.uniform(2, 4), color=self.color_edge)
                )

        elif self.state == "firing":
            self.fire_t += dt
            t = clamp(self.fire_t / self.fire_duration, 0.0, 1.0)

            # ĐỘ DÀI BEAM: dùng _shot_len để chạm đúng impact
            self.fire_len = self._shot_len * ease_out_cubic(min(1.0, t * 2.2))
            self.shake *= (0.86 ** (dt * 60))

            if t < 0.65:
                for _ in range(3):
                    off = pygame.Vector2(random.uniform(-8, 8), random.uniform(-8, 8))
                    p0 = origin + off + aim_dir * random.uniform(30, 90)
                    v = aim_dir * random.uniform(260, 560) + pygame.Vector2(
                        random.uniform(-90, 90), random.uniform(-90, 90)
                    )
                    self.particles.append(
                        Particle(p0, v, life=random.uniform(0.18, 0.35),
                                 radius=random.uniform(2, 4), color=self.color_glow)
                    )

            if self.fire_t >= self.fire_duration:
                self.state = "idle"
                self.charge = 0.0
                self.fire_t = 0.0
                self.fire_len = 0.0
                self.shake = 0.0
                self._shot_len = 0.0

        else:
            self.charge = max(0.0, self.charge - dt * 0.6)

        if self.impact_t > 0:
            self.impact_t = max(0.0, self.impact_t - dt)

        for p in self.particles:
            p.update(dt)
        self.particles = [p for p in self.particles if p.life > 0]

    def draw(self, screen: pygame.Surface, origin, aim_dir, cam=(0, 0)):
        origin = pygame.Vector2(origin)
        aim_dir = _norm(pygame.Vector2(aim_dir))

        if self.state == "firing":
            aim_dir = self._shot_dir
        else:
            if self.locked:
                aim_dir = _norm(self.target - origin)

        for p in self.particles:
            p.draw(screen, cam=cam)

        if self.state == "charging":
            r = lerp(10, 32, self.charge)
            jitter = pygame.Vector2(random.uniform(-2, 2), random.uniform(-2, 2)) * (self.charge ** 1.7)
            ball_pos = origin + jitter

            draw_glow_circle(screen, (ball_pos.x - cam[0], ball_pos.y - cam[1]), int(r * 2.4),
                             self.color_edge, intensity=0.9)
            draw_glow_circle(screen, (ball_pos.x - cam[0], ball_pos.y - cam[1]), int(r * 1.7),
                             self.color_glow, intensity=1.0)
            draw_glow_circle(screen, (ball_pos.x - cam[0], ball_pos.y - cam[1]), int(r * 1.1),
                             self.color_core, intensity=1.2)

        if self.state == "firing" and self.fire_len > 8:
            t = clamp(self.fire_t / self.fire_duration, 0.0, 1.0)
            thickness = self.base_thickness * lerp(1.0, 1.25, (1 - t) ** 2) * lerp(0.9, 1.15, self.charge)

            wob_angle = math.sin(pygame.time.get_ticks() * 0.02) * 0.03 * (1 - t)
            dir2 = _vec_from_angle(math.atan2(aim_dir.y, aim_dir.x) + wob_angle).normalize()

            self._draw_beam(screen, origin, dir2, self.fire_len, thickness,
                            intensity=lerp(1.2, 0.55, t), cam=cam)

        if self.impact_t > 0:
            it = clamp(self.impact_t / 0.18, 0.0, 1.0)
            rr = int(lerp(28, 8, 1 - it))
            draw_glow_circle(screen, (self.impact_pos.x - cam[0], self.impact_pos.y - cam[1]),
                             rr * 2, self.color_glow, intensity=lerp(1.2, 0.2, 1 - it))
            draw_glow_circle(screen, (self.impact_pos.x - cam[0], self.impact_pos.y - cam[1]),
                             rr, self.color_impact, intensity=lerp(1.0, 0.2, 1 - it))

    def _draw_beam(self, screen, origin, direction, length, thickness, intensity=1.0, cam=(0, 0)):
        length = int(length)
        h = int(max(40, thickness * 3.2))
        beam = pygame.Surface((length + 40, h), pygame.SRCALPHA)
        cy = h // 2

        outer_w = int(thickness * 1.75)
        mid_w = int(thickness * 1.05)
        core_w = int(max(2, thickness * 0.45))

        # IMPORTANT: pygame.draw.line dùng width=..., không có thickness=
        pygame.draw.line(beam, (*self.color_edge, int(55 * intensity)), (10, cy), (length + 10, cy), width=outer_w)
        pygame.draw.line(beam, (*self.color_glow, int(90 * intensity)), (10, cy), (length + 10, cy), width=mid_w)
        pygame.draw.line(beam, (*self.color_core, int(155 * intensity)), (10, cy), (length + 10, cy), width=core_w)

        noise = [random.uniform(-1.0, 1.0) for _ in range(7)]
        for i in range(10):
            px = int(lerp(30, length, i / 9.0))
            ny = noise[i % len(noise)]
            rr = int(lerp(thickness * 0.55, thickness * 0.95, random.random()))
            a = int(lerp(40, 90, random.random()) * intensity)
            pygame.draw.circle(beam, (*self.color_glow, a), (px, cy + int(ny * thickness * 0.35)), rr)
            pygame.draw.circle(beam, (*self.color_core, int(a * 0.65)),
                               (px, cy + int(ny * thickness * 0.22)), max(2, rr // 2))

        head_x = length + 10
        pygame.draw.circle(beam, (*self.color_edge, int(140 * intensity)), (head_x, cy), int(thickness * 1.0))
        pygame.draw.circle(beam, (*self.color_core, int(160 * intensity)), (head_x, cy), int(thickness * 0.55))

        ang = math.degrees(math.atan2(direction.y, direction.x))
        rot = pygame.transform.rotozoom(beam, -ang, 1.0)

        center = origin + direction * (length * 0.5 + 20)
        rect = rot.get_rect(center=(int(center.x - cam[0]), int(center.y - cam[1])))
        screen.blit(rot, rect.topleft, special_flags=pygame.BLEND_RGBA_ADD)

    def get_shake(self) -> pygame.Vector2:
        if self.shake <= 0.01:
            return pygame.Vector2(0, 0)
        return pygame.Vector2(random.uniform(-self.shake, self.shake),
                              random.uniform(-self.shake, self.shake))

    def _fire_dir(self, origin, aim_dir, charge_level=1.0, impact_pos=None):
        """Bắn theo hướng aim_dir. Nếu impact_pos có, beam sẽ dài đúng tới đó."""
        if self.state == "firing":
            return
        aim_dir = _norm(pygame.Vector2(aim_dir))

        self.charge = clamp(charge_level, 0.0, 1.0)
        self.state = "firing"
        self.fire_t = 0.0
        self.fire_len = 0.0
        self.shake = lerp(2.0, 8.0, self.charge)

        # cache hướng bắn để không bị lệch
        self._shot_dir = pygame.Vector2(aim_dir)

        if impact_pos is None:
            # nếu không có target, dùng một độ dài mặc định
            self._shot_len = min(self.max_len, 800)
            self.impact_pos = pygame.Vector2(origin) + self._shot_dir * self._shot_len
        else:
            self.impact_pos = pygame.Vector2(impact_pos)
            dist = (self.impact_pos - pygame.Vector2(origin)).length()
            # clamp để tránh beam quá ngắn/0
            self._shot_len = clamp(dist, 60.0, float(self.max_len))

        self.impact_t = 0.18

        # sparks ở impact
        for _ in range(16):
            ang = random.random() * math.tau
            v = _vec_from_angle(ang) * random.uniform(120, 420)
            self.particles.append(
                Particle(self.impact_pos, v, life=random.uniform(0.12, 0.28),
                         radius=random.uniform(2, 4), color=self.color_core)
            )
