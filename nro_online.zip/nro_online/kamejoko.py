# kamejoko_boss_hit_fix.py  (BẢN GỌN + FIX BOSS KHÔNG DÍNH)
# Chiêu 2: Kamejoko (110% sát thương)
# - Gồng 1.5s (2 tay chụm) rồi mới bắn
# - Hồi chiêu 2.0s
# - Tầm bắn ~200
# - Tương thích main.py: consume_fire() + consume_hit()
# - FIX BOSS KHÔNG DÍNH: kiểm tra trúng bằng rect.clipline (tia 200 cắt vào hitbox là tính trúng)
#
# Yêu cầu: đặt chung thư mục với kame_fx.py

import pygame
from kame_fx import KameFX


def _norm(v: pygame.Vector2) -> pygame.Vector2:
    v = pygame.Vector2(v)
    if v.length_squared() < 1e-8:
        return pygame.Vector2(1, 0)
    return v.normalize()


def _as_rect(r):
    if r is None:
        return None
    if isinstance(r, pygame.Rect):
        return r
    # tuple/list (x,y,w,h)
    try:
        if isinstance(r, (list, tuple)) and len(r) == 4:
            return pygame.Rect(r[0], r[1], r[2], r[3])
    except Exception:
        pass
    return None


def _get_target_rect(obj):
    """Boss đôi khi không dùng .rect mà dùng hitbox/hit_rect... -> hỗ trợ nhiều tên."""
    if obj is None:
        return None

    # dict style
    if isinstance(obj, dict):
        for k in ("rect", "hitbox", "hit_rect", "collision_rect", "rect_hit"):
            rr = _as_rect(obj.get(k))
            if rr is not None:
                return rr
        return None

    # object style
    for k in ("rect", "hitbox", "hit_rect", "collision_rect", "rect_hit"):
        if hasattr(obj, k):
            rr = _as_rect(getattr(obj, k))
            if rr is not None:
                return rr
    return None


class KameJoko:
    SKILL_ID = "kamejoko"
    NAME = "Kamejoko"
    DAMAGE_PCT = 125

    COOLDOWN = 2.0
    CHARGE_TIME = 1.5
    BEAM_RANGE = 200.0

    def __init__(self):
        self.fx = KameFX()

        # ép thông số cho FX nếu có
        for k, v in (("charge_time", self.CHARGE_TIME), ("max_len", self.BEAM_RANGE)):
            if hasattr(self.fx, k):
                try:
                    setattr(self.fx, k, float(v))
                except Exception:
                    pass

        self.cast_state = "idle"  # idle / charging / firing
        self.cooldown_left = 0.0
        self.charge_left = 0.0

        self._lock_dir = pygame.Vector2(1, 0)
        self._lock_target_obj = None
        self._lock_target_pos = None

        self._fired_flag = False
        self._pending_hit_obj = None

    def ready(self) -> bool:
        return self.cooldown_left <= 0.0 and self.cast_state == "idle"

    def request_cast(self, origin, target_obj=None, target_pos=None, aim_dir=None) -> bool:
        """Bấm 1 lần => gồng 1.5s => tự bắn."""
        if not self.ready():
            return False

        origin = pygame.Vector2(origin)

        if target_obj is not None:
            # cố lấy rect (boss thường có hitbox)
            rr = _get_target_rect(target_obj)
            if rr is not None:
                tp = pygame.Vector2(rr.centerx, rr.centery)
            elif hasattr(target_obj, "rect"):
                tp = pygame.Vector2(target_obj.rect.centerx, target_obj.rect.centery)
            else:
                tp = None

            if tp is not None:
                self._lock_dir = _norm(tp - origin)
                self._lock_target_obj = target_obj
                self._lock_target_pos = tp
            else:
                # fallback sang aim_dir nếu không có tp
                if aim_dir is not None:
                    self._lock_dir = _norm(pygame.Vector2(aim_dir))
                self._lock_target_obj = target_obj
                self._lock_target_pos = None

        elif target_pos is not None:
            tp = pygame.Vector2(target_pos)
            self._lock_dir = _norm(tp - origin)
            self._lock_target_obj = None
            self._lock_target_pos = tp

        elif aim_dir is not None:
            self._lock_dir = _norm(pygame.Vector2(aim_dir))
            self._lock_target_obj = None
            self._lock_target_pos = None

        else:
            self._lock_dir = pygame.Vector2(1, 0)
            self._lock_target_obj = None
            self._lock_target_pos = None

        self.cast_state = "charging"
        self.charge_left = float(self.CHARGE_TIME)
        self._fired_flag = False
        self._pending_hit_obj = None

        # start charge FX
        if hasattr(self.fx, "reset"):
            self.fx.reset()
        if hasattr(self.fx, "charge_time"):
            try:
                self.fx.charge_time = float(self.CHARGE_TIME)
            except Exception:
                pass
        if hasattr(self.fx, "max_len"):
            try:
                self.fx.max_len = float(self.BEAM_RANGE)
            except Exception:
                pass
        if hasattr(self.fx, "start_charge"):
            self.fx.start_charge()
        return True

    def update(self, dt: float, origin, aim_dir):
        dt = float(dt)
        origin = pygame.Vector2(origin)

        if self.cooldown_left > 0.0:
            self.cooldown_left = max(0.0, self.cooldown_left - dt)

        if self.cast_state == "charging":
            self.charge_left = max(0.0, self.charge_left - dt)

            if hasattr(self.fx, "update"):
                self.fx.update(dt, origin, self._lock_dir)

            if self.charge_left <= 0.0:
                impact_pos, hit_obj = self._compute_impact_and_hit(origin)
                self._pending_hit_obj = hit_obj
                self._fire_fx(origin, impact_pos)

                self.cast_state = "firing"
                self.cooldown_left = float(self.COOLDOWN)
                self._fired_flag = True

        elif self.cast_state == "firing":
            if hasattr(self.fx, "update"):
                self.fx.update(dt, origin, self._lock_dir)
            if getattr(self.fx, "state", "") == "idle":
                self.cast_state = "idle"
                self._lock_target_obj = None
                self._lock_target_pos = None

        else:
            if hasattr(self.fx, "update"):
                self.fx.update(dt, origin, pygame.Vector2(aim_dir))

    def draw(self, screen, origin, aim_dir, cam=(0, 0), player_rect=None, facing_right=True):
        if self.cast_state == "charging" and player_rect is not None:
            self._draw_two_hands_pose(screen, origin, player_rect, cam=cam)

        if hasattr(self.fx, "draw"):
            self.fx.draw(screen, origin, self._lock_dir if self.cast_state != "idle" else aim_dir, cam=cam)

    def get_shake(self) -> pygame.Vector2:
        if hasattr(self.fx, "get_shake"):
            return self.fx.get_shake()
        return pygame.Vector2(0, 0)

    def consume_fire(self) -> bool:
        v = bool(self._fired_flag)
        self._fired_flag = False
        return v

    def consume_hit(self):
        obj = self._pending_hit_obj
        self._pending_hit_obj = None
        return obj

    @staticmethod
    def apply_damage(base_damage: int) -> int:
        return max(1, int(base_damage * KameJoko.DAMAGE_PCT / 100))

    # ---- internal ----
    def _fire_fx(self, origin: pygame.Vector2, impact_pos: pygame.Vector2):
        if hasattr(self.fx, "fire_at"):
            try:
                self.fx.fire_at(origin, impact_pos, charge_level=1.0)
                return
            except TypeError:
                try:
                    self.fx.fire_at(origin, impact_pos)
                    return
                except Exception:
                    pass
        if hasattr(self.fx, "fire_to"):
            try:
                self.fx.fire_to(origin, impact_pos, self._lock_dir)
                return
            except Exception:
                pass

    def _compute_impact_and_hit(self, origin: pygame.Vector2):
        """
        FIX BOSS:
        - Dùng rect.clipline(start,end). Nếu tia (0..200) cắt hitbox => tính trúng.
        - Không còn phụ thuộc "tâm boss" nằm trong tầm nữa.
        """
        start = pygame.Vector2(origin)
        end = start + self._lock_dir * float(self.BEAM_RANGE)

        # mặc định impact ở cuối tia
        impact = pygame.Vector2(end)
        hit_obj = None

        if self._lock_target_obj is not None:
            rr = _get_target_rect(self._lock_target_obj)
            if rr is not None:
                # nới hitbox một chút cho dễ dính (boss to/di chuyển)
                r2 = rr.inflate(8, 8)
                hit = r2.clipline((start.x, start.y), (end.x, end.y))
                if hit:
                    # hit là ((x1,y1),(x2,y2)) -> lấy điểm đầu làm impact
                    impact = pygame.Vector2(hit[0][0], hit[0][1])
                    hit_obj = self._lock_target_obj
                    return impact, hit_obj

        # fallback: nếu chỉ có target_pos
        if self._lock_target_pos is not None:
            tp = pygame.Vector2(self._lock_target_pos)
            # nếu target nằm trong tầm thì impact vào đúng tp (đẹp hơn)
            if (tp - start).length() <= float(self.BEAM_RANGE):
                impact = tp

        return impact, hit_obj

    def _draw_two_hands_pose(self, screen, origin, player_rect, cam=(0, 0)):
        ox, oy = origin[0] - cam[0], origin[1] - cam[1]
        cx = player_rect.centerx - cam[0]
        sy = player_rect.y + 22 - cam[1]
        shoulder_l = (cx - 12, sy)
        shoulder_r = (cx + 12, sy)

        pygame.draw.line(screen, (120, 160, 220), shoulder_l, (ox, oy), 6)
        pygame.draw.line(screen, (120, 160, 220), shoulder_r, (ox, oy), 6)
        pygame.draw.circle(screen, (160, 200, 255), (int(ox), int(oy)), 6)

        prog = 1.0 - (self.charge_left / max(0.001, float(self.CHARGE_TIME)))
        r = int(14 + 18 * prog)
        pygame.draw.circle(screen, (120, 180, 255), (int(ox), int(oy)), r, 2)
