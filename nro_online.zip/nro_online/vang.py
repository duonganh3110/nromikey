import pygame
import math

# --- CẤU HÌNH & MÀU SẮC (Dùng từ main.py) ---
WHITE = (255, 255, 255)
C_VANG = (255, 215, 0) # Vàng cơ bản cho chữ VIP
C_DIAMOND = (0, 200, 255) 
C_VND = (0, 150, 0) # Màu xanh lá đậm cho VND
C_VIP_GLOW = (255, 255, 150) # Màu phát sáng VIP (sáng hơn)
BLACK = (0, 0, 0)

# Kích thước HUD tiền tệ
HUD_WIDTH = 250 
HUD_HEIGHT = 90
ICON_SIZE = 16
MARGIN = 10
LINE_HEIGHT = 20

# Biến font để sử dụng
font_small = None
font_mini = None
font_vip = None # Font riêng cho VIP

def init_fonts():
    """Khởi tạo fonts nếu chưa được khởi tạo"""
    global font_small, font_mini, font_vip
    if font_small is None or font_mini is None:
        try:
            if not pygame.font.get_init():
                pygame.font.init()
            font_small = pygame.font.SysFont("Arial", 16)
            font_mini = pygame.font.SysFont("Arial", 12)
            font_vip = pygame.font.SysFont("Arial", 14, bold=True)
        except:
            # Fallback nếu không load được font hệ thống
            font_small = pygame.font.SysFont("Arial", 16)
            font_mini = pygame.font.SysFont("Arial", 12)
            font_vip = pygame.font.SysFont("Arial", 14, bold=True)

def draw_currency_icon(surface, cx, cy, currency_type):
    """Vẽ icon Vàng, Kim Cương hoặc VND (Tờ tiền giấy)"""
    if font_mini is None: init_fonts()
    radius = ICON_SIZE // 2

    if currency_type == "VANG":
        # Icon Vàng
        pygame.draw.circle(surface, C_VANG, (cx, cy), radius + 1)
        pygame.draw.circle(surface, (200, 150, 0), (cx, cy), radius, 1)
        v_surf = font_mini.render("V", True, BLACK)
        surface.blit(v_surf, v_surf.get_rect(center=(cx, cy)))

    elif currency_type == "KIM_CUONG":
        # Icon Kim Cương
        pts = [(cx, cy - radius), 
               (cx + ICON_SIZE//3, cy), 
               (cx, cy + radius), 
               (cx - ICON_SIZE//3, cy)]
        pygame.draw.polygon(surface, C_DIAMOND, pts)
        pygame.draw.polygon(surface, BLACK, pts, 1)
    
    elif currency_type == "VND":
        # Icon VND (Tờ tiền giấy màu xanh)
        RECT_W, RECT_H = 14, 8
        pygame.draw.rect(surface, C_VND, (cx - RECT_W//2, cy - RECT_H//2, RECT_W, RECT_H), border_radius=1)
        pygame.draw.rect(surface, (255, 255, 255), (cx - RECT_W//2, cy - RECT_H//2, RECT_W, RECT_H), 1)
        # Chữ V
        font_v = pygame.font.SysFont("Arial", 7, bold=True)
        text_surf = font_v.render("V", True, BLACK)
        surface.blit(text_surf, text_surf.get_rect(center=(cx + 3, cy - 1)))

# [CẬP NHẬT] Hàm vẽ ký hiệu VIP nhấp nháy (Chỉ Glow nhấp nháy)
def draw_vip_symbol(surface, x, y, current_time, is_vip):
    """Vẽ chữ VIP nhấp nháy bên phải các dòng tiền tệ. Chỉ phần GLOW nhấp nháy."""
    if not is_vip:
        return
        
    init_fonts()
    
    # 1. Hiệu ứng nhấp nháy: Đổi màu phát sáng mỗi 500ms
    # (current_time // 500) % 2 sẽ luân phiên trả về 0 hoặc 1
    if (current_time // 500) % 2 == 0:
        # Trạng thái phát sáng mạnh (Vàng/Trắng)
        glow_color = C_VIP_GLOW
    else:
        # Trạng thái phát sáng yếu (Màu chữ chính, tạo cảm giác pulse nhẹ)
        glow_color = C_VANG 
    
    # 2. Vẽ hiệu ứng phát sáng/shadow mờ (chuyển đổi màu)
    txt_vip_shadow = font_vip.render("VIP", True, glow_color)
    # Vẽ lệch 1 pixel để tạo shadow/glow
    surface.blit(txt_vip_shadow, (x + 1, y + 1)) 
    surface.blit(txt_vip_shadow, (x - 1, y - 1))
    
    # 3. Vẽ chữ VIP chính (màu cố định C_VANG)
    txt_vip = font_vip.render("VIP", True, C_VANG)
    surface.blit(txt_vip, (x, y))


# [UPDATE] Hàm draw_currency_hud không còn cần thiết vì logic chuyển vào main.py (ve_thanh_trang_thai)
# Nhưng giữ lại can_afford và deduct_currency

def can_afford(player_data, cost_vang=0, cost_kc=0, cost_vnd=0):
    """Kiểm tra người chơi có đủ tiền không (Đã thêm VND)"""
    return (player_data.get("vang", 0) >= cost_vang and 
            player_data.get("kim_cuong", 0) >= cost_kc and
            player_data.get("vnd", 0) >= cost_vnd)

def deduct_currency(player_data, cost_vang=0, cost_kc=0, cost_vnd=0):
    """Trừ tiền và trả về True nếu thành công, False nếu không đủ tiền (Đã thêm VND)"""
    if can_afford(player_data, cost_vang, cost_kc, cost_vnd):
        player_data["vang"] = player_data.get("vang", 0) - cost_vang
        player_data["kim_cuong"] = player_data.get("kim_cuong", 0) - cost_kc
        player_data["vnd"] = player_data.get("vnd", 0) - cost_vnd
        
        player_data["vang"] = max(0, player_data["vang"])
        player_data["kim_cuong"] = max(0, player_data["kim_cuong"])
        player_data["vnd"] = max(0, player_data["vnd"])
        return True
    return False