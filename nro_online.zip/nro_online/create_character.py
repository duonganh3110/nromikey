# create_character.py - Màn hình tạo nhân vật (Full Fix)
import pygame
import sys
import os

# --- CẤU HÌNH ---
SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 600

# Màu sắc
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (128, 128, 128)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)

# Đường dẫn ảnh
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
BG_IMAGE_PATH = os.path.join(CURRENT_DIR, "background_login.jpg")

def tai_hinh_nen(screen_width, screen_height):
    """Hàm tải hình nền an toàn, không crash nếu thiếu ảnh"""
    if os.path.exists(BG_IMAGE_PATH):
        try:
            img = pygame.image.load(BG_IMAGE_PATH)
            img = pygame.transform.scale(img, (screen_width, screen_height))
            return img
        except Exception as e:
            print(f"Loi load anh nen: {e}")
            return None
    else:
        print(f"Khong tim thay file anh: {BG_IMAGE_PATH}")
        return None

def ve_nut(screen, rect, mau_nen, text, font, mau_chu=WHITE):
    pygame.draw.rect(screen, mau_nen, rect, border_radius=8)
    pygame.draw.rect(screen, WHITE, rect, 2, border_radius=8)
    text_surf = font.render(text, True, mau_chu)
    text_rect = text_surf.get_rect(center=rect.center)
    screen.blit(text_surf, text_rect)

def chay_man_hinh_tao_nv(screen, username):
    """
    Hàm chính hiển thị màn hình tạo nhân vật.
    Trả về: (ten_nhan_vat, hanh_tinh) hoặc (None, None) nếu thoát.
    """
    clock = pygame.time.Clock()
    
    # Font chữ
    try:
        font_title = pygame.font.SysFont("Arial", 40, bold=True)
        font_input = pygame.font.SysFont("Arial", 30)
        font_btn = pygame.font.SysFont("Arial", 20, bold=True)
    except:
        font_title = pygame.font.Font(None, 40)
        font_input = pygame.font.Font(None, 30)
        font_btn = pygame.font.Font(None, 25)

    # Tải hình nền
    bg_image = tai_hinh_nen(screen.get_width(), screen.get_height())

    # Biến nhập liệu
    input_text = ""
    active_input = True
    
    # Biến chọn hành tinh
    selected_planet = "Trai Dat" # Mặc định

    # Định nghĩa các nút bấm (Toạ độ)
    w, h = screen.get_width(), screen.get_height()
    center_x = w // 2
    
    # Hộp nhập tên
    input_box_rect = pygame.Rect(center_x - 150, h // 2 - 50, 300, 50)
    
    # Các nút hành tinh
    btn_td_rect = pygame.Rect(center_x - 200, h // 2 + 50, 120, 150)
    btn_nm_rect = pygame.Rect(center_x - 60, h // 2 + 50, 120, 150)
    btn_xd_rect = pygame.Rect(center_x + 80, h // 2 + 50, 120, 150)
    
    # Nút Tạo
    btn_create_rect = pygame.Rect(center_x - 100, h // 2 + 230, 200, 50)

    while True:
        # 1. Xử lý sự kiện
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos
                
                # Click chọn hành tinh
                if btn_td_rect.collidepoint(mx, my):
                    selected_planet = "Trai Dat"
                elif btn_nm_rect.collidepoint(mx, my):
                    selected_planet = "Namec"
                elif btn_xd_rect.collidepoint(mx, my):
                    selected_planet = "Xayda"
                
                # Click nút Tạo
                if btn_create_rect.collidepoint(mx, my):
                    if len(input_text.strip()) > 0:
                        return input_text.strip(), selected_planet
                
                # Focus ô nhập
                if input_box_rect.collidepoint(mx, my):
                    active_input = True
                else:
                    active_input = False

            if event.type == pygame.KEYDOWN:
                if active_input:
                    if event.key == pygame.K_RETURN:
                        if len(input_text.strip()) > 0:
                            return input_text.strip(), selected_planet
                    elif event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    else:
                        # Giới hạn độ dài tên
                        if len(input_text) < 12 and event.unicode.isprintable():
                            input_text += event.unicode

        # 2. Vẽ màn hình
        if bg_image:
            screen.blit(bg_image, (0, 0))
        else:
            screen.fill(BLACK) # Màu nền dự phòng nếu ảnh lỗi

        # Lớp phủ mờ cho dễ nhìn
        overlay = pygame.Surface((w, h), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        screen.blit(overlay, (0, 0))

        # Tiêu đề
        title_surf = font_title.render("TẠO NHÂN VẬT MỚI", True, YELLOW)
        screen.blit(title_surf, (center_x - title_surf.get_width() // 2, 100))

        # Ô nhập tên
        pygame.draw.rect(screen, WHITE if active_input else GRAY, input_box_rect, 2)
        txt_surface = font_input.render(input_text, True, WHITE)
        # Căn giữa text trong ô nhập
        screen.blit(txt_surface, (input_box_rect.x + 10, input_box_rect.y + 10))
        
        # Gợi ý nhập
        if not input_text and not active_input:
            hint = font_input.render("Nhập tên nhân vật...", True, (150, 150, 150))
            screen.blit(hint, (input_box_rect.x + 10, input_box_rect.y + 10))

        # Vẽ các nút chọn hành tinh
        # Trái Đất
        col_td = GREEN if selected_planet == "Trai Dat" else GRAY
        ve_nut(screen, btn_td_rect, col_td, "TRÁI ĐẤT", font_btn)
        
        # Namec
        col_nm = GREEN if selected_planet == "Namec" else GRAY
        ve_nut(screen, btn_nm_rect, col_nm, "NAMEC", font_btn)
        
        # Xayda
        col_xd = GREEN if selected_planet == "Xayda" else GRAY
        ve_nut(screen, btn_xd_rect, col_xd, "XAYDA", font_btn)

        # Vẽ nút Tạo
        col_create = BLUE if len(input_text.strip()) > 0 else GRAY
        ve_nut(screen, btn_create_rect, col_create, "VÀO GAME", font_btn)

        pygame.display.flip()
        clock.tick(60)