# detucoban.py
# ĐỆ TỬ CƠ BẢN (NRO-like) - v8 (AI THEO / BẢO VỆ / TẤN CÔNG / VỀ NHÀ)
# Mikey yêu cầu:
# - THEO: chỉ đi theo, không tự đánh
# - BẢO VỆ: đánh quái gần nhân vật (và chỉ chạy quanh khu vực nhân vật)
# - TẤN CÔNG: tự chạy khắp map để đánh quái (KHÔNG đánh boss)
# - VỀ NHÀ: ẩn đệ (không vẽ, không có hitbox, không đánh)
#
# Chỉ số:
# - HP random: 1000-1500
# - KI random: 1000-1500
# - Sức đánh random: 10-25
# - Sức mạnh & Tiềm năng random: 2000-15000
#
# Combat:
# - Dame tay giống calculate_player_damage trong game_loop (set_damage_calc_func)
# - TNSM giống nhân vật:
#     real_hp_lost = min(calc_dmg, hp_truoc_khi_danh)
#     bonus_multiplier = 2 (30%) else 1
#     tnsm = int(real_hp_lost * bonus_multiplier)
#     det.suc_manh += tnsm; det.tiem_nang += tnsm
#
# Single-mode: đã có đệ rồi thì hạ SuperBroly KHÔNG cấp thêm (đúng ý Mikey)

from __future__ import annotations

import json
import hashlib
import math
import os
import random
import re
from dataclasses import dataclass
from typing import Optional, Dict, Any, Callable, Tuple, List, Iterable

import pygame

VERSION = "detucoban_v9_ai_modes_per_account"

# -------------------- CONFIG --------------------
TOGGLE_TAB_KEY = pygame.K_y
HUD_TAG_POS = (14, 10)

FOLLOW_OFFSET_X = -70
FOLLOW_OFFSET_Y = 0
FOLLOW_SMOOTH = 0.18

PET_W, PET_H = 28, 46
PET_MOVE_SPEED = 4.0   # tốc độ chạy (world px / frame)
PET_STOP_DIST = 22.0   # tới gần mục tiêu thì đứng lại đánh

ENABLE_SAVE = True
SAVE_FILE = "detu_save.json"


# -------------------- SAVE CONTEXT (PER ACCOUNT / CHARACTER) --------------------
# Lỗi Mikey gặp: dùng chung 1 file detu_save.json => acc nào có đệ thì acc khác load cũng có.
# Fix: mỗi (username_acc, ten_nv) có 1 file save riêng.
_CURRENT_OWNER = None  # tuple(username_acc, ten_nv)
_SAVE_DIR = ""         # nếu muốn đặt thư mục riêng

def _safe_name(s: str) -> str:
    raw = str(s) if s is not None else ""
    # phần dễ đọc (ASCII) + thêm hash để không bị trùng nếu tên có dấu/ký tự lạ
    base = re.sub(r"[^0-9A-Za-z_\-]+", "_", raw).strip("_")
    h = hashlib.md5(raw.encode("utf-8")).hexdigest()[:8]
    if not base:
        base = "u"
    return f"{base}_{h}"

def get_save_file() -> str:
    return SAVE_FILE

def bind_owner(username_acc: str, ten_nv: str, save_dir: str = "") -> str:
    """Gọi 1 lần khi vào game / đổi nhân vật để tách save đệ theo từng acc."""
    global SAVE_FILE, _CURRENT_OWNER, _SAVE_DIR, _det
    _CURRENT_OWNER = (str(username_acc), str(ten_nv))
    _SAVE_DIR = str(save_dir) if save_dir is not None else ""
    fn = f"detu_save__{_safe_name(username_acc)}__{_safe_name(ten_nv)}.json"
    SAVE_FILE = os.path.join(_SAVE_DIR, fn) if _SAVE_DIR else fn

    # reset state rồi load theo owner mới
    _det = None
    if ENABLE_SAVE:
        load()
    return SAVE_FILE

PLANETS = ("Trai Dat", "Xayda", "Namec")

# Random ranges
HP_MIN, HP_MAX = 1000, 1500
KI_MIN, KI_MAX = 1000, 1500
SD_MIN, SD_MAX = 10, 25
SM_MIN, SM_MAX = 2000, 15000
TN_MIN, TN_MAX = 2000, 15000

# Combat
ATTACK_RANGE = 90
ATTACK_COOLDOWN_MS = 650

# Protect logic
PROTECT_RADIUS = 180  # quái gần nhân vật trong khoảng này mới đánh khi BẢO VỆ
PROTECT_LEASH = 260   # đệ không chạy xa nhân vật quá khi BẢO VỆ

# Regen (Mikey): hồi 5% mỗi 0.5s nếu đệ rảnh (không đánh) và không bị đánh
REGEN_INTERVAL_MS = 500
REGEN_PERCENT = 0.05

# Modes
MODE_THEO = "THEO"
MODE_BAO_VE = "BAO_VE"
MODE_TAN_CONG = "TAN_CONG"
MODE_VE_NHA = "VE_NHA"

MODE_LABELS = {
    MODE_THEO: "Đi theo",
    MODE_BAO_VE: "Bảo vệ",
    MODE_TAN_CONG: "Tấn công",
    MODE_VE_NHA: "Về nhà",
}

# Dame calc callback: func(base_sd, crit_stat) -> (damage, is_crit)
_damage_calc_func: Optional[Callable[[int, int], Tuple[int, bool]]] = None


@dataclass
class DeTu:
    planet: str

    hp_max: int
    ki_max: int

    suc_danh: int
    chi_mang: int

    # để tuido hiển thị gọn
    dmg_min: int
    dmg_max: int

    suc_manh: int
    tiem_nang: int

    hp: int
    ki: int

    # world position
    x: float
    y: float

    # mode
    mode: str = MODE_THEO

    # runtime
    is_dead: bool = False
    last_hit_tick: int = 0
    last_attack_tick: int = 0
    last_regen_tick: int = 0

    @property
    def label(self) -> str:
        return f"đệ {self.planet}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "planet": self.planet,
            "hp_max": self.hp_max,
            "ki_max": self.ki_max,
            "suc_danh": self.suc_danh,
            "chi_mang": self.chi_mang,
            "dmg_min": self.dmg_min,
            "dmg_max": self.dmg_max,
            "suc_manh": self.suc_manh,
            "tiem_nang": self.tiem_nang,
            "hp": self.hp,
            "ki": self.ki,
            "x": self.x,
            "y": self.y,
            "mode": self.mode,
            "is_dead": self.is_dead,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "DeTu":
        hp_max = int(d.get("hp_max", 1000))
        ki_max = int(d.get("ki_max", 1000))
        suc_danh = int(d.get("suc_danh", int(d.get("dmg_min", 10))))
        chi_mang = int(d.get("chi_mang", 0))
        dmg_min = int(d.get("dmg_min", suc_danh))
        dmg_max = int(d.get("dmg_max", suc_danh))
        mode = str(d.get("mode", MODE_THEO))
        if mode not in MODE_LABELS:
            mode = MODE_THEO
        return DeTu(
            planet=str(d.get("planet", "Trai Dat")),
            hp_max=hp_max,
            ki_max=ki_max,
            suc_danh=suc_danh,
            chi_mang=chi_mang,
            dmg_min=dmg_min,
            dmg_max=dmg_max,
            suc_manh=int(d.get("suc_manh", 2000)),
            tiem_nang=int(d.get("tiem_nang", 2000)),
            hp=int(d.get("hp", hp_max)),
            ki=int(d.get("ki", ki_max)),
            x=float(d.get("x", 0.0)),
            y=float(d.get("y", 0.0)),
            mode=mode,
            is_dead=bool(d.get("is_dead", False)),
            last_regen_tick=int(d.get("last_regen_tick", 0)),
        )


# -------------------- STATE --------------------
_det: Optional[DeTu] = None
_tab_open: bool = False
_last_award_tick: int = -10_000_000

_font_head = None
_font_small = None

# cache player pos để mode BẢO VỆ / về nhà dùng
_player_world_x: Optional[float] = None
_player_ground_y: Optional[int] = None

# cache mục tiêu hiện tại để đệ chạy tới
_current_target = None


# -------------------- API --------------------
def set_damage_calc_func(func: Optional[Callable[[int, int], Tuple[int, bool]]]):
    global _damage_calc_func
    _damage_calc_func = func


def has_det() -> bool:
    return _det is not None and not _det.is_dead


def get_det() -> Optional[DeTu]:
    return _det if has_det() else None


def get_mode() -> str:
    det = get_det()
    is_idle = True  # để regen
    return det.mode if det else MODE_THEO


def get_mode_label() -> str:
    return MODE_LABELS.get(get_mode(), "Đi theo")


def set_mode(mode: str):
    det = get_det()
    if det is None:
        return
    if mode not in MODE_LABELS:
        return
    prev = det.mode
    det.mode = mode

    # rời VỀ NHÀ -> kéo ra cạnh nhân vật
    if prev == MODE_VE_NHA and mode != MODE_VE_NHA and _player_world_x is not None and _player_ground_y is not None:
        det.x = float(_player_world_x) + 30
        det.y = float(_player_ground_y) - PET_H

    if ENABLE_SAVE:
        _save()


def clear_det():
    global _det
    _det = None
    if ENABLE_SAVE:
        _save()


def handle_event(event: pygame.event.Event) -> bool:
    global _tab_open
    if event.type == pygame.KEYDOWN and event.key == TOGGLE_TAB_KEY:
        _tab_open = not _tab_open
        return True
    return False


def get_rect(map_offset_x: float = 0.0) -> Optional[pygame.Rect]:
    det = get_det()
    if det is None:
        return None
    if det.mode == MODE_VE_NHA:
        return None
    x = int(det.x - map_offset_x)
    y = int(det.y)
    return pygame.Rect(x, y, PET_W, PET_H)


def take_damage(amount: int, current_time: Optional[int] = None) -> int:
    det = get_det()
    if det is None:
        return 0
    if det.mode == MODE_VE_NHA:
        return 0
    if current_time is None:
        current_time = pygame.time.get_ticks()

    dmg = max(0, int(amount))
    if dmg <= 0:
        return 0

    det.hp -= dmg
    det.last_hit_tick = int(current_time)
    if det.hp <= 0:
        det.hp = 0
        det.is_dead = True

    if ENABLE_SAVE:
        _save()
    return dmg


# -------------------- FOLLOW / AI --------------------
def update_follow(
    player_rect: pygame.Rect,
    player_world_x: Optional[float] = None,
    ground_y: Optional[int] = None,
    dt: float = 1 / 60,
):
    """Gọi mỗi frame. (Mode VỀ NHÀ vẫn cache vị trí nhân vật)."""
    global _player_world_x, _player_ground_y

    if player_world_x is None:
        player_world_x = float(player_rect.centerx)
    if ground_y is None:
        ground_y = int(player_rect.bottom)

    _player_world_x = float(player_world_x)
    _player_ground_y = int(ground_y)

    det = get_det()
    if det is None:
        return
    if det.mode == MODE_VE_NHA:
        return

    # THEO / BẢO VỆ: mặc định đứng gần nhân vật
    if det.mode in (MODE_THEO, MODE_BAO_VE):
        target_x = float(player_world_x) + FOLLOW_OFFSET_X
        target_y = float(ground_y) - PET_H + FOLLOW_OFFSET_Y
        det.x = det.x + (target_x - det.x) * FOLLOW_SMOOTH
        det.y = det.y + (target_y - det.y) * FOLLOW_SMOOTH




def _regen_if_idle(det: DeTu, current_time: int, is_idle: bool):
    """Hồi HP 5% mỗi 0.5s nếu đệ rảnh (không đánh) và không bị đánh gần đây."""
    if not is_idle:
        return
    if det.mode == MODE_VE_NHA or det.is_dead:
        return
    if det.hp >= det.hp_max or det.hp_max <= 0:
        return

    # không bị đánh gần đây
    if current_time - int(det.last_hit_tick) < REGEN_INTERVAL_MS:
        return
    # không đánh gần đây
    if current_time - int(det.last_attack_tick) < REGEN_INTERVAL_MS:
        return
    # tick theo interval
    if current_time - int(det.last_regen_tick) < REGEN_INTERVAL_MS:
        return

    det.last_regen_tick = int(current_time)
    heal = max(1, int(det.hp_max * REGEN_PERCENT))
    det.hp = min(det.hp_max, det.hp + heal)
    if ENABLE_SAVE:
        _save()


def update_ai(
    player_rect: pygame.Rect,
    player_world_x: float,
    ground_y: int,
    map_offset_x: float,
    current_time: int,
    mobs: Optional[Iterable] = None,
    moc_nhan_list: Optional[Iterable] = None,
    boss_list: Optional[Iterable] = None,
    text_manager=None,
    effect_manager=None,
):
    """AI chính cho đệ:
    - THEO: chỉ gọi update_follow là đủ
    - BẢO VỆ: chọn quái gần nhân vật -> chạy tới đánh, không đi xa quá leash
    - TẤN CÔNG: chạy khắp map tìm quái -> đánh, loại trừ boss
    - VỀ NHÀ: không làm gì
    """
    det = get_det()
    if det is None:
        return

    # cập nhật cache player
    update_follow(player_rect, player_world_x, ground_y)

    if det.mode == MODE_VE_NHA:
        return

    if det.mode == MODE_THEO:
        # chỉ đi theo thôi (idle -> regen)
        _regen_if_idle(det, current_time, is_idle=True)
        return

    # build candidates
    candidates = []
    if mobs:
        candidates.extend([m for m in mobs if _is_valid_mob(m)])
    if moc_nhan_list:
        candidates.extend([m for m in moc_nhan_list if _is_valid_mob(m)])

    # loại trừ boss
    if boss_list:
        boss_set = set([b for b in boss_list if b is not None])
        candidates = [m for m in candidates if m not in boss_set]
    candidates = [m for m in candidates if not _looks_like_boss(m)]

    if not candidates:
        # không có quái -> idle -> regen
        _regen_if_idle(det, current_time, is_idle=True)
        # không có quái -> với BẢO VỆ thì đứng cạnh nhân vật, TẤN CÔNG thì cũng quay về gần nhân vật
        if det.mode in (MODE_BAO_VE, MODE_TAN_CONG):
            _move_towards(det, float(player_world_x) + FOLLOW_OFFSET_X, float(ground_y) - PET_H, speed=PET_MOVE_SPEED)
        return

    # chọn mục tiêu
    target = _choose_target(det, candidates, player_world_x, map_offset_x)

    if target is None:
        return

    # mode BẢO VỆ: target phải gần nhân vật
    if det.mode == MODE_BAO_VE:
        t_world_x = _target_world_x(target, map_offset_x)
        if t_world_x is None:
            return
        if abs(t_world_x - float(player_world_x)) > PROTECT_RADIUS:
            # mục tiêu không gần -> đứng cạnh người
            _move_towards(det, float(player_world_x) + FOLLOW_OFFSET_X, float(ground_y) - PET_H, speed=PET_MOVE_SPEED)
            _regen_if_idle(det, current_time, is_idle=True)
            return
        # leash: đệ không được chạy xa người quá
        if abs(det.x - float(player_world_x)) > PROTECT_LEASH:
            _move_towards(det, float(player_world_x) + FOLLOW_OFFSET_X, float(ground_y) - PET_H, speed=PET_MOVE_SPEED)
            _regen_if_idle(det, current_time, is_idle=True)
            return

    is_idle = False

    # chạy tới mục tiêu
    t_world_x = _target_world_x(target, map_offset_x)
    if t_world_x is None:
        return

    dist = abs(float(t_world_x) - float(det.x))
    if dist > PET_STOP_DIST:
        # đi thẳng theo trục x; y giữ theo ground
        _move_towards(det, float(t_world_x), float(ground_y) - PET_H, speed=PET_MOVE_SPEED)
    else:
        # đủ gần -> đánh
        pet_try_hit_target(
            target,
            map_offset_x=map_offset_x,
            current_time=current_time,
            text_manager=text_manager,
            effect_manager=effect_manager,
            list_moc_nhan=list(moc_nhan_list) if moc_nhan_list else None,
        )


def _move_towards(det: DeTu, tx: float, ty: float, speed: float = 4.0):
    dx = float(tx) - float(det.x)
    if abs(dx) <= speed:
        det.x = float(tx)
    else:
        det.x += speed if dx > 0 else -speed
    # y kéo nhẹ về ground (đỡ rung)
    det.y = det.y + (float(ty) - det.y) * 0.35


def _is_valid_mob(m) -> bool:
    if m is None:
        return False
    if hasattr(m, "is_dead") and getattr(m, "is_dead"):
        return False
    if hasattr(m, "hp") and int(getattr(m, "hp", 1)) <= 0:
        return False
    if not hasattr(m, "rect"):
        return False
    return True


def _looks_like_boss(m) -> bool:
    # loại trừ boss theo flag phổ biến
    if hasattr(m, "is_boss") and bool(getattr(m, "is_boss")):
        return True
    # loại trừ theo name/class (an toàn)
    n = ""
    try:
        n = str(getattr(m, "name", "")) + " " + m.__class__.__name__
    except Exception:
        n = ""
    n = n.lower()
    if "broly" in n or "boss" in n:
        return True
    return False


def _target_world_x(target, map_offset_x: float) -> Optional[float]:
    try:
        return float(target.rect.centerx + map_offset_x)
    except Exception:
        return None


def _choose_target(det: DeTu, candidates: List, player_world_x: float, map_offset_x: float):
    # Ưu tiên gần nhất theo mode
    if det.mode == MODE_TAN_CONG:
        # gần đệ nhất (để chạy khắp map)
        best = None
        best_d = 1e18
        for t in candidates:
            wx = _target_world_x(t, map_offset_x)
            if wx is None:
                continue
            d = abs(wx - det.x)
            if d < best_d:
                best_d = d
                best = t
        return best
    # BẢO VỆ: ưu tiên gần người nhất trong radius
    best = None
    best_d = 1e18
    for t in candidates:
        wx = _target_world_x(t, map_offset_x)
        if wx is None:
            continue
        d = abs(wx - float(player_world_x))
        if d < best_d:
            best_d = d
            best = t
    return best





# -------------------- DAMAGE + TNSM LIKE PLAYER --------------------
def _calculate_like_player(base_sd: int, crit_stat: int) -> Tuple[int, bool]:
    base_dame = int(base_sd) * 3
    rand_percent = random.uniform(0, 100)
    damage_multiplier = 1.00
    is_crit = False

    if random.uniform(0, 100) < (30 + int(crit_stat)):
        is_crit = True

    if rand_percent <= 0.1:
        damage_multiplier = 1.60
    elif rand_percent <= 0.5:
        damage_multiplier = 1.50
    elif rand_percent <= 1:
        damage_multiplier = 1.40
    elif rand_percent <= 5:
        damage_multiplier = 1.30
    elif rand_percent <= 10:
        damage_multiplier = 1.30
    elif rand_percent <= 20:
        damage_multiplier = 1.20
    elif rand_percent <= 50:
        damage_multiplier = 1.20
    elif rand_percent <= 80:
        damage_multiplier = 1.10

    final_damage = math.ceil(base_dame * damage_multiplier)
    return (final_damage * 2, True) if is_crit else (final_damage, False)


def calc_det_damage(det: DeTu) -> Tuple[int, bool]:
    if _damage_calc_func:
        try:
            dmg, is_crit = _damage_calc_func(int(det.suc_danh), int(det.chi_mang))
            return max(0, int(dmg)), bool(is_crit)
        except Exception:
            pass
    return _calculate_like_player(int(det.suc_danh), int(det.chi_mang))


def apply_tnsm_like_player(det: DeTu, real_hp_lost: int) -> int:
    real_hp_lost = max(0, int(real_hp_lost))
    bonus_multiplier = 2 if random.randint(1, 100) <= 30 else 1
    tnsm = int(real_hp_lost * bonus_multiplier)
    det.suc_manh += tnsm
    det.tiem_nang += tnsm
    return tnsm


def pet_try_hit_target(
    target,
    map_offset_x: float,
    current_time: int,
    text_manager=None,
    effect_manager=None,
    color_crit=(255, 255, 0),
    color_norm=(255, 0, 0),
    color_tnsm=(0, 255, 0),
    list_moc_nhan: Optional[List] = None,
) -> bool:
    det = get_det()
    if det is None:
        return False

    # mode check
    if det.mode in (MODE_VE_NHA, MODE_THEO):
        return False

    if current_time - int(det.last_attack_tick) < ATTACK_COOLDOWN_MS:
        return False

    det_rect = get_rect(map_offset_x)
    if det_rect is None or not hasattr(target, "rect"):
        return False

    atk = det_rect.inflate(ATTACK_RANGE, 30)

    try:
        if not target.rect.inflate(30, 30).colliderect(atk):
            return False
    except Exception:
        return False

    det.last_attack_tick = int(current_time)

    calc_dmg, is_crit = calc_det_damage(det)
    calc_dmg = max(1, int(calc_dmg))

    is_mn = False
    if list_moc_nhan is not None:
        try:
            is_mn = (target in list_moc_nhan)
        except Exception:
            is_mn = False

    if is_mn:
        dmg = calc_dmg
        tnsm = 1
        try:
            target.take_damage(dmg)
            if hasattr(target, "level"):
                target.level = 1
        except Exception:
            return False
    else:
        try:
            hp_truoc = int(getattr(target, "hp", 0))
        except Exception:
            hp_truoc = 0

        try:
            target.take_damage(calc_dmg)
        except Exception:
            return False

        real_hp_lost = max(0, min(int(calc_dmg), int(hp_truoc)))
        dmg = int(calc_dmg)
        tnsm = apply_tnsm_like_player(det, real_hp_lost)

        if hasattr(target, "last_hit_time"):
            try:
                target.last_hit_time = current_time
            except Exception:
                pass

    # effect/text
    try:
        if effect_manager is not None and hasattr(effect_manager, "add_slash"):
            effect_manager.add_slash(target.rect.x + map_offset_x, target.rect.y, target.rect.width, target.rect.height)
    except Exception:
        pass

    try:
        if text_manager is not None and hasattr(text_manager, "add"):
            d_col = color_crit if is_crit else color_norm
            text_manager.add(target.rect.centerx + map_offset_x, target.rect.y - 20, f"{'!' if is_crit else '-'}{dmg}", d_col)
            text_manager.add(det.x + 15, det.y - 25, f"+{tnsm}", color_tnsm)
    except Exception:
        pass

    det.dmg_min = det.suc_danh
    det.dmg_max = det.suc_danh

    if ENABLE_SAVE:
        _save()
    return True


# -------------------- DRAW --------------------
def draw_det(screen: pygame.Surface, map_offset_x: float = 0.0):
    det = get_det()
    if det is None:
        return
    if det.mode == MODE_VE_NHA:
        return

    x = int(det.x - map_offset_x)
    y = int(det.y)
    bob = int((pygame.time.get_ticks() // 240) % 2)

    if det.planet == "Trai Dat":
        skin = (255, 224, 189); suit = (30, 90, 200); hair = (30, 30, 30)
    elif det.planet == "Xayda":
        skin = (245, 205, 170); suit = (80, 80, 90); hair = (40, 40, 40)
    else:
        skin = (120, 220, 120); suit = (140, 60, 170); hair = (0, 0, 0)

    outline = (20, 20, 20)

    pygame.draw.ellipse(screen, (0, 0, 0, 45), (x + 2, y + PET_H - 6, PET_W - 4, 10))

    body = pygame.Rect(x + 6, y + 18 + bob, PET_W - 12, PET_H - 20)
    pygame.draw.rect(screen, suit, body, border_radius=8)
    pygame.draw.rect(screen, outline, body, 2, border_radius=8)

    head_center = (x + PET_W // 2, y + 12 + bob)
    pygame.draw.circle(screen, skin, head_center, 10)
    pygame.draw.circle(screen, outline, head_center, 10, 2)

    if det.planet == "Namec":
        pygame.draw.line(screen, outline, (head_center[0] - 4, head_center[1] - 10), (head_center[0] - 8, head_center[1] - 18), 2)
        pygame.draw.line(screen, outline, (head_center[0] + 4, head_center[1] - 10), (head_center[0] + 8, head_center[1] - 18), 2)
        pygame.draw.circle(screen, skin, (head_center[0] - 8, head_center[1] - 18), 3)
        pygame.draw.circle(screen, skin, (head_center[0] + 8, head_center[1] - 18), 3)
        pygame.draw.circle(screen, outline, (head_center[0] - 8, head_center[1] - 18), 3, 1)
        pygame.draw.circle(screen, outline, (head_center[0] + 8, head_center[1] - 18), 3, 1)
    else:
        pygame.draw.circle(screen, hair, (head_center[0], head_center[1] - 6), 7)
        pygame.draw.circle(screen, outline, (head_center[0], head_center[1] - 6), 7, 2)

    pygame.draw.circle(screen, (255, 255, 255), (head_center[0] - 4, head_center[1] - 1), 2)
    pygame.draw.circle(screen, (255, 255, 255), (head_center[0] + 4, head_center[1] - 1), 2)
    pygame.draw.circle(screen, (0, 0, 0), (head_center[0] - 4, head_center[1]), 1)
    pygame.draw.circle(screen, (0, 0, 0), (head_center[0] + 4, head_center[1]), 1)

    # HP BAR trên đầu đệ
    bar_w = 46
    bar_h = 7
    bar_x = x + (PET_W - bar_w) // 2
    bar_y = y - 14
    pygame.draw.rect(screen, (20, 20, 20), (bar_x, bar_y, bar_w, bar_h), border_radius=4)
    ratio = 0.0 if det.hp_max <= 0 else max(0.0, min(1.0, det.hp / det.hp_max))
    fill_w = int((bar_w - 2) * ratio)
    pygame.draw.rect(screen, (200, 60, 60), (bar_x + 1, bar_y + 1, fill_w, bar_h - 2), border_radius=4)
    pygame.draw.rect(screen, (230, 230, 230), (bar_x, bar_y, bar_w, bar_h), 1, border_radius=4)

    # tag "ĐỆ"
    _ensure_head_font()
    tag = _font_small.render("ĐỆ", True, (255, 255, 255))
    pad = 6
    tag_rect = pygame.Rect(x + (PET_W - tag.get_width()) // 2 - pad, y - 28, tag.get_width() + pad * 2, 14)
    pygame.draw.rect(screen, (200, 60, 60), tag_rect, border_radius=6)
    pygame.draw.rect(screen, outline, tag_rect, 2, border_radius=6)
    screen.blit(tag, (tag_rect.x + pad, tag_rect.y + 1))


def _ensure_head_font():
    global _font_head, _font_small
    if _font_head and _font_small:
        return
    try:
        _font_head = pygame.font.SysFont("Arial", 18, bold=True)
        _font_small = pygame.font.SysFont("Arial", 16)
    except Exception:
        _font_head = pygame.font.Font(None, 24)
        _font_small = pygame.font.Font(None, 20)


def draw_hud_tag(screen: pygame.Surface):
    det = get_det()
    if det is None:
        return
    _ensure_head_font()
    txt = _font_head.render(det.label, True, (255, 255, 255))
    pad = 8
    x, y = HUD_TAG_POS
    bg = pygame.Rect(x, y, txt.get_width() + pad * 2, txt.get_height() + 6)
    pygame.draw.rect(screen, (0, 0, 0), bg, border_radius=10)
    pygame.draw.rect(screen, (220, 220, 220), bg, 2, border_radius=10)
    screen.blit(txt, (x + pad, y + 3))


def draw_tab(screen: pygame.Surface):
    global _tab_open
    if not _tab_open:
        return

    det = get_det()
    _ensure_head_font()

    sw, sh = screen.get_width(), screen.get_height()
    w = int(sw * 0.58)
    h = int(sh * 0.52)
    x = (sw - w) // 2
    y = int(sh * 0.18)
    panel = pygame.Rect(x, y, w, h)

    overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 120))
    screen.blit(overlay, (0, 0))

    pygame.draw.rect(screen, (245, 245, 245), panel, border_radius=18)
    pygame.draw.rect(screen, (30, 30, 30), panel, 4, border_radius=18)

    title = _font_head.render("ĐỆ TỬ", True, (200, 30, 30))
    screen.blit(title, (panel.centerx - title.get_width() // 2, panel.y + 14))

    if det is None:
        msg = _font_small.render("Chưa có đệ tử", True, (40, 40, 40))
        screen.blit(msg, (panel.centerx - msg.get_width() // 2, panel.centery))
        return

    sd_min = int(getattr(det, "dmg_min", det.suc_danh))
    sd_max = int(getattr(det, "dmg_max", det.suc_danh))
    sd_txt = str(sd_min) if sd_min == sd_max else f"{sd_min}-{sd_max}"

    yy = panel.y + 58
    lines = [
        f"Đệ tử: {det.planet}",
        f"Trạng thái: {MODE_LABELS.get(det.mode, 'Đi theo')}",
        f"HP: {det.hp}/{det.hp_max}",
        f"KI: {det.ki}/{det.ki_max}",
        f"SĐ: {sd_txt}",
        f"Sức mạnh: {det.suc_manh}",
        f"Tiềm năng: {det.tiem_nang}",
    ]
    for s in lines:
        t = _font_small.render(s, True, (20, 20, 20))
        screen.blit(t, (panel.x + 24, yy))
        yy += t.get_height() + 10

    hint = _font_small.render(f"Nhấn {pygame.key.name(TOGGLE_TAB_KEY).upper()} để đóng", True, (70, 70, 70))
    screen.blit(hint, (panel.x + 24, panel.bottom - 30))


# -------------------- AWARD LOGIC --------------------
def award_random_det(
    player_rect: pygame.Rect,
    player_world_x: Optional[float] = None,
    ground_y: Optional[int] = None,
    current_time: Optional[int] = None,
) -> Optional[DeTu]:
    global _det, _last_award_tick

    if current_time is None:
        current_time = pygame.time.get_ticks()

    if current_time - _last_award_tick < 1500:
        return None
    _last_award_tick = int(current_time)

    if has_det():
        return None

    planet = random.choice(PLANETS)

    hp_max = random.randint(HP_MIN, HP_MAX)
    ki_max = random.randint(KI_MIN, KI_MAX)
    suc_danh = random.randint(SD_MIN, SD_MAX)

    suc_manh = random.randint(SM_MIN, SM_MAX)
    tiem_nang = random.randint(TN_MIN, TN_MAX)

    if player_world_x is None:
        player_world_x = float(player_rect.centerx)
    if ground_y is None:
        ground_y = int(player_rect.bottom)

    x = float(player_world_x) + 30
    y = float(ground_y) - PET_H

    _det = DeTu(
        planet=planet,
        hp_max=hp_max,
        ki_max=ki_max,
        suc_danh=suc_danh,
        chi_mang=0,
        dmg_min=suc_danh,
        dmg_max=suc_danh,
        suc_manh=suc_manh,
        tiem_nang=tiem_nang,
        hp=hp_max,
        ki=ki_max,
        x=x,
        y=y,
        mode=MODE_THEO,
    )

    if ENABLE_SAVE:
        _save()
    return _det


def on_superbroly_defeated(
    player_rect: pygame.Rect,
    player_world_x: Optional[float] = None,
    ground_y: Optional[int] = None,
    current_time: Optional[int] = None,
) -> Optional[DeTu]:
    return award_random_det(player_rect, player_world_x, ground_y, current_time)


# -------------------- SAVE/LOAD --------------------


def trigger_save():
    """Public save hook for UI modules (tuido)."""
    try:
        if ENABLE_SAVE:
            _save()
    except Exception:
        pass


def _save():
    if not ENABLE_SAVE:
        return
    data = {"version": VERSION, "owner": _CURRENT_OWNER, "det": (_det.to_dict() if _det else None)}
    try:
        # ensure save dir exists
        try:
            d = os.path.dirname(SAVE_FILE)
            if d:
                os.makedirs(d, exist_ok=True)
        except Exception:
            pass
        with open(SAVE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def load():
    global _det
    if not ENABLE_SAVE:
        return
    if not os.path.exists(SAVE_FILE):
        return
    try:
        with open(SAVE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        try:
            if data.get("owner") is not None and _CURRENT_OWNER is not None:
                if tuple(data.get("owner")) != tuple(_CURRENT_OWNER):
                    # file belongs to other owner -> không load
                    return
        except Exception:
            pass
        if data.get("det"):
            _det = DeTu.from_dict(data["det"])
    except Exception:
        _det = None
