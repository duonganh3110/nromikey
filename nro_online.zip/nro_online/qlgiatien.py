# File: qlgiatien.py (ANXIN VIP-ONLY: chỉ sync từ itemvip.py)

import json
import os
import pygame
from collections import defaultdict
import sys
import re

# Thêm path để import item_manager
try:
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.join(current_dir, '..')
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)
    try:
        from item_manager import ITEM_TEMPLATES
    except ImportError:
        ITEM_TEMPLATES = {}
except Exception:
    ITEM_TEMPLATES = {}

THU_MUC_GAME = os.path.dirname(os.path.abspath(__file__))
PRICE_DATA_FILE = os.path.join(THU_MUC_GAME, "du_lieu_gia_tien.json")

# Giá cơ bản cho shop thường
DEFAULT_BASE_PRICES = {
    "Vu Khi": {"price": 100, "currency": "VANG"},
    "Giap": {"price": 250, "currency": "VANG"},
    "Tieu Hao": {"price": 50, "currency": "VANG"},
}

PRICE_DATA = {}

# --- JSON UTILS ---
def load_json(filename):
    if not os.path.exists(filename):
        return {}
    try:
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_json(filename, data):
    try:
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
    except Exception:
        pass

def save_price_data():
    save_json(PRICE_DATA_FILE, PRICE_DATA)

# --- INTERNAL HELPERS ---
def _ensure_shop_key(shop_key: str):
    global PRICE_DATA
    if shop_key not in PRICE_DATA or not isinstance(PRICE_DATA.get(shop_key), dict):
        PRICE_DATA[shop_key] = {}

def _setdefault_shop_item(shop_key: str, item_key: str, price_data: dict):
    _ensure_shop_key(shop_key)
    if item_key not in PRICE_DATA[shop_key]:
        PRICE_DATA[shop_key][item_key] = dict(price_data)

def _sync_anxin_from_itemvip(purge_non_vip: bool = True):
    """
    ANXIN chỉ sync từ itemvip.py:
    - purge_non_vip=True: xoá mọi item không thuộc VIP khỏi PRICE_DATA['ANXIN']
    - chỉ ADD item mới (nếu chưa có) -> không đè giá Mikey đã chỉnh
    """
    _ensure_shop_key("ANXIN")

    vip_templates = {}
    vip_keys = []

    try:
        import itemvip
        # itemvip có thể cung cấp ITEM_VIP_TEMPLATES
        if hasattr(itemvip, "ITEM_VIP_TEMPLATES") and isinstance(itemvip.ITEM_VIP_TEMPLATES, dict):
            vip_templates = itemvip.ITEM_VIP_TEMPLATES
            vip_keys = list(vip_templates.keys())
        # hoặc có thể có hàm register_into(ITEM_TEMPLATES)
        if hasattr(itemvip, "register_into"):
            try:
                itemvip.register_into(ITEM_TEMPLATES)
            except Exception:
                pass
    except Exception:
        vip_templates = {}
        vip_keys = []

    # Nếu muốn purge thì xoá hết item cũ không thuộc vip
    if purge_non_vip:
        for k in list(PRICE_DATA["ANXIN"].keys()):
            if k not in vip_keys:
                del PRICE_DATA["ANXIN"][k]

    # Add item vip mới (chỉ setdefault)
    for item_key, tmpl in vip_templates.items():
        shops = tmpl.get("shops", {}) if isinstance(tmpl, dict) else {}
        anx = shops.get("ANXIN", {}) if isinstance(shops, dict) else {}

        price = anx.get("price", 50)
        currency = anx.get("currency", "KIM_CUONG")

        _setdefault_shop_item("ANXIN", item_key, {"price": int(price), "currency": currency})

# --- LOAD LOGIC ---
def load_price_data():
    global PRICE_DATA

    saved_data = load_json(PRICE_DATA_FILE)

    tmp = defaultdict(dict)
    if isinstance(saved_data, dict):
        for shop_key, data in saved_data.items():
            if isinstance(data, dict):
                tmp[shop_key] = data

    PRICE_DATA = dict(tmp)

    # đảm bảo có đủ shop key
    for shop_key in ["BANDO", "NAMEC", "XAYDA", "ANXIN"]:
        _ensure_shop_key(shop_key)

    # Auto add item cho shop thường (BANDO/NAMEC/XAYDA)
    for item_key, item_data in (ITEM_TEMPLATES or {}).items():
        item_type = item_data.get("type")
        base_price_data = DEFAULT_BASE_PRICES.get(item_type)
        if base_price_data:
            for shop_key in ["BANDO", "NAMEC", "XAYDA"]:
                _setdefault_shop_item(shop_key, item_key, base_price_data)

    # ANXIN: chỉ lấy từ itemvip.py (và purge áo + potion cũ)
    _sync_anxin_from_itemvip(purge_non_vip=True)

    save_price_data()

def get_item_price(shop_key, item_key):
    if shop_key in PRICE_DATA and item_key in PRICE_DATA[shop_key]:
        data = PRICE_DATA[shop_key][item_key]
        return data.get("price"), data.get("currency")
    return None, None

# --- UI HELPER ---
def ve_nut_custom(screen, rect, mau, text, text_color=(0, 0, 0), font_obj=None):
    try:
        font_small = pygame.font.SysFont("Arial", 16)
    except Exception:
        font_small = pygame.font.SysFont(None, 16)

    pygame.draw.rect(screen, mau, rect, border_radius=3)
    font_use = font_obj if font_obj else font_small
    t_surf = font_use.render(text, True, text_color)
    screen.blit(t_surf, (rect.centerx - t_surf.get_width() // 2, rect.centery - t_surf.get_height() // 2))

def draw_giatien_tab(screen, current_price_tab, ITEM_TEMPLATES, font_small, font_tiny,
                    selected_price_item_key, msg_price, msg_color_price, InputBox):
    tab_labels = {"BANDO": "BUMMA", "NAMEC": "NAMEC", "XAYDA": "XAYDA", "ANXIN": "AN XIN"}
    start_x = 170
    y_tab = 80
    price_tab_rects = {}

    for key, label in tab_labels.items():
        rect = pygame.Rect(start_x, y_tab, 100, 30)
        color = (0, 100, 255) if current_price_tab == key else (150, 150, 150)
        ve_nut_custom(screen, rect, color, label, (255, 255, 255), font_small)
        price_tab_rects[key] = rect
        start_x += 110

    list_rect = pygame.Rect(170, 120, 600, 350)
    pygame.draw.rect(screen, (40, 40, 40), list_rect)
    pygame.draw.rect(screen, (100, 100, 100), list_rect, 2)

    items_on_sale = PRICE_DATA.get(current_price_tab, {})
    price_item_rects = {}
    y_item = 130
    x_item = 180

    if not items_on_sale:
        screen.blit(font_small.render("Shop trong.", True, (200, 200, 200)), (x_item, y_item))

    for item_key, price_data in items_on_sale.items():
        item_template = ITEM_TEMPLATES.get(item_key, {})
        name = item_template.get("name", item_key)
        item_id = item_template.get("item_id", "?")

        display_text = f"ID:{item_id} - {name} | Gia: {price_data.get('price', 0):,} {price_data.get('currency', 'VANG')}"
        color_text = (255, 215, 0) if item_key == selected_price_item_key else (255, 255, 255)

        item_rect = pygame.Rect(x_item, y_item, 580, 25)
        if item_key == selected_price_item_key:
            pygame.draw.rect(screen, (60, 60, 100), item_rect)

        screen.blit(font_small.render(display_text, True, color_text), (x_item + 5, y_item + 2))
        price_item_rects[item_key] = item_rect
        y_item += 30

    if msg_price:
        screen.blit(font_small.render(msg_price, True, msg_color_price), (170, 480))

    screen.blit(font_tiny.render("Nhap: [Gia] [Loai]. VD: 100 VANG, 100 KC, 100 VND", True, (200, 200, 200)), (170, 520))

    return price_tab_rects, items_on_sale, price_item_rects

def handle_giatien_event(event, current_price_tab, key_input_box_price, ITEM_TEMPLATES,
                        RED_ERROR, GREEN_SUCCESS, selected_price_item_key, btn_confirm_rect_price):
    if not selected_price_item_key:
        return "Chua chon vat pham!", RED_ERROR, None

    text = key_input_box_price.text.strip().upper()
    match = re.match(r"^(\d+)\s*([A-Z_]+)$", text)
    if not match:
        return "Sai cu phap! VD: 100 VANG", RED_ERROR, None

    price = int(match.group(1))
    currency_code = match.group(2)

    valid_currencies = {
        "VANG": "VANG", "V": "VANG",
        "KIM_CUONG": "KIM_CUONG", "KC": "KIM_CUONG", "NGOC": "KIM_CUONG",
        "VND": "VND"
    }

    if currency_code not in valid_currencies:
        return "Loai tien: VANG, KC, VND", RED_ERROR, None

    final_currency = valid_currencies[currency_code]

    if current_price_tab not in PRICE_DATA:
        PRICE_DATA[current_price_tab] = {}

    PRICE_DATA[current_price_tab][selected_price_item_key] = {"price": price, "currency": final_currency}
    save_price_data()

    return f"Da cap nhat: {price} {final_currency}!", GREEN_SUCCESS, selected_price_item_key
