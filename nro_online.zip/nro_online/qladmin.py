import __main__ as _main
import pygame
import sys
import json
import re

def admin_panel(screen):
    # kéo toàn bộ globals từ main.py sang để khỏi thiếu biến/module
    globals().update(_main.__dict__)
    running = True; current_tab = "ACCOUNTS"; current_sub_tab = "VU_KHI" 
    mk_user_input = InputBox(350, 70, 150, 30, text=""); admin_mk_new_input = InputBox(520, 550, 150, 30, text="", is_password=True); btn_change_admin_mk = pygame.Rect(680, 550, 110, 30)
    key_input_box_vp = InputBox(170, 500, 450, 30, text=""); msg_vp = ""; msg_color_vp = WHITE; btn_confirm_rect_vp = pygame.Rect(0,0,0,0)
    key_input_box_price = InputBox(200, 540, 200, 30, text=""); msg_price = ""; msg_color_price = WHITE; btn_confirm_rect_price = pygame.Rect(0,0,0,0)
    popup_item_key = None; popup_close_rect = None
    
    price_tab = "BANDO"; selected_price_item_key = None; selected_stats_item_key = None 
    sidebar_scroll_y = 0; SIDEBAR_AREA = pygame.Rect(0, 50, 150, 500); TAB_HEIGHT = 35; TAB_MARGIN = 5  
    ADMIN_TABS = [
        {"id": "ACCOUNTS", "label": "QL TAI KHOAN", "color_active": BLUE_UI},
        {"id": "ITEMS", "label": "QL VAT PHAM", "color_active": BLUE_UI},
        {"id": "BUFF", "label": "BUFF TIEN TE", "color_active": (0, 150, 0)},
        {"id": "PRICE", "label": "QL GIA TIEN", "color_active": (255, 140, 0)},
        {"id": "SUC_MANH", "label": "SUC MANH", "color_active": (200, 0, 200)} # <--- THÊM DÒNG NÀY
    ]
    # --- [FIX] KHỞI TẠO BUFF MANAGER ---
    # Cố gắng khởi tạo từ module bufftiente, nếu lỗi thì dùng class giả để không crash
    try:
        # Import class InputBox để truyền vào cho bufftiente dùng
        # Lưu ý: InputBox phải là class toàn cục đã khai báo ở đầu file main.py
        buff_manager = bufftiente.BuffManager(DATA_CHAR_FILE, font, font_small, InputBox)
        print("[SYSTEM] Da khoi tao BuffManager thanh cong.")
    except Exception as e:
        print(f"[SYSTEM] Warning: Khong the khoi tao BuffManager ({e}). Kiem tra file bufftiente.py.")
    try:
        # InputBox được truyền vào là class InputBox đã có trong main.py
        sm_manager = buffsucmanh.BuffSucManhManager(DATA_CHAR_FILE, font, font_small, InputBox)
    except Exception as e:
        print(f"Lỗi khởi tạo Buff SM: {e}")
        class DummySM: 
            def draw(self, s): pass
            def handle_event(self, e): pass
        sm_manager = DummySM()
        
        # Class giả lập (Dummy) phòng trường hợp vẫn lỗi để không crash game
        class DummyBuff:
            def __init__(self): self.btn_rect = pygame.Rect(0,0,0,0)
            def draw(self, s): 
                ts = font_small.render(f"Loi module Buff: {e}", True, RED_ERROR)
                s.blit(ts, (200, 100))
            def handle_event(self, e): pass
            def reload_data(self): pass
        buff_manager = DummyBuff()
    # -----------------------------------

    def parse_stats_shorthand(shorthand_text):
        stats = {}; shorthand_text = shorthand_text.strip()
        if shorthand_text.startswith('{'):
             import json
             try: return json.loads(shorthand_text)
             except json.JSONDecodeError as e: raise ValueError(f"Lỗi JSON: {e}")
        tokens = shorthand_text.upper().replace('%', '').split()
        MAPPINGS = [(r'^SD(\d+)$', 'suc_danh'), (r'^SDP(\d+)$', 'suc_danh_percent'), (r'^GIA(\d+)$', 'giap'), (r'^CM(\d+)$', 'chi_mang'), (r'^NE(\d+)$', 'ne_tranh'), (r'^NN(\d+)$', 'nhanh_nhen'), (r'^HP(\d+)$', 'max_hp'), (r'^KI(\d+)$', 'max_ki'), (r'^HM(\d+)$', 'hoi_mau'), (r'^HK(\d+)$', 'hoi_ki')]
        for token in tokens:
            found = False; 
            if not token: continue
            for regex, key_name in MAPPINGS:
                match = re.fullmatch(regex, token); 
                if match: stats[key_name] = int(match.group(1)); found = True; break
            if not found: raise ValueError(f"Token '{token}' không hợp lệ.")
        if not stats: raise ValueError("Chưa nhập chỉ số.")
        return stats
    
    def reset_user_to_creation_state(user):
        data_char = load_json(DATA_CHAR_FILE)
        if user in data_char: del data_char[user]; save_json(DATA_CHAR_FILE, data_char); return True
        return False
    def delete_all_users():
        data_acc = load_json(DATA_ACC_FILE); data_char = load_json(DATA_CHAR_FILE); users_to_keep = ["admin"]
        new_data_acc = {k: v for k, v in data_acc.items() if k in users_to_keep}; save_json(DATA_ACC_FILE, new_data_acc)
        new_data_char = {k: v for k, v in data_char.items() if k in users_to_keep}; save_json(DATA_CHAR_FILE, new_data_char)
    def reset_all_characters():
        data_char = load_json(DATA_CHAR_FILE); users_to_keep = ["admin"]
        new_data_char = {k: v for k, v in data_char.items() if k in users_to_keep}; save_json(DATA_CHAR_FILE, new_data_char)
    def ban_unban_user(user, ban_status):
        data_acc = load_json(DATA_ACC_FILE)
        if user in data_acc:
            if not isinstance(data_acc[user], dict): data_acc[user] = {"password": data_acc[user], "is_banned": False}
            data_acc[user]["is_banned"] = ban_status; save_json(DATA_ACC_FILE, data_acc)
    def change_admin_password(new_password):
        data_acc = load_json(DATA_ACC_FILE)
        if "admin" in data_acc:
             if isinstance(data_acc["admin"], dict): data_acc["admin"]["password"] = new_password
             else: data_acc["admin"] = new_password 
             save_json(DATA_ACC_FILE, data_acc)
    
    while running:
        item_click_rects = {}; btn_sub_rects = {}; price_tab_rects = {}; price_item_rects = {}
        btn_reset_all = None; btn_delete_all = None; list_actions = []
        
        # --- BẮT ĐẦU VẼ ADMIN PANEL ---
        if GLOBAL_BG_IMAGE: screen.blit(GLOBAL_BG_IMAGE, (0, 0)); 
        else: screen.fill(BLACK)

        dark = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT)); dark.set_alpha(180); dark.fill(BLACK); 
        screen.blit(dark, (0,0)); # <--- Đảm bảo phủ nền mờ lên trên

        pygame.draw.rect(screen, DARK_GRAY, (0, 0, 150, SCREEN_HEIGHT)); # Sidebar nền cứng
        
        original_clip = screen.get_clip(); screen.set_clip(SIDEBAR_AREA); 
        tab_rects_map = {}; start_y = SIDEBAR_AREA.y - sidebar_scroll_y
        for tab in ADMIN_TABS:
            rect = pygame.Rect(10, start_y, 130, TAB_HEIGHT); is_active = (current_tab == tab["id"]); col = tab["color_active"] if is_active else GRAY; text_color = BLACK; 
            if is_active and tab["id"] != "PRICE": text_color = WHITE
            ve_nut_custom(screen, rect, col, tab["label"], text_color, font_small); tab_rects_map[tab["id"]] = rect; start_y += TAB_HEIGHT + TAB_MARGIN
        screen.set_clip(original_clip) 
        btn_logout = pygame.Rect(10, 550, 130, 40); ve_nut_custom(screen, btn_logout, RED_ERROR, "DANG XUAT", WHITE); title = font_big.render("ADMIN PANEL", True, RED_TITLE); screen.blit(title, (300, 10))
        
        if current_tab == "ACCOUNTS":
             lbl_mk_admin = font_small.render("DOI MK ADMIN:", True, WHITE); screen.blit(lbl_mk_admin, (400, 525)); admin_mk_new_input.rect.x = 520; admin_mk_new_input.rect.y = 520; btn_change_admin_mk.x = 680; btn_change_admin_mk.y = 520; admin_mk_new_input.draw(screen); ve_nut_custom(screen, btn_change_admin_mk, C_VANG, "Doi MK", BLACK)
             lbl_hd = font_small.render("Nhap MK Moi/Ly do ban:", True, WHITE); screen.blit(lbl_hd, (160, 75)); mk_user_input.draw(screen); y_start = 120; pygame.draw.line(screen, WHITE, (160, y_start), (790, y_start), 1); headers = ["Tai khoan", "Trang Thai", "Ten NV", "Hanh Tinh", "Chuc Nang"]; xs = [170, 280, 380, 480, 600]
             for idx, h in enumerate(headers): screen.blit(font_small.render(h, True, C_VANG), (xs[idx], y_start - 20))
             data_acc = load_json(DATA_ACC_FILE); data_char = load_json(DATA_CHAR_FILE); list_users = list(data_acc.keys()); index_row = 0
             for u in list_users:
                 if u == "admin": continue
                 if index_row > 10: break 
                 row_y = y_start + 10 + (index_row * 40); acc_info = data_acc.get(u); is_banned = False
                 if not isinstance(acc_info, dict): acc_info = {"password": acc_info, "is_banned": False}
                 is_banned = acc_info.get("is_banned", False); status_color = C_BANNED if is_banned else C_UNBANNED; status_text = "BANNED" if is_banned else "ACTIVE"; char_name = "Chua tao"; char_phai = "---"
                 char_entries = data_char.get(u, {}); char_data = None
                 if char_entries and isinstance(char_entries, dict): first_char_name = next(iter(char_entries.keys()), "Loi"); char_data = char_entries.get(first_char_name); 
                 if isinstance(char_data, dict): char_name = char_data.get("ten", "Loi"); char_phai = char_data.get("phai", "Loi");
                 screen.blit(font_small.render(str(u), True, WHITE), (170, row_y)); screen.blit(font_small.render(status_text, True, status_color), (280, row_y)); screen.blit(font_small.render(char_name, True, (100, 200, 50)), (380, row_y)); screen.blit(font_small.render(char_phai, True, WHITE), (480, row_y)); btn_reset_user = pygame.Rect(590, row_y, 70, 25); btn_edit = pygame.Rect(670, row_y, 70, 25); btn_ban = pygame.Rect(750, row_y, 40, 25); ve_nut_custom(screen, btn_reset_user, C_BTN_RESET, "RESET"); ve_nut_custom(screen, btn_edit, (255, 140, 0), "DOI MK"); ve_nut_custom(screen, btn_ban, C_BANNED if not is_banned else C_UNBANNED, "BAN" if not is_banned else "UNBAN", WHITE); list_actions.append({"type": "reset", "rect": btn_reset_user, "user": u}); list_actions.append({"type": "edit", "rect": btn_edit, "user": u}); list_actions.append({"type": "ban_unban", "rect": btn_ban, "user": u, "status": is_banned}); index_row += 1
             btn_reset_all = pygame.Rect(160, 480, 150, 40); btn_delete_all = pygame.Rect(320, 480, 150, 40); ve_nut_custom(screen, btn_reset_all, C_BTN_RESET, "RESET ALL NV", BLACK); ve_nut_custom(screen, btn_delete_all, C_BTN_DEL, "XOA ALL TK", WHITE)
        elif current_tab == "ITEMS":
             title_text = "QL VẬT PHẨM VÀ CHỈ SỐ"; lbl_item_title = font.render(title_text, True, C_VANG); screen.blit(lbl_item_title, (160, 50))
             # Tab con phân loại
             tab_keys_map = ["VU_KHI", "GIAP", "TIEU_HAO", "DAC_BIET", "LINH_TINH"]
             tab_labels = ["VU KHI", "TRANG BI", "TIEU HAO", "DAC BIET", "KHAC"]
             start_x_sub = 160
             for i, t_key in enumerate(tab_keys_map):
                 r = pygame.Rect(160 + i * 110, 80, 100, 30); color = BLUE_UI if current_sub_tab == t_key else GRAY; label = tab_labels[i] if i < len(tab_labels) else "KHAC"
                 ve_nut_custom(screen, r, color, label, WHITE if current_sub_tab == t_key else BLACK); btn_sub_rects[t_key] = r
             
             # Khung hiển thị item
             item_display_rect = pygame.Rect(160, 120, 630, 330); pygame.draw.rect(screen, DARK_GRAY, item_display_rect, border_radius=5); pygame.draw.rect(screen, GRAY, item_display_rect, 2)
             
             # Lọc và SẮP XẾP vật phẩm (Sort by ID)
             filtered_keys = []
             for k, v in ITEM_TEMPLATES.items():
                 itype = v.get("type", "KHAC"); 
                 if current_sub_tab == "VU_KHI" and itype == "Vu Khi": filtered_keys.append(k)
                 elif current_sub_tab == "GIAP" and itype == "Giap": filtered_keys.append(k)
                 elif current_sub_tab == "TIEU_HAO" and itype == "Tieu Hao": filtered_keys.append(k)
                 elif current_sub_tab == "DAC_BIET" and itype == "Dac Biet": filtered_keys.append(k)
                 elif current_sub_tab == "LINH_TINH" and itype not in ["Vu Khi", "Giap", "Tieu Hao", "Dac Biet"]: filtered_keys.append(k)
                 
             # Sắp xếp danh sách key theo item_id (nếu có) hoặc tên
             filtered_keys.sort(key=lambda k: ITEM_TEMPLATES[k].get('item_id', 9999))

             slots_per_row = 12; grid_size = 40 + 5; start_x = item_display_rect.x + 10; start_y = item_display_rect.y + 10
             for i, key in enumerate(filtered_keys):
                 item_template = ITEM_TEMPLATES[key]; row = i // slots_per_row; col = i % slots_per_row; slot_rect = pygame.Rect(start_x + col * grid_size, start_y + row * grid_size, 40, 40)
                 border_col = C_HIGHLIGHT if (key == selected_stats_item_key) else item_template.get('rarity', WHITE); pygame.draw.rect(screen, (30, 30, 30), slot_rect, border_radius=3); pygame.draw.rect(screen, border_col, slot_rect, 1, border_radius=3)
                 cx, cy = slot_rect.centerx, slot_rect.centery; rarity = item_template.get('rarity', WHITE)
                 if "potion" in key: pygame.draw.circle(screen, rarity, (cx, cy + 2), 8)
                 elif "sword" in key: pygame.draw.line(screen, rarity, (cx - 8, cy + 8), (cx + 8, cy - 8), 2)
                 else: pygame.draw.circle(screen, rarity, (cx, cy), 5) 
                 item_id = item_template.get('item_id', '??'); name_surf = font_tiny.render(f"ID{item_id}", True, WHITE); screen.blit(name_surf, (slot_rect.x + 2, slot_rect.bottom - 10)); item_click_rects[key] = slot_rect 
             
             key_input_box_vp.rect.x = 170; key_input_box_vp.rect.y = 500; key_input_box_vp.update(); key_input_box_vp.draw(screen)
             btn_confirm_rect_vp = pygame.Rect(630, 500, 150, 30); ve_nut_custom(screen, btn_confirm_rect_vp, GREEN_SUCCESS, "LUU CHI SO", BLACK, font_small)
             
             sel_name = ITEM_TEMPLATES.get(selected_stats_item_key, {}).get('name', 'Chua chon') if selected_stats_item_key else 'Chua chon'; sel_id = ITEM_TEMPLATES.get(selected_stats_item_key, {}).get('item_id', '??')
             lbl_hd = font_small.render(f"Sửa ID {sel_id}: {sel_name} (VD: SD5)", True, msg_color_vp); screen.blit(lbl_hd, (170, 475))
             if msg_vp: msg_s = font_small.render(msg_vp, True, msg_color_vp); screen.blit(msg_s, (170, 535))
        
        elif current_tab == "BUFF": 
            # --- [FIX] SỬ DỤNG buff_manager ĐÃ KHỞI TẠO Ở TRÊN ---
            buff_manager.draw(screen); btn_buff_rect = buff_manager.btn_rect 

        elif current_tab == "PRICE": 
             btn_confirm_rect_price = pygame.Rect(0,0,0,0)
             price_tab_rects, items_on_sale, price_item_rects = qlgiatien.draw_giatien_tab(screen, price_tab, ITEM_TEMPLATES, font_small, font_tiny, selected_price_item_key, msg_price, msg_color_price, InputBox)
             
             Y_INPUT_FIXED = 540; key_input_box_price.rect.x = 200; key_input_box_price.rect.y = Y_INPUT_FIXED; key_input_box_price.update(); key_input_box_price.draw(screen)
             btn_confirm_rect_price = pygame.Rect(key_input_box_price.rect.right + 10, Y_INPUT_FIXED, 100, 30); ve_nut_custom(screen, btn_confirm_rect_price, GREEN_SUCCESS, "CAP NHAT", BLACK, font_small)
        elif current_tab == "SUC_MANH": # <--- THÊM ĐOẠN NÀY
             sm_manager.draw(screen)
        
        if popup_item_key: popup_close_rect = item_editor.draw_item_detail_popup(screen, popup_item_key, ITEM_TEMPLATES, SCREEN_WIDTH, SCREEN_HEIGHT, font, font_small)

        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.MOUSEWHEEL: sidebar_scroll_y -= event.y * 15; max_scroll = max(0, len(ADMIN_TABS) * (TAB_HEIGHT + TAB_MARGIN) - SIDEBAR_AREA.height); sidebar_scroll_y = max(0, min(sidebar_scroll_y, max_scroll))
            if current_tab == "SUC_MANH": sm_manager.handle_event(event)
            if current_tab == "BUFF": buff_manager.handle_event(event)
            else:
                if current_tab == "ITEMS" and 'key_input_box_vp' in locals(): key_input_box_vp.handle_event(event)
                elif current_tab == "ACCOUNTS": 
                     if 'mk_user_input' in locals(): mk_user_input.handle_event(event)
                     if 'admin_mk_new_input' in locals(): admin_mk_new_input.handle_event(event) 
                elif current_tab == "PRICE" and 'key_input_box_price' in locals(): key_input_box_price.handle_event(event) 
            
            if popup_item_key:
                if event.type == pygame.MOUSEBUTTONDOWN and popup_close_rect.collidepoint(event.pos): popup_item_key = None
                continue
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos
                if SIDEBAR_AREA.collidepoint(mx, my):
                    for t_id, rect in tab_rects_map.items():
                        if rect.collidepoint(mx, my):
                            current_tab = t_id; popup_item_key = None; selected_stats_item_key = None; selected_price_item_key = None; 
                            # --- [FIX] GỌI reload_data() AN TOÀN ---
                            if current_tab == "BUFF": buff_manager.reload_data()
                            break
                if current_tab == "ITEMS":
                    if 80 <= my <= 110:
                        for t_key, r in btn_sub_rects.items():
                            if r.collidepoint(mx, my): current_sub_tab = t_key; item_click_rects = {}; break
                    if 120 <= my <= 450:
                        for key, r in item_click_rects.items():
                            if r.collidepoint(mx, my): 
                                selected_stats_item_key = key; popup_item_key = key; stats = ITEM_TEMPLATES[key].get('stats', {}); import json; 
                                try:
                                    shorthand = ""
                                    if 'suc_danh' in stats: shorthand += f"SD{stats['suc_danh']} "
                                    key_input_box_vp.text = shorthand.strip() or json.dumps(stats)
                                except: key_input_box_vp.text = json.dumps(stats)
                                key_input_box_vp.update(); msg_vp = ""; break
                if current_tab == "PRICE":
                    for p_key, r in price_tab_rects.items():
                        if r.collidepoint(mx, my): price_tab = p_key; selected_price_item_key = None; msg_price = ""; break
                    for i_key, r in price_item_rects.items():
                        if r.collidepoint(mx, my): 
                            selected_price_item_key = i_key
                            # Lấy giá an toàn
                            p, c = qlgiatien.get_item_price(price_tab, i_key)
                            if p is not None: 
                                key_input_box_price.text = f"{p} {c}"
                                key_input_box_price.update()
                            msg_price = f"Đang chọn: {ITEM_TEMPLATES.get(i_key, {}).get('name', i_key)}"; 
                            break
                    if 'btn_confirm_rect_price' in locals() and btn_confirm_rect_price.collidepoint(mx, my):
                        msg, color, new_sel = qlgiatien.handle_giatien_event(event, price_tab, key_input_box_price, ITEM_TEMPLATES, RED_ERROR, GREEN_SUCCESS, selected_price_item_key, btn_confirm_rect_price)
                        msg_price = msg; msg_color_price = color; selected_price_item_key = new_sel if new_sel is not None else selected_price_item_key
                        if msg_color_price == GREEN_SUCCESS: key_input_box_price.text = ""; key_input_box_price.update()
                
                if current_tab == "ITEMS" and 'btn_confirm_rect_vp' in locals() and btn_confirm_rect_vp.collidepoint(mx, my):
                    if selected_stats_item_key:
                        try:
                            new_stats = parse_stats_shorthand(key_input_box_vp.text)
                            if isinstance(new_stats, dict): ITEM_TEMPLATES[selected_stats_item_key]['stats'] = new_stats; save_item_data(); msg_vp = f"Đã lưu chỉ số {selected_stats_item_key}!"; msg_color_vp = GREEN_SUCCESS; popup_item_key = None
                            else: raise ValueError("Lỗi parse.")
                        except (ValueError, json.JSONDecodeError, AttributeError) as e: msg_vp = f"Lỗi cú pháp: {e}"; msg_color_vp = RED_ERROR
                    else: msg_vp = "Chưa chọn vật phẩm!"; msg_color_vp = RED_ERROR

                if btn_logout.collidepoint(mx, my): return "LOGOUT"
                if btn_change_admin_mk.collidepoint(mx, my): 
                    admin_new_pass = admin_mk_new_input.text; 
                    if admin_new_pass: change_admin_password(admin_new_pass); print("Đã đổi MK Admin"); admin_mk_new_input.text = "" 
                
                if current_tab == "ACCOUNTS":
                    if btn_reset_all and btn_reset_all.collidepoint(mx, my): reset_all_characters()
                    elif btn_delete_all and btn_delete_all.collidepoint(mx, my): delete_all_users()
                    elif 'list_actions' in locals():
                        for action in list_actions:
                            if action["rect"].collidepoint(mx, my):
                                u_act = action["user"]
                                if action["type"] == "edit": 
                                    user_new_pass = mk_user_input.text; 
                                    if user_new_pass: data_acc_act = load_json(DATA_ACC_FILE); isinstance(data_acc_act.get(u_act), dict) and data_acc_act[u_act].update({"password": user_new_pass}) or data_acc_act.update({u_act: user_new_pass}); save_json(DATA_ACC_FILE, data_acc_act)
                                elif action["type"] == "reset": reset_user_to_creation_state(u_act)
                                elif action["type"] == "ban_unban": ban_unban_user(u_act, not action["status"]) 
                                break
        pygame.display.flip(); clock.tick(60)

# --- MENU SCREEN FUNCTION (Fixes integrated here) ---

def chay_man_hinh_tao_nv(screen, username):
    # Cấu hình Font
    font_large = pygame.font.SysFont("Arial", 24)
    font_small = pygame.font.SysFont("Arial", 16)

    # --- 1. LOAD ẢNH NỀN AN TOÀN ---
    bg_image = None
    try:
        # Tự động tìm đường dẫn file, bất kể chạy từ đâu
        base_path = os.path.dirname(os.path.abspath(__file__))
        img_path = os.path.join(base_path, "background_login.jpg")
        
        if os.path.exists(img_path):
            loaded_img = pygame.image.load(img_path)
            bg_image = pygame.transform.scale(loaded_img, (SCREEN_WIDTH, SCREEN_HEIGHT))
        else:
            print("CẢNH BÁO: Không tìm thấy file 'background_login.jpg'. Sử dụng nền đen.")
    except Exception as e:
        print(f"Lỗi load ảnh: {e}")
        bg_image = None # Dùng nền đen nếu lỗi

    # Cấu hình giao diện
    input_box = pygame.Rect(SCREEN_WIDTH // 2 - 100, 200, 200, 40)
    color_inactive = pygame.Color('lightskyblue3')
    color_active = pygame.Color('dodgerblue2')
    color = color_inactive
    active = False
    text = ''
    
    selected_planet = "Trai Dat"
    
    btn_td = pygame.Rect(SCREEN_WIDTH // 2 - 160, 300, 100, 40)
    btn_nm = pygame.Rect(SCREEN_WIDTH // 2 - 50, 300, 100, 40)
    btn_xd = pygame.Rect(SCREEN_WIDTH // 2 + 60, 300, 100, 40)
    btn_create = pygame.Rect(SCREEN_WIDTH // 2 - 60, 400, 120, 50)

    while True:
        # --- 2. VẼ NỀN ---
        if bg_image:
            screen.blit(bg_image, (0, 0))
            # Vẽ lớp đen mờ lên trên để chữ dễ đọc (Độ trong suốt 150)
            s = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            s.fill((0, 0, 0, 150))
            screen.blit(s, (0,0))
        else:
            screen.fill(BLACK) # Nền đen nếu thiếu ảnh
        
        # Tiêu đề & Hướng dẫn
        t_surf = font_large.render("TAO NHAN VAT MOI", True, WHITE)
        screen.blit(t_surf, (SCREEN_WIDTH // 2 - t_surf.get_width() // 2, 100))
        
        p_surf = font_small.render(f"Tai khoan: {username} - Nhap ten nhan vat:", True, WHITE)
        screen.blit(p_surf, (SCREEN_WIDTH // 2 - 100, 170))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                # Xử lý click ô nhập tên
                if input_box.collidepoint(event.pos):
                    active = not active
                else:
                    active = False
                color = color_active if active else color_inactive
                
                # Xử lý chọn hành tinh
                if btn_td.collidepoint(event.pos): selected_planet = "Trai Dat"
                elif btn_nm.collidepoint(event.pos): selected_planet = "Namec"
                elif btn_xd.collidepoint(event.pos): selected_planet = "Xayda"
                
                # Xử lý nút Tạo
                elif btn_create.collidepoint(event.pos):
                    if len(text) > 0:
                        return text, selected_planet 

            if event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN: pass
                    elif event.key == pygame.K_BACKSPACE: text = text[:-1]
                    else: 
                        if len(text) < 10: text += event.unicode

        # Vẽ ô nhập tên
        txt_s = font_large.render(text, True, color)
        input_box.w = max(200, txt_s.get_width()+10)
        screen.blit(txt_s, (input_box.x+5, input_box.y+5))
        pygame.draw.rect(screen, color, input_box, 2)

        # Vẽ nút chọn hành tinh (Xanh lá nếu đang chọn)
        for btn, name, p_key in [(btn_td, "Trai Dat", "Trai Dat"), (btn_nm, "Namec", "Namec"), (btn_xd, "Xayda", "Xayda")]:
            c = GREEN_SUCCESS if selected_planet == p_key else GRAY
            pygame.draw.rect(screen, c, btn, border_radius=5)
            lbl = font_small.render(name, True, WHITE)
            screen.blit(lbl, (btn.centerx - lbl.get_width()//2, btn.centery - lbl.get_height()//2))

        # Vẽ nút Tạo
        pygame.draw.rect(screen, (255, 165, 0), btn_create, border_radius=5)
        lbl_c = font_large.render("TAO NGAY", True, WHITE)
        screen.blit(lbl_c, (btn_create.centerx - lbl_c.get_width()//2, btn_create.centery - lbl_c.get_height()//2))

        pygame.display.flip()

# --- HÀM MENU CHÍNH (Đã tích hợp Logic Đăng Nhập & Tạo NV) ---