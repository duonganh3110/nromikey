import pygame
import json
import os

# --- MÀU SẮC ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
RED = (255, 0, 0)
GREEN = (0, 200, 0)
BLUE_UI = (0, 100, 255)
C_HIGHLIGHT = (255, 255, 100)
C_VANG = (255, 215, 0)
C_TIEMNANG = (0, 255, 255) # Màu Cyan cho tiềm năng

class BuffSucManhManager:
    def __init__(self, data_char_path, font, font_small, InputBoxClass):
        self.data_char_path = data_char_path
        self.font = font
        self.font_small = font_small
        
        # Tạo InputBox riêng cho tab này
        # (x, y, w, h)
        self.input_sm = InputBoxClass(300, 500, 200, 35, text="")
        self.btn_set_rect = pygame.Rect(510, 500, 100, 35)
        
        self.selected_user = None
        self.selected_char_name = None
        self.message = ""
        self.message_color = WHITE
        
        self.scroll_y = 0
        self.row_height = 40
        self.list_view_rect = pygame.Rect(160, 100, 630, 380)

    def load_data(self):
        if not os.path.exists(self.data_char_path):
            return {}
        try:
            with open(self.data_char_path, "r") as f:
                return json.load(f)
        except:
            return {}

    def save_data(self, data):
        try:
            with open(self.data_char_path, "w") as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"Loi luu file: {e}")

    def handle_event(self, event):
        # Xử lý input box
        self.input_sm.handle_event(event)
        
        # Xử lý lăn chuột
        if event.type == pygame.MOUSEWHEEL:
            self.scroll_y -= event.y * 20
            self.scroll_y = max(0, self.scroll_y) # Không cuộn quá đầu

        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = event.pos
            
            # 1. Check click nút SET
            if self.btn_set_rect.collidepoint(mx, my):
                self.process_set_power()
                return

            # 2. Check click vào hàng trong danh sách
            if self.list_view_rect.collidepoint(mx, my):
                data_char = self.load_data()
                # Tạo danh sách phẳng để dễ tính tọa độ click
                flat_list = []
                for user, chars in data_char.items():
                    if user == "admin": continue
                    if isinstance(chars, dict):
                        for char_name, info in chars.items():
                            flat_list.append((user, char_name))
                
                # Tính xem click vào hàng thứ mấy
                click_y_offset = my - self.list_view_rect.y + self.scroll_y
                row_idx = click_y_offset // self.row_height
                
                if 0 <= row_idx < len(flat_list):
                    self.selected_user, self.selected_char_name = flat_list[row_idx]
                    self.message = f"Đã chọn: {self.selected_char_name} ({self.selected_user})"
                    self.message_color = C_VANG

    def process_set_power(self):
        text_cmd = self.input_sm.text.strip().lower()
        
        if not self.selected_user:
            self.message = "Vui lòng chọn nhân vật trước!"
            self.message_color = RED
            return

        # Kiểm tra cú pháp
        is_sm = text_cmd.startswith("sm")
        is_tn = text_cmd.startswith("tn")

        if not (is_sm or is_tn):
            self.message = "Sai cú pháp! Gõ: sm[số] hoặc tn[số]"
            self.message_color = RED
            return
        
        try:
            # Lấy số sau chữ cái
            value_str = text_cmd[2:] 
            new_value = int(value_str)
            
            # Thực hiện lưu dữ liệu
            full_data = self.load_data()
            
            # Kiểm tra xem user và nhân vật còn tồn tại không
            if self.selected_user in full_data and self.selected_char_name in full_data[self.selected_user]:
                char_info = full_data[self.selected_user][self.selected_char_name]
                
                if is_sm:
                    char_info["suc_manh"] = new_value
                    target_key = "SM"
                else:
                    char_info["tiem_nang"] = new_value
                    target_key = "TN"
                
                self.save_data(full_data)
                self.message = f"Đã set {target_key} của {self.selected_char_name} thành {new_value:,}"
                self.message_color = GREEN
                self.input_sm.text = "" # Xóa ô nhập
                self.input_sm.update()
            else:
                self.message = "Nhân vật không khả dụng/Chưa tạo!"
                self.message_color = RED
                
        except ValueError:
            self.message = "Lỗi: Sau lệnh phải là số nguyên!"
            self.message_color = RED

    def draw(self, screen):
        # 1. Vẽ Tiêu đề
        lbl_title = self.font.render("QUẢN LÝ SỨC MẠNH & TIỀM NĂNG", True, C_VANG)
        screen.blit(lbl_title, (160, 50))

        # 2. Vẽ Header Bảng
        headers_y = 80
        pygame.draw.rect(screen, (80, 80, 80), (160, headers_y, 630, 30))
        # Cập nhật Header thêm cột Tiềm Năng
        headers = ["Tài Khoản", "Tên NV", "Sức Mạnh", "Tiềm Năng", "Hành Tinh"]
        # Điều chỉnh tọa độ X cho 5 cột
        xs = [165, 270, 380, 510, 650] 
        for i, h in enumerate(headers):
            s = self.font_small.render(h, True, C_HIGHLIGHT)
            screen.blit(s, (xs[i], headers_y + 5))

        # 3. Vẽ Danh sách (Có Scroll)
        orig_clip = screen.get_clip()
        screen.set_clip(self.list_view_rect)
        
        start_y = self.list_view_rect.y - self.scroll_y
        
        data_char = self.load_data()
        current_row = 0
        
        for user, chars in data_char.items():
            if user == "admin": continue 
            
            if not chars or not isinstance(chars, dict): continue
                
            for char_name, info in chars.items():
                row_y = start_y + (current_row * self.row_height)
                
                if row_y + self.row_height > self.list_view_rect.y and row_y < self.list_view_rect.bottom:
                    is_sel = (user == self.selected_user and char_name == self.selected_char_name)
                    bg_col = (60, 60, 80) if is_sel else (30, 30, 30)
                    
                    row_rect = pygame.Rect(160, row_y, 630, self.row_height - 2)
                    pygame.draw.rect(screen, bg_col, row_rect, border_radius=5)
                    if is_sel:
                        pygame.draw.rect(screen, C_VANG, row_rect, 1, border_radius=5)

                    # Thông tin
                    sm_val = info.get("suc_manh", 0)
                    tn_val = info.get("tiem_nang", 0) # Lấy tiềm năng
                    planet = info.get("phai", "Chưa chọn")
                    
                    c_user = self.font_small.render(str(user)[:10], True, WHITE)
                    c_name = self.font_small.render(str(char_name)[:10], True, GREEN)
                    c_sm = self.font_small.render(f"{sm_val:,}", True, C_VANG)
                    c_tn = self.font_small.render(f"{tn_val:,}", True, C_TIEMNANG) # Vẽ tiềm năng màu Cyan
                    c_pl = self.font_small.render(str(planet), True, WHITE)
                    
                    screen.blit(c_user, (165, row_y + 10))
                    screen.blit(c_name, (270, row_y + 10))
                    screen.blit(c_sm, (380, row_y + 10))
                    screen.blit(c_tn, (510, row_y + 10))
                    screen.blit(c_pl, (650, row_y + 10))
                
                current_row += 1

        screen.set_clip(orig_clip) 

        # 4. Vẽ khu vực điều khiển
        lbl_guide = self.font_small.render("Nhập lệnh (VD: sm50000, tn10000):", True, WHITE)
        screen.blit(lbl_guide, (300, 480))
        
        self.input_sm.draw(screen)
        
        # Vẽ nút SET
        pygame.draw.rect(screen, BLUE_UI, self.btn_set_rect, border_radius=5)
        pygame.draw.rect(screen, WHITE, self.btn_set_rect, 1, border_radius=5)
        lbl_btn = self.font_small.render("THỰC HIỆN", True, WHITE)
        screen.blit(lbl_btn, lbl_btn.get_rect(center=self.btn_set_rect.center))
        
        # 5. Thông báo trạng thái
        if self.message:
            msg_surf = self.font_small.render(self.message, True, self.message_color)
            screen.blit(msg_surf, (300, 545))