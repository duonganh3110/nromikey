import pygame
import math
import random

# --- CẤU HÌNH ---
RESPAWN_DURATION = 60000 
RED_BOSS_NAME = (255, 0, 0)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN_HP = (0, 255, 0)
RED_HP = (255, 0, 0)
YELLOW_TIMER = (255, 255, 0)

# [CẤU HÌNH PHẠM VI]
TERRITORY_LIMIT = 300   
CHASE_TRIGGER_DIST = 150 
JUMP_LIMIT_COUNT = 2    

# Màu hiệu ứng
WIND_COLOR = (200, 255, 255, 150)
DUST_COLOR = (120, 100, 80, 180)

THEME_COLORS = {
    "Trai Dat": {
        "body": (101, 67, 33),      "light": (139, 90, 43),
        "mane": (50, 30, 10),       "tusk": (240, 240, 220)
    },
    "Namec": {
        "body": (46, 139, 87),      "light": (144, 238, 144),
        "mane": (128, 0, 128),      "tusk": (200, 255, 200)
    },
    "Xayda": {
        "body": (80, 20, 20),       "light": (120, 50, 50),
        "mane": (20, 20, 20),       "tusk": (255, 215, 0)
    }
}

FONT_BOSS = None

def get_font():
    global FONT_BOSS
    if FONT_BOSS is None:
        try:
            FONT_BOSS = pygame.font.SysFont("Arial", 16, bold=True)
        except:
            FONT_BOSS = pygame.font.Font(None, 26)
    return FONT_BOSS

class BossLonLoi:
    def __init__(self, x, y, planet_name):
        self.world_x = x
        self.world_y = y 
        self.home_x = x
        self.current_map_offset_x = 0
        
        self.planet_name = planet_name  
        self.name_display = f"(BOSS) Lon Loi Me {planet_name}"
        self.max_hp = 2000
        self.hp = 2000
        
        self.width = 135
        self.height = 110 
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        
        self.is_dead = False
        self.death_time = 0
        self.huong_phai = False 
        
        # AI Logic
        self.state = "IDLE"
        self.state_timer = 0
        self.frame_index = 0
        self.last_anim_time = 0
        
        self.speed = 3.0 
        self.visual_offset_x = 0
        
        # --- BIẾN ĐIỀU CHỈNH HỒI MÁU & TỐC ĐỘ ĐÁNH ---
        self.last_hit_time = pygame.time.get_ticks() 
        self.last_regen_time = 0
        self.attack_cooldown = 800  # Tốc độ đánh (0.8s một lần gây damage)
        self.last_attack_hit_time = 0 
        self.last_successful_stun_time = 0
        
        self.jump_counter = 0 

        # Physics & VFX
        self.dy = 0
        self.gravity = 1.2 
        self.jump_vx = 0 
        self.ground_y_level = y 
        self.particles = []

    def add_particle(self, p_type, x, y, vx, vy, size, life):
        self.particles.append({
            'type': p_type, 'x': x, 'y': y, 
            'vx': vx, 'vy': vy, 
            'size': size, 'life': life, 'max_life': life
        })

    def update_particles(self):
        for p in self.particles:
            p['x'] += p['vx']
            p['y'] += p['vy']
            p['life'] -= 1
            p['size'] *= 0.95 
        self.particles = [p for p in self.particles if p['life'] > 0]

    def update(self, map_offset_x, player_rect=None, player_world_x=0):
        self.current_map_offset_x = map_offset_x
        current_time = pygame.time.get_ticks()
        
        if self.is_dead:
            if current_time - self.death_time > RESPAWN_DURATION: self.respawn()
            return 

        # --- LOGIC HỒI MÁU: 10s không bị đánh thì hồi 10% mỗi 0.5s ---
        if current_time - self.last_hit_time > 10000:
            if current_time - self.last_regen_time > 500:
                heal_val = self.max_hp * 0.1
                self.hp = min(self.max_hp, self.hp + heal_val)
                self.last_regen_time = current_time

        dist_boss_to_player = abs(self.world_x - player_world_x) if player_rect else 9999
        dist_player_to_home = abs(player_world_x - self.home_x) if player_rect else 9999
        is_target_valid = dist_player_to_home <= TERRITORY_LIMIT

        # [STATE: IDLE]
        if self.state == "IDLE":
            self.jump_counter = 0 
            self.visual_offset_x = 0
            self.world_y = self.ground_y_level
            
            if self.huong_phai:
                if self.world_x < self.home_x + 100: self.world_x += self.speed
                else: self.huong_phai = False 
            else:
                if self.world_x > self.home_x - 100: self.world_x -= self.speed
                else: self.huong_phai = True 
            
            if is_target_valid and dist_boss_to_player < 350:
                self.state = "ANGRY"
                self.state_timer = current_time
                self.huong_phai = player_world_x > self.world_x
                for _ in range(5):
                    self.add_particle('dust', self.world_x + random.randint(0, self.width), self.ground_y_level, random.uniform(-1, 1), random.uniform(-2, 0), random.randint(3, 6), 20)

        # [STATE: ANGRY]
        elif self.state == "ANGRY":
            self.visual_offset_x = random.randint(-2, 2) 
            self.world_y = self.ground_y_level
            
            if abs(player_world_x - self.world_x) > 20:
                self.huong_phai = player_world_x > self.world_x
            
            if current_time - self.state_timer > 100: 
                if not is_target_valid:
                    self.state = "RETURN_HOME"
                elif dist_boss_to_player > CHASE_TRIGGER_DIST and self.jump_counter < JUMP_LIMIT_COUNT:
                    self.state = "JUMP_SMASH"
                    self.dy = -16 
                    flight_time = (2 * abs(self.dy)) / self.gravity 
                    distance_needed = player_world_x - self.world_x
                    self.jump_vx = distance_needed / flight_time
                    if self.jump_vx > 40: self.jump_vx = 40
                    if self.jump_vx < -40: self.jump_vx = -40
                else:
                    if dist_boss_to_player <= CHASE_TRIGGER_DIST:
                        self.state = "CHARGE"
                        self.dy = -5
                        self.jump_counter = 0 
                    else:
                        self.state = "RETURN_HOME"
                self.state_timer = current_time

        # [STATE: CHARGE]
        elif self.state == "CHARGE":
            dash_speed = 18 
            dx = dash_speed if self.huong_phai else -dash_speed
            
            self.world_y += self.dy
            self.dy += self.gravity
            
            if self.world_y >= self.ground_y_level:
                self.world_y = self.ground_y_level
                self.dy = 0 
                self.state = "TIRED"
                self.state_timer = current_time

            self.world_x += dx
            
            # Hitbox Charge gây damage
            charge_hitbox = self.rect.inflate(60, 20)
            if self.huong_phai: charge_hitbox.x += 20
            else: charge_hitbox.x -= 20
            
            if player_rect and charge_hitbox.colliderect(player_rect):
                if current_time - self.last_attack_hit_time > self.attack_cooldown:
                    dmg = self.calculate_attack_damage()
                    if current_time - self.last_successful_stun_time > 6000:
                        if hasattr(player_rect, 'stun'): player_rect.stun(1.0)
                        elif hasattr(player_rect, 'is_stunned'): 
                             player_rect.is_stunned = True; player_rect.stun_timer = current_time + 1000
                        if hasattr(player_rect, 'boss_combo'): player_rect.boss_combo(dmg)
                        self.last_successful_stun_time = current_time
                    else:
                        if hasattr(player_rect, 'boss_single_hit'):
                            player_rect.boss_single_hit(dmg)
                    self.last_attack_hit_time = current_time

        # [STATE: JUMP_SMASH]
        elif self.state == "JUMP_SMASH":
            if player_rect:
                target_x = player_world_x
                tracking_force = 3.0 
                if self.world_x < target_x: self.jump_vx += tracking_force
                else: self.jump_vx -= tracking_force
                if self.jump_vx > 50: self.jump_vx = 50
                if self.jump_vx < -50: self.jump_vx = -50

            self.world_x += self.jump_vx 
            self.world_y += self.dy
            self.dy += self.gravity 
            
            if self.jump_vx > 0: self.huong_phai = True
            elif self.jump_vx < 0: self.huong_phai = False

            attack_hitbox = self.rect.inflate(100, 80)
            
            if player_rect and attack_hitbox.colliderect(player_rect):
                if current_time - self.last_attack_hit_time > self.attack_cooldown:
                    dmg = self.calculate_attack_damage()
                    if current_time - self.last_successful_stun_time > 6000:
                        if hasattr(player_rect, 'stun'): player_rect.stun(1.0)
                        elif hasattr(player_rect, 'is_stunned'): 
                             player_rect.is_stunned = True; player_rect.stun_timer = current_time + 1000
                        if hasattr(player_rect, 'boss_combo'): player_rect.boss_combo(dmg)
                        self.last_successful_stun_time = current_time
                    else:
                        if hasattr(player_rect, 'boss_single_hit'):
                            player_rect.boss_single_hit(dmg)
                    self.last_attack_hit_time = current_time
                    self.jump_vx *= 0.1 

            if self.world_y >= self.ground_y_level:
                self.world_y = self.ground_y_level
                for _ in range(15):
                    self.add_particle('dust', self.world_x + self.width//2, self.ground_y_level, random.uniform(-8, 8), random.uniform(-5, -2), random.randint(8, 15), 25)
                self.jump_counter += 1
                if self.jump_counter >= JUMP_LIMIT_COUNT: self.state = "RETURN_HOME"
                else: self.state = "TIRED"; self.state_timer = current_time

        # [STATE: RETURN_HOME]
        elif self.state == "RETURN_HOME":
            self.jump_counter = 0 
            self.world_y = self.ground_y_level
            return_speed = 10 
            if self.world_x < self.home_x: self.world_x += return_speed; self.huong_phai = True
            else: self.world_x -= return_speed; self.huong_phai = False 
            if abs(self.world_x - self.home_x) < 20: self.state = "IDLE"

        # [STATE: TIRED]
        elif self.state == "TIRED":
            self.world_y = self.ground_y_level
            if current_time - self.state_timer > 200:
                if is_target_valid and dist_boss_to_player < 400: self.state = "ANGRY"; self.state_timer = current_time
                else: self.state = "RETURN_HOME"

        self.update_particles()
        self.world_x = max(self.home_x - TERRITORY_LIMIT, min(self.world_x, self.home_x + TERRITORY_LIMIT))
        self.rect.x = self.world_x - map_offset_x + self.visual_offset_x
        self.rect.y = self.world_y - self.height 
        
        if current_time - self.last_anim_time > 80:
            self.frame_index += 1
            self.last_anim_time = current_time

    def take_damage(self, dmg):
        if not self.is_dead:
            self.hp -= dmg
            self.last_hit_time = pygame.time.get_ticks() # Reset 10s khi bị đánh
            if self.state in ["IDLE", "RETURN_HOME", "TIRED"]: 
                self.state = "ANGRY"; self.state_timer = pygame.time.get_ticks() - 800 
            if self.hp <= 0: self.hp = 0; self.is_dead = True; self.death_time = pygame.time.get_ticks()

    def calculate_attack_damage(self):
        dmg = random.randint(50, 75)
        if random.randint(1, 100) <= 20: dmg *= 2 
        return dmg

    def respawn(self):
        self.hp = self.max_hp; self.is_dead = False; self.world_x = self.home_x; self.state = "IDLE"; self.jump_counter = 0
        self.last_hit_time = pygame.time.get_ticks()

    def draw_target_indicator(self, screen):
        if self.is_dead: return
        pygame.draw.ellipse(screen, (255, 50, 0), (self.rect.centerx - 40, self.rect.bottom - 10, 80, 20), 3)

    def draw(self, screen):
        font = get_font()
        offset_x = self.current_map_offset_x
        if self.is_dead: return
        theme = THEME_COLORS.get(self.planet_name, THEME_COLORS["Trai Dat"])
        sx = self.rect.x; sy = self.rect.y; w = self.width; h = self.height
        
        # Vẽ particles
        for p in self.particles:
            if p['type'] == 'dust':
                s = pygame.Surface((int(p['size']*2), int(p['size']*2)), pygame.SRCALPHA)
                alpha = int((p['life'] / p['max_life']) * 200)
                color = (*DUST_COLOR[:3], alpha)
                pygame.draw.circle(s, color, (int(p['size']), int(p['size'])), int(p['size']))
                screen.blit(s, (p['x'] - offset_x - p['size'], p['y'] - p['size']))
            elif p['type'] == 'wind':
                pygame.draw.line(screen, WIND_COLOR, (p['x'] - offset_x, p['y']), (p['x'] - offset_x - p['vx']*3, p['y']), int(p['life'] / 3) + 1)

        # Body animation
        bobbing = math.sin(pygame.time.get_ticks() * 0.008) * 4
        if self.state in ["CHARGE", "JUMP_SMASH", "RETURN_HOME"]: bobbing = 0
        sy_draw = sy + bobbing
        
        leg_w, leg_h = 20, 30
        is_moving = self.state in ["IDLE", "CHARGE", "JUMP_SMASH", "RETURN_HOME"]
        anim_speed = 0.8 if self.state == "RETURN_HOME" else 0.5
        leg_swing = math.sin(self.frame_index * anim_speed) * 15 if is_moving else 0
        if self.state in ["CHARGE", "JUMP_SMASH"]: leg_swing = -10 
        
        c_leg = tuple(max(0, c - 30) for c in theme["body"])
        pygame.draw.rect(screen, c_leg, (sx + 20 + leg_swing, sy_draw + h - 15, leg_w, leg_h))
        pygame.draw.rect(screen, c_leg, (sx + w - 40 - leg_swing, sy_draw + h - 15, leg_w, leg_h))
        pygame.draw.ellipse(screen, theme["body"], pygame.Rect(sx, sy_draw + 10, w, h - 20))
        pygame.draw.ellipse(screen, theme["light"], pygame.Rect(sx + 10, sy_draw + h - 40, w - 20, 20))
        pygame.draw.rect(screen, theme["body"], (sx + 15 - leg_swing, sy_draw + h - 20, leg_w, leg_h))
        pygame.draw.rect(screen, theme["body"], (sx + w - 35 + leg_swing, sy_draw + h - 20, leg_w, leg_h))

        # Head
        head_size = 50
        head_x = sx + w - 40 if self.huong_phai else sx - 10
        head_y = sy_draw + 15
        pygame.draw.circle(screen, theme["body"], (int(head_x + head_size//2), int(head_y + head_size//2)), head_size)
        snout_color = tuple(min(255, c + 20) for c in theme["body"])
        snout_x = head_x + head_size - 10 if self.huong_phai else head_x - 10
        pygame.draw.ellipse(screen, snout_color, (snout_x, head_y + 20, 30, 25))
        pygame.draw.circle(screen, BLACK, (int(snout_x + (20 if self.huong_phai else 5)), int(head_y + 30)), 4)

        tusk_color = theme["tusk"]
        tusk_pts = [(head_x + 35, head_y + 40), (head_x + 55, head_y + 30), (head_x + 45, head_y + 20)] if self.huong_phai else [(head_x + 15, head_y + 40), (head_x - 5, head_y + 30), (head_x + 5, head_y + 20)]
        pygame.draw.polygon(screen, tusk_color, tusk_pts); pygame.draw.line(screen, (50,50,50), tusk_pts[0], tusk_pts[1], 1)

        eye_x = head_x + 30 if self.huong_phai else head_x + 10; eye_y = head_y + 15
        pygame.draw.circle(screen, WHITE, (int(eye_x), int(eye_y)), 8)
        eye_color = (255, 0, 0) if self.state in ["ANGRY", "CHARGE", "JUMP_SMASH"] else BLACK
        pygame.draw.circle(screen, eye_color, (int(eye_x + (2 if self.huong_phai else -2)), int(eye_y)), 3)
        pygame.draw.line(screen, BLACK, (eye_x - 5, eye_y - 8), (eye_x + 5, eye_y - 5), 3)

        # Mane
        mane_color = theme["mane"]
        for i in range(0, int(w - 20), 15):
            mx = sx + 10 + i
            pygame.draw.polygon(screen, mane_color, [(mx, sy_draw + 10), (mx + 8, sy_draw - 10), (mx + 16, sy_draw + 10)])

        # Health bar
        bar_x = self.rect.centerx - 60; bar_y = self.rect.y - 15
        pygame.draw.rect(screen, BLACK, (bar_x, bar_y, 120, 8))
        pygame.draw.rect(screen, RED_HP, (bar_x, bar_y, int(120 * (self.hp / self.max_hp)), 8))
        pygame.draw.rect(screen, WHITE, (bar_x, bar_y, 120, 8), 1)

        # Name
        name_shadow = font.render(self.name_display, True, BLACK)
        screen.blit(name_shadow, (self.rect.centerx - name_shadow.get_width()//2 + 1, self.rect.y - 35 + 1))
        name_surf = font.render(self.name_display, True, RED_BOSS_NAME)
        screen.blit(name_surf, (self.rect.centerx - name_surf.get_width()//2, self.rect.y - 35))

# --- HÀM KHỞI TẠO BOSS ---
def create_boss_for_map(map_id, ground_y, start_x_gau_pos=0):
    if "Map_2" not in map_id: return None
    planet = "Trai Dat"
    if "_NM" in map_id: planet = "Namec"
    elif "_XD" in map_id: planet = "Xayda"
    boss_x = 1650 + 600 if start_x_gau_pos == 0 else start_x_gau_pos + 600
    return BossLonLoi(boss_x, ground_y, planet)