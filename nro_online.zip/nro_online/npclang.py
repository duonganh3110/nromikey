import pygame

# --- CẤU HÌNH NPC ---
NPC_X_WORLD = 150  # Vị trí cách rương (x=20) một đoạn
NPC_WIDTH = 50
NPC_HEIGHT = 70

# --- MÀU SẮC ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
SKIN_COLOR = (255, 220, 170) 

# Màu Gohan
C_HAT_GREEN = (34, 139, 34)
C_FACE_MASK = (255, 250, 240)
C_ORANGE_GI = (255, 140, 0)
C_PANTS_PURPLE = (75, 0, 130)
RED_ACCENT = (200, 0, 0)

# Màu Mori (Namec)
C_SKIN_NAMEC = (100, 200, 50) # Xanh lá
C_ROBE_RED = (180, 50, 50)    # Áo khoác đỏ mận
C_VEST_BLUE = (50, 50, 150)   # Áo lót xanh
C_BEARD = (240, 240, 240)     # Râu trắng

# Màu King Vegeta (Xayda)
C_HAIR_BLACK = (20, 20, 20)
C_ARMOR_WHITE = (240, 240, 240)
C_ARMOR_GOLD = (218, 165, 32)
C_SUIT_BLUE = (0, 0, 100)
C_CAPE_RED = (220, 20, 60)

def get_npc_rect(map_offset_x, ground_y):
    screen_x = NPC_X_WORLD - map_offset_x
    screen_y = ground_y - NPC_HEIGHT
    return pygame.Rect(screen_x, screen_y, NPC_WIDTH, NPC_HEIGHT)

def check_click(pos, map_offset_x, ground_y):
    """Kiểm tra click chung cho tất cả NPC"""
    rect = get_npc_rect(map_offset_x, ground_y)
    return rect.collidepoint(pos)

# --- VẼ ÔNG GOHAN (Trái Đất) ---
def draw_gohan(screen, x, y):
    cx = x + NPC_WIDTH // 2
    # 1. Chân
    pygame.draw.rect(screen, C_PANTS_PURPLE, (cx - 15, y + 45, 12, 25))
    pygame.draw.rect(screen, C_PANTS_PURPLE, (cx + 3, y + 45, 12, 25))
    # 2. Thân (Áo cam)
    pygame.draw.rect(screen, C_ORANGE_GI, (cx - 18, y + 25, 36, 30))
    pygame.draw.rect(screen, BLACK, (cx - 18, y + 40, 36, 5)) # Đai
    # 3. Đầu (Mặt nạ)
    pygame.draw.circle(screen, C_FACE_MASK, (cx, y + 15), 16)
    pygame.draw.line(screen, BLACK, (cx - 8, y + 12), (cx - 3, y + 15), 2) # Mắt
    pygame.draw.line(screen, BLACK, (cx + 8, y + 12), (cx + 3, y + 15), 2)
    pygame.draw.circle(screen, RED_ACCENT, (cx, y + 18), 3) # Mũi đỏ
    # 4. Mũ
    pygame.draw.ellipse(screen, C_HAT_GREEN, (cx - 20, y - 2, 40, 15))
    pygame.draw.circle(screen, C_HAT_GREEN, (cx, y + 2), 12)
    pygame.draw.circle(screen, RED_ACCENT, (cx, y - 5), 4) # Chóp đỏ

# --- VẼ TRƯỞNG LÃO MORI (Namec) ---
def draw_mori(screen, x, y):
    cx = x + NPC_WIDTH // 2
    # 1. Áo choàng dài (Namek style)
    pygame.draw.polygon(screen, C_ROBE_RED, [(cx, y+10), (x, y+70), (x+NPC_WIDTH, y+70)])
    pygame.draw.rect(screen, C_VEST_BLUE, (cx-10, y+25, 20, 45)) # Phần giữa
    # 2. Đầu
    pygame.draw.circle(screen, C_SKIN_NAMEC, (cx, y + 15), 15)
    # 3. Râu trắng
    pygame.draw.polygon(screen, C_BEARD, [(cx-10, y+20), (cx+10, y+20), (cx, y+40)])
    # 4. Anten
    pygame.draw.line(screen, C_SKIN_NAMEC, (cx-5, y+5), (cx-8, y-5), 3)
    pygame.draw.line(screen, C_SKIN_NAMEC, (cx+5, y+5), (cx+8, y-5), 3)
    # 5. Gậy (Staff)
    pygame.draw.line(screen, (139, 69, 19), (cx + 20, y + 70), (cx + 20, y), 4)
    pygame.draw.circle(screen, (50, 150, 255), (cx + 20, y), 6) # Ngọc trên gậy

# --- VẼ KING VEGETA (Xayda) ---
def draw_king_vegeta(screen, x, y):
    cx = x + NPC_WIDTH // 2
    # 1. Áo choàng đỏ phía sau
    pygame.draw.rect(screen, C_CAPE_RED, (cx - 20, y + 20, 40, 50))
    # 2. Body suit xanh
    pygame.draw.rect(screen, C_SUIT_BLUE, (cx - 15, y + 40, 12, 30))
    pygame.draw.rect(screen, C_SUIT_BLUE, (cx + 3, y + 40, 12, 30))
    # 3. Giáp ngực (Trắng + Vàng)
    pygame.draw.rect(screen, C_ARMOR_WHITE, (cx - 20, y + 20, 40, 25), border_radius=5)
    pygame.draw.rect(screen, C_ARMOR_GOLD, (cx - 15, y + 20, 30, 20), 2) # Viền vàng
    # 4. Đầu
    pygame.draw.circle(screen, SKIN_COLOR, (cx, y + 12), 14)
    # 5. Râu dê + Tóc
    pygame.draw.polygon(screen, C_HAIR_BLACK, [(cx, y+26), (cx-5, y+22), (cx+5, y+22)]) # Râu
    # Tóc dựng đứng (King Vegeta style)
    pts_hair = [(cx-14, y+5), (cx-10, y-15), (cx, y-10), (cx+10, y-15), (cx+14, y+5), (cx+18, y+10), (cx-18, y+10)]
    pygame.draw.polygon(screen, C_HAIR_BLACK, pts_hair)
    # 6. Biểu tượng Hoàng gia (Đỏ trên ngực trái)
    pygame.draw.circle(screen, RED_ACCENT, (cx - 8, y + 30), 4)

def draw_npc(screen, map_offset_x, ground_y, planet_name):
    """Hàm chính để vẽ NPC dựa trên hành tinh"""
    rect = get_npc_rect(map_offset_x, ground_y)
    
    # Tối ưu: Không vẽ nếu ngoài màn hình
    if rect.right < 0 or rect.left > 800:
        return

    # Vẽ NPC tương ứng
    if planet_name == "Trai Dat":
        draw_gohan(screen, rect.x, rect.y)
        name_npc = "Ong Gohan"
    elif planet_name == "Namec":
        draw_mori(screen, rect.x, rect.y)
        name_npc = "Mori"
    elif planet_name == "Xayda":
        draw_king_vegeta(screen, rect.x, rect.y)
        name_npc = "King"
    else:
        name_npc = "NPC"

    # Vẽ tên NPC
    font_name = pygame.font.SysFont("Arial", 12, bold=True)
    text = font_name.render(name_npc, True, (255, 255, 0))
    text_rect = text.get_rect(center=(rect.centerx, rect.y - 10))
    # Vẽ nền đen mờ cho tên dễ đọc
    bg_name = pygame.Surface((text_rect.width + 4, text_rect.height + 4), pygame.SRCALPHA)
    bg_name.fill((0, 0, 0, 100))
    screen.blit(bg_name, (text_rect.x - 2, text_rect.y - 2))
    screen.blit(text, text_rect)