import pygame
import sys
import os

# --- IMPORT MODULE QUẢN LÝ GIÁ TIỀN ---
qlgiatien = None
try:
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.join(current_dir, "..")
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)
    import qlgiatien as _qlgiatien
    qlgiatien = _qlgiatien
except Exception:
    qlgiatien = None


# =========================
# Helpers an toàn (không crash nếu thiếu qlgiatien)
# =========================
def _get_price_data():
    if qlgiatien and hasattr(qlgiatien, "PRICE_DATA"):
        return qlgiatien.PRICE_DATA
    return {}


def _get_item_price(shop_key, item_key):
    # ưu tiên hàm chính
    if qlgiatien and hasattr(qlgiatien, "get_item_price"):
        try:
            p, c = qlgiatien.get_item_price(shop_key, item_key)
            return (p or 0), (c or "VANG")
        except Exception:
            pass

    # fallback: đọc trực tiếp PRICE_DATA
    pd = _get_price_data()
    shop = pd.get(shop_key, {})
    v = shop.get(item_key)
    if isinstance(v, dict):
        return int(v.get("price", 0) or 0), (v.get("currency") or "VANG")
    if isinstance(v, (list, tuple)) and len(v) >= 1:
        price = int(v[0] or 0)
        currency = v[1] if len(v) >= 2 else "VANG"
        return price, (currency or "VANG")
    if isinstance(v, (int, float)):
        return int(v), "VANG"
    return 0, "VANG"


# --- CẤU HÌNH NPC BÁN ĐỒ ---
BANDO_X_WORLD = 350
NPC_WIDTH = 40
NPC_HEIGHT = 55

# --- CẤU HÌNH SHOP ---
SLOT_SIZE = 40
SLOT_MARGIN = 5
TAB_HEIGHT = 40
TAB_TITLES = ["TRANG_BI", "TIEU_HAO", "DAC_BIET", "BAN_DO"]
current_shop_tab = TAB_TITLES[0]

# --- MÀU SẮC ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
C_VANG = (255, 215, 0)
C_HIGHLIGHT = (255, 255, 100)
C_DARK_BG = (50, 50, 50)
GRAY = (200, 200, 200)
C_BTN_HIGHLIGHT = (200, 200, 255)
C_BLUE_UI = (0, 100, 255)
C_KI_BLUE = (0, 120, 255)
C_SELL_TAB = (200, 50, 50)  # Màu đỏ cho tab bán

# Màu cho NPC
SKIN_COLOR = (255, 220, 170)
C_BLUE_HAIR = (0, 150, 200)
C_PINK_SUIT = (255, 100, 150)
C_BOOTS_B = (100, 50, 0)
C_SKIN_DENDE = (120, 255, 120)
C_ROBE_NAMEK = (255, 255, 255)
C_INSUIT_BROWN = (139, 69, 19)
C_ANTENNA = (100, 200, 50)
C_SAIYAN_HAIR = (20, 20, 20)
C_ARMOR_WHITE = (240, 240, 240)
C_SHOULDER_GREEN = (0, 100, 0)
C_SUIT_BLUE = (0, 0, 100)

# Khởi tạo font
try:
    pygame.font.init()
    font_tab = pygame.font.SysFont("Arial", 14, bold=True)
    font_tiny = pygame.font.SysFont("Arial", 9)
    font_small = pygame.font.SysFont("Arial", 16)
    font_title = pygame.font.SysFont("Arial", 28, bold=True)
    font_close = pygame.font.SysFont("Arial", 20, bold=True)
except Exception:
    font_tab = pygame.font.SysFont(None, 14)
    font_tiny = pygame.font.SysFont(None, 9)
    font_small = pygame.font.SysFont(None, 16)
    font_title = pygame.font.SysFont(None, 28)
    font_close = pygame.font.SysFont(None, 20)


# --- VẼ ICON TIỀN TỆ ---
def draw_currency_icon_shop(surface, x, y, currency_type):
    if currency_type == "VANG":
        pygame.draw.circle(surface, C_VANG, (x, y), 5)
        pygame.draw.line(surface, BLACK, (x - 3, y), (x + 3, y), 1)
    elif currency_type == "KIM_CUONG":
        C_DIAMOND = (0, 200, 255)
        pts = [(x, y - 5), (x + 5, y), (x, y + 5), (x - 5, y)]
        pygame.draw.polygon(surface, C_DIAMOND, pts)
        pygame.draw.polygon(surface, BLACK, pts, 1)
    elif currency_type == "VND":
        pygame.draw.circle(surface, (0, 255, 100), (x, y), 5)
        pygame.draw.line(surface, BLACK, (x - 3, y), (x + 3, y), 1)


def get_npc_rect(map_offset_x, ground_y):
    screen_x = BANDO_X_WORLD - map_offset_x
    screen_y = ground_y - NPC_HEIGHT
    return pygame.Rect(screen_x, screen_y, NPC_WIDTH, NPC_HEIGHT)


def check_click(pos, map_offset_x, ground_y):
    rect = get_npc_rect(map_offset_x, ground_y)
    return rect.collidepoint(pos)


# --- VẼ NPC ---
def draw_bulma(screen, x, y):
    cx = x + NPC_WIDTH // 2
    y -= 10
    pygame.draw.rect(screen, C_PINK_SUIT, (cx - 10, y + 40, 8, 15))
    pygame.draw.rect(screen, C_PINK_SUIT, (cx + 2, y + 40, 8, 15))
    pygame.draw.rect(screen, C_BOOTS_B, (cx - 10, y + 53, 8, 7))
    pygame.draw.rect(screen, C_BOOTS_B, (cx + 2, y + 53, 8, 7))
    pygame.draw.rect(screen, C_PINK_SUIT, (cx - 15, y + 20, 30, 20))
    pygame.draw.circle(screen, SKIN_COLOR, (cx, y + 15), 12)
    pygame.draw.rect(screen, C_BLUE_HAIR, (cx - 15, y + 8, 30, 15), border_radius=3)
    pygame.draw.rect(screen, C_BLUE_HAIR, (cx - 18, y + 15, 3, 10))
    pygame.draw.rect(screen, C_BLUE_HAIR, (cx + 15, y + 15, 3, 10))
    pygame.draw.rect(screen, WHITE, (cx - 15, y + 10, 30, 2))
    pygame.draw.rect(screen, C_PINK_SUIT, (cx + 10, y + 25, 5, 10))
    pygame.draw.rect(screen, C_PINK_SUIT, (cx - 15, y + 25, 5, 10))


def draw_dende(screen, x, y):
    cx = x + NPC_WIDTH // 2
    y_dende = y + 10
    pygame.draw.polygon(
        screen,
        C_ROBE_NAMEK,
        [(cx, y_dende + 15), (x, y_dende + NPC_HEIGHT + 10), (x + NPC_WIDTH, y_dende + NPC_HEIGHT + 10)],
    )
    pygame.draw.rect(screen, C_INSUIT_BROWN, (cx - 10, y_dende + 25, 20, 30))
    pygame.draw.circle(screen, C_SKIN_DENDE, (cx, y_dende + 10), 14)
    pygame.draw.polygon(
        screen, C_SKIN_DENDE, [(cx - 14, y_dende + 10), (cx - 22, y_dende + 15), (cx - 14, y_dende + 20)]
    )
    pygame.draw.polygon(
        screen, C_SKIN_DENDE, [(cx + 14, y_dende + 10), (cx + 22, y_dende + 15), (cx + 14, y_dende + 20)]
    )
    pygame.draw.circle(screen, C_ANTENNA, (cx - 5, y_dende - 2), 2)
    pygame.draw.circle(screen, C_ANTENNA, (cx + 5, y_dende - 2), 2)
    pygame.draw.rect(screen, C_SKIN_DENDE, (cx + 10, y_dende + 25, 5, 10))
    pygame.draw.rect(screen, C_SKIN_DENDE, (cx - 15, y_dende + 25, 5, 10))


def draw_cabba(screen, x, y):
    cx = x + NPC_WIDTH // 2
    pygame.draw.rect(screen, C_SUIT_BLUE, (cx - 10, y + 35, 20, 25))
    pygame.draw.rect(screen, C_ARMOR_WHITE, (cx - 12, y + 55, 24, 5))
    pygame.draw.rect(screen, C_ARMOR_WHITE, (cx - 18, y + 20, 36, 18), border_radius=3)
    pygame.draw.rect(screen, C_SHOULDER_GREEN, (cx - 20, y + 20, 5, 5))
    pygame.draw.rect(screen, C_SHOULDER_GREEN, (cx + 15, y + 20, 5, 5))
    pygame.draw.circle(screen, SKIN_COLOR, (cx, y + 15), 12)
    pts_hair = [(cx - 10, y + 5), (cx, y - 5), (cx + 10, y + 5), (cx + 10, y + 10), (cx - 10, y + 10)]
    pygame.draw.polygon(screen, C_SAIYAN_HAIR, pts_hair)
    pygame.draw.rect(screen, C_SAIYAN_HAIR, (cx - 10, y + 10, 20, 5))
    pygame.draw.rect(screen, C_ARMOR_WHITE, (cx + 10, y + 35, 5, 10))
    pygame.draw.rect(screen, C_ARMOR_WHITE, (cx - 15, y + 35, 5, 10))


def draw_npc(screen, map_offset_x, ground_y, planet_name):
    rect = get_npc_rect(map_offset_x, ground_y)
    if rect.right < 0 or rect.left > 800:
        return
    if planet_name == "Trai Dat":
        draw_bulma(screen, rect.x, rect.y)
        name_npc = "Bulma"
    elif planet_name == "Namec":
        draw_dende(screen, rect.x, rect.y)
        name_npc = "Dende"
    elif planet_name == "Xayda":
        draw_cabba(screen, rect.x, rect.y)
        name_npc = "Cabba"
    else:
        name_npc = "NPC Bán Đồ"

    font_name = pygame.font.SysFont("Arial", 12, bold=True)
    text = font_name.render(name_npc, True, (0, 255, 255))
    text_rect = text.get_rect(center=(rect.centerx, rect.y - 10))
    bg_name = pygame.Surface((text_rect.width + 4, text_rect.height + 4), pygame.SRCALPHA)
    bg_name.fill((0, 0, 0, 100))
    screen.blit(bg_name, (text_rect.x - 2, text_rect.y - 2))
    screen.blit(text, text_rect)


# =========================
# ICON ITEM (giống túi đồ) - bắt theo KEY
# =========================
def draw_item_icon_shop(surface, rect, item_template, item_key=None, count=1, stars=0):
    if rect.width < 10:
        return
    if not item_template:
        return

    cx, cy = rect.center

    if not item_key:
        item_key = item_template.get("key", "unknown")

    k = str(item_key).lower()
    rarity = item_template.get("rarity", GRAY)
    if isinstance(rarity, list):
        rarity = tuple(rarity)

    # thêm name để bắt "hoàng đế" nếu key không có
    name_low = str(item_template.get("name", "") or "").lower()
    combo = k + " " + name_low

    # Potion
    if ("potion" in combo) or ("thuoc" in combo):
        color = (230, 0, 0) if ("hp" in combo) else (0, 120, 255)
        pygame.draw.circle(surface, color, (cx, cy + 3), 9)
        pygame.draw.rect(surface, WHITE, (cx - 3, cy - 8, 6, 6))
        pygame.draw.rect(surface, (139, 69, 19), (cx - 4, cy - 10, 8, 3))
        pygame.draw.circle(surface, (255, 255, 255, 100), (cx + 3, cy), 3)

    # Kiếm
    elif ("sword" in combo) or ("kiem" in combo):
        pygame.draw.line(surface, (220, 220, 220), (cx - 8, cy + 8), (cx + 8, cy - 8), 4)
        pygame.draw.line(surface, (100, 100, 100), (cx - 8, cy + 8), (cx + 8, cy - 8), 1)
        pygame.draw.line(surface, (139, 69, 19), (cx - 8, cy + 8), (cx - 12, cy + 12), 4)

    # Rada / radar (phụ kiện)
    elif ("radar" in combo) or ("rada" in combo):
        pygame.draw.circle(surface, (0, 255, 0), (cx, cy), 9, 1)
        pygame.draw.circle(surface, (0, 255, 0), (cx, cy), 3, 1)
        pygame.draw.line(surface, (0, 255, 0), (cx, cy), (cx + 6, cy - 6), 1)

    # Giày vải (giay / shoes / boot)
    elif ("giay" in combo) or ("shoe" in combo) or ("shoes" in combo) or ("boot" in combo):
        pygame.draw.rect(surface, rarity, (cx - 9, cy + 3, 18, 6), border_radius=2)
        pygame.draw.rect(
            surface,
            (max(0, rarity[0] - 40), max(0, rarity[1] - 40), max(0, rarity[2] - 40)),
            (cx - 6, cy - 1, 12, 6),
            border_radius=2,
        )

    # Quần vải (quan / pant / pants)
    elif ("quan" in combo) or ("pant" in combo) or ("pants" in combo):
        pygame.draw.rect(surface, rarity, (cx - 9, cy - 7, 18, 5), border_radius=2)
        pygame.draw.rect(surface, rarity, (cx - 9, cy - 2, 8, 13), border_radius=2)
        pygame.draw.rect(surface, rarity, (cx + 1, cy - 2, 8, 13), border_radius=2)
        pygame.draw.rect(surface, (30, 30, 40), (cx - 1, cy - 2, 2, 10))

    # ✅ GĂNG / glove (Găng Hoàng Đế vẽ vàng y như shop Ăn Xin)
    elif ("gang" in combo) or ("glove" in combo):
        is_hoang_de = (
            ("hoang de" in combo) or ("hoang_de" in combo) or
            ("hoàng đế" in combo) or ("hoàng_đế" in combo) or
            ("emperor" in combo)
        )
        glove_color = (255, 215, 0) if is_hoang_de else rarity

        # style y chang shop ăn xin
        pygame.draw.circle(surface, glove_color, (cx, cy), 7)
        pygame.draw.circle(surface, (60, 60, 60), (cx, cy), 7, 1)
        pygame.draw.circle(surface, (30, 30, 30), (cx - 2, cy - 1), 1)
        pygame.draw.circle(surface, (30, 30, 30), (cx + 2, cy - 1), 1)

    # Áo / giáp (ao / armor / giap)
    elif ("ao" in combo) or ("armor" in combo) or ("giap" in combo):
        pygame.draw.rect(surface, rarity, (cx - 7, cy - 4, 14, 15), border_radius=2)
        pygame.draw.rect(surface, rarity, (cx - 12, cy - 2, 5, 8), border_radius=2)
        pygame.draw.rect(surface, rarity, (cx + 7, cy - 2, 5, 8), border_radius=2)

    # Ngọc rồng
    elif "dragon_ball" in combo:
        pygame.draw.circle(surface, (255, 140, 0), (cx, cy), 10)
        pygame.draw.circle(surface, (255, 200, 100), (cx - 3, cy - 3), 4)
        pygame.draw.circle(surface, (220, 0, 0), (cx, cy), 3)

    # Hạt đậu
    elif "zenkai" in combo:
        pygame.draw.ellipse(surface, (50, 205, 50), (cx - 8, cy - 5, 16, 10))
        pygame.draw.line(surface, (20, 100, 20), (cx - 6, cy), (cx + 6, cy), 1)

    else:
        font_q = pygame.font.SysFont("Arial", 20, bold=True)
        txt = font_q.render("?", True, WHITE)
        surface.blit(txt, txt.get_rect(center=(cx, cy)))

    # số lượng
    if count > 1:
        txt_count = font_tiny.render(str(count), True, WHITE)
        surface.blit(txt_count, (rect.right - txt_count.get_width() - 2, rect.bottom - txt_count.get_height() - 2))

    # sao
    if stars > 0:
        star_txt = font_tiny.render(f"{stars}*", True, C_VANG)
        surface.blit(star_txt, (rect.x + 2, rect.y + 2))


def draw_sell_tab_content(screen, menu_rect, inventory_list, ITEM_TEMPLATES_REF):
    """
    Vẽ tab BÁN ĐỒ - Đồng bộ hành trang (Lưới 8x5)
    Trả về rect các ô có item để click bán
    """
    SEPARATOR_Y = menu_rect.y + TAB_HEIGHT + 20
    pygame.draw.line(screen, GRAY, (menu_rect.x + 5, SEPARATOR_Y), (menu_rect.right - 5, SEPARATOR_Y), 1)

    START_Y_SLOT = SEPARATOR_Y + 25

    COLS = 8
    ROWS = 5
    SLOT_GAP = 10

    grid_width = COLS * SLOT_SIZE + (COLS - 1) * SLOT_GAP
    start_x = menu_rect.x + (menu_rect.width - grid_width) // 2

    item_rects = {}

    for row in range(ROWS):
        for col in range(COLS):
            index = row * COLS + col

            x_pos = start_x + col * (SLOT_SIZE + SLOT_GAP)
            y_pos = START_Y_SLOT + row * (SLOT_SIZE + SLOT_GAP)

            slot_rect = pygame.Rect(x_pos, y_pos, SLOT_SIZE, SLOT_SIZE)

            pygame.draw.rect(screen, (30, 30, 40), slot_rect)
            pygame.draw.rect(screen, (100, 100, 100), slot_rect, 1)

            if inventory_list and index < len(inventory_list):
                item_data = inventory_list[index]
                if item_data:
                    key = item_data.get("key")
                    template = ITEM_TEMPLATES_REF.get(key)
                    if template:
                        count = item_data.get("count", 1)
                        stars = item_data.get("stars", 0)
                        draw_item_icon_shop(screen, slot_rect, template, item_key=key, count=count, stars=stars)
                        item_rects[index] = {"rect": slot_rect, "data": item_data}

    return item_rects


def draw_shop_tab_content(screen, menu_rect, tab_key, ITEM_TEMPLATES_REF):
    """
    Vẽ lưới vật phẩm MUA từ Shop
    - TRANG_BI: bán Vu Khi + Giap + Phu Kien (rada cũng vào đây)
    - Tự auto-add quần/giày/rada nếu thiếu PRICE_DATA để không bị "mất icon"
    """
    SEPARATOR_Y = menu_rect.y + TAB_HEIGHT + 20
    pygame.draw.line(screen, GRAY, (menu_rect.x + 5, SEPARATOR_Y), (menu_rect.right - 5, SEPARATOR_Y), 1)

    START_Y_SLOT = SEPARATOR_Y + 25
    MAX_SLOT_AREA_W = menu_rect.width - 2 * SLOT_MARGIN
    SLOT_PLUS_MARGIN = SLOT_SIZE + SLOT_MARGIN
    NUM_COLS = max(1, MAX_SLOT_AREA_W // SLOT_PLUS_MARGIN)
    total_grid_width = NUM_COLS * SLOT_PLUS_MARGIN - SLOT_MARGIN
    offset_x = (MAX_SLOT_AREA_W - total_grid_width) // 2 + SLOT_MARGIN
    START_X_SLOT = menu_rect.x + offset_x

    price_data = _get_price_data()
    bando_price = price_data.get("BANDO", {}) if isinstance(price_data, dict) else {}

    def norm_type(t):
        t = (t or "").strip().lower()
        t = t.replace(" ", "_")
        return t

    def is_trang_bi_item(key, itype_norm):
        kk = str(key).lower()
        if itype_norm in ["vu_khi", "giap", "phu_kien", "phukien", "phu-kien"]:
            return True
        if ("rada" in kk) or ("radar" in kk):
            return True
        return False

    def is_tieu_hao_item(itype_norm):
        return itype_norm in ["tieu_hao", "tieuhao"]

    def is_dac_biet_item(itype_norm):
        return itype_norm in ["dac_biet", "dacbiet"]

    # KEY bán: ưu tiên PRICE_DATA
    selling_keys = set(bando_price.keys())

    # Auto-add: quần/giày/rada nếu thiếu giá
    for k in ITEM_TEMPLATES_REF.keys():
        if k in selling_keys:
            continue
        kk = str(k).lower()
        if (
            ("quan" in kk) or ("pant" in kk) or ("pants" in kk) or
            ("giay" in kk) or ("shoe" in kk) or ("shoes" in kk) or ("boot" in kk) or
            ("rada" in kk) or ("radar" in kk)
        ):
            selling_keys.add(k)

    shop_list = []
    for key in sorted(list(selling_keys)):
        item = ITEM_TEMPLATES_REF.get(key)
        if not item:
            continue

        itype_norm = norm_type(item.get("type", ""))

        add_item = False
        if tab_key == "TRANG_BI" and is_trang_bi_item(key, itype_norm):
            add_item = True
        elif tab_key == "TIEU_HAO" and is_tieu_hao_item(itype_norm):
            add_item = True
        elif tab_key == "DAC_BIET" and is_dac_biet_item(itype_norm):
            add_item = True

        if not add_item:
            continue

        price, currency = _get_item_price("BANDO", key)

        # default giá nếu thiếu
        if not price or price <= 0:
            kk = str(key).lower()
            if ("rada" in kk) or ("radar" in kk):
                price, currency = 250, "VANG"
            elif ("quan" in kk) or ("pant" in kk) or ("pants" in kk):
                price, currency = 250, "VANG"
            elif ("giay" in kk) or ("shoe" in kk) or ("shoes" in kk) or ("boot" in kk):
                price, currency = 250, "VANG"

        shop_list.append({"key": key, "cost": int(price), "currency": (currency or "VANG")})

    item_rects = {}

    for i, shop_item in enumerate(shop_list):
        row = i // NUM_COLS
        col = i % NUM_COLS
        y_pos = START_Y_SLOT + row * (SLOT_PLUS_MARGIN + 30)
        x_pos = START_X_SLOT + col * SLOT_PLUS_MARGIN

        if y_pos + SLOT_SIZE > menu_rect.bottom - SLOT_MARGIN - 20:
            break

        slot_rect = pygame.Rect(x_pos, y_pos, SLOT_SIZE, SLOT_SIZE)
        item_rects[shop_item["key"]] = {"rect": slot_rect, "data": shop_item}

        key = shop_item["key"]
        item_template = ITEM_TEMPLATES_REF.get(key, {"name": "Lỗi Key", "type": "unknown", "rarity": (255, 0, 0)})

        pygame.draw.rect(screen, BLACK, slot_rect, border_radius=5)
        pygame.draw.rect(screen, item_template.get("rarity", GRAY), slot_rect, 1, border_radius=5)

        # icon theo KEY (đúng kiểu túi đồ)
        draw_item_icon_shop(screen, slot_rect, item_template, item_key=key)

        cost_text = f"{shop_item['cost']:,}"
        currency = shop_item["currency"]

        icon_x = slot_rect.centerx - (font_small.size(cost_text)[0] // 2) - 10
        draw_currency_icon_shop(screen, icon_x, slot_rect.bottom + 15, currency)

        text_color = C_VANG if currency == "VANG" else (0, 200, 255)
        lbl_cost = font_small.render(cost_text, True, text_color)
        screen.blit(lbl_cost, (icon_x + 8, slot_rect.bottom + 15 - lbl_cost.get_height() // 2))

    return item_rects


# --- HÀM CHÍNH VẼ SHOP ---
def draw_shop_menu(screen, screen_width, screen_height, draw_only=False, ITEM_TEMPLATES_REF=None, player_inventory=None):
    global current_shop_tab
    if ITEM_TEMPLATES_REF is None:
        ITEM_TEMPLATES_REF = {}

    W = int(screen_width * 0.75)
    H = int(screen_height * 0.8)
    X = (screen_width - W) // 2
    Y = (screen_height - H) // 2

    menu_rect = pygame.Rect(X, Y, W, H)
    tab_rects = {}

    if not draw_only:
        overlay = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))

    pygame.draw.rect(screen, (50, 50, 50), menu_rect, border_radius=10)
    pygame.draw.rect(screen, C_VANG, menu_rect, 3, border_radius=10)

    title_str = "CỬA HÀNG" if current_shop_tab != "BAN_DO" else "BÁN ĐỒ (HÀNH TRANG)"
    lbl_title = font_title.render(title_str, True, C_VANG)
    screen.blit(lbl_title, (menu_rect.centerx - lbl_title.get_width() // 2, Y + 10))

    tab_start_y = Y + 50
    tab_width = 100
    tab_spacing = 5
    current_x = X + 20

    for tab_key in TAB_TITLES:
        tab_rect = pygame.Rect(current_x, tab_start_y, tab_width, TAB_HEIGHT - 5)

        if tab_key == "BAN_DO":
            color = C_SELL_TAB if tab_key == current_shop_tab else (80, 20, 20)
        else:
            color = C_BLUE_UI if tab_key == current_shop_tab else C_DARK_BG

        border_color = C_VANG if tab_key == current_shop_tab else GRAY

        pygame.draw.rect(screen, color, tab_rect, border_top_left_radius=5, border_top_right_radius=5)
        pygame.draw.rect(screen, border_color, tab_rect, 1, border_top_left_radius=5, border_top_right_radius=5)

        viet_name = tab_key.replace("_", " ").title()
        lbl_tab = font_tab.render(viet_name, True, WHITE)
        screen.blit(lbl_tab, (tab_rect.centerx - lbl_tab.get_width() // 2, tab_rect.centery - lbl_tab.get_height() // 2))

        tab_rects[tab_key] = tab_rect
        current_x += tab_width + tab_spacing

    # NỘI DUNG TAB
    if current_shop_tab == "BAN_DO":
        item_rects = draw_sell_tab_content(screen, menu_rect, player_inventory, ITEM_TEMPLATES_REF)
    else:
        item_rects = draw_shop_tab_content(screen, menu_rect, current_shop_tab, ITEM_TEMPLATES_REF)

    close_text = font_close.render("X", True, WHITE)
    close_rect = close_text.get_rect(topright=(menu_rect.right - 15, menu_rect.top + 10))

    if not draw_only:
        pygame.draw.circle(screen, (200, 50, 50), close_rect.center, 15)
        pygame.draw.circle(screen, WHITE, close_rect.center, 15, 2)
        screen.blit(close_text, close_rect)

    return close_rect, tab_rects, item_rects, current_shop_tab
