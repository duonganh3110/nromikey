
# detu skill popup state
detu_skill_popup = {'show': False, 'skill': None, 'prev_down': False}

# Kỹ năng
try:
    import kynang
except Exception:
    kynang = None
# File: tuido.py (FULL - FIX ICON quần/giày/rada + găng Hoàng Đế vàng giống shop ăn xin)

import pygame
import unicodedata

# [NEW] fusion feature
try:
    import luonglongnhatthe
except Exception:
    luonglongnhatthe = None
import nangchiso  # <--- IMPORT FILE MỚI

# Đệ tử
try:
    import detucoban
except Exception:
    detucoban = None

# --- CẤU HÌNH UI TÚI ĐỒ ---
UI_WIDTH = 600

# debounce click cho nút trạng thái đệ
_prev_mouse_down = False
UI_HEIGHT = 450
TAB_WIDTH = 100
TAB_HEIGHT = 35

# TỶ LỆ CHIA: 30% TRÁI - 70% PHẢI
SPLIT_RATIO = 0.3
WIDTH_LEFT = int(UI_WIDTH * SPLIT_RATIO)
WIDTH_RIGHT = UI_WIDTH - WIDTH_LEFT

COLOR_BG = (30, 30, 40)
COLOR_PANEL_LEFT = (35, 35, 45)
COLOR_BORDER = (255, 215, 0)
COLOR_TAB_ACTIVE = (0, 100, 255)
COLOR_TAB_INACTIVE = (50, 50, 50)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

font_ui = None
font_tiny = None

# Khởi tạo quản lý nâng cấp (sẽ được tạo trong hàm init)
upgrade_manager = None

# Nâng chỉ số cho đệ (tiêu tiềm năng của đệ)
pet_upgrade_manager = None


def init_font(screen_w=800, screen_h=600):
    global font_ui, font_tiny, upgrade_manager, pet_upgrade_manager
    try:
        font_names = ["arial", "tahoma", "segoe ui", "roboto", "sans-serif"]
        found_font = pygame.font.match_font(font_names)
        if found_font:
            font_ui = pygame.font.Font(found_font, 16)
            font_ui.set_bold(True)
            font_tiny = pygame.font.Font(found_font, 11)
        else:
            font_ui = pygame.font.SysFont("Arial", 16, bold=True)
            font_tiny = pygame.font.SysFont("Arial", 11)
    except:
        font_ui = pygame.font.Font(None, 20)
        font_tiny = pygame.font.Font(None, 14)

    # Khởi tạo Manager nếu chưa có
    if upgrade_manager is None:
        upgrade_manager = nangchiso.UpgradeManager(screen_w, screen_h, font_ui, font_tiny)

    if pet_upgrade_manager is None:
        pet_upgrade_manager = nangchiso.UpgradeManager(screen_w, screen_h, font_ui, font_tiny)


def draw_bag_icon(screen, x, y):
    rect = pygame.Rect(x, y, 40, 40)
    pygame.draw.rect(screen, (160, 82, 45), rect, border_radius=5)
    pygame.draw.rect(screen, (200, 200, 200), rect, 2, border_radius=5)
    pygame.draw.rect(screen, (100, 50, 20), (x + 5, y + 5, 30, 20), border_radius=2)
    return rect


def get_grid_geometry(screen_w, screen_h):
    ui_x = (screen_w - UI_WIDTH) // 2
    ui_y = (screen_h - UI_HEIGHT) // 2
    right_panel_x = ui_x + WIDTH_LEFT
    cols = 8
    rows = 5
    slot_sz = 40
    gap = 8
    grid_width = cols * slot_sz + (cols - 1) * gap
    start_x = right_panel_x + (WIDTH_RIGHT - grid_width) // 2
    start_y = ui_y + 60
    return start_x, start_y, slot_sz, gap, cols, rows


def _norm_txt(s: str) -> str:
    s = str(s or "")
    s = unicodedata.normalize("NFD", s)
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")  # bỏ dấu
    return s.lower()


def draw_item_icon_in_bag(screen, x, y, item_data, item_templates):
    """
    Vẽ icon vật phẩm trong túi đồ (đồng bộ style với shop icon)
    FIX: nhận cả key/tên có dấu (quần/giày) + fallback theo tên item
    + FIX: găng Hoàng Đế vẽ màu vàng giống shop ăn xin
    """
    if font_tiny is None:
        init_font()

    if not item_data:
        return

    key = item_data.get("key", "")
    if not key:
        return

    count = item_data.get("count", 1)
    stars = item_data.get("stars", 0)

    template = item_templates.get(key, {})
    rarity = template.get("rarity", WHITE)
    if isinstance(rarity, list):
        rarity = tuple(rarity)

    # normalize: key + name (để bắt được trường hợp key không chứa quan/giay)
    key_norm = _norm_txt(key)
    name_norm = _norm_txt(template.get("name", ""))
    combo = key_norm + " " + name_norm

    cx, cy = x + 20, y + 20

    # 1) POTION
    if "potion" in combo or "thuoc" in combo:
        color = (230, 0, 0) if ("hp" in combo or "mau" in combo) else (0, 120, 255)
        pygame.draw.circle(screen, color, (cx, cy + 3), 9)
        pygame.draw.rect(screen, WHITE, (cx - 3, cy - 8, 6, 6))
        pygame.draw.rect(screen, (139, 69, 19), (cx - 4, cy - 10, 8, 3))
        pygame.draw.circle(screen, (255, 255, 255), (cx + 3, cy), 2)

    # 2) SWORD/KIEM
    elif ("sword" in combo) or ("kiem" in combo):
        pygame.draw.line(screen, (220, 220, 220), (cx - 8, cy + 8), (cx + 8, cy - 8), 4)
        pygame.draw.line(screen, (100, 100, 100), (cx - 8, cy + 8), (cx + 8, cy - 8), 1)
        pygame.draw.line(screen, (139, 69, 19), (cx - 8, cy + 8), (cx - 12, cy + 12), 4)
        pygame.draw.line(screen, (255, 215, 0), (cx - 5, cy + 5), (cx - 10, cy + 10), 6)

    # 3) RADA/RADAR
    elif ("radar" in combo) or ("rada" in combo):
        pygame.draw.circle(screen, (0, 255, 0), (cx, cy), 8, 1)
        pygame.draw.circle(screen, (0, 255, 0), (cx, cy), 3, 1)
        pygame.draw.line(screen, (0, 255, 0), (cx, cy), (cx + 5, cy - 5), 1)

    # 4) GIÀY (ưu tiên trước giáp)
    elif ("giay" in combo) or ("shoe" in combo) or ("boot" in combo):
        pygame.draw.rect(screen, rarity, (cx - 10, cy + 6, 20, 7), border_radius=2)   # đế
        pygame.draw.rect(screen, rarity, (cx - 7, cy + 1, 14, 7), border_radius=2)    # thân
        pygame.draw.rect(screen, (50, 50, 50), (cx - 10, cy + 11, 20, 2))             # line đế

    # 5) QUẦN (ưu tiên trước giáp)
    elif ("quan" in combo) or ("pants" in combo):
        pygame.draw.rect(screen, rarity, (cx - 10, cy - 8, 20, 6), border_radius=2)   # cạp
        pygame.draw.rect(screen, rarity, (cx - 10, cy - 2, 9, 18), border_radius=2)   # ống trái
        pygame.draw.rect(screen, rarity, (cx + 1, cy - 2, 9, 18), border_radius=2)    # ống phải
        pygame.draw.rect(screen, (30, 30, 40), (cx - 1, cy - 2, 2, 12))               # khe giữa

    # 6) GĂNG / GLOVE (găng hoàng đế vàng)
    elif ("gang" in combo) or ("glove" in combo):
        # găng Hoàng Đế
        if ("hoang de" in combo) or ("emperor" in combo):
            gold = (255, 215, 0)
            gold_dark = (150, 120, 0)

            # thân găng (tròn)
            pygame.draw.circle(screen, gold, (cx, cy), 9)
            pygame.draw.circle(screen, gold_dark, (cx, cy), 9, 1)

            # cổ tay
            pygame.draw.rect(screen, gold, (cx - 6, cy + 6, 12, 5), border_radius=3)
            pygame.draw.rect(screen, gold_dark, (cx - 6, cy + 6, 12, 5), 1, border_radius=3)

            # highlight
            pygame.draw.circle(screen, (255, 245, 180), (cx - 3, cy - 2), 2)
            pygame.draw.circle(screen, (255, 245, 180), (cx + 2, cy), 1)
        else:
            # găng thường
            pygame.draw.circle(screen, rarity, (cx, cy), 9)
            pygame.draw.circle(screen, (60, 60, 60), (cx, cy), 9, 1)
            pygame.draw.circle(screen, (30, 30, 30), (cx - 2, cy - 1), 1)
            pygame.draw.circle(screen, (30, 30, 30), (cx + 2, cy - 1), 1)

    # 7) GIÁP / ÁO
    elif any(t in combo for t in ["armor", "ao", "giap"]):
        pygame.draw.rect(screen, rarity, (cx - 8, cy - 10, 16, 18), border_radius=3)  # thân áo
        pygame.draw.rect(screen, rarity, (cx - 12, cy - 8, 4, 8), border_radius=2)   # tay trái
        pygame.draw.rect(screen, rarity, (cx + 8, cy - 8, 4, 8), border_radius=2)    # tay phải
        pygame.draw.rect(screen, (50, 50, 50), (cx - 8, cy + 2, 16, 3))              # line ngang

    # 8) fallback
    else:
        pygame.draw.circle(screen, (100, 100, 100), (cx, cy), 5)

    # số lượng
    if count and count > 1:
        txt_count = font_tiny.render(str(count), True, WHITE)
        screen.blit(txt_count, (x + 38 - txt_count.get_width(), y + 38 - txt_count.get_height()))

    # sao
    if stars and stars > 0:
        star_txt = font_tiny.render(f"{stars}*", True, (255, 215, 0))
        screen.blit(star_txt, (x + 2, y + 2))


def get_slot_index_from_pos(pos, screen_w, screen_h):
    grid_x, grid_y, slot_sz, gap, cols, rows = get_grid_geometry(screen_w, screen_h)
    mx, my = pos
    if mx < grid_x or my < grid_y:
        return -1
    rel_x, rel_y = mx - grid_x, my - grid_y
    col = rel_x // (slot_sz + gap)
    row = rel_y // (slot_sz + gap)
    if 0 <= col < cols and 0 <= row < rows:
        return row * cols + col
    return -1


def draw_main_menu_full(
    screen,
    current_tab_key,
    screen_w,
    screen_h,
    mode="NORMAL",
    data_list=None,
    ITEM_TEMPLATES=None,
    dragging_index=-1,
    player_info=None
):
    if font_ui is None:
        init_font(screen_w, screen_h)
    if data_list is None:
        data_list = []
    if ITEM_TEMPLATES is None:
        ITEM_TEMPLATES = {}

    if mode == "NORMAL":
        tabs_map = {
            "TUI_DO": "HÀNH TRANG",
            "DE_TU": "ĐỆ TỬ",
            "KY_NANG": "KỸ NĂNG",
            "NHIEM_VU": "NHIỆM VỤ",
            "CAI_DAT": "CÀI ĐẶT",
        }
    else:
        tabs_map = {
            "TUI_DO": "HÀNH TRANG",
            "DE_TU": "ĐỆ TỬ",
            "KY_NANG": "KỸ NĂNG",
            "NHIEM_VU": "NHIỆM VỤ",
            "RUONG": "RƯƠNG ĐỒ",
        }

    tab_keys = list(tabs_map.keys())
    x = (screen_w - UI_WIDTH) // 2
    y = (screen_h - UI_HEIGHT) // 2

    # 1. Overlay & Popup (Vẽ Popup Nâng Cấp nếu đang mở)
    if upgrade_manager and upgrade_manager.show_popup:
        upgrade_manager.draw_popup(screen, player_info)
    else:
        overlay = pygame.Surface((screen_w, screen_h))
        overlay.set_alpha(150)
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))

    # 2. Khung chính
    main_rect = pygame.Rect(x, y, UI_WIDTH, UI_HEIGHT)
    pygame.draw.rect(screen, COLOR_BG, main_rect, border_radius=10)

    if current_tab_key in ["TUI_DO", "RUONG"]:
        left_rect = pygame.Rect(x, y, WIDTH_LEFT, UI_HEIGHT)
        pygame.draw.rect(
            screen,
            COLOR_PANEL_LEFT,
            left_rect,
            border_top_left_radius=10,
            border_bottom_left_radius=10,
        )
        split_line_x = x + WIDTH_LEFT
        pygame.draw.line(screen, COLOR_BORDER, (split_line_x, y), (split_line_x, y + UI_HEIGHT), 2)

    pygame.draw.rect(screen, COLOR_BORDER, main_rect, 2, border_radius=10)

    # 3. Tabs
    tab_rects = {}
    start_x = x + 20
    for key in tab_keys:
        name = tabs_map[key]
        t_rect = pygame.Rect(start_x, y - TAB_HEIGHT, TAB_WIDTH, TAB_HEIGHT)
        bg_c = COLOR_TAB_ACTIVE if key == current_tab_key else COLOR_TAB_INACTIVE
        pygame.draw.rect(screen, bg_c, t_rect, border_top_left_radius=8, border_top_right_radius=8)
        pygame.draw.rect(screen, COLOR_BORDER, t_rect, 1, border_top_left_radius=8, border_top_right_radius=8)
        txt = font_ui.render(name, True, WHITE)
        screen.blit(txt, txt.get_rect(center=t_rect.center))
        tab_rects[key] = t_rect
        start_x += TAB_WIDTH + 5

    close_rect = pygame.Rect(x + UI_WIDTH - 30, y - 30, 30, 30)
    pygame.draw.rect(screen, (200, 50, 50), close_rect, border_radius=5)
    txt_x = font_ui.render("X", True, WHITE)
    screen.blit(txt_x, (close_rect.centerx - txt_x.get_width() // 2, close_rect.centery - txt_x.get_height() // 2))

    btn_logout_rect = None

    # --- NỘI DUNG ---
    if current_tab_key in ["TUI_DO", "RUONG"]:
        # VẼ BẢNG NÂNG CẤP Ở BÊN TRÁI 30%
        if player_info and upgrade_manager:
            upgrade_manager.draw_left_panel(screen, x, y, WIDTH_LEFT, player_info)

        # Bên phải: Lưới vật phẩm
        grid_x, grid_y, slot_sz, gap, cols, rows = get_grid_geometry(screen_w, screen_h)
        for r in range(rows):
            for c in range(cols):
                index = r * cols + c
                rx = grid_x + c * (slot_sz + gap)
                ry = grid_y + r * (slot_sz + gap)
                pygame.draw.rect(screen, (50, 50, 60), (rx, ry, slot_sz, slot_sz))
                pygame.draw.rect(screen, (100, 100, 100), (rx, ry, slot_sz, slot_sz), 1)
                if index < len(data_list) and index != dragging_index:
                    item_data = data_list[index]
                    if item_data:
                        draw_item_icon_in_bag(screen, rx, ry, item_data, ITEM_TEMPLATES)

    elif current_tab_key == "DE_TU":
        # --- TAB ĐỆ TỬ ---
        lbl = font_ui.render("ĐỆ TỬ", True, (255, 255, 0))
        screen.blit(lbl, (x + 250, y + 92))

        # --- Ô VUÔNG PLACEHOLDER (Mikey sẽ xử lý sau) ---
        box_size = 30
        box_gap = 8

        # 5 ô vuông xếp ngang (hàng trên)
        row1_total_w = 5 * box_size + 4 * box_gap
        row1_x = x + (UI_WIDTH - row1_total_w) // 2
        row1_y = y + 16

        # [NEW] HOP THE BUTTON (left of slots)
        btn_fuse = pygame.Rect(max(x + 18, row1_x - 170), row1_y + 2, 150, 26)
        det0 = None
        try:
            if detucoban and hasattr(detucoban, 'get_det'):
                det0 = detucoban.get_det()
        except Exception:
            det0 = None
        has_pet_for_fuse = bool(det0)
        try:
            if luonglongnhatthe:
                luonglongnhatthe.draw_fuse_button(screen, btn_fuse, has_pet_for_fuse, player_info, font_ui, font_tiny)
            else:
                pygame.draw.rect(screen, (70, 70, 70), btn_fuse, border_radius=8)
                pygame.draw.rect(screen, (120, 120, 120), btn_fuse, 2, border_radius=8)
                t0 = font_tiny.render('HOP THE', True, WHITE)
                screen.blit(t0, (btn_fuse.centerx - t0.get_width() // 2, btn_fuse.centery - t0.get_height() // 2))
        except Exception:
            pass

        # click hop the (rising edge)
        try:
            mx, my = pygame.mouse.get_pos()
            mouse_down = pygame.mouse.get_pressed(3)[0]
            prev_down = False
            if player_info is not None:
                prev_down = bool(player_info.get('_fusion_prev_down', False))
            if btn_fuse.collidepoint(mx, my) and mouse_down and (not prev_down):
                if player_info is not None and has_pet_for_fuse:
                    if (luonglongnhatthe is None) or luonglongnhatthe.ui_can_click(player_info):
                        player_info['fusion_request'] = True
                        player_info['_close_bag_menu'] = True
            if player_info is not None:
                player_info['_fusion_prev_down'] = mouse_down
        except Exception:
            pass

        for i in range(5):
            r = pygame.Rect(row1_x + i * (box_size + box_gap), row1_y, box_size, box_size)
            pygame.draw.rect(screen, (245, 245, 245), r, border_radius=4)
            pygame.draw.rect(screen, (220, 220, 220), r, 3, border_radius=4)

        # 4 ô vuông xếp ngang (hàng dưới)
        row2_total_w = 4 * box_size + 3 * box_gap
        row2_x = x + (UI_WIDTH - row2_total_w) // 2
        row2_y = row1_y + box_size + 10

        for j in range(4):
            r = pygame.Rect(row2_x + j * (box_size + box_gap), row2_y, box_size, box_size)
            pygame.draw.rect(screen, (245, 245, 245), r, border_radius=4)
            pygame.draw.rect(screen, (220, 220, 220), r, 3, border_radius=4)
        
            # --- [KY NANG] Hiển thị đòn đệ tử ở hàng 4 ô (đặt ở ô ngoài cùng bên trái) ---
            try:
                if player_info and kynang is not None:
                    detu_sid = player_info.get('detu_skill_id')
                    detu_slot = 0  # ép hiển thị ở ô ngoài cùng bên trái (index=0)
                    if detu_slot < 0:
                        detu_slot = 0
                    if detu_slot > 3:
                        detu_slot = 3
                    if detu_sid and j == detu_slot:
                        sk = kynang.get_skill_by_id(detu_sid)
                        if sk:
                            pygame.draw.rect(screen, (0, 120, 255), r, border_radius=4)
                            pygame.draw.rect(screen, (255, 215, 0), r, 2, border_radius=4)
                            lab = 'G'
                            _id = str(sk.get('id','')).lower()
                            if 'dragon' in _id:
                                lab = 'DR'
                            elif 'demon' in _id:
                                lab = 'DE'
                            elif 'galick' in _id:
                                lab = 'G'
                            t = font_tiny.render(lab, True, (255, 255, 255))
                            screen.blit(t, (r.centerx - t.get_width()//2, r.centery - t.get_height()//2))
                            # click xem thong tin ky nang (no accent)
                            mx, my = pygame.mouse.get_pos()
                            mouse_down = pygame.mouse.get_pressed(3)[0]
                            if r.collidepoint(mx, my) and mouse_down and (not detu_skill_popup.get('_prev_down_skill', False)):
                                detu_skill_popup['show'] = True
                                detu_skill_popup['skill'] = sk
                                detu_skill_popup['_skill_rect'] = r.copy()
                            detu_skill_popup['_prev_down_skill'] = mouse_down
            except Exception:
                pass
        # ve bang thong tin ky nang de tu (popup) - CO DINH 1 VI TRI, CLICK RA NGOAI TU DONG DONG
        # (khong theo chuot, khong can chuot phai)
        if detu_skill_popup.get('show') and detu_skill_popup.get('skill'):
            sk2 = detu_skill_popup.get('skill')
            mx, my = pygame.mouse.get_pos()
            mouse_down2 = pygame.mouse.get_pressed(3)[0]

            # vi tri co dinh (goc tren ben phai trong khung UI)
            pw, ph = 220, 80
            pr = pygame.Rect(x + UI_WIDTH - pw - 18, y + 48, pw, ph)

            pygame.draw.rect(screen, (30, 30, 40), pr, border_radius=6)
            pygame.draw.rect(screen, (255, 215, 0), pr, 2, border_radius=6)

            t1 = font_tiny.render('Skill: ' + str(sk2.get('name','Skill')), True, (255,255,255))
            t2 = font_tiny.render('DMG: ' + str(sk2.get('damage_pct',100)) + '%', True, (200,200,200))
            screen.blit(t1, (pr.x + 8, pr.y + 8))
            screen.blit(t2, (pr.x + 8, pr.y + 32))
            # click chuột trái -> đóng popup (rising edge)
            # (trừ khi click đúng vào ô kỹ năng vừa mở, để tránh tắt ngay trong frame mở)
            if mouse_down2 and (not detu_skill_popup.get('_prev_down_popup', False)):
                skill_rect = detu_skill_popup.get('_skill_rect')
                clicked_skill = isinstance(skill_rect, pygame.Rect) and skill_rect.collidepoint(mx, my)
                if not clicked_skill:
                    detu_skill_popup['show'] = False
                    detu_skill_popup['skill'] = None

            # cập nhật debounce (riêng cho popup)
            detu_skill_popup['_prev_down_popup'] = mouse_down2

# lấy info đệ
        det = None
        mode_key = None
        mode_label = "Đi theo"
        if detucoban:
            try:
                det = detucoban.get_det()
            except Exception:
                det = None
            try:
                mode_key = detucoban.get_mode() if hasattr(detucoban, "get_mode") else None
                mode_label = detucoban.get_mode_label() if hasattr(detucoban, "get_mode_label") else mode_label
            except Exception:
                mode_key = None

        
        # --- NÂNG CHỈ SỐ ĐỆ (tiêu Tiềm năng của đệ) ---
        if pet_upgrade_manager is None:
            # phòng khi init_font chưa chạy
            try:
                init_font(screen_w, screen_h)
            except Exception:
                pass

        __pet_info_cache = None
        __pet_trigger_save = None

        if det and pet_upgrade_manager:
            # map info đệ -> cấu trúc giống nangchiso.py
            try:
                __pet_info_cache = {
                    "tiem_nang": int(getattr(det, "tiem_nang", 0)),
                    "max_hp": int(getattr(det, "hp_max", 0)),
                    "max_ki": int(getattr(det, "ki_max", 0)),
                    "suc_danh": int(getattr(det, "suc_danh", 0)),
                    "hp": int(getattr(det, "hp", int(getattr(det, "hp_max", 0)))),
                    "ki": int(getattr(det, "ki", int(getattr(det, "ki_max", 0)))),
                }
            except Exception:
                __pet_info_cache = None

            def __pet_trigger_save():
                # sync ngược lại vào detucoban
                if not det or __pet_info_cache is None:
                    return
                try:
                    det.tiem_nang = int(__pet_info_cache.get("tiem_nang", getattr(det, "tiem_nang", 0)))
                    det.hp_max = int(__pet_info_cache.get("max_hp", getattr(det, "hp_max", 0)))
                    det.ki_max = int(__pet_info_cache.get("max_ki", getattr(det, "ki_max", 0)))
                    det.suc_danh = int(__pet_info_cache.get("suc_danh", getattr(det, "suc_danh", 0)))

                    # cộng HP/KI hiện tại theo logic nangchiso (info['hp']/['ki'] đã tăng trong manager)
                    det.hp = min(det.hp_max, int(__pet_info_cache.get("hp", getattr(det, "hp", det.hp_max))))
                    det.ki = min(det.ki_max, int(__pet_info_cache.get("ki", getattr(det, "ki", det.ki_max))))

                    # update dmg display
                    try:
                        det.dmg_min = det.suc_danh
                        det.dmg_max = det.suc_danh
                    except Exception:
                        pass

                    # save
                    if detucoban:
                        if hasattr(detucoban, "trigger_save"):
                            detucoban.trigger_save()
                        elif hasattr(detucoban, "_save"):
                            detucoban._save()
                except Exception:
                    pass

        # Draw popup overlay của đệ (nếu mở)
        if pet_upgrade_manager and pet_upgrade_manager.show_popup and __pet_info_cache is not None:
            try:
                pet_upgrade_manager.draw_popup(screen, __pet_info_cache)
            except Exception:
                pass

        # vùng hiển thị gọn lên trên
        base_x = x + 70
        base_y = y + 130

        if not det:
            screen.blit(font_ui.render("Chưa có đệ tử", True, WHITE), (base_x, base_y))
        else:
            planet = getattr(det, "planet", "Trai Dat")

            # stats (tách 3 hàng)
            hp = int(getattr(det, "hp", getattr(det, "hp_max", 0)))
            hp_max = int(getattr(det, "hp_max", hp))
            ki = int(getattr(det, "ki", getattr(det, "ki_max", 0)))
            ki_max = int(getattr(det, "ki_max", ki))

            # SD gọn: nếu min=max thì 1 số
            try:
                sd_min = int(getattr(det, "dmg_min", getattr(det, "suc_danh", 0)))
                sd_max = int(getattr(det, "dmg_max", sd_min))
            except Exception:
                sd_min, sd_max = 0, 0
            sd_txt = str(sd_min) if sd_min == sd_max else f"{sd_min}-{sd_max}"

            sm = int(getattr(det, "suc_manh", 0))
            tn = int(getattr(det, "tiem_nang", 0))

            screen.blit(font_ui.render(f"Đệ tử: đệ {planet}", True, WHITE), (base_x, base_y))
            screen.blit(font_ui.render(f"Trạng thái: {mode_label}", True, WHITE), (base_x, base_y + 30))
            # Panel nâng chỉ số (tiêu tiềm năng) - giống nangchiso.py
            if pet_upgrade_manager and __pet_info_cache is not None:
                try:
                    pet_upgrade_manager.draw_left_panel(screen, x + UI_WIDTH - 250 - 25, base_y + 15, 250, __pet_info_cache)
                except Exception:
                    pass
            screen.blit(font_ui.render(f"HP: {hp}/{hp_max}", True, WHITE), (base_x, base_y + 65))
            screen.blit(font_ui.render(f"KI: {ki}/{ki_max}", True, WHITE), (base_x, base_y + 95))
            screen.blit(font_ui.render(f"SĐ: {sd_txt}", True, WHITE), (base_x, base_y + 125))
            screen.blit(font_ui.render(f"Sức mạnh: {sm}", True, WHITE), (base_x, base_y + 165))
            screen.blit(font_ui.render(f"Tiềm năng: {tn}", True, WHITE), (base_x, base_y + 195))
            # --- NÚT TRẠNG THÁI (NRO style) ---
        # 2 hàng 2 cột cho gọn
        btn_w, btn_h = 210, 40
        gap = 18
        bx1 = x + 70
        bx2 = bx1 + btn_w + gap
        by1 = y + UI_HEIGHT - 130
        by2 = by1 + btn_h + 14

        btn_follow = pygame.Rect(bx1, by1, btn_w, btn_h)
        btn_protect = pygame.Rect(bx2, by1, btn_w, btn_h)
        btn_attack = pygame.Rect(bx1, by2, btn_w, btn_h)
        btn_home = pygame.Rect(bx2, by2, btn_w, btn_h)

        def _draw_btn(r, text, active=False, disabled=False):
            if disabled:
                bg = (70, 70, 70)
                bd = (120, 120, 120)
            else:
                bg = (50, 160, 50) if active else (60, 60, 90)
                bd = (255, 255, 255) if active else (200, 200, 200)
            pygame.draw.rect(screen, bg, r, border_radius=8)
            pygame.draw.rect(screen, bd, r, 2, border_radius=8)
            t = font_ui.render(text, True, WHITE)
            screen.blit(t, (r.centerx - t.get_width() // 2, r.centery - t.get_height() // 2))

        has_pet = bool(det)

        _draw_btn(btn_follow, "Đi theo", active=(mode_key == "THEO"), disabled=not has_pet)
        _draw_btn(btn_protect, "Bảo vệ", active=(mode_key == "BAO_VE"), disabled=not has_pet)
        _draw_btn(btn_attack, "Tấn công", active=(mode_key == "TAN_CONG"), disabled=not has_pet)
        _draw_btn(btn_home, "Về nhà", active=(mode_key == "VE_NHA"), disabled=not has_pet)

        # click xử lý ngay trong draw (debounce) để khỏi phải sửa game_loop
        global _prev_mouse_down
        mx, my = pygame.mouse.get_pos()
        mouse_down = pygame.mouse.get_pressed(3)[0]

        # click nâng chỉ số đệ (tiêu tiềm năng) - bắt chước nangchiso.py
        if mouse_down and not _prev_mouse_down and pet_upgrade_manager and __pet_info_cache is not None:
            try:
                ev = pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=(mx, my), button=1)
                pet_upgrade_manager.handle_event(ev, __pet_info_cache, __pet_trigger_save)
            except Exception:
                pass

        if mouse_down and not _prev_mouse_down and has_pet and detucoban and hasattr(detucoban, "set_mode"):
            if btn_follow.collidepoint(mx, my):
                detucoban.set_mode("THEO")
            elif btn_protect.collidepoint(mx, my):
                detucoban.set_mode("BAO_VE")
            elif btn_attack.collidepoint(mx, my):
                detucoban.set_mode("TAN_CONG")
            elif btn_home.collidepoint(mx, my):
                detucoban.set_mode("VE_NHA")

        _prev_mouse_down = mouse_down

    elif current_tab_key == "KY_NANG":
        # --- TAB KỸ NĂNG ---
        if kynang is None:
            lbl = font_ui.render("Thiếu file kynang.py", True, (255, 255, 0))
            screen.blit(lbl, (x + 230, y + 120))
        else:
            try:
                planet = None
                if player_info:
                    planet = player_info.get("phai") or player_info.get("hanh_tinh") or player_info.get("planet")
                kynang.draw_skill_tab(screen, x, y, UI_WIDTH, UI_HEIGHT, player_info=player_info, planet=planet, font_ui=font_ui, font_tiny=font_tiny)
            except Exception:
                lbl = font_ui.render("Lỗi tab KỸ NĂNG", True, (255, 255, 0))
                screen.blit(lbl, (x + 240, y + 120))

    elif current_tab_key == "CAI_DAT":
        lbl = font_ui.render("CẤU HÌNH TRÒ CHƠI", True, (255, 255, 0))
        screen.blit(lbl, (x + 200, y + 100))
        pygame.draw.rect(screen, (50, 150, 50), (x + 150, y + 150, 300, 40))
        screen.blit(font_ui.render("Âm thanh: BẬT", True, WHITE), (x + 230, y + 160))

        btn_logout_rect = pygame.Rect(x + 150, y + 300, 300, 50)
        pygame.draw.rect(screen, (200, 50, 50), btn_logout_rect, border_radius=5)
        pygame.draw.rect(screen, WHITE, btn_logout_rect, 2, border_radius=5)
        txt_logout = font_ui.render("ĐĂNG XUẤT", True, WHITE)
        screen.blit(
            txt_logout,
            (btn_logout_rect.centerx - txt_logout.get_width() // 2, btn_logout_rect.centery - txt_logout.get_height() // 2),
        )



    return tab_rects, close_rect, btn_logout_rect


def draw_dragging_item(screen, mouse_pos, item_data, ITEM_TEMPLATES):
    mx, my = mouse_pos
    draw_item_icon_in_bag(screen, mx - 20, my - 20, item_data, ITEM_TEMPLATES)
