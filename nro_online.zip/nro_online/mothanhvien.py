import pygame
import os
import sys

# Đảm bảo có thể truy cập các biến Global và module Vang
try:
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.join(current_dir, '..')
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)
    import vang 
except Exception as e:
    pass

# --- CẤU HÌNH VIP ---
VIP_COST = 50000
VIP_CURRENCY = "VND"
TITLE_TEXT = "BẠN CẦN MỞ THÀNH VIÊN VIP"

# COLORS
C_BG = (10, 10, 30, 240)
C_BORDER = (255, 255, 0)
C_TITLE = (255, 100, 0)
C_GUIDE = (200, 200, 200)
C_BTN_BUY = (0, 150, 0)
C_BTN_HOVER = (0, 200, 0)
C_BTN_CLOSE = (180, 50, 50)
WHITE = (255, 255, 255)

# Kích thước
POPUP_W = 400
POPUP_H = 250

def draw_vip_popup(screen, screen_w, screen_h, font_title, font_small, player_data, mouse_pos):
    """Vẽ pop-up mua thành viên VIP"""
    
    X = (screen_w - POPUP_W) // 2
    Y = (screen_h - POPUP_H) // 2
    popup_rect = pygame.Rect(X, Y, POPUP_W, POPUP_H)

    # 1. Nền
    surface = pygame.Surface((POPUP_W, POPUP_H), pygame.SRCALPHA)
    surface.fill(C_BG)
    screen.blit(surface, (X, Y))
    pygame.draw.rect(screen, C_BORDER, popup_rect, 2, border_radius=5)

    # 2. Tiêu đề
    lbl_title = font_title.render(TITLE_TEXT, True, C_TITLE)
    screen.blit(lbl_title, (popup_rect.centerx - lbl_title.get_width()//2, Y + 15))

    # 3. Nội dung và giá
    cost_str = f"{VIP_COST:,}"
    currency_name = "VND"
    
    # Dòng 1: Cần mở khóa
    lbl_feature = font_small.render("Bạn cần mở thành viên VIP để mở chức năng này.", True, C_GUIDE)
    screen.blit(lbl_feature, (X + 20, Y + 70))
    
    # Dòng 2: Giá
    lbl_cost = font_small.render(f"Giá mở thành viên: {cost_str}", True, C_BORDER)
    screen.blit(lbl_cost, (X + 20, Y + 100))
    
    # Icon VND
    icon_x = X + 20 + lbl_cost.get_width() + 10
    # [FIX] Đảm bảo hàm vang.draw_currency_icon có đủ tham số (cx, cy, currency_type)
    vang.draw_currency_icon(screen, icon_x, Y + 100 + 8, VIP_CURRENCY)

    # 4. Nút MUA
    btn_w, btn_h = 150, 40
    btn_buy_rect = pygame.Rect(popup_rect.centerx - btn_w//2, Y + POPUP_H - 60, btn_w, btn_h)
    
    can_afford = player_data.get(VIP_CURRENCY.lower(), 0) >= VIP_COST
    
    color_btn = C_BTN_BUY if can_afford else (100, 100, 100)
    if can_afford and btn_buy_rect.collidepoint(mouse_pos):
        color_btn = C_BTN_HOVER
        
    pygame.draw.rect(screen, color_btn, btn_buy_rect, border_radius=5)
    
    buy_text = font_small.render("MUA NGAY", True, WHITE)
    if not can_afford:
        buy_text = font_small.render("THIẾU VND", True, (200, 200, 200))
        
    screen.blit(buy_text, buy_text.get_rect(center=btn_buy_rect.center))

    # 5. Nút Đóng (X)
    close_rect = pygame.Rect(X + POPUP_W - 30, Y + 10, 20, 20)
    pygame.draw.circle(screen, C_BTN_CLOSE, close_rect.center, 10)

    return close_rect, btn_buy_rect, can_afford

def handle_buy_vip(player_data, can_afford):
    """Thực hiện giao dịch mua VIP"""
    if not can_afford:
        return False, "Không đủ VND để mở thành viên VIP!"

    if vang.deduct_currency(player_data, cost_vnd=VIP_COST):
        player_data["is_vip"] = True
        return True, "Chúc mừng! Bạn đã mở thành viên VIP!"
    else:
        return False, "Lỗi giao dịch trừ VND."