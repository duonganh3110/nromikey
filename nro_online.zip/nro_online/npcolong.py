# npcolong.py
# NPC Olong - THONG BAO BOSS (UI SYNC)
# v8: Làm lại bảng (layout đồng bộ theo kích thước màn hình, không nhấp nháy)
# - Panel & bảng tự canh theo screen size (không hardcode nhiều số)
# - handle_event KHÔNG vẽ (chỉ hit-test) -> hết nhấp nháy/đè
# - Luôn có 2 dòng: BROLY + S.BROLY (dễ mở rộng sau này)
# - Có dòng "USER: duong anh" ở bên trái bảng

import pygame
from typing import Optional, List, Tuple

VERSION = "npcolong_v8_ui_sync"

# -------------------- USER DISPLAY --------------------
DISPLAY_USER_NAME = "duong anh"  # Mikey muốn đổi thì sửa dòng này


def set_user_name(name: str):
    global DISPLAY_USER_NAME
    DISPLAY_USER_NAME = str(name)


# -------------------- NPC CONFIG --------------------
NPC_OFFSET_FROM_GATE = 300
DEFAULT_GATE_X_WORLD = 50
NPC_W, NPC_H = 60, 90
INTERACT_DISTANCE = 170

_npc_x_world = DEFAULT_GATE_X_WORLD + NPC_OFFSET_FROM_GATE

# -------------------- UI STATE --------------------
_show_ui = False
_alerts: List[Tuple[int, str]] = []  # (tick, boss_name)

_font_title = None
_font_head = None
_font_row = None
_font_small = None

_last_panel_rect: Optional[pygame.Rect] = None
_last_close_rect: Optional[pygame.Rect] = None

# Boss list (sau này thêm boss chỉ cần append)
_BOSS_DEFS = [
    {"key": "BROLY", "label": "BROLY"},
    {"key": "SUPER_BROLY", "label": "S.BROLY"},
]


# -------------------- PUBLIC API --------------------
def set_gateway_x(gateway_x_world: int):
    global _npc_x_world
    _npc_x_world = int(gateway_x_world) + NPC_OFFSET_FROM_GATE


def set_world_x(world_x: int):
    global _npc_x_world
    _npc_x_world = int(world_x)


def is_open() -> bool:
    return _show_ui


def notify_boss_spawn(boss_name: str, current_time: Optional[int] = None):
    global _alerts
    if current_time is None:
        current_time = pygame.time.get_ticks()
    _alerts.append((int(current_time), str(boss_name)))
    _alerts = _alerts[-6:]


# -------------------- INTERNAL HELPERS --------------------
def _ensure_fonts(screen: pygame.Surface):
    """Font scale theo kích thước màn hình để 'đồng bộ'."""
    global _font_title, _font_head, _font_row, _font_small
    if _font_title and _font_head and _font_row and _font_small:
        return

    base = min(screen.get_width(), screen.get_height())
    title_sz = max(34, base // 12)     # ~44 khi base ~540
    head_sz = max(16, base // 30)      # ~18
    row_sz = max(15, base // 32)       # ~17
    small_sz = max(13, base // 38)     # ~14

    try:
        _font_title = pygame.font.SysFont("Arial", title_sz, bold=True)
        _font_head = pygame.font.SysFont("Arial", head_sz, bold=True)
        _font_row = pygame.font.SysFont("Arial", row_sz, bold=True)
        _font_small = pygame.font.SysFont("Arial", small_sz)
    except Exception:
        _font_title = pygame.font.Font(None, title_sz + 12)
        _font_head = pygame.font.Font(None, head_sz + 6)
        _font_row = pygame.font.Font(None, row_sz + 6)
        _font_small = pygame.font.Font(None, small_sz + 6)


def _fmt_mmss(seconds: int) -> str:
    seconds = max(0, int(seconds))
    return f"{seconds // 60:02d}:{seconds % 60:02d}"


def _get_spawn_interval_ms():
    """Lấy SPAWN_INTERVAL từ boss module nếu có."""
    for mod_name in ("bossbroly_super50", "bossbroly"):
        try:
            mod = __import__(mod_name)
            return int(getattr(mod, "SPAWN_INTERVAL", 15 * 60 * 1000))
        except Exception:
            continue
    return 15 * 60 * 1000


def _get_last_spawn_time(broly_manager) -> int:
    if broly_manager is None:
        return 0
    for attr in ("last_spawn_time", "last_boss_spawn_time", "last_broly_spawn_time", "last_spawn"):
        if hasattr(broly_manager, attr):
            try:
                return int(getattr(broly_manager, attr) or 0)
            except Exception:
                pass
    return 0


def _boss_key_from_obj(boss) -> str:
    """Nhận diện boss hiện tại là BROLY hay SUPER_BROLY."""
    if boss is None:
        return ""
    bt = getattr(boss, "boss_type", None)
    if bt:
        s = str(bt).lower()
        if "super" in s and "broly" in s:
            return "SUPER_BROLY"
        if "broly" in s:
            return "BROLY"

    nd = getattr(boss, "name_display", None) or getattr(boss, "name", None) or ""
    s = str(nd).lower()
    if "super" in s and "broly" in s:
        return "SUPER_BROLY"
    if "broly" in s:
        return "BROLY"

    cn = boss.__class__.__name__.lower()
    if "super" in cn and "broly" in cn:
        return "SUPER_BROLY"
    if "broly" in cn:
        return "BROLY"
    return ""


def _collect_rows(broly_manager, current_time: int):
    """Trả list dict: name/status/remain."""
    spawn_interval = _get_spawn_interval_ms()

    if broly_manager is None:
        return [{"name": b["label"], "status": "Chưa kích hoạt", "remain": "--:--"} for b in _BOSS_DEFS]

    boss = getattr(broly_manager, "boss", None)
    alive = bool(boss) and (not getattr(boss, "is_dead", False))

    if not alive:
        last_spawn = _get_last_spawn_time(broly_manager)
        elapsed = max(0, int(current_time) - int(last_spawn))
        remain_sec = max(0, (spawn_interval - elapsed) // 1000)
        remain = _fmt_mmss(remain_sec)
        return [{"name": b["label"], "status": "ĐANG CHỜ", "remain": remain} for b in _BOSS_DEFS]

    active = _boss_key_from_obj(boss)
    rows = []
    for b in _BOSS_DEFS:
        if b["key"] == active:
            rows.append({"name": b["label"], "status": "ĐANG XUẤT HIỆN", "remain": "00:00"})
        else:
            # theo yêu cầu Mikey: boss kia "không có" (trống cũng được, nhưng để rõ)
            rows.append({"name": b["label"], "status": "", "remain": "--:--"})
    return rows


# -------------------- GEOMETRY --------------------
def _calc_panel_rect(sw: int, sh: int) -> pygame.Rect:
    """Panel gần full màn hình nhưng luôn chừa viền đều để 'đồng bộ'."""
    margin = max(26, int(min(sw, sh) * 0.05))
    pw = sw - margin * 2
    ph = sh - margin * 2
    return pygame.Rect(margin, margin, pw, ph)


def _calc_close_rect(panel: pygame.Rect) -> pygame.Rect:
    size = max(34, int(panel.width * 0.05))
    return pygame.Rect(panel.right - size - 14, panel.y + 14, size, int(size * 0.82))


def _get_npc_rect_screen(map_offset_x: int, ground_y: int) -> pygame.Rect:
    sx = int(_npc_x_world - map_offset_x)
    sy = int(ground_y - NPC_H)
    return pygame.Rect(sx - NPC_W // 2, sy, NPC_W, NPC_H)


# -------------------- DRAW NPC --------------------
def draw_npc(screen: pygame.Surface, map_offset_x: int, ground_y: int, current_time: Optional[int] = None):
    """Vẽ NPC Olong trên map (vẽ tay)."""
    if current_time is None:
        current_time = pygame.time.get_ticks()

    rect = _get_npc_rect_screen(map_offset_x, ground_y)
    if rect.right < -100 or rect.left > screen.get_width() + 100:
        return

    bob = int((pygame.time.get_ticks() // 250) % 2) * 1
    cx = rect.centerx
    top = rect.y + bob

    PINK = (255, 190, 200)
    PINK2 = (255, 160, 175)
    OUTLINE = (30, 30, 30)
    SHIRT = (70, 130, 200)
    PANTS = (60, 60, 80)
    HAT = (40, 180, 120)
    YELLOW = (255, 220, 60)
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)

    sh_surf = pygame.Surface((50, 18), pygame.SRCALPHA)
    pygame.draw.ellipse(sh_surf, (0, 0, 0, 70), (5, 4, 40, 10))
    screen.blit(sh_surf, (cx - 25, rect.bottom - 12))

    body_rect = pygame.Rect(cx - 18, top + 32, 36, 40)
    pygame.draw.ellipse(screen, PINK, body_rect)
    pygame.draw.ellipse(screen, OUTLINE, body_rect, 2)

    shirt_rect = pygame.Rect(cx - 20, top + 40, 40, 24)
    pygame.draw.rect(screen, SHIRT, shirt_rect, border_radius=8)
    pygame.draw.rect(screen, OUTLINE, shirt_rect, 2, border_radius=8)

    pygame.draw.rect(screen, PANTS, (cx - 16, top + 64, 14, 22), border_radius=5)
    pygame.draw.rect(screen, PANTS, (cx + 2, top + 64, 14, 22), border_radius=5)
    pygame.draw.rect(screen, OUTLINE, (cx - 16, top + 64, 14, 22), 2, border_radius=5)
    pygame.draw.rect(screen, OUTLINE, (cx + 2, top + 64, 14, 22), 2, border_radius=5)

    pygame.draw.circle(screen, PINK, (cx, top + 20), 18)
    pygame.draw.circle(screen, OUTLINE, (cx, top + 20), 18, 2)

    pygame.draw.ellipse(screen, PINK, (cx - 24, top + 10, 10, 18))
    pygame.draw.ellipse(screen, PINK, (cx + 14, top + 10, 10, 18))
    pygame.draw.ellipse(screen, OUTLINE, (cx - 24, top + 10, 10, 18), 2)
    pygame.draw.ellipse(screen, OUTLINE, (cx + 14, top + 10, 10, 18), 2)

    pygame.draw.ellipse(screen, PINK2, (cx - 10, top + 22, 20, 12))
    pygame.draw.ellipse(screen, OUTLINE, (cx - 10, top + 22, 20, 12), 2)
    pygame.draw.circle(screen, OUTLINE, (cx - 4, top + 28), 2)
    pygame.draw.circle(screen, OUTLINE, (cx + 4, top + 28), 2)

    pygame.draw.circle(screen, WHITE, (cx - 6, top + 18), 4)
    pygame.draw.circle(screen, WHITE, (cx + 6, top + 18), 4)
    pygame.draw.circle(screen, BLACK, (cx - 5, top + 19), 2)
    pygame.draw.circle(screen, BLACK, (cx + 5, top + 19), 2)

    pygame.draw.rect(screen, HAT, (cx - 18, top + 2, 36, 10), border_radius=5)
    pygame.draw.rect(screen, OUTLINE, (cx - 18, top + 2, 36, 10), 2, border_radius=5)
    pygame.draw.rect(screen, HAT, (cx - 10, top - 6, 20, 10), border_radius=5)
    pygame.draw.rect(screen, OUTLINE, (cx - 10, top - 6, 20, 10), 2, border_radius=5)
    pygame.draw.circle(screen, YELLOW, (cx, top - 4), 3)
    pygame.draw.circle(screen, OUTLINE, (cx, top - 4), 3, 1)

    _ensure_fonts(screen)
    tag = _font_small.render("BOSS", True, (255, 255, 255))
    pad = 6
    tag_rect = pygame.Rect(cx - tag.get_width() // 2 - pad, rect.y - 22, tag.get_width() + pad * 2, 18)
    pygame.draw.rect(screen, (200, 60, 60), tag_rect, border_radius=6)
    pygame.draw.rect(screen, OUTLINE, tag_rect, 2, border_radius=6)
    screen.blit(tag, (tag_rect.x + pad, tag_rect.y + 2))


# -------------------- DRAW UI --------------------
def _draw_panel(screen: pygame.Surface, broly_manager, current_time: int):
    global _last_panel_rect, _last_close_rect

    _ensure_fonts(screen)
    sw, sh = screen.get_width(), screen.get_height()

    panel = _calc_panel_rect(sw, sh)
    close_rect = _calc_close_rect(panel)
    _last_panel_rect = panel.copy()
    _last_close_rect = close_rect.copy()

    # overlay
    overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 120))
    screen.blit(overlay, (0, 0))

    # panel
    pygame.draw.rect(screen, (245, 245, 245), panel, border_radius=18)
    pygame.draw.rect(screen, (20, 20, 20), panel, 4, border_radius=18)

    # close
    pygame.draw.rect(screen, (220, 70, 70), close_rect, border_radius=10)
    pygame.draw.rect(screen, (20, 20, 20), close_rect, 2, border_radius=10)
    x_txt = _font_head.render("X", True, (255, 255, 255))
    screen.blit(x_txt, (close_rect.centerx - x_txt.get_width() // 2, close_rect.centery - x_txt.get_height() // 2))

    # title
    title = _font_title.render("THONG BAO BOSS", True, (200, 30, 30))
    title_y = panel.y + max(10, int(panel.height * 0.03))
    screen.blit(title, (panel.centerx - title.get_width() // 2, title_y))

    # user label (trái)
    user_y = title_y + title.get_height() + 6
    user_txt = _font_head.render(f"USER: {DISPLAY_USER_NAME}", True, (40, 40, 40))
    screen.blit(user_txt, (panel.x + 40, user_y))

    # separator
    sep_y = user_y + user_txt.get_height() + 10
    pygame.draw.line(screen, (0, 0, 0), (panel.x + 30, sep_y), (panel.right - 30, sep_y), 3)

    # header positions
    header_y = sep_y + 12
    col1 = panel.x + 40
    col2 = panel.x + int(panel.width * 0.42)
    col3 = panel.x + int(panel.width * 0.76)

    screen.blit(_font_head.render("BOSS", True, (30, 30, 30)), (col1, header_y))
    screen.blit(_font_head.render("TRANG THAI", True, (30, 30, 30)), (col2, header_y))
    screen.blit(_font_head.render("CON", True, (30, 30, 30)), (col3, header_y))

    underline_y = header_y + _font_head.get_height() + 8
    pygame.draw.line(screen, (120, 120, 120), (panel.x + 30, underline_y), (panel.right - 30, underline_y), 2)

    # rows
    rows = _collect_rows(broly_manager, current_time)
    y = underline_y + 12
    row_h = max(28, int(panel.height * 0.055))
    for i, r in enumerate(rows):
        row_rect = pygame.Rect(panel.x + 26, y - 4, panel.width - 52, row_h)
        if i % 2 == 0:
            pygame.draw.rect(screen, (235, 235, 235), row_rect, border_radius=10)

        status_text = str(r["status"])
        if "XUẤT HIỆN" in status_text:
            status_col = (25, 130, 25)
        elif "CHỜ" in status_text:
            status_col = (180, 90, 20)
        else:
            status_col = (120, 120, 120)

        screen.blit(_font_row.render(str(r["name"]), True, (0, 0, 0)), (col1, y))
        screen.blit(_font_row.render(status_text, True, status_col), (col2, y))
        screen.blit(_font_row.render(str(r["remain"]), True, (0, 0, 0)), (col3, y))
        y += row_h

    # alerts box
    alerts_top = panel.bottom - max(150, int(panel.height * 0.22))
    pygame.draw.line(screen, (120, 120, 120), (panel.x + 30, alerts_top), (panel.right - 30, alerts_top), 2)

    screen.blit(_font_head.render("Thong bao gan day", True, (30, 30, 30)), (panel.x + 40, alerts_top + 10))

    if not _alerts:
        screen.blit(_font_small.render("- (Chua co thong bao) -", True, (80, 80, 80)), (panel.x + 45, alerts_top + 40))
    else:
        dy = alerts_top + 38
        for t, bn in _alerts[-5:][::-1]:
            screen.blit(_font_small.render(f"+ {bn} xuat hien (tick {t})", True, (40, 40, 40)), (panel.x + 45, dy))
            dy += _font_small.get_height() + 4

    screen.blit(_font_small.render("Click X hoac click ra ngoai de dong.", True, (60, 60, 60)),
                (panel.x + 40, panel.bottom - (_font_small.get_height() + 12)))

    return panel, close_rect


def draw_ui_if_open(screen: pygame.Surface, broly_manager, current_time: Optional[int] = None):
    if not _show_ui:
        return None
    if current_time is None:
        current_time = pygame.time.get_ticks()
    return _draw_panel(screen, broly_manager, current_time)


# -------------------- EVENT HANDLER (NO DRAW) --------------------
def handle_event(
    event: pygame.event.Event,
    map_offset_x: int,
    ground_y: int,
    player_world_x: Optional[int] = None,
    broly_manager=None,
    current_time: Optional[int] = None,
):
    """Trả True nếu đã xử lý click.
    QUAN TRỌNG: main.py nên 'continue' khi hàm này trả True.
    """
    global _show_ui

    if current_time is None:
        current_time = pygame.time.get_ticks()

    if event.type != pygame.MOUSEBUTTONDOWN:
        return False

    mx, my = event.pos

    # UI đang mở: hit-test bằng rect cache (không vẽ)
    if _show_ui:
        surf = pygame.display.get_surface()
        if surf is None:
            _show_ui = False
            return True

        panel = _last_panel_rect.copy() if _last_panel_rect else _calc_panel_rect(surf.get_width(), surf.get_height())
        close_rect = _last_close_rect.copy() if _last_close_rect else _calc_close_rect(panel)

        if close_rect.collidepoint(mx, my):
            _show_ui = False
            return True
        if not panel.collidepoint(mx, my):
            _show_ui = False
            return True
        return True  # click trong panel thì chặn luôn

    # UI chưa mở -> click NPC
    npc_rect = _get_npc_rect_screen(map_offset_x, ground_y)
    if npc_rect.collidepoint(mx, my):
        if player_world_x is None or abs(int(player_world_x) - int(_npc_x_world)) <= INTERACT_DISTANCE:
            _show_ui = True
            return True

    return False
