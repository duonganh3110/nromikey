# masenko.py
# Skill Masenko (Namec) - quả cầu đỏ (đậm + sáng hơn) + ghim mục tiêu
# Module hiệu ứng/skill để tích hợp vào game.
#
# Interface:
#   - request_cast(origin_world, target_obj=None, aim_dir=None) -> bool
#   - update(dt, origin_world=None, aim_dir=None)
#   - consume_fire() -> bool  (True đúng 1 lần lúc impact)
#   - get_last_impact_screen(map_offset_x, map_offset_y=0) -> (x_screen, y_screen) | None
#   - draw(screen, cam_off=pygame.Vector2(-map_offset_x, 0))
#
# Cooldown mặc định: 1.0s | damage_pct mặc định: 100 (tham khảo; damage thật nên lấy từ kynang)

import math
import random
import pygame


# ===== TUNE COLORS HERE (đậm/sáng) =====
ORB_BASE = (255, 30, 30)          # đỏ đậm
ORB_HIGHLIGHT = (255, 190, 190)   # highlight
GLOW_CORE = (255, 40, 40)
GLOW_MID = (255, 70, 30)          # đỏ cam để "sáng" hơn nhưng vẫn đỏ
GLOW_SOFT = (255, 35, 35)

PARTICLE_RED = (255, 45, 45)
PARTICLE_ORANGE = (255, 120, 40)
RING_BRIGHT = (255, 90, 50)
RING_DARK = (255, 35, 35)


def clamp(x, a, b):
    return a if x < a else b if x > b else x


def lerp(a, b, t):
    return a + (b - a) * t


def lerp2(p, q, t):
    return (lerp(p[0], q[0], t), lerp(p[1], q[1], t))


def ease_out_cubic(t):
    t = clamp(t, 0.0, 1.0)
    return 1.0 - (1.0 - t) ** 3


def v_sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def v_len(a):
    return math.hypot(a[0], a[1])


def v_norm(a):
    l = v_len(a)
    if l <= 1e-9:
        return (0.0, 0.0)
    return (a[0] / l, a[1] / l)


def v_perp(a):
    return (-a[1], a[0])


def make_radial_glow(radius, color, alpha=220, power=2.4):
    """Radial glow (RGBA) for additive blit. power lớn => lõi đậm, rìa mịn."""
    r = int(radius)
    size = r * 2 + 2
    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    cx, cy = size // 2, size // 2
    for i in range(r, 0, -1):
        k = (i / r) ** power
        a = int(alpha * k)
        pygame.draw.circle(surf, (color[0], color[1], color[2], a), (cx, cy), i)
    return surf


class Particle:
    __slots__ = ("pos", "vel", "life", "age", "radius", "color", "drag", "grow")

    def __init__(self, pos, vel, life, radius, color, drag=0.98, grow=0.0):
        self.pos = [float(pos[0]), float(pos[1])]
        self.vel = [float(vel[0]), float(vel[1])]
        self.life = float(life)
        self.age = 0.0
        self.radius = float(radius)
        self.color = color
        self.drag = float(drag)
        self.grow = float(grow)

    def update(self, dt):
        self.age += dt
        if self.age >= self.life:
            return False
        self.vel[0] *= self.drag
        self.vel[1] *= self.drag
        self.pos[0] += self.vel[0] * dt
        self.pos[1] += self.vel[1] * dt
        self.radius = max(0.0, self.radius + self.grow * dt)
        return True


class Ring:
    __slots__ = ("pos", "radius", "speed", "life", "age", "thick", "color")

    def __init__(self, pos, radius0, speed, life, thick, color):
        self.pos = (float(pos[0]), float(pos[1]))
        self.radius = float(radius0)
        self.speed = float(speed)
        self.life = float(life)
        self.age = 0.0
        self.thick = float(thick)
        self.color = color

    def update(self, dt):
        self.age += dt
        if self.age >= self.life:
            return False
        self.radius += self.speed * dt
        return True


class _MasenkoOrb:
    def __init__(self, start_pos, target_pos, travel_time=0.18):
        self.start = (float(start_pos[0]), float(start_pos[1]))
        self.target = (float(target_pos[0]), float(target_pos[1]))
        self.t = 0.0
        self.travel_time = max(0.05, float(travel_time))
        d = v_sub(self.target, self.start)
        nd = v_norm(d)
        self.perp = v_perp(nd)
        self.arc = random.uniform(-1.0, 1.0) * random.uniform(14.0, 32.0) * (1.0 + clamp(v_len(d) / 500.0, 0.0, 1.0))
        self.done = False

    def update(self, dt):
        self.t += dt
        if self.t >= self.travel_time:
            self.t = self.travel_time
            self.done = True

    def pos(self):
        u = self.t / self.travel_time
        e = ease_out_cubic(u)
        base = lerp2(self.start, self.target, e)
        bulge = math.sin(math.pi * u) * self.arc
        return (base[0] + self.perp[0] * bulge, base[1] + self.perp[1] * bulge)


class MasenkoSkill:
    def __init__(self, damage_pct=100, cooldown_s=1.0, charge_time=0.20, impact_time=0.18, max_range=260):
        self.damage_pct = int(damage_pct)
        self.cooldown_s = float(cooldown_s)
        self.charge_time = float(charge_time)
        self.impact_time = float(impact_time)
        self.max_range = float(max_range)

        # Glow đậm hơn (tăng alpha + lõi rõ)
        self.glow_core = make_radial_glow(14, GLOW_CORE, alpha=255, power=2.8)
        self.glow_mid = make_radial_glow(30, GLOW_MID, alpha=190, power=2.2)
        self.glow_soft = make_radial_glow(54, GLOW_SOFT, alpha=120, power=2.0)

        self.state = "IDLE"
        self.cooldown_remain = 0.0
        self.charge_t = 0.0
        self.impact_t = 0.0

        self._fire_event = False
        self._last_impact_world = None

        self._origin_world = pygame.Vector2(0, 0)
        self._aim_dir = pygame.Vector2(1, 0)
        self._target_obj = None  # expect .rect in WORLD coords
        self._orb = None

        self.particles = []
        self.rings = []

    def is_ready(self):
        return (self.cooldown_remain <= 0.0) and (self.state == "IDLE")

    def request_cast(self, origin_world, target_obj=None, aim_dir=None):
        if not self.is_ready():
            return False
        try:
            self._origin_world = pygame.Vector2(origin_world)
        except Exception:
            return False

        self._target_obj = target_obj
        if aim_dir is not None:
            try:
                v = pygame.Vector2(aim_dir)
                if v.length_squared() > 1e-9:
                    self._aim_dir = v.normalize()
            except Exception:
                pass

        if (self._target_obj is None) and (self._aim_dir.length_squared() <= 1e-9):
            return False

        self.state = "CHARGING"
        self.charge_t = 0.0
        self._fire_event = False
        return True

    def _spawn_charge_fx(self, center):
        # hút hạt vào tay (đậm hơn)
        for _ in range(8):
            ang = random.random() * math.tau
            r = random.uniform(8, 26)
            px = center[0] + math.cos(ang) * r
            py = center[1] + math.sin(ang) * r
            vx = (center[0] - px)
            vy = (center[1] - py)
            nx, ny = v_norm((vx, vy))
            spd = random.uniform(150, 280)
            vel = (nx * spd + random.uniform(-40, 40), ny * spd + random.uniform(-40, 40))
            col = PARTICLE_ORANGE if random.random() < 0.35 else PARTICLE_RED
            self.particles.append(Particle((px, py), vel, random.uniform(0.10, 0.18), random.uniform(2.0, 4.5), col, drag=0.88, grow=-7.0))

    def _spawn_trail_fx(self, pos):
        # trail đậm
        for _ in range(4):
            vel = (random.uniform(-60, 60), random.uniform(-60, 60))
            col = PARTICLE_ORANGE if random.random() < 0.25 else PARTICLE_RED
            self.particles.append(Particle(pos, vel, random.uniform(0.12, 0.24), random.uniform(3.0, 6.5), col, drag=0.90, grow=-9.0))

    def _spawn_impact_fx(self, pos):
        self.rings.append(Ring(pos, radius0=12, speed=760, life=0.22, thick=5, color=RING_BRIGHT))
        self.rings.append(Ring(pos, radius0=22, speed=480, life=0.28, thick=3, color=RING_DARK))
        for _ in range(56):
            ang = random.random() * math.tau
            spd = random.uniform(260, 620)
            vel = (math.cos(ang) * spd, math.sin(ang) * spd)
            life = random.uniform(0.18, 0.34)
            rad = random.uniform(2.0, 4.8)
            col = PARTICLE_ORANGE if random.random() < 0.35 else PARTICLE_RED
            self.particles.append(Particle(pos, vel, life, rad, col, drag=0.88, grow=-6.0))

    def _compute_target_world(self):
        if self._target_obj is not None:
            try:
                r = self._target_obj.rect
                return (float(r.centerx), float(r.centery))
            except Exception:
                pass
        d = self._aim_dir
        if d.length_squared() <= 1e-9:
            d = pygame.Vector2(1, 0)
        return (float(self._origin_world.x + d.x * self.max_range), float(self._origin_world.y + d.y * self.max_range))

    def update(self, dt, origin_world=None, aim_dir=None):
        dt = float(dt)
        if self.cooldown_remain > 0.0:
            self.cooldown_remain = max(0.0, self.cooldown_remain - dt)

        if origin_world is not None:
            try:
                self._origin_world = pygame.Vector2(origin_world)
            except Exception:
                pass
        if aim_dir is not None:
            try:
                v = pygame.Vector2(aim_dir)
                if v.length_squared() > 1e-9:
                    self._aim_dir = v.normalize()
            except Exception:
                pass

        self.particles = [p for p in self.particles if p.update(dt)]
        self.rings = [r for r in self.rings if r.update(dt)]

        if self.state == "CHARGING":
            self.charge_t += dt
            center = (float(self._origin_world.x), float(self._origin_world.y))
            self._spawn_charge_fx(center)
            u = clamp(self.charge_t / self.charge_time, 0.0, 1.0)
            # ring gồng (đỏ cam)
            if random.random() < 0.55:
                self.rings.append(Ring(center, radius0=10 + 26 * u, speed=220 + 300 * u, life=0.12, thick=2, color=RING_BRIGHT))

            if self.charge_t >= self.charge_time:
                tpos = self._compute_target_world()
                dist = v_len(v_sub(tpos, center))
                travel = clamp(0.14 + dist / 2200.0, 0.14, 0.26)
                self._orb = _MasenkoOrb(center, tpos, travel_time=travel)
                self.state = "FIRING"

        elif self.state == "FIRING":
            if self._orb is not None:
                self._orb.update(dt)
                pos = self._orb.pos()
                self._spawn_trail_fx(pos)
                if self._orb.done:
                    impact_pos = self._orb.target
                    self._last_impact_world = pygame.Vector2(impact_pos[0], impact_pos[1])
                    self._spawn_impact_fx(impact_pos)
                    self._orb = None
                    self._fire_event = True
                    self.impact_t = 0.0
                    self.state = "IMPACT"
                    self.cooldown_remain = max(self.cooldown_remain, self.cooldown_s)

        elif self.state == "IMPACT":
            self.impact_t += dt
            if self.impact_t >= self.impact_time:
                self.state = "IDLE"

    def consume_fire(self):
        if self._fire_event:
            self._fire_event = False
            return True
        return False

    def get_last_impact_screen(self, map_offset_x: float, map_offset_y: float = 0.0):
        if self._last_impact_world is None:
            return None
        return (float(self._last_impact_world.x - map_offset_x), float(self._last_impact_world.y - map_offset_y))

    def draw(self, screen, cam_off=None):
        if cam_off is None:
            cam_off = pygame.Vector2(0, 0)

        # rings (additive)
        tmp = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
        for r in self.rings:
            t = r.age / r.life if r.life > 1e-9 else 1.0
            a = int(230 * (1.0 - t))
            if a <= 0:
                continue
            rr = int(r.radius)
            thick = max(1, int(r.thick))
            size = rr * 2 + thick * 2 + 4
            srf = pygame.Surface((size, size), pygame.SRCALPHA)
            cx, cy = size // 2, size // 2
            pygame.draw.circle(srf, (r.color[0], r.color[1], r.color[2], a), (cx, cy), rr, thick)
            x = (r.pos[0] + cam_off.x) - cx
            y = (r.pos[1] + cam_off.y) - cy
            tmp.blit(srf, (x, y))
        screen.blit(tmp, (0, 0), special_flags=pygame.BLEND_ADD)

        # particles (additive)
        tmp2 = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
        for p in self.particles:
            t = p.age / p.life if p.life > 1e-9 else 1.0
            a = int(220 * (1.0 - t))
            if a <= 0:
                continue
            pygame.draw.circle(
                tmp2,
                (p.color[0], p.color[1], p.color[2], a),
                (int(p.pos[0] + cam_off.x), int(p.pos[1] + cam_off.y)),
                max(1, int(p.radius)),
            )
        screen.blit(tmp2, (0, 0), special_flags=pygame.BLEND_ADD)

        # orb (đỏ đậm + glow đỏ cam)
        if self._orb is not None:
            pos = self._orb.pos()
            x = int(pos[0] + cam_off.x)
            y = int(pos[1] + cam_off.y)

            screen.blit(self.glow_soft, (x - self.glow_soft.get_width() // 2, y - self.glow_soft.get_height() // 2), special_flags=pygame.BLEND_ADD)
            screen.blit(self.glow_mid, (x - self.glow_mid.get_width() // 2, y - self.glow_mid.get_height() // 2), special_flags=pygame.BLEND_ADD)
            screen.blit(self.glow_core, (x - self.glow_core.get_width() // 2, y - self.glow_core.get_height() // 2), special_flags=pygame.BLEND_ADD)

            # thân cầu (đậm)
            pygame.draw.circle(screen, ORB_BASE, (x, y), 12)
            pygame.draw.circle(screen, (255, 90, 60), (x, y), 12, 2)   # viền sáng
            pygame.draw.circle(screen, (140, 0, 0), (x + 2, y + 2), 12, 2)  # viền tối tăng depth
            pygame.draw.circle(screen, ORB_HIGHLIGHT, (x - 4, y - 4), 3)

            # tia nhỏ cho "sáng hơn"
            if random.random() < 0.35:
                ang = random.random() * math.tau
                rx = x + int(math.cos(ang) * 10)
                ry = y + int(math.sin(ang) * 10)
                pygame.draw.line(screen, (255, 140, 90), (x, y), (rx, ry), 2)

        # charge glow ở tay (đậm)
        if self.state in ("CHARGING", "FIRING"):
            hx = int(self._origin_world.x + cam_off.x)
            hy = int(self._origin_world.y + cam_off.y)
            screen.blit(self.glow_mid, (hx - self.glow_mid.get_width() // 2, hy - self.glow_mid.get_height() // 2), special_flags=pygame.BLEND_ADD)
            screen.blit(self.glow_core, (hx - self.glow_core.get_width() // 2, hy - self.glow_core.get_height() // 2), special_flags=pygame.BLEND_ADD)
