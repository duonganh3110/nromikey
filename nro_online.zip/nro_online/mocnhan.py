import pygame

# --- CẤU HÌNH MỘC NHÂN ---
HP_MAX = 10 
WIDTH = 40
HEIGHT = 60
COLOR_WOOD = (139, 69, 19)
COLOR_HP_BG = (50, 0, 0)
COLOR_HP = (255, 0, 0)
WHITE = (255, 255, 255)
GREEN_REGEN = (0, 255, 0)
NAME_COLOR = (255, 255, 0)

font_tiny = None
font_name = None

def init_font():
    global font_tiny, font_name
    if font_tiny is None:
        try:
            pygame.font.init()
            font_tiny = pygame.font.SysFont("Arial", 10)
            font_name = pygame.font.SysFont("Arial", 12, bold=True)
        except pygame.error:
            # Fallback nếu không thể khởi tạo font
            font_tiny = None
            font_name = None

class MocNhan:
    def __init__(self, x, y):
        self.world_x = x 
        self.rect = pygame.Rect(x, y - HEIGHT, WIDTH, HEIGHT)
        self.hp = HP_MAX
        self.is_hit = False
        self.hit_timer = 0
        self.respawn_timer = 0
        
        self.last_damage_time = 0
        self.regen_tick_timer = 0
        
        self.name = "Moc Nhan"
        self.level = 1
        self.rect.y = y - HEIGHT
        
        # [FIX ATTRIBUTE ERROR] Thêm thuộc tính is_dead
        self.is_dead = False 


    def take_damage(self, amount):
        real_damage = 1 
        
        if self.hp > 0:
            self.hp -= real_damage
            self.is_hit = True
            current_time = pygame.time.get_ticks()
            self.hit_timer = current_time
            self.last_damage_time = current_time
            
            if self.hp <= 0:
                self.hp = 0
                # [FIX] Cập nhật trạng thái chết
                self.is_dead = True 
                self.respawn_timer = current_time

    def update(self, map_offset_x): 
        current_time = pygame.time.get_ticks()
        
        # Cập nhật vị trí trên màn hình dựa trên world_x và offset
        self.rect.x = self.world_x - map_offset_x

        if self.is_hit:
            if current_time - self.hit_timer > 100:
                self.is_hit = False
        
        # [LOGIC HỒI SINH MỘC NHÂN]
        if self.hp <= 0:
            # Hồi sinh sau 5s
            if current_time - self.respawn_timer > 5000:
                self.hp = HP_MAX
                self.last_damage_time = current_time
                self.level += 1 
                self.world_x = self.rect.x + map_offset_x 
                # [FIX] Đặt lại trạng thái sống
                self.is_dead = False 
        
        elif self.hp < HP_MAX:
            # Tự hồi phục nếu không bị đánh (sau 5s không bị đánh)
            if current_time - self.last_damage_time > 5000:
                if current_time - self.regen_tick_timer > 500:
                    self.hp += 2 
                    if self.hp > HP_MAX:
                        self.hp = HP_MAX
                    self.regen_tick_timer = current_time

    def draw_target_indicator(self, screen):
        """Vẽ mũi tên ghim mục tiêu trên đầu quái"""
        if self.hp <= 0: return
        
        x = self.rect.centerx
        y = self.rect.y - 30 
        
        if pygame.display.get_init():
            YELLOW = (255, 255, 0)
            pygame.draw.polygon(screen, YELLOW, [
                (x, y), 
                (x - 5, y + 10), 
                (x + 5, y + 10)
            ])


    def draw(self, screen):
        init_font()
        draw_x = self.rect.x 
        draw_y = self.rect.y
        
        if -50 < draw_x < screen.get_width():
            offset_shake = 2 if self.is_hit else 0
            
            if self.hp > 0:
                # Ve ten
                if font_name:
                    name_text = f"{self.name} [Lv {self.level}]"
                    txt_surf = font_name.render(name_text, True, NAME_COLOR)
                    name_rect = txt_surf.get_rect(center=(draw_x + WIDTH // 2 + offset_shake, draw_y - 35))
                    screen.blit(txt_surf, name_rect)
                
                # Ve Moc Nhan
                pygame.draw.rect(screen, (100, 50, 0), (draw_x - 10 + offset_shake, draw_y + HEIGHT - 5, WIDTH + 20, 5))
                pygame.draw.rect(screen, COLOR_WOOD, (draw_x + offset_shake, draw_y, WIDTH, HEIGHT))
                pygame.draw.circle(screen, COLOR_WOOD, (draw_x + WIDTH//2 + offset_shake, draw_y), 15)
                pygame.draw.line(screen, (100, 50, 0), (draw_x - 10 + offset_shake, draw_y + 20), (draw_x + WIDTH + 10 + offset_shake, draw_y + 20), 4)

                # Ve thanh mau
                hp_width = 40
                hp_fill = max(0, (self.hp / HP_MAX) * hp_width)
                hp_bar_y = draw_y - 15
                
                pygame.draw.rect(screen, COLOR_HP_BG, (draw_x, hp_bar_y, hp_width, 5))
                is_regenerating = (pygame.time.get_ticks() - self.last_damage_time > 5000) and (self.hp < HP_MAX)
                current_hp_color = GREEN_REGEN if is_regenerating else COLOR_HP
                pygame.draw.rect(screen, current_hp_color, (draw_x, hp_bar_y, hp_fill, 5))
                pygame.draw.rect(screen, (0,0,0), (draw_x, hp_bar_y, hp_width, 5), 1)
                
                # Hien thi so mau 10/10
                if font_tiny:
                    hp_text = f"{self.hp}/{HP_MAX}"
                    txt_hp = font_tiny.render(hp_text, True, WHITE)
                    screen.blit(txt_hp, (draw_x + WIDTH//2 - txt_hp.get_width()//2, hp_bar_y - 12))

            else:
                # Quai chet, ve thoi gian hoi sinh
                pygame.draw.rect(screen, (80, 80, 80), (draw_x, draw_y + 40, WIDTH, 20))
                time_left = 5 - (pygame.time.get_ticks() - self.respawn_timer) / 1000
                if time_left < 0: time_left = 0
                if font_tiny:
                    txt = font_tiny.render(f"Hoi sinh: {time_left:.1f}s", True, WHITE)
                    screen.blit(txt, (draw_x - 10, draw_y + 20))