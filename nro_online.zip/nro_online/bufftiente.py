# File: bufftiente.py (Phiên bản đã FIX lỗi khởi tạo biến)

import pygame
import json
import os
import re

# --- UTILITIES ---
# Màu sắc
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (150, 150, 150)
BLUE_UI = (0, 150, 255)
GREEN_SUCCESS = (0, 180, 0)
RED_ERROR = (200, 0, 0)
C_VANG = (255, 255, 0)

def load_json(filename):
    """Tải dữ liệu từ file JSON."""
    if os.path.exists(filename):
        with open(filename, 'r', encoding='utf-8') as f:
            try: return json.load(f)
            except json.JSONDecodeError: return {}
    return {}

def save_json(filename, data):
    """Lưu dữ liệu vào file JSON."""
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def ve_nut_custom(screen, rect, color, text, text_color=BLACK, font_obj=None):
    """Vẽ nút bấm đơn giản."""
    pygame.draw.rect(screen, color, rect, border_radius=5)
    if font_obj and text:
        text_surf = font_obj.render(text, True, text_color)
        screen.blit(text_surf, (rect.centerx - text_surf.get_width() // 2, rect.centery - text_surf.get_height() // 2))

class BuffManager:
    def __init__(self, data_char_file, font, font_small, InputBox_class):
        self.DATA_CHAR_FILE = data_char_file
        self.font = font
        self.font_small = font_small
        self.InputBox = InputBox_class

        # [FIXED] Khởi tạo các biến trạng thái UI trước khi gọi reload_data
        self.selected_user = None
        self.selected_user_details = None
        
        self.reload_data()
        
        # UI State (Cập nhật sau khi reload_data chạy)
        self.message = "Chon tai khoan va nhap lenh buff (VD: vang5000 hoac vnd10000)"
        self.message_color = WHITE
        
        # Input for Buff Command
        self.input_box = self.InputBox(300, 550, 300, 30, text="")
        self.btn_rect = pygame.Rect(610, 550, 100, 30) # BUFF button position

    def reload_data(self):
        """Tải lại danh sách tài khoản và nhân vật, đọc đúng cấu trúc."""
        data_char = load_json(self.DATA_CHAR_FILE)
        self.users = []
        
        # Cấu trúc: {user: {char_name: {data}}}
        for user, chars in data_char.items():
            if user != "admin" and isinstance(chars, dict) and chars:
                # Tìm tên nhân vật (Giả định mỗi user có một nhân vật)
                char_name = next(iter(chars.keys()))
                char_data = chars.get(char_name, {})
                
                # Đọc các giá trị tiền tệ từ data nhân vật (cấp độ 2)
                vang = char_data.get("vang", 0)
                kim_cuong = char_data.get("kim_cuong", 0)
                vnd = char_data.get("vnd", 0)
                
                self.users.append({
                    "username": user, 
                    "char_name": char_name,
                    "vang": vang,
                    "kim_cuong": kim_cuong,
                    "vnd": vnd,
                    "color": WHITE
                })
        
        # Cập nhật lại chi tiết người dùng sau khi reload
        if self.selected_user:
            current_details = next((u for u in self.users if u['username'] == self.selected_user), None)
            if current_details:
                self.selected_user_details = current_details
            else:
                self.selected_user = None

    def parse_and_buff(self, command):
        """Phân tích cú pháp và thực hiện buff tiền tệ."""
        command = command.lower().replace(" ", "")
        
        # Định nghĩa các tiền tệ và key tương ứng
        CURRENCY_MAP = {
            "vang": "vang",
            "kc": "kim_cuong",
            "vnd": "vnd",
            # Thêm các tiền tệ khác nếu cần
        }
        
        if not self.selected_user or not self.selected_user_details:
            return "Vui long chon tai khoan truoc!", RED_ERROR

        user = self.selected_user
        char_name = self.selected_user_details['char_name']
        
        data_key = None
        amount = 0
        prefix_used = ""
        
        # --- PARSE COMMAND ---
        for prefix, key in CURRENCY_MAP.items():
            if command.startswith(prefix):
                try:
                    amount_str = command[len(prefix):]
                    amount = int(amount_str)
                    data_key = key
                    prefix_used = prefix
                    break
                except ValueError:
                    return f"So luong cho '{prefix}' khong hop le!", RED_ERROR
        
        if not data_key or amount <= 0:
            return "Lenh buff khong hop le. VD: vang5000 hoac vnd2000", RED_ERROR

        # --- APPLY BUFF ---
        try:
            data_char = load_json(self.DATA_CHAR_FILE)
            
            # [FIXED] TRUY CẬP VÀ CẬP NHẬT Ở CẤP ĐỘ NHÂN VẬT (Level 2)
            if user in data_char and char_name in data_char[user] and isinstance(data_char[user][char_name], dict):
                char_data = data_char[user][char_name]
                
                # Khởi tạo key nếu thiếu và cộng thêm số lượng
                current_value = char_data.get(data_key, 0)
                char_data[data_key] = current_value + amount
                
                # Lưu dữ liệu
                data_char[user][char_name] = char_data
                save_json(self.DATA_CHAR_FILE, data_char)
                
                currency_label = prefix_used.upper() 
                return f"Buff thanh cong {amount} {currency_label} cho TK {user} ({char_name})!", GREEN_SUCCESS
            else:
                return f"Loi: Du lieu nhan vat '{char_name}' bi hong hoac chua tao!", RED_ERROR

        except Exception as e:
            return f"Loi he thong khi buff: {e}", RED_ERROR


    def draw(self, screen):
        """Vẽ giao diện Buff Tiền Tệ."""
        PANEL_X, PANEL_Y, W, H = 160, 50, 630, 540
        
        # Draw background panel
        pygame.draw.rect(screen, (30, 30, 30), (PANEL_X, PANEL_Y, W, H), border_radius=5)
        pygame.draw.rect(screen, (255, 215, 0), (PANEL_X, PANEL_Y, W, H), 2)
        
        # Title
        lbl_title = self.font.render("BUFF TIEN TE", True, (0, 150, 0))
        screen.blit(lbl_title, (170, 60))
        
        # Header cho Danh sách
        lbl_acc = self.font_small.render("TAI KHOAN", True, C_VANG); screen.blit(lbl_acc, (170, 100))
        lbl_nv = self.font_small.render("TEN NV", True, C_VANG); screen.blit(lbl_nv, (300, 100))
        lbl_vang = self.font_small.render("VANG", True, C_VANG); screen.blit(lbl_vang, (420, 100))
        lbl_kc = self.font_small.render("KC", True, C_VANG); screen.blit(lbl_kc, (540, 100))
        lbl_vnd = self.font_small.render("VND", True, C_VANG); screen.blit(lbl_vnd, (660, 100))
        pygame.draw.line(screen, WHITE, (160, 120), (790, 120), 1)

        # Danh sách người dùng
        y_start = 125
        list_rects = {}
        for i, user_data in enumerate(self.users):
            rect = pygame.Rect(160, y_start + i * 35, 630, 30)
            if rect.bottom > 490: break 

            color = BLUE_UI if user_data['username'] == self.selected_user else (60, 60, 60)
            pygame.draw.rect(screen, color, rect, border_radius=3)
            
            lbl_u = self.font_small.render(user_data['username'], True, WHITE); screen.blit(lbl_u, (170, rect.y + 5))
            lbl_c = self.font_small.render(user_data['char_name'], True, WHITE); screen.blit(lbl_c, (300, rect.y + 5))
            
            # Hiển thị tiền tệ
            screen.blit(self.font_small.render(f"{user_data['vang']:,}", True, C_VANG), (420, rect.y + 5))
            screen.blit(self.font_small.render(f"{user_data['kim_cuong']:,}", True, (0, 200, 255)), (540, rect.y + 5))
            screen.blit(self.font_small.render(f"{user_data['vnd']:,}", True, (0, 150, 0)), (660, rect.y + 5))
            
            list_rects[user_data['username']] = rect
            
            if user_data['username'] == self.selected_user:
                self.selected_user_details = user_data 
        
        # --- Khu vực Input Buff (Đẩy xuống dưới cùng) ---
        X_INPUT = 170 
        Y_INPUT = 550 
        
        # Message Area
        lbl_msg = self.font_small.render(self.message, True, self.message_color)
        screen.blit(lbl_msg, (X_INPUT, 520)) 

        # Input Box và Button
        self.input_box.rect.x = X_INPUT
        self.input_box.rect.y = Y_INPUT
        self.input_box.update()
        self.input_box.draw(screen)

        # Nút BUFF
        self.btn_rect = pygame.Rect(self.input_box.rect.right + 10, Y_INPUT, 100, 30)
        ve_nut_custom(screen, self.btn_rect, GREEN_SUCCESS, "BUFF", WHITE, self.font_small)
        
        return list_rects

    def handle_event(self, event):
        """Xử lý sự kiện chuột và bàn phím."""
        screen = pygame.display.get_surface()
        list_rects = self.draw(screen)

        # 1. Xử lý InputBox
        self.input_box.handle_event(event)

        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = event.pos

            # 2. Xử lý click chọn người dùng
            clicked_user = None
            for user, rect in list_rects.items():
                if rect.collidepoint(mx, my):
                    clicked_user = user
                    break
            
            if clicked_user:
                self.selected_user = clicked_user
                # Tự tìm index
                self.selected_index = next((i for i, u in enumerate(self.users) if u['username'] == clicked_user), -1)
                self.message = f"Da chon TK {clicked_user}. Nhap lenh buff."
                self.message_color = BLUE_UI

            # 3. Xử lý click nút BUFF
            if self.btn_rect.collidepoint(mx, my):
                command = self.input_box.text
                new_msg, new_color = self.parse_and_buff(command)
                self.message = new_msg
                self.message_color = new_color
                if new_color == GREEN_SUCCESS:
                    self.input_box.text = ""
                    self.reload_data() # Quan trọng: Reload data để cập nhật số tiền trên UI
                    
                # Cập nhật surface text của InputBox sau khi buff
                self.input_box.update()

            return True

        if event.type == pygame.KEYDOWN:
            if self.input_box.active and event.key == pygame.K_RETURN:
                command = self.input_box.text
                new_msg, new_color = self.parse_and_buff(command)
                self.message = new_msg
                self.message_color = new_color
                
                if new_color == GREEN_SUCCESS:
                    self.input_box.text = ""
                    self.reload_data()
                
                # Cập nhật surface text của InputBox
                self.input_box.update()
                return True

        return False