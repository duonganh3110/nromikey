import pygame

# --- MÀU SẮC ĐẶC TRƯNG CỦA ÔNG GOHAN ---
C_HAT_GREEN = (34, 139, 34)      # Mũ xanh lá
C_FACE_MASK = (255, 250, 240)    # Mặt nạ trắng
C_ORANGE_GI = (255, 140, 0)      # Áo cam
C_PANTS_PURPLE = (75, 0, 130)    # Quần tím than
BLACK = (0, 0, 0)
RED_ACCENT = (200, 0, 0)

# Vị trí: Cách rương (x=20) một khoảng. Đặt tại 150 là hợp lý.
GOHAN_X_WORLD = 150 
NPC_WIDTH = 40
NPC_HEIGHT = 55

def get_npc_rect(map_offset_x, ground_y):
    """Tính toán khung hình chữ nhật của NPC trên màn hình"""
    screen_x = GOHAN_X_WORLD - map_offset_x
    screen_y = ground_y - NPC_HEIGHT
    return pygame.Rect(screen_x, screen_y, NPC_WIDTH, NPC_HEIGHT)

def draw_npc(screen, map_offset_x, ground_y):
    """Vẽ Ông Nội Gohan (Style Mặt nạ cáo)"""
    npc_rect = get_npc_rect(map_offset_x, ground_y)
    
    # Kiểm tra nếu NPC nằm ngoài màn hình thì không vẽ để tối ưu
    if npc_rect.right < 0 or npc_rect.left > 800: # 800 là screen_width
        return

    cx = npc_rect.centerx
    y = npc_rect.y

    # 1. Chân (Quần tím)
    pygame.draw.rect(screen, C_PANTS_PURPLE, (cx - 12, y + 35, 10, 20))
    pygame.draw.rect(screen, C_PANTS_PURPLE, (cx + 2, y + 35, 10, 20))

    # 2. Thân (Áo cam)
    pygame.draw.rect(screen, C_ORANGE_GI, (cx - 15, y + 15, 30, 25))
    # Đai lưng đen
    pygame.draw.rect(screen, BLACK, (cx - 15, y + 30, 30, 5))

    # 3. Đầu (Mặt nạ cáo trắng)
    pygame.draw.circle(screen, C_FACE_MASK, (cx, y + 10), 14)
    # Họa tiết trên mặt nạ (Mắt cáo)
    pygame.draw.line(screen, BLACK, (cx - 8, y + 8), (cx - 3, y + 10), 2)
    pygame.draw.line(screen, BLACK, (cx + 8, y + 8), (cx + 3, y + 10), 2)
    # Mũi đỏ
    pygame.draw.circle(screen, RED_ACCENT, (cx, y + 12), 2)

    # 4. Mũ (Xanh lá - đặc trưng Gohan)
    pygame.draw.ellipse(screen, C_HAT_GREEN, (cx - 16, y - 5, 32, 15)) # Vành mũ
    pygame.draw.circle(screen, C_HAT_GREEN, (cx, y - 2), 10) # Chóp mũ
    # Cục tròn đỏ trên mũ
    pygame.draw.circle(screen, RED_ACCENT, (cx, y - 8), 3)

    # 5. Halo (Vòng thiên thần - nếu muốn, ở đây vẽ đơn giản không có halo)
    
    # Hiển thị tên
    font_name = pygame.font.SysFont("Arial", 12, bold=True)
    text = font_name.render("Ong Gohan", True, (255, 255, 0))
    screen.blit(text, (cx - text.get_width()//2, y - 15))

def check_click(pos, map_offset_x, ground_y):
    """Kiểm tra xem người chơi có click vào NPC không"""
    npc_rect = get_npc_rect(map_offset_x, ground_y)
    if npc_rect.collidepoint(pos):
        return True
    return False