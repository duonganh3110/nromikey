import pygame

# --- CẤU HÌNH ---
POPUP_WIDTH = 400
POPUP_HEIGHT = 300
C_BG_POPUP = (40, 40, 50)
C_BORDER = (255, 215, 0) # Vàng
C_TEXT_TITLE = (255, 100, 100) # Đỏ nhạt
C_TEXT_INFO = (255, 255, 255)
C_BTN_CLOSE = (200, 50, 50)

# --- MAPPING ID (TẠM THỜI) ---
def get_item_real_id(key):
    # Theo yêu cầu: Kiếm gỗ là ID 1
    if key == "sword_1": return "1"
    # Các món khác chưa định nghĩa
    return "?"

def draw_item_detail_popup(screen, item_key, ITEM_TEMPLATES, screen_w, screen_h, font_title, font_small):
    """Vẽ bảng chi tiết vật phẩm giữa màn hình"""
    
    # 1. Vẽ nền tối làm mờ phía sau
    overlay = pygame.Surface((screen_w, screen_h), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 150))
    screen.blit(overlay, (0, 0))

    # 2. Tính toán khung bảng (giữa màn hình)
    popup_rect = pygame.Rect((screen_w - POPUP_WIDTH)//2, (screen_h - POPUP_HEIGHT)//2, POPUP_WIDTH, POPUP_HEIGHT)
    
    # Vẽ bảng
    pygame.draw.rect(screen, C_BG_POPUP, popup_rect, border_radius=10)
    pygame.draw.rect(screen, C_BORDER, popup_rect, 2, border_radius=10)

    # 3. Lấy thông tin vật phẩm
    if item_key not in ITEM_TEMPLATES:
        return None # Lỗi không tìm thấy item
        
    item_data = ITEM_TEMPLATES[item_key]
    item_name = item_data.get('name', 'Unknown')
    item_id = get_item_real_id(item_key)
    
    # 4. Vẽ Tiêu đề: Tên (ID)
    title_str = f"{item_name} ({item_id})"
    title_surf = font_title.render(title_str, True, C_TEXT_TITLE)
    title_rect = title_surf.get_rect(center=(popup_rect.centerx, popup_rect.y + 40))
    screen.blit(title_surf, title_rect)
    
    pygame.draw.line(screen, C_BORDER, (popup_rect.x + 20, popup_rect.y + 70), (popup_rect.right - 20, popup_rect.y + 70), 1)

    # 5. Vẽ Chỉ số (Logic liên kết dữ liệu thực)
    # Nếu có custom_stats (đã sửa trong QL CHI SO), ưu tiên hiện nó
    # Nếu không, phân tích từ desc gốc
    stats_text_lines = []
    
    if 'custom_stats' in item_data and item_data['custom_stats']:
        stats_text_lines.append("--- CHI SO TUY CHINH (LIVE) ---")
        for k, v in item_data['custom_stats'].items():
            stats_text_lines.append(f"{k.upper()}: {v}")
    else:
        # Phân tích mô tả gốc
        desc = item_data.get('desc', '')
        # Tách các chỉ số cơ bản (giả lập phân tích chuỗi đơn giản)
        stats_text_lines.append(f"Mô tả gốc: {desc}")
        
    # Vẽ các dòng chỉ số
    start_y_stats = popup_rect.y + 90
    for i, line in enumerate(stats_text_lines):
        line_surf = font_small.render(line, True, C_TEXT_INFO)
        # Căn giữa
        line_rect = line_surf.get_rect(center=(popup_rect.centerx, start_y_stats + i * 25))
        screen.blit(line_surf, line_rect)

    # 6. Vẽ Nút Đóng (X)
    close_rect = pygame.Rect(popup_rect.right - 40, popup_rect.y + 10, 30, 30)
    pygame.draw.rect(screen, C_BTN_CLOSE, close_rect, border_radius=5)
    pygame.draw.rect(screen, (255,255,255), close_rect, 2, border_radius=5)
    
    x_surf = font_title.render("X", True, (255, 255, 255))
    x_rect = x_surf.get_rect(center=close_rect.center)
    screen.blit(x_surf, x_rect)

    return close_rect

def check_close_click(pos, close_rect):
    if close_rect and close_rect.collidepoint(pos):
        return True
    return False