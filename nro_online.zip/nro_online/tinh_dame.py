import random

def tinh_sat_thuong(suc_danh, chi_mang_cong_them):
    """
    Tính sát thương với tỉ lệ chí mạng 20% (base) + chi_mang_cong_them.
    Trả về (sát thương, là_chí_mạng)
    """
    
    # --- CẬP NHẬT: TÍNH TỈ LỆ CHÍ MẠNG CUỐI CÙNG ---
    BASE_CRIT_RATE = 20 # 20% mặc định của hệ thống
    final_crit_rate = BASE_CRIT_RATE + chi_mang_cong_them # Ví dụ: 20 + 3 = 23
    
    is_crit = False
    final_dame = 0
    
    # --- KIEM TRA CHI MANG (final_crit_rate co hoi) ---
    if random.randint(1, 100) <= final_crit_rate:
        is_crit = True
        base_crit = suc_danh * 2 # Cong thuc chinh: X * 2
        
        # Tinh toan tier chi mang (RNG 0.0 -> 100.0)
        roll = random.uniform(0, 100)
        multiplier = 0
        
        # Xep thu tu tu kho nhat den de nhat
        if roll <= 0.1:      # 0.1%
            multiplier = 0.20 # +20%
        elif roll <= 1.0:    # 1%
            multiplier = 0.10 # +10%
        elif roll <= 5.0:    # 5%
            multiplier = 0.10 # +10%
        elif roll <= 20.0:   # 20%
            multiplier = 0.08 # +8%
        elif roll <= 50.0:   # 50%
            multiplier = 0.06 # +6%
        elif roll <= 80.0:   # 80%
            multiplier = 0.03 # +3%
        else:
            multiplier = 0    # Truong hop hut ti le (dung chinh X*2)
            
        final_dame = int(base_crit * (1 + multiplier))

    else:
        # --- DAME THUONG (Con lai) ---
        
        # Ti le phu (40% co hoi): Dame to (2.8x) nhung bi tru 20%
        if random.randint(1, 100) <= 40:
            raw_dame = suc_danh * 2.8 
            final_dame = int(raw_dame * 0.8)
            final_dame += random.choice([0, 1])
            
        else:
            # Ti le chinh (60% con lai): 1 dame + 100% = 2x
            final_dame = int(suc_danh * 2)
            final_dame += random.choice([-1, 0, 1])

    # Sát thương không thể âm
    final_dame = max(1, final_dame)
    
    return final_dame, is_crit