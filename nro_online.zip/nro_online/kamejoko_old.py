# kamejoko.py
# Chiêu Kamejoko (wrapper) dùng FX procedural từ kame_fx.py
# Mục đích: để Mikey ghép vào game sau này (skill 2).
#
# Yêu cầu: đặt chung thư mục với kame_fx.py

import pygame
from kame_fx import KameFX


class KameJoko:
    """
    Skill 2: Kamejoko
      - DAMAGE_PCT = 125 (% sát thương)
      - Có FX: charge + beam + impact + particles + shake

    Gợi ý tích hợp:
      kame = KameJoko()
      # khi bắt đầu tụ lực:
      kame.start_charge()
      # khi thả:
      kame.release_fire(origin, aim_dir)  # nếu đã lock_target thì bắn vào target
      # hoặc bắn thẳng:
      kame.fire_at(origin, target_pos)

      # mỗi frame:
      kame.update(dt, origin, aim_dir)
      shake = kame.get_shake()
      kame.draw(screen, origin, aim_dir, cam=(cam_x, cam_y))
    """

    SKILL_ID = "kamejoko"
    NAME = "Kamejoko"
    DAMAGE_PCT = 110  # 110% sát thương

    def __init__(self):
        self.fx = KameFX()

    # ---- điều khiển ----
    def reset(self):
        self.fx.reset()

    def lock_target(self, pos):
        self.fx.lock_target(pos)

    def clear_lock(self):
        self.fx.clear_lock()

    def start_charge(self):
        self.fx.start_charge()

    def release_fire(self, origin, aim_dir):
        self.fx.release_fire(origin, aim_dir)

    def fire_at(self, origin, target_pos, charge_level=1.0):
        self.fx.fire_at(origin, target_pos, charge_level=charge_level)

    # ---- update/draw ----
    def update(self, dt, origin, aim_dir):
        self.fx.update(dt, origin, aim_dir)

    def draw(self, screen: pygame.Surface, origin, aim_dir, cam=(0, 0)):
        self.fx.draw(screen, origin, aim_dir, cam=cam)

    def get_shake(self) -> pygame.Vector2:
        return self.fx.get_shake()

    # ---- damage helper ----
    @staticmethod
    def apply_damage(base_damage: int) -> int:
        """Nếu Mikey muốn tự nhân % trong code bắn, dùng hàm này."""
        return max(1, int(base_damage * KameJoko.DAMAGE_PCT / 100))
