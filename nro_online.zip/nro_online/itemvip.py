# File: itemvip.py
# Item VIP (tự đồng bộ shop nếu có field "shops")

ITEM_VIP_TEMPLATES = {
    "gang_hoang_de": {
        "key": "gang_hoang_de",
        "name": "Găng Hoàng Đế",
        "type": "Gang",
        "item_id": 9001,
        "rarity": (255, 215, 0),
        "desc": "Trang bị VIP",

        # để popup tự hiện % chuẩn: dùng key có chữ 'percent'
        "stats": {
            "suc_danh_percent": 30,
            "max_hp_percent": 10,
            "max_ki_percent": 10,
        },

        # tự hiện trong shop ANXIN
        "shops": {
            "ANXIN": {"price": 200, "currency": "KIM_CUONG"}
        }
    }
}

def register_into(item_templates: dict):
    """Gọi hàm này để gộp VIP templates vào ITEM_TEMPLATES"""
    if isinstance(item_templates, dict):
        item_templates.update(ITEM_VIP_TEMPLATES)
