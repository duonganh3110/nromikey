import pygame
import random
import math

# --- CẤU HÌNH CƠ BẢN ---
SCREEN_WIDTH_DEFAULT = 800
SCREEN_HEIGHT_DEFAULT = 600

# ĐỊNH NGHĨA CONFIG CHO TỪNG MAP
MAP_CONFIGS = {
    # ----------------------------------------------------
    # MAP LÀNG KHỞI ĐẦU (MAP 1) - Map Lớn, nhiều NPC
    # ----------------------------------------------------
    "Map_1_Lang_Hanh_Tinh": { 
        "MAP_WIDTH_REAL": 2500,
        "GROUND_Y": 520,
        "BACKGROUND_DECO_COUNT": 15,
        "STATIC_OBJECT_COUNT": 360,
    },
    
    # ----------------------------------------------------
    # MAP KHU VỰC 2 (MAP 2) - Map Riêng biệt cho từng hành tinh
    # ----------------------------------------------------
    "Map_2_Khu_Vuc_TD": { # Trái Đất (VD: Đồi hoang)
        "MAP_WIDTH_REAL": 3000,
        "GROUND_Y": 500,
        "BACKGROUND_DECO_COUNT": 18,
        "STATIC_OBJECT_COUNT": 400,
    },
    "Map_2_Khu_Vuc_NM": { # Namec (VD: Rừng Namec)
        "MAP_WIDTH_REAL": 3200,
        "GROUND_Y": 490,
        "BACKGROUND_DECO_COUNT": 20,
        "STATIC_OBJECT_COUNT": 450,
    },
    "Map_2_Khu_Vuc_XD": { # Xayda (VD: Vực Xayda)
        "MAP_WIDTH_REAL": 3000,
        "GROUND_Y": 530, 
        "BACKGROUND_DECO_COUNT": 16,
        "STATIC_OBJECT_COUNT": 380,
    },
}

# --- CẤU HÌNH MÀU SẮC ---
DARK_GOLD = (184, 134, 11)
GREEN_NAMEC = (100, 200, 50)
BROWN_XAYDA = (101, 67, 33)

THEMES = {
    "traidat": {
        "sky_top": (100, 180, 255), "sky_bottom": (180, 230, 255),
        "ground": (34, 139, 34), "grass": (50, 205, 50),
        "rock": (105, 105, 105), "cloud": (255, 255, 255),
        "deco_color": (50, 150, 50) # Màu cho đồi/cây nền
    },
    "namec": {
        "sky_top": (0, 150, 100), "sky_bottom": (150, 220, 180),
        "ground": (40, 60, 120), "grass": (0, 255, 255),
        "rock": (60, 90, 100), "cloud": (200, 255, 200),
        "deco_color": (0, 100, 50) # Màu cho đồi/cây nền Namec
    },
    "xayda": {
        "sky_top": (100, 30, 30), "sky_bottom": (180, 80, 80),
        "ground": (101, 67, 33), "grass": (139, 69, 19),
        "rock": (47, 47, 47), "cloud": (255, 200, 200),
        "deco_color": (70, 40, 20) # Màu cho đồi/cây nền Xayda
    }
}

class Cloud:
    def __init__(self, map_width, screen_height):
        self.map_width = map_width
        self.x = random.randint(0, map_width)
        self.y = random.randint(0, int(screen_height * 0.4))
        self.speed = random.uniform(0.2, 0.5)
        self.size = random.randint(30, 80)
        self.opacity = random.randint(150, 220)
        
        self.surface = pygame.Surface((self.size * 3, self.size * 2), pygame.SRCALPHA)
        self.color = (255, 255, 255)
        
        self.blobs = []
        for _ in range(5):
            ox = random.randint(0, self.size * 2)
            oy = random.randint(0, self.size // 2)
            r = random.randint(self.size // 2, self.size)
            self.blobs.append((ox, oy, r))

    def set_color(self, color):
        self.color = color

    def update(self):
        self.x += self.speed
        if self.x > self.map_width:
            self.x = -200

    def draw(self, screen, offset_x):
        # Parallax Rate: 0.8 (Trôi chậm hơn)
        draw_x = self.x - (offset_x * 0.8) 
        
        if -200 < draw_x < screen.get_width() + 200:
            self.surface.fill((0,0,0,0))
            for ox, oy, r in self.blobs:
                pygame.draw.circle(self.surface, (*self.color, self.opacity), (ox, oy + r), r)
            screen.blit(self.surface, (draw_x, self.y))

# LỚP BACKGROUND DECORATION (Vật thể nền xa)
class BackgroundDeco:
    def __init__(self, x, y, kind, size_min=40, size_max=100):
        self.world_x = x
        self.y = y
        self.kind = kind
        self.size = random.randint(size_min, size_max)
        self.parallax_rate = random.uniform(0.5, 0.7)
        
        if self.kind == 'hill':
            self.hill_points = []
            for i in range(4):
                px = (i / 3.0) * self.size * 2
                py = random.uniform(-self.size * 0.5, -self.size * 0.9)
                self.hill_points.append((px, py))
            self.hill_points.insert(0, (0, 0))
            self.hill_points.append((self.size * 2, 0))
            
        elif self.kind == 'tree':
            self.trunk_width = random.randint(5, 10)
            self.crown_size = random.randint(30, 60)

    def draw(self, screen, theme, offset_x):
        # Áp dụng tỷ lệ Parallax thấp
        screen_x = self.world_x - (offset_x * self.parallax_rate)
        
        if -200 < screen_x < screen.get_width() + 200:
            c = theme['deco_color']
            
            if self.kind == 'hill':
                pts = [(p[0] + screen_x, p[1] + self.y) for p in self.hill_points]
                pygame.draw.polygon(screen, c, pts)
                
            elif self.kind == 'tree':
                # Thân cây
                pygame.draw.rect(screen, (100, 50, 0), (screen_x, self.y - self.crown_size, self.trunk_width, self.crown_size))
                # Tán lá
                leaf_color = GREEN_NAMEC if theme == THEMES['namec'] else c
                pygame.draw.circle(screen, leaf_color, (screen_x + self.trunk_width // 2, self.y - self.crown_size - self.crown_size // 4), self.crown_size // 2)


class StaticObject:
    """Đá và Cỏ đứng yên tại tọa độ thực của Map (Tiền cảnh - Parallax 1.0)"""
    def __init__(self, x, y, kind):
        self.world_x = x
        self.y = y
        self.kind = kind
        self.size = random.randint(4, 8) if kind == 'grass' else random.randint(12, 28)
        
        if self.kind == 'rock':
            self.poly_points = [
                (0, -self.size), 
                (self.size, -self.size//2), 
                (self.size-3, self.size//2), 
                (-self.size+2, self.size//2),
                (-self.size, -self.size//2)
            ]

    def draw(self, screen, theme, offset_x):
        # Parallax Rate: 1.0 (Trôi chuẩn theo player)
        screen_x = self.world_x - offset_x
        
        if -50 < screen_x < screen.get_width() + 50:
            if self.kind == 'grass':
                c = theme['grass']
                pygame.draw.line(screen, c, (screen_x, self.y), (screen_x - 3, self.y - self.size), 2)
                pygame.draw.line(screen, c, (screen_x, self.y), (screen_x, self.y - self.size - 3), 2)
                pygame.draw.line(screen, c, (screen_x, self.y), (screen_x + 3, self.y - self.size), 2)
                
            elif self.kind == 'rock':
                c = theme['rock']
                pts = [(p[0] + screen_x, p[1] + self.y) for p in self.poly_points]
                pygame.draw.polygon(screen, c, pts)

class GameMapGraphics:
    def __init__(self, screen_w, screen_h):
        self.screen_w = screen_w
        self.screen_h = screen_h
        self.map_name = "Map Default"
        self.font = pygame.font.SysFont("arial", 26, bold=True)
        self.current_planet = "traidat"
        self.current_map_id = "Map_1_Lang_Hanh_Tinh"
        
        # Cấu hình Map đang hoạt động
        self.MAP_WIDTH_REAL = 0
        self.GROUND_Y = 0
        
        # Khởi tạo rỗng
        self.clouds = []
        self.background_deco = []
        self.objects = []
        
        # Tải map mặc định
        self.load_map_assets(self.current_map_id)

    def load_map_assets(self, map_id):
        config = MAP_CONFIGS.get(map_id, MAP_CONFIGS["Map_1_Lang_Hanh_Tinh"])
        
        self.MAP_WIDTH_REAL = config["MAP_WIDTH_REAL"]
        self.GROUND_Y = config["GROUND_Y"]
        
        # Reset lists
        self.clouds = [Cloud(self.MAP_WIDTH_REAL, SCREEN_HEIGHT_DEFAULT) for _ in range(20)]
        self.background_deco = []
        self.objects = []
        
        # 1. TẠO DECORATION NỀN
        deco_count = config["BACKGROUND_DECO_COUNT"]
        for _ in range(deco_count // 2): # Hills
            wx = random.randint(0, self.MAP_WIDTH_REAL)
            wy = random.randint(int(SCREEN_HEIGHT_DEFAULT * 0.45), self.GROUND_Y - 50) 
            self.background_deco.append(BackgroundDeco(wx, wy, 'hill'))
            
        for _ in range(deco_count // 2): # Trees
            wx = random.randint(0, self.MAP_WIDTH_REAL)
            wy = random.randint(self.GROUND_Y - 80, self.GROUND_Y - 30) 
            self.background_deco.append(BackgroundDeco(wx, wy, 'tree'))
            
        self.background_deco.sort(key=lambda o: o.y)
        
        # 2. TẠO CỎ VÀ ĐÁ CỐ ĐỊNH (Tiền cảnh)
        static_count = config["STATIC_OBJECT_COUNT"]
        
        # Rock/Grass count (chia tỉ lệ)
        grass_count = int(static_count * 0.8)
        rock_count = int(static_count * 0.2)
        
        for _ in range(grass_count):
            wx = random.randint(0, self.MAP_WIDTH_REAL)
            wy = random.randint(self.GROUND_Y + 5, SCREEN_HEIGHT_DEFAULT - 10) 
            self.objects.append(StaticObject(wx, wy, 'grass'))
            
        for _ in range(rock_count):
            wx = random.randint(0, self.MAP_WIDTH_REAL)
            wy = random.randint(self.GROUND_Y + 5, SCREEN_HEIGHT_DEFAULT - 10)
            self.objects.append(StaticObject(wx, wy, 'rock'))
            
        self.objects.sort(key=lambda o: o.y)
        self.current_map_id = map_id


    def set_planet(self, name):
        if name in THEMES:
            self.current_planet = name
            for c in self.clouds: c.set_color(THEMES[name]['cloud']) 
    
    def set_map_name(self, name):
        self.map_name = name

    def set_map_id(self, map_id):
        """Thay đổi map ID và tải lại tài nguyên tương ứng"""
        if map_id != self.current_map_id:
            self.load_map_assets(map_id)
            # Đồng bộ màu sắc sau khi load map mới
            self.set_planet(self.current_planet) 


    def draw(self, screen, offset_x):
        t = THEMES[self.current_planet]
        
        # 1. BẦU TRỜI (Vẽ full màn hình, không trôi)
        screen.fill(t['sky_top'])
        # Vùng chuyển màu
        pygame.draw.rect(screen, t['sky_bottom'], (0, int(self.screen_h*0.3), self.screen_w, self.GROUND_Y))

        # 2. MÂY (Trôi chậm - Parallax Rate: 0.8)
        for c in self.clouds:
            c.update()
            c.draw(screen, offset_x)
            
        # 3. ĐỒ HỌA NỀN (Đồi, cây xa - Parallax Rate: 0.5 - 0.7)
        for deco in self.background_deco:
            deco.draw(screen, t, offset_x)

        # 4. MẶT ĐẤT NỀN (Vẽ full màn hình, không trôi)
        # Sử dụng GROUND_Y đã FIX 
        pygame.draw.rect(screen, t['ground'], (0, self.GROUND_Y, self.screen_w, self.screen_h - self.GROUND_Y))
        pygame.draw.line(screen, (0,0,0), (0, self.GROUND_Y), (self.screen_w, self.GROUND_Y), 2)

        # 5. VẼ VẬT THỂ (CỎ/ĐÁ) - Trôi chuẩn theo map (Parallax Rate: 1.0 - Tiền cảnh)
        for obj in self.objects:
            obj.draw(screen, t, offset_x)

        # 6. TÊN MAP (Góc phải dưới, cố định)
        txt = self.font.render(self.map_name, True, DARK_GOLD)
        shd = self.font.render(self.map_name, True, (0,0,0))
        tx = self.screen_w - txt.get_width() - 20
        ty = self.screen_h - txt.get_height() - 20
        screen.blit(shd, (tx+2, ty+2))
        screen.blit(txt, (tx, ty))
        
    # [MỚI] HÀM TRẢ VỀ THÔNG SỐ MAP
    def get_map_config(self):
        """Trả về các thông số map cần thiết cho Game Loop trong main.py"""
        return {
            "MAP_WIDTH_REAL": self.MAP_WIDTH_REAL,
            "GROUND_Y": self.GROUND_Y
        }