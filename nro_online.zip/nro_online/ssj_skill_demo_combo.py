
import math
import pygame
import ssj2

# DEMO: Skill SSJ Cấp 1 + aura glow y hệt demo
# - Giữ LMB lên ô SSJ (skill bar)
# - Hoặc chọn SSJ (1..5) rồi giữ RMB
# - Đủ charge => nổ + buff +30%
W, H = 960, 540
FPS = 60

AO_CAM = (255, 110, 20)
AO_CAM_DAM = (220, 70, 0)
DAI_XANH = (40, 120, 220)
GIAY_XANH = (40, 80, 210)
DAY_GIAY_DO = (255, 60, 60)
MAU_DA = (255, 210, 170)
TOC_DEN = (10, 10, 15)

SSJ_HAIR = (255, 210, 40)
SSJ_OUT = (190, 130, 10)

GROUND = (30, 30, 38)
GROUND2 = (20, 20, 26)

def clamp(x, a, b):
    return a if x < a else b if x > b else x

def draw_ground(surf):
    surf.fill(GROUND)
    pygame.draw.rect(surf, GROUND2, (0, H - 110, W, 110))
    for i in range(-80, W + 80, 80):
        pygame.draw.line(surf, (45, 45, 55), (i, H - 110), (i + 40, H), 1)

def draw_shadow(surf, x, y):
    r = pygame.Rect(0, 0, 40, 12)
    r.center = (x, y + 56)
    pygame.draw.ellipse(surf, (0, 0, 0, 95), r)

def hair_points_base(cx, y0, fd):
    return [
        (cx, y0 - 4),
        (cx + 4*fd, y0 - 14),
        (cx + 12*fd, y0 - 20),
        (cx + 22*fd, y0 - 12),
        (cx + 26*fd, y0 - 2),
        (cx + 20*fd, y0 + 6),
        (cx + 10*fd, y0 + 3),
        (cx, y0 + 3),
        (cx - 10*fd, y0 + 3),
        (cx - 20*fd, y0 + 6),
        (cx - 26*fd, y0 - 2),
        (cx - 22*fd, y0 - 12),
        (cx - 12*fd, y0 - 20),
        (cx - 4*fd, y0 - 14),
    ]

def hair_points_ssj(cx, y0, fd, flick=0.0):
    s = 1.0 + 0.06 * math.sin(flick * 2.5)
    return [
        (cx, y0 - int(8*s)),
        (cx + 6*fd, y0 - int(21*s)),
        (cx + 14*fd, y0 - int(32*s)),
        (cx + 22*fd, y0 - int(28*s)),
        (cx + 30*fd, y0 - int(18*s)),
        (cx + 28*fd, y0 - int(6*s)),
        (cx + 18*fd, y0 + 2),
        (cx + 8*fd, y0 + 1),
        (cx, y0 + 6),
        (cx - 8*fd, y0 + 1),
        (cx - 18*fd, y0 + 2),
        (cx - 28*fd, y0 - int(6*s)),
        (cx - 30*fd, y0 - int(18*s)),
        (cx - 22*fd, y0 - int(28*s)),
        (cx - 14*fd, y0 - int(32*s)),
        (cx - 6*fd, y0 - int(21*s)),
    ]

def draw_char(surf, x, y, face_right, run_phase, charging, charge_t, ssj_on, tick):
    fd = 1 if face_right else -1
    f = int(run_phase) % 4
    bob = [0, 1, 0, 1][f]
    squat = int(7*charge_t) if charging else 0
    y0 = y + bob + squat
    cx = x + 15

    draw_shadow(surf, cx, y0)

    spread = int(2 + 6*charge_t) if charging else 2
    knee = int(2 + 6*charge_t) if charging else 1

    pygame.draw.rect(surf, AO_CAM, (cx - (12+spread), y0 + 34 + knee, 9, 12), border_radius=3)
    pygame.draw.rect(surf, GIAY_XANH, (cx - (13+spread), y0 + 44 + knee, 11, 7), border_radius=3)
    pygame.draw.rect(surf, DAY_GIAY_DO, (cx - (12+spread), y0 + 46 + knee, 8, 2), border_radius=2)

    pygame.draw.rect(surf, AO_CAM, (cx + (3+spread), y0 + 34 + knee, 9, 12), border_radius=3)
    pygame.draw.rect(surf, GIAY_XANH, (cx + (2+spread), y0 + 44 + knee, 11, 7), border_radius=3)
    pygame.draw.rect(surf, DAY_GIAY_DO, (cx + (3+spread), y0 + 46 + knee, 8, 2), border_radius=2)

    pygame.draw.rect(surf, (20, 20, 25), (cx - 10, y0 + 20, 20, 14), border_radius=4)
    pygame.draw.rect(surf, AO_CAM, (cx - 12, y0 + 20, 24, 18), border_radius=5)
    pygame.draw.rect(surf, DAI_XANH, (cx - 12, y0 + 33, 24, 6), border_radius=4)
    pygame.draw.line(surf, AO_CAM_DAM, (cx - 6, y0 + 22), (cx - 6, y0 + 36), 2)
    pygame.draw.line(surf, (255, 150, 60), (cx + 5, y0 + 22), (cx + 5, y0 + 36), 2)

    pygame.draw.circle(surf, MAU_DA, (cx, y0 + 12), 10)
    eye_x = cx + 4*fd
    pygame.draw.ellipse(surf, (255,255,255), (eye_x - 3, y0 + 10, 6, 4))
    pygame.draw.circle(surf, (0,0,0), (eye_x, y0 + 12), 2)
    pygame.draw.line(surf, (0,0,0), (eye_x - 4, y0 + 9), (eye_x + 2, y0 + 8), 2)
    pygame.draw.line(surf, (0,0,0), (cx - 2*fd, y0 + 17), (cx + 3*fd, y0 + 17), 1)

    flick = tick * 0.02
    if ssj_on:
        pts = hair_points_ssj(cx, y0, fd, flick=flick)
        pygame.draw.polygon(surf, SSJ_HAIR, pts)
        pygame.draw.polygon(surf, SSJ_OUT, pts, 2)
        pygame.draw.circle(surf, (255, 250, 200), (cx + 6*fd, y0 - 10), 3)
    else:
        pts = hair_points_base(cx, y0, fd)
        pygame.draw.polygon(surf, TOC_DEN, pts)
        pygame.draw.polygon(surf, (0,0,0), pts, 2)

def draw_text(surf, font, s, x, y, col=(230,230,240)):
    surf.blit(font.render(s, True, col), (x, y))

def draw_skill_bar(screen, font, active_idx, ssj_idx):
    slot_size = 48
    gap = 7
    total_w = 5 * slot_size + 4 * gap
    base_x = (W - total_w) // 2
    base_y = H - slot_size - 10

    rects = []
    for i in range(5):
        r = pygame.Rect(base_x + i*(slot_size+gap), base_y, slot_size, slot_size)
        rects.append(r)
        pygame.draw.rect(screen, (25, 25, 35), r, border_radius=10)
        if i == active_idx:
            pygame.draw.rect(screen, (0, 160, 255), r, 3, border_radius=10)
        else:
            pygame.draw.rect(screen, (255, 215, 0), r, 2, border_radius=10)

        num = font.render(str(i+1), True, (255,255,255))
        screen.blit(num, (r.x + 6, r.y + 4))

        if i == ssj_idx:
            name = font.render("SSJ", True, (255,240,160))
            screen.blit(name, (r.centerx - name.get_width()//2, r.bottom - name.get_height() - 6))

    return rects

def main():
    pygame.init()
    screen = pygame.display.set_mode((W,H))
    pygame.display.set_caption("DEMO SSJ Cấp 1 + Aura glow (fix import + SSJ_MULT)")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("consolas", 18)
    font_s = pygame.font.SysFont("consolas", 16)

    x = W//2 - 15
    y = H - 170
    face_right = True
    run_phase = 0.0
    tick = 0

    base_hp = 1000
    base_ki = 1000
    base_sd = 100

    ssj_on = False
    charge = 0.0
    fx = ssj2.SSJFX()

    active_slot = 0
    ssj_slot = 0

    running = True
    while running:
        dt = clock.tick(FPS)/1000.0
        tick += 1

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    running = False
                elif e.key == pygame.K_1: active_slot = 0
                elif e.key == pygame.K_2: active_slot = 1
                elif e.key == pygame.K_3: active_slot = 2
                elif e.key == pygame.K_4: active_slot = 3
                elif e.key == pygame.K_5: active_slot = 4
                elif e.key == pygame.K_k:
                    ssj_on = False
                    charge = 0.0
                    fx.reset()

        keys = pygame.key.get_pressed()
        move = 0
        if keys[pygame.K_LEFT]: move -= 1
        if keys[pygame.K_RIGHT]: move += 1
        if move != 0:
            face_right = True if move > 0 else False

        x += move * 240.0 * dt
        x = clamp(x, 40, W-70)
        run_phase += dt*(9.0 if abs(move)>0 else 2.0)

        draw_ground(screen)
        rects = draw_skill_bar(screen, font_s, active_slot, ssj_slot)

        mx,my = pygame.mouse.get_pos()
        lmb, _, rmb = pygame.mouse.get_pressed(3)

        hold_lmb_on_ssj = lmb and rects[ssj_slot].collidepoint(mx,my)
        hold_rmb_active = rmb and (active_slot == ssj_slot)
        holding = hold_lmb_on_ssj or hold_rmb_active

        state = "IDLE"
        if not ssj_on:
            if holding:
                state = "CHARGING"
                charge += dt/ssj2.SSJ_CHARGE_TIME
                charge = clamp(charge, 0.0, 1.0)
                if charge >= 1.0:
                    state = "TRANSFORM"
                    ssj_on = True
                    fx.trigger_transform(x+15, y+28, H-110+8, power=1.15)
            else:
                charge = max(0.0, charge - dt*0.9)
        else:
            state = "SSJ"

        cx = int(x+15)
        cy = int(y+30)

        fx.update(dt, cx, cy, charge_t=charge, ssj_active=ssj_on, state=("CHARGING" if (not ssj_on and holding) else "SSJ" if ssj_on else "IDLE"))
        fx.draw(screen, cx, cy, charge_t=charge, ssj_active=ssj_on, state=("CHARGING" if (not ssj_on and holding) else "SSJ" if ssj_on else "IDLE"))

        draw_char(screen, int(x), int(y), face_right, run_phase, (not ssj_on and holding), charge, ssj_on, tick)

        mult = ssj2.SSJ_MULT if ssj_on else 1.0
        hp = int(base_hp*mult)
        ki = int(base_ki*mult)
        sd = int(base_sd*mult)

        draw_text(screen, font, "Giữ LMB lên ô SSJ hoặc chọn slot SSJ rồi giữ RMB", 14, 14)
        draw_text(screen, font, f"SSJ: {'ON' if ssj_on else 'OFF'}  CHARGE: {int(charge*100)}%", 14, 38, col=(255,235,140) if (ssj_on or charge>0) else (220,230,240))
        draw_text(screen, font, f"BUFF (+30%): HP {hp} | KI {ki} | SD {sd}", 14, 62, col=(255,235,140) if ssj_on else (200,200,210))
        draw_text(screen, font, "K reset | 1..5 đổi slot active | ESC thoát", 14, 86)

        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
