import pygame
import random
import math
import sys
import os

# --- CẤU HÌNH MÀU SẮC ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
C_BODY_HEO = (150, 80, 50)
C_LEG_HEO = (100, 50, 30)
C_GAU_BODY = (120, 90, 60)
C_GAU_MUZZLE = (180, 150, 120)

# Biến toàn cục để khởi tạo Font an toàn
FONT_MONSTER = None

def get_monster_font():
    global FONT_MONSTER
    if FONT_MONSTER is None:
        try:
            if not pygame.font.get_init():
                pygame.font.init()
            FONT_MONSTER = pygame.font.SysFont("Arial", 14, bold=True)
        except:
            FONT_MONSTER = pygame.font.Font(None, 24)
    return FONT_MONSTER

# --- HÀM VẼ CHI TIẾT ---
def draw_boar_monster(surface, sx, sy, width, height, frame_index, huong_phai, is_moving):
    bobbing = math.sin(pygame.time.get_ticks() * 0.01) * 2
    sy_eff = sy + bobbing
    leg_swing = math.sin(frame_index * 0.5) * 8 if is_moving else 0

    pygame.draw.rect(surface, C_LEG_HEO, (sx + 5 + leg_swing, sy_eff + height - 10, 6, 10))
    pygame.draw.rect(surface, C_LEG_HEO, (sx + width - 15 - leg_swing, sy_eff + height - 10, 6, 10))

    pygame.draw.ellipse(surface, C_BODY_HEO, (sx, sy_eff + 10, width, height - 20))

    head_x = sx + width - 15 if huong_phai else sx - 5
    pygame.draw.circle(surface, C_BODY_HEO, (int(head_x + 10), int(sy_eff + 20)), 15)
    tusk_x = head_x + 18 if huong_phai else head_x + 2
    pygame.draw.line(surface, WHITE, (tusk_x, sy_eff + 25), (tusk_x + (5 if huong_phai else -5), sy_eff + 20), 2)
    pygame.draw.circle(surface, BLACK, (int(head_x + (15 if huong_phai else 5)), int(sy_eff + 18)), 2)

def draw_bear_monster(surface, sx, sy, width, height, frame_index, huong_phai, is_moving):
    sy_eff = sy + math.sin(pygame.time.get_ticks() * 0.008) * 3
    leg_swing = math.sin(frame_index * 0.4) * 10 if is_moving else 0
    pygame.draw.rect(surface, C_GAU_BODY, (sx + 5, sy_eff + 5, width - 10, height - 15), border_radius=8)
    cx = sx + width // 2
    pygame.draw.circle(surface, C_GAU_BODY, (cx, sy_eff - 5), 18)
    pygame.draw.circle(surface, C_GAU_MUZZLE, (cx + (8 if huong_phai else -8), sy_eff), 8)
    pygame.draw.circle(surface, BLACK, (cx + (12 if huong_phai else -4), sy_eff - 8), 2)

DRAW_FUNCS = {"quai_heo_1": draw_boar_monster, "quai_gau_1": draw_bear_monster}

# --- CLASS MONSTER ---
class Monster:
    def __init__(self, world_x, world_y, key, initial_hp=1000):
        self.world_x = world_x
        self.world_y = world_y
        self.home_x = world_x
        self.key = key

        self.max_hp = initial_hp
        self.hp = initial_hp
        self.is_dead = False

        self.huong_phai = True
        self.width, self.height = 45, 50
        self.rect = pygame.Rect(0, 0, self.width, self.height)

        # State machine
        self.state = "WALK"
        self.state_timer = 0
        self.visual_offset_x = 0

        # Patrol
        self.speed = 0.5
        self.patrol_range = 100  # đi qua lại quanh home_x

        # Aggro/Attack ranges (tự tính theo world_x của player)
        self.aggro_range = 320          # trong tầm này mới “nhắm”
        self.attack_trigger_range = 150 # trong tầm này mới được PREPARE/DASH

        # Animation
        self.frame_index = 0
        self.last_anim_time = 0

        # Combat timers
        self.last_hit_time = 0
        self.last_regen_time = 0

        # FIX “húc không khí”
        self.last_attack_time = 0
        self.attack_cooldown = 1200  # ms

    def calculate_attack_damage(self):
        if self.key == "quai_heo_1":
            return random.randint(10, 15)
        return random.randint(25, 40)

    def take_damage(self, dmg):
        if not self.is_dead:
            self.hp -= dmg
            self.last_hit_time = pygame.time.get_ticks()
            if self.hp <= 0:
                self.hp = 0
                self.is_dead = True

    def _player_world_x(self, player_obj):
        # player_obj bên em là player_rect có gán .world_x, nên lấy được
        if player_obj is None:
            return None
        if hasattr(player_obj, "world_x"):
            return player_obj.world_x
        # fallback: nếu ai đó truyền Rect thường (không có world_x) thì coi như không có target
        return None

    def update(self, map_offset_x, is_player_in_range=False, player_obj=None):
        current_time = pygame.time.get_ticks()

        if self.is_dead:
            if current_time - self.last_hit_time > 5000:
                self.respawn()
            return False

        # REGEN 20% HP sau 5s không bị đánh
        if self.hp < self.max_hp and (current_time - self.last_hit_time > 5000):
            if current_time - self.last_regen_time > 500:
                heal_amount = int(self.max_hp * 0.20)
                self.hp = min(self.max_hp, self.hp + heal_amount)
                self.last_regen_time = current_time

        # ====== TARGET LOGIC (CHỐT) ======
        px = self._player_world_x(player_obj)
        dist = abs(px - self.world_x) if (px is not None) else 999999

        # target chỉ hợp lệ khi: có px + trong aggro_range + (tùy em) is_player_in_range
        # (giữ is_player_in_range để không phá logic cũ của em, nhưng dist là điều kiện chính)
        has_target = (px is not None) and (dist <= self.aggro_range) and bool(is_player_in_range)

        # attack chỉ bắt đầu khi target đủ gần
        can_start_attack = has_target and (dist <= self.attack_trigger_range) and (current_time - self.last_attack_time >= self.attack_cooldown)

        # ====== STATE MACHINE ======
        if self.state == "WALK":
            self.visual_offset_x = 0

            # Patrol qua lại 2 hướng trong phạm vi
            left_bound = self.home_x - self.patrol_range
            right_bound = self.home_x + self.patrol_range

            if self.world_x <= left_bound:
                self.huong_phai = True
            elif self.world_x >= right_bound:
                self.huong_phai = False

            self.world_x += self.speed if self.huong_phai else -self.speed

            # chỉ PREPARE khi đủ gần thật sự (không còn “tự húc không khí”)
            if can_start_attack:
                self.state = "PREPARE"
                self.state_timer = current_time
                self.huong_phai = (px > self.world_x)

        elif self.state == "PREPARE":
            # ===== FIX CHÍNH: mất mục tiêu -> hủy ngay, KHÔNG ĐƯỢC DASH =====
            if not has_target:
                self.state = "WALK"
                self.visual_offset_x = 0
            else:
                # nếu target còn nhưng chạy xa quá khỏi trigger thì cũng hủy
                if dist > self.attack_trigger_range:
                    self.state = "WALK"
                    self.visual_offset_x = 0
                else:
                    self.huong_phai = (px > self.world_x)
                    self.visual_offset_x = -15 if self.huong_phai else 15
                    if current_time - self.state_timer > 700:  # ngắn hơn tí cho mượt
                        self.state = "DASH"
                        self.state_timer = current_time

        elif self.state == "DASH":
            # ===== FIX CHÍNH: trong lúc DASH mà mất target -> hủy ngay, không “húc gió” =====
            if not has_target:
                self.state = "WALK"
                self.visual_offset_x = 0
                self.last_attack_time = current_time  # vẫn tính cooldown để khỏi spam
                # update rect rồi return
            else:
                # nếu target chạy khỏi trigger khi đang dash -> hủy luôn
                if dist > self.attack_trigger_range:
                    self.state = "WALK"
                    self.visual_offset_x = 0
                    self.last_attack_time = current_time
                else:
                    self.huong_phai = (px > self.world_x)
                    self.visual_offset_x = 40 if self.huong_phai else -40

                    if current_time - self.state_timer > 350:
                        self.state = "WALK"
                        self.visual_offset_x = 0
                        self.last_attack_time = current_time
                        # return True báo “đã thực hiện pha húc”, nhưng chỉ khi target còn hợp lệ
                        # (game_loop của em không dùng return này để gây dame, nhưng để debug vẫn chuẩn)
                        self.rect.x = self.world_x - map_offset_x + self.visual_offset_x
                        self.rect.y = self.world_y - self.height
                        return True

        # cập nhật rect
        self.rect.x = int(self.world_x - map_offset_x + self.visual_offset_x)
        self.rect.y = int(self.world_y - self.height)

        # animation
        if current_time - self.last_anim_time > 130:
            self.frame_index += 1
            self.last_anim_time = current_time

        return False

    def draw(self, screen):
        if self.is_dead:
            return

        f = DRAW_FUNCS.get(self.key, draw_boar_monster)
        f(screen, self.rect.x, self.rect.y, self.width, self.height, self.frame_index, self.huong_phai, self.state == "WALK")

        font = get_monster_font()
        name_txt = font.render(self.key.replace("quai_", "").title(), True, WHITE)
        screen.blit(name_txt, (self.rect.x + self.width // 2 - name_txt.get_width() // 2, self.rect.y - 25))

        pygame.draw.rect(screen, BLACK, (self.rect.x, self.rect.y - 10, self.width, 5))
        hp_color = RED if self.hp < self.max_hp else GREEN
        pygame.draw.rect(screen, hp_color, (self.rect.x, self.rect.y - 10, int(self.width * (self.hp / self.max_hp)), 5))

    def respawn(self):
        self.hp = self.max_hp
        self.is_dead = False
        self.world_x = self.home_x
        self.state = "WALK"
        self.visual_offset_x = 0
        self.last_hit_time = pygame.time.get_ticks()
        self.last_attack_time = 0

    def draw_target_indicator(self, screen):
        pygame.draw.circle(screen, (255, 255, 0), (self.rect.centerx, self.rect.bottom + 5), 15, 2)

# --- HÀM TẠO QUÁI (HP GẤU = 700) ---
def create_all_monsters(map_id, ground_y):
    monsters = []
    if "Map_2" in map_id:
        start_x_heo = 700
        khoang_cach_le = 150
        so_luong_heo = 4

        for i in range(so_luong_heo):
            monsters.append(Monster(start_x_heo + i * khoang_cach_le, ground_y, "quai_heo_1", 400))

        last_heo_pos = start_x_heo + (so_luong_heo - 1) * khoang_cach_le
        start_x_gau = last_heo_pos + 500

        for i in range(3):
            monsters.append(Monster(start_x_gau + i * khoang_cach_le, ground_y, "quai_gau_1", 700))

    return monsters
