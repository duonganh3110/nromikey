import pygame
import random
import math
import json
import os

# --- CẤU HÌNH ---
BROLY_HP = 550000
BROLY_DAME_MIN = 10000
BROLY_DAME_MAX = 15000
SPAWN_INTERVAL = 15 * 60 * 1000  # 15 phút mới ra 1 lần
DESPAWN_TIMEOUT = 2 * 60 * 1000  # 2 phút không có người thì biến mất

DATA_FILE = "broly_data.json"

# --- MÀU SẮC ---
SKIN_COLOR = (255, 200, 150)
HAIR_COLOR = (10, 10, 10) # Tóc đen (dạng base)
PANTS_COLOR_Z = (240, 240, 240)
SASH_COLOR = (200, 0, 0)
AURA_COLOR_INNER = (255, 255, 0) # Vàng
AURA_COLOR_OUTER = (0, 255, 0)   # Xanh lá đặc trưng Broly

# --- CLASS HIỆU ỨNG HẠT (ĐẤT ĐÁ) ---
class Particle:
    def __init__(self, x, y, color, speed_x, speed_y, life):
        self.x = x
        self.y = y
        self.color = color
        self.speed_x = speed_x
        self.speed_y = speed_y
        self.life = life
        self.size = random.randint(3, 6)

    def update(self):
        self.x += self.speed_x
        self.y += self.speed_y
        self.speed_y += 0.5 # Trọng lực
        self.life -= 1

    def draw(self, screen):
        if self.life > 0:
            pygame.draw.rect(screen, self.color, (self.x, self.y, self.size, self.size))

class BossBroly:
    def __init__(self, x, y, ground_y, map_width, current_hp=None):
        # Tọa độ thực (World Coordinates)
        self.world_x = x
        self.world_y = ground_y - 90
        
        # Rect dùng để vẽ và va chạm
        self.rect = pygame.Rect(x, self.world_y, 60, 90)
        
        self.ground_y = ground_y
        self.map_width = map_width
        
        # Stats
        self.max_hp = BROLY_HP
        self.hp = current_hp if current_hp is not None else self.max_hp
        self.dame_min = BROLY_DAME_MIN
        self.dame_max = BROLY_DAME_MAX
        
        # Physics
        self.vel_x = 0
        self.vel_y = 0
        self.gravity = 0.8
        self.jump_force_high = -19
        self.jump_force_low = -12
        self.speed_run = 14
        
        self.is_dead = False
        self.facing_right = True
        self.on_ground = False
        self.prev_on_ground = False # Để check khoảnh khắc tiếp đất
        
        # AI
        self.state = "IDLE"
        self.state_timer = 0 
        self.target_world_x = x 
        
        self.last_attack_time = 0
        self.attack_cooldown = 1000 
        
        self.frame_index = 0
        self.anim_timer = 0
        self.time_without_player = 0
        self.last_update_time = pygame.time.get_ticks()
        
        # FX System
        self.particles = []
        self.aura_radius = 40
        self.aura_expand = True
        
        # Tên hiển thị (để main.py nhận dạng)
        self.name_display = "Broly"

    def create_impact_effect(self):
        """Tạo hiệu ứng đất đá bắn lên"""
        for _ in range(10):
            p = Particle(
                self.world_x + 30 + random.randint(-20, 20),
                self.world_y + 90,
                (100, 80, 50), # Màu đất nâu
                random.uniform(-4, 4),
                random.uniform(-8, -3),
                random.randint(20, 40)
            )
            self.particles.append(p)

    def calculate_attack_damage(self):
        return random.randint(self.dame_min, self.dame_max)

    def update(self, map_offset_x, player_rect, player_world_x=None):
        if self.is_dead: return
        current_time = pygame.time.get_ticks()
        dt = current_time - self.last_update_time
        self.last_update_time = current_time

        # --- 1. ĐỒNG BỘ HÓA TỌA ĐỘ ---
        player_present = False
        p_world_x = 0
        p_y_screen = 0
        dist_x = 0
        
        if player_rect:
            p_world_x = player_rect.centerx + map_offset_x
            p_y_screen = player_rect.y
            player_present = True
            self.time_without_player = 0
            dist_x = p_world_x - self.world_x
        else:
            self.time_without_player += dt
            if self.time_without_player >= DESPAWN_TIMEOUT:
                self.hp = 0; self.is_dead = True; return

        # --- 2. AI LOGIC ---
        if player_present:
            if self.state in ["COOLDOWN", "ATTACK_PREP"]:
                pass
            else:
                self.target_world_x = p_world_x
                if p_y_screen < self.rect.y - 150 and self.on_ground: 
                    self.state = "ENGAGE_JUMP"
                    self.vel_y = self.jump_force_high
                    self.on_ground = False
                    self.create_impact_effect() 
                
                elif abs(dist_x) > 200:
                    self.state = "ENGAGE_RUN"
                
                elif abs(dist_x) > 80: 
                    if self.on_ground:
                        self.state = "ENGAGE_JUMP"
                        self.vel_y = self.jump_force_low
                        self.on_ground = False
                        self.create_impact_effect() 
                    else:
                        self.state = "ENGAGE_RUN"
                
                else: 
                    if self.state != "ATTACK_PREP" and current_time - self.last_attack_time >= self.attack_cooldown:
                        self.state = "ATTACK_PREP"
                        self.state_timer = current_time + 200 
                        self.vel_x = 0 
        else:
            self.state = "IDLE"; self.vel_x = 0

        # State Reset
        if self.state == "ATTACK_PREP" and current_time > self.state_timer + 200:
             self.state = "COOLDOWN"; self.state_timer = current_time + 500
        if self.state == "COOLDOWN" and current_time > self.state_timer:
             self.state = "ENGAGE_RUN"

        # --- 3. PHYSICS ---
        if self.state == "ENGAGE_RUN":
            if self.target_world_x > self.world_x: self.vel_x = self.speed_run; self.facing_right = True
            else: self.vel_x = -self.speed_run; self.facing_right = False
        elif self.state == "ENGAGE_JUMP":
            target_dir = 1 if self.target_world_x > self.world_x else -1
            self.vel_x = target_dir * self.speed_run
            self.facing_right = (target_dir == 1)
        elif self.state in ["ATTACK_PREP", "COOLDOWN", "IDLE"]:
            self.vel_x = 0

        self.vel_y += self.gravity 
        self.world_x += self.vel_x
        self.world_y += self.vel_y
        
        # Check tiếp đất
        self.prev_on_ground = self.on_ground
        if self.world_y >= self.ground_y - 90:
            self.world_y = self.ground_y - 90
            self.vel_y = 0
            self.on_ground = True
        else:
            self.on_ground = False
            
        if not self.prev_on_ground and self.on_ground:
            self.create_impact_effect()

        if self.world_x < 0: self.world_x = 0
        if self.world_x > self.map_width - 60: self.world_x = self.map_width - 60

        self.rect.x = int(self.world_x - map_offset_x)
        self.rect.y = int(self.world_y)

        # Animation Frame
        if abs(self.vel_x) > 1:
            if current_time - self.anim_timer > 50:
                self.frame_index += 1; self.anim_timer = current_time
        else:
            self.frame_index = 0
            
        # Update Particles
        for p in self.particles: p.update()
        self.particles = [p for p in self.particles if p.life > 0]
        
        # Update Aura Pulsing
        if self.aura_expand:
            self.aura_radius += 0.5
            if self.aura_radius > 50: self.aura_expand = False
        else:
            self.aura_radius -= 0.5
            if self.aura_radius < 40: self.aura_expand = True

    def check_attack(self, player_rect):
        if self.is_dead: return 0
        current_time = pygame.time.get_ticks()
        
        if self.state == "ATTACK_PREP" and current_time >= self.state_timer:
            attack_box = self.rect.inflate(200, 150) 
            if attack_box.colliderect(player_rect):
                self.last_attack_time = current_time
                self.state = "COOLDOWN"
                self.state_timer = current_time + 800
                return self.calculate_attack_damage()
            else:
                self.state = "COOLDOWN"
                self.state_timer = current_time + 300
        return 0

    def draw_aura_and_wind(self, screen, cx, cy):
        """Vẽ hào quang và gió"""
        aura_surf = pygame.Surface((120, 120), pygame.SRCALPHA)
        pygame.draw.circle(aura_surf, (*AURA_COLOR_OUTER, 100), (60, 60), int(self.aura_radius))
        pygame.draw.circle(aura_surf, (*AURA_COLOR_INNER, 150), (60, 60), int(self.aura_radius * 0.7))
        screen.blit(aura_surf, (cx - 60, cy - 60))
        
        if abs(self.vel_x) > 1 or self.state == "ATTACK_PREP":
            for _ in range(3):
                offset_x = random.randint(-40, 40)
                offset_y = random.randint(-50, 50)
                length = random.randint(20, 50)
                pygame.draw.line(screen, (200, 255, 200), (cx + offset_x, cy + offset_y), (cx + offset_x, cy + offset_y - length), 2)

    def draw_target_indicator(self, screen):
        """Vẽ mũi tên đỏ chỉ vào boss khi được chọn (FIX LỖI CRASH)"""
        if self.is_dead: return
        cx = self.rect.centerx
        top = self.rect.y - 15
        # Vẽ tam giác đỏ ngược
        points = [
            (cx - 10, top - 10),
            (cx + 10, top - 10),
            (cx, top)
        ]
        pygame.draw.polygon(screen, (255, 0, 0), points)

    def draw_manual(self, screen, map_offset_x):
        if self.is_dead: return
        sx = self.rect.x 
        sy = self.rect.y
        
        if sx < -100 or sx > 800 + 100: return

        cx = sx + 30; cy = sy + 45
        d = 1 if self.facing_right else -1
        b = 2 if (self.frame_index % 2 != 0 and self.on_ground) else 0

        # FX
        for p in self.particles:
            p_draw_x = p.x - map_offset_x
            if 0 <= p_draw_x <= 800:
                pygame.draw.rect(screen, p.color, (p_draw_x, p.y, p.size, p.size))
        
        self.draw_aura_and_wind(screen, cx, cy)

        # Body
        pygame.draw.rect(screen, PANTS_COLOR_Z, (cx-15, sy+60-b, 12, 30))
        pygame.draw.rect(screen, PANTS_COLOR_Z, (cx+3, sy+60-b, 12, 30))
        
        body_col = (255, 100, 100) if self.state == "ATTACK_PREP" else SKIN_COLOR
        pygame.draw.rect(screen, body_col, (cx-22, sy+25, 44, 40))
        pygame.draw.rect(screen, SASH_COLOR, (cx-20, sy+60-b, 40, 8))
        pygame.draw.polygon(screen, (218, 165, 32), [(cx-15, sy+65), (cx+15, sy+65), (cx, sy+85)])
        
        pygame.draw.circle(screen, body_col, (cx, sy+15), 15)
        
        # Hair
        h = [(cx, sy-25), (cx-20, sy-10), (cx-35, sy+5), (cx-28, sy+30), 
             (cx+20, sy-10), (cx+35, sy+5), (cx+28, sy+30)]
        fh = [(cx + (hx-cx)*d, hy) for hx, hy in h]
        pygame.draw.polygon(screen, HAIR_COLOR, fh)
        
        pygame.draw.circle(screen, (255, 255, 255), (cx+5*d, sy+13), 3) 

        # Attack FX
        current_time = pygame.time.get_ticks()
        if self.state == "ATTACK_PREP":
            glow_s = pygame.Surface((30, 30), pygame.SRCALPHA)
            pygame.draw.circle(glow_s, (255, 50, 0, 150), (15, 15), 15)
            screen.blit(glow_s, (cx + 20*d - 15, sy + 30 - 15))

        if self.state == "COOLDOWN" and current_time - self.last_attack_time < 200:
            fist_x = cx + 55 * d
            fist_y = sy + 40
            pygame.draw.line(screen, (255, 255, 200), (cx, sy+35), (fist_x, fist_y), 15) 
            pygame.draw.circle(screen, (255, 0, 0), (fist_x, fist_y), 25) 
            for _ in range(4):
                lx = fist_x + random.randint(-20, 20)
                ly = fist_y + random.randint(-20, 20)
                pygame.draw.line(screen, (255, 255, 0), (fist_x, fist_y), (lx, ly), 2)

        self.draw_health_bar(screen, sx, sy)

    def draw_health_bar(self, screen, x, y):
        w = 80; h = 10; p = max(0, self.hp / self.max_hp)
        pygame.draw.rect(screen, (100, 0, 0), (x-10, y-20, w, h))
        pygame.draw.rect(screen, (255, 100, 0), (x-10, y-20, w*p, h))
        pygame.draw.rect(screen, (0, 0, 0), (x-10, y-20, w, h), 1)
        try: font = pygame.font.SysFont("Arial", 14, bold=True)
        except: font = pygame.font.Font(None, 20)
        s = font.render(f"Broly [{int(p*100)}%]", True, (255, 0, 0))
        screen.blit(s, (x+30-s.get_width()//2, y-40))

    def take_damage(self, dmg):
        self.hp -= dmg
        if self.hp <= 0:
            self.hp = 0
            self.is_dead = True
    
    def get_drops(self):
        drops = []
        if random.randint(1, 100) <= 30: drops.append({"type": "VANG", "amount": 2000000})
        dice = random.uniform(0, 100); item_key = "gang_hoang_de"; drop_item = None
        if dice <= 1: drop_item = {"key": item_key, "star": 6}
        elif dice <= 6: drop_item = {"key": item_key, "star": 4}
        elif dice <= 16: drop_item = {"key": item_key, "star": 0}
        if drop_item:
            base_sd = 3000
            if drop_item["star"] == 6: drop_item["options"] = {"suc_danh": base_sd + 10000, "tan_cong_percent": 20}
            elif drop_item["star"] == 4: drop_item["options"] = {"suc_danh": base_sd + 5000}
            else: drop_item["options"] = {"suc_danh": base_sd}
            drops.append({"type": "ITEM", "data": drop_item})
        return drops

class BrolyBossManager:
    def __init__(self, map_width, ground_y):
        self.boss = None
        self.map_width = map_width
        self.ground_y = ground_y
        # Mặc định chưa có boss thì coi như đã chết từ rất lâu (để spawn ngay)
        # TRỪ KHI có dữ liệu load được
        self.last_spawn_time = pygame.time.get_ticks() - SPAWN_INTERVAL 
        self.load_data()

    def load_data(self):
        if not os.path.exists(DATA_FILE): return
        try:
            with open(DATA_FILE, "r") as f:
                data = json.load(f)
            import time
            current_ticks = pygame.time.get_ticks()
            real_time_now = time.time()
            saved_time = data.get("saved_time_system", 0)
            
            if data.get("is_alive"):
                # Nếu file ghi là đang sống, nhưng thời gian đã trôi qua quá lâu (> 15p)
                # thì coi như đã "biến mất" do time-out
                if real_time_now - saved_time < 900: # 15 phút
                    self.boss = BossBroly(data["x"], 0, self.ground_y, self.map_width, current_hp=data["hp"])
                    # Boss đang sống, không cần quan tâm last_spawn_time
                else:
                    self.boss = None
                    self.last_spawn_time = current_ticks - SPAWN_INTERVAL 
            else:
                # [QUAN TRỌNG] Logic khôi phục thời gian chờ
                self.boss = None
                cooldown_progress = data.get("cooldown_progress", 0)
                
                # Thời gian trôi qua khi tắt máy (đổi ra mili giây)
                time_offline_ms = (real_time_now - saved_time) * 1000
                
                # Tổng thời gian đã trôi qua kể từ lần chết trước
                total_elapsed = cooldown_progress + time_offline_ms
                
                # Đặt lại mốc thời gian spawn
                # last_spawn_time là mốc "Bắt đầu tính giờ"
                # Hiện tại (current_ticks) phải cách mốc đó một khoảng bằng total_elapsed
                self.last_spawn_time = current_ticks - total_elapsed

        except Exception as e:
            print(f"Lỗi load data Broly: {e}")

    def save_data(self):
        import time
        current_ticks = pygame.time.get_ticks()
        
        data = {
            "is_alive": False,
            "hp": 0,
            "x": 0,
            "saved_time_system": time.time(),
            "cooldown_progress": 0 # [MỚI] Lưu tiến độ hồi sinh
        }
        
        if self.boss and not self.boss.is_dead:
            data["is_alive"] = True
            data["hp"] = self.boss.hp
            data["x"] = self.boss.world_x
        else:
            # Boss đã chết hoặc chưa spawn
            # Tính xem đã trôi qua bao lâu kể từ mốc last_spawn_time
            data["cooldown_progress"] = current_ticks - self.last_spawn_time
            
        try:
            with open(DATA_FILE, "w") as f: json.dump(data, f)
        except: pass

    def update(self, current_time, player_rect, player_world_x, map_offset_x):
        if self.boss is None or self.boss.is_dead:
            if self.boss and self.boss.is_dead: 
                self.boss = None 
                self.last_spawn_time = current_time # Đánh dấu mốc bắt đầu chờ
                self.save_data()
            
            # Kiểm tra thời gian chờ
            if current_time - self.last_spawn_time >= SPAWN_INTERVAL:
                rand_x = random.randint(100, self.map_width - 100)
                self.boss = BossBroly(rand_x, 0, self.ground_y, self.map_width)
                self.save_data()
                return True 
        
        if self.boss: 
            self.boss.update(map_offset_x, player_rect, player_world_x)
            if current_time % 10000 < 60: self.save_data()
        return False

    def draw(self, screen, map_offset_x):
        if self.boss: self.boss.draw_manual(screen, map_offset_x)
        
    def check_attack(self, player_rect):
        if self.boss and not self.boss.is_dead: return self.boss.check_attack(player_rect)
        return 0