import os, json, pygame

# ===== PATHS =====
THU_MUC_GAME = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # -> c:\nro online
DATA_ACC_FILE  = os.path.join(THU_MUC_GAME, "du_lieu_acc.json")
DATA_CHAR_FILE = os.path.join(THU_MUC_GAME, "du_lieu_nhan_vat.json")
DATA_ITEM_FILE = os.path.join(THU_MUC_GAME, "du_lieu_vat_pham.json")
SAVED_LOGIN_FILE = os.path.join(THU_MUC_GAME, "saved_login.json")

# ===== CONFIG =====
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
GRAVITY = 1
JUMP_STRENGTH = -18

MENU_WIDTH = 300
MENU_SPEED = 20

GATEWAY_WIDTH = 80
GATEWAY_HEIGHT = 110

CHEST_POS_WORLD = 20
CHEST_HEIGHT = 50
CHEST_SIZE = 50
CHEST_INTERACT_DISTANCE = 80

# NPC positions (em dùng trong loop)
NPC_GOHAN_X = 200
NPC_BANDO_X = 350
NPC_ANXIN_X = 500
NPC_BHATMIT_X = NPC_ANXIN_X + 150
NPC_INTERACT_RANGE = 130

# ===== COLORS =====
WHITE = (255,255,255)
BLACK = (0,0,0)
GRAY = (200,200,200)
DARK_GRAY = (50,50,50)
BLUE_UI = (0,100,255)
RED_ERROR = (255,0,0)
GREEN_SUCCESS = (0,200,0)
C_VANG = (255,215,0)
C_HIGHLIGHT = (255,255,100)
RED_TITLE = (255,0,0)

# ===== JSON HELPERS =====
def load_json(filename):
    if not os.path.exists(filename):
        return {}
    try:
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

def save_json(filename, data):
    try:
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
    except Exception as e:
        print(f"Loi luu file: {e}")

# ===== PYGAME SHARED =====
def init_pygame_once():
    if not pygame.get_init():
        pygame.init()

def make_default_fonts():
    init_pygame_once()
    font = pygame.font.SysFont("Arial", 24)
    font_small = pygame.font.SysFont("Arial", 16)
    font_mini = pygame.font.SysFont("Arial", 12)
    font_big = pygame.font.SysFont("Arial", 50, bold=True)
    font_btn = pygame.font.SysFont("Arial", 20, bold=True)
    font_tiny = pygame.font.SysFont("Arial", 10)
    try:
        font_gateway = pygame.font.SysFont("Arial", 14, bold=True)
    except:
        font_gateway = pygame.font.Font(None, 20)
    return font, font_small, font_mini, font_big, font_btn, font_tiny, font_gateway

def make_screen_and_clock():
    init_pygame_once()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    clock = pygame.time.Clock()
    return screen, clock