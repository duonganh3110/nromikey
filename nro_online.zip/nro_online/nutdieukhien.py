# nutdieukhien.py
# Virtual on-screen controls (joystick + action buttons) for Pygame / pygame-ce
#
# VERSION: 2025-12-27 v5 (show skill names reliably)
#
# Mikey requirements:
# - Left: circular joystick for movement
# - Right: circular punch button
# - 5 skill slots: SQUARE, placed at bottom (replace old skill bar)
# - Slot must show SKILL NAME clearly when assigned from tab KỸ NĂNG (tuido/kynang)
# - Big UI panels should cover controls -> use ui.set_visible(False) / ui.cancel_inputs()
# - draw() must not crash even if caller passes extra args/kwargs (e.g. player_info=...)
#
# Usage in main loop:
#   ui_gamepad.draw(screen, player_info=info)   # IMPORTANT to see names
#
# This file is standalone.
# If kynang.py exists, we map skill_id -> skill name via kynang.get_skill_by_id().

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Tuple, List, Any, Dict

import pygame

try:
    import kynang as _kynang  # type: ignore
except Exception:
    _kynang = None


VERSION = "2025-12-27_v5"


def _clamp(v: float, lo: float, hi: float) -> float:
    return lo if v < lo else hi if v > hi else v


def _dist(ax: float, ay: float, bx: float, by: float) -> float:
    return math.hypot(ax - bx, ay - by)


def _normalize(x: float, y: float) -> Tuple[float, float]:
    m = math.hypot(x, y)
    if m <= 1e-9:
        return 0.0, 0.0
    return x / m, y / m


def _get_font(name: Optional[str], size: int, bold: bool = False) -> pygame.font.Font:
    if not pygame.font.get_init():
        pygame.font.init()
    try:
        return pygame.font.SysFont(name or "arial", size, bold=bold)
    except Exception:
        return pygame.font.Font(None, size)


def _skill_id_to_name(skill_id: Any) -> str:
    """
    Accepts skill_id in several forms:
    - string id, e.g. "kamejoko"
    - dict that contains {"id": "..."} or {"name": "..."}
    """
    if not skill_id:
        return "Trống"

    # dict support
    if isinstance(skill_id, dict):
        if "name" in skill_id and skill_id["name"]:
            return str(skill_id["name"]).strip()
        if "id" in skill_id and skill_id["id"]:
            skill_id = skill_id["id"]

    sid = str(skill_id).strip()
    if not sid:
        return "Trống"

    if _kynang is not None and hasattr(_kynang, "get_skill_by_id"):
        try:
            sk = _kynang.get_skill_by_id(sid)
            if sk:
                name = sk.get("name", sid)
                name = str(name).strip()
                if name:
                    return name
        except Exception:
            pass
    return sid


def _wrap_text(font: pygame.font.Font, text: str, max_w: int, max_lines: int = 2) -> List[str]:
    text = (text or "").strip()
    if not text:
        return [""]

    text = text.replace("_", " ")
    words = text.split()
    if not words:
        return [text[:max(1, min(len(text), 10))]]

    lines: List[str] = []
    cur = ""
    for w in words:
        test = (cur + " " + w).strip()
        if font.size(test)[0] <= max_w:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = w
            if len(lines) >= max_lines:
                break

    if len(lines) < max_lines and cur:
        lines.append(cur)

    if len(lines) == max_lines:
        joined = " ".join(words)
        drawn = " ".join(lines)
        if len(drawn) < len(joined):
            last = lines[-1]
            while last and font.size(last + "...")[0] > max_w:
                last = last[:-1]
            lines[-1] = (last + "...") if last else "..."
    return lines


@dataclass
class ButtonState:
    is_down: bool = False
    just_pressed: bool = False
    just_released: bool = False
    clicked: bool = False  # release-inside


class CircleButton:
    def __init__(
        self,
        cx: int,
        cy: int,
        radius: int,
        label: str = "",
        font: Optional[pygame.font.Font] = None,
        enabled: bool = True,
    ) -> None:
        self.cx = int(cx)
        self.cy = int(cy)
        self.radius = int(radius)
        self.label = label
        self.font = font
        self.enabled = enabled

        self._pressed_inside = False
        self.state = ButtonState()

        self.base_color = (40, 40, 40)
        self.ring_color = (220, 220, 220)
        self.down_color = (70, 70, 70)
        self.disabled_color = (25, 25, 25)
        self.text_color = (245, 245, 245)

    def set_pos(self, cx: int, cy: int) -> None:
        self.cx = int(cx)
        self.cy = int(cy)

    def hit_test(self, mx: int, my: int) -> bool:
        return _dist(mx, my, self.cx, self.cy) <= self.radius

    def reset_frame_flags(self) -> None:
        self.state.just_pressed = False
        self.state.just_released = False
        self.state.clicked = False

    def handle_event(self, event: pygame.event.Event) -> None:
        if not self.enabled:
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            if self.hit_test(mx, my):
                self._pressed_inside = True
                self.state.is_down = True
                self.state.just_pressed = True

        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            mx, my = event.pos
            inside = self.hit_test(mx, my)
            if self.state.is_down:
                self.state.is_down = False
                self.state.just_released = True
                if self._pressed_inside and inside:
                    self.state.clicked = True
            self._pressed_inside = False

    def draw(self, surf: pygame.Surface, active: bool = False) -> None:
        if not self.enabled:
            base = self.disabled_color
            ring = (90, 90, 90)
        else:
            base = self.down_color if self.state.is_down else self.base_color
            ring = self.ring_color

        if active and self.enabled:
            ring = (255, 210, 60)

        pygame.draw.circle(surf, base, (self.cx, self.cy), self.radius)
        pygame.draw.circle(surf, ring, (self.cx, self.cy), self.radius, 3)

        if self.label and self.font:
            txt = self.font.render(self.label, True, self.text_color)
            surf.blit(txt, txt.get_rect(center=(self.cx, self.cy)))


class SquareButton:
    """Square skill slot button."""
    def __init__(
        self,
        x: int,
        y: int,
        size: int,
        font_num: pygame.font.Font,
        font_name: pygame.font.Font,
        enabled: bool = True,
    ) -> None:
        self.rect = pygame.Rect(int(x), int(y), int(size), int(size))
        self.font_num = font_num
        self.font_name = font_name
        self.enabled = enabled

        self._pressed_inside = False
        self.state = ButtonState()

        self.fill = (25, 25, 35)
        self.fill_down = (45, 45, 60)
        self.border = (255, 215, 0)
        self.border_active = (0, 160, 255)
        self.text_color = (245, 245, 245)

    def set_pos(self, x: int, y: int) -> None:
        self.rect.x = int(x)
        self.rect.y = int(y)

    def set_size(self, size: int) -> None:
        size = int(size)
        self.rect.w = size
        self.rect.h = size

    def hit_test(self, mx: int, my: int) -> bool:
        return self.rect.collidepoint(mx, my)

    def reset_frame_flags(self) -> None:
        self.state.just_pressed = False
        self.state.just_released = False
        self.state.clicked = False

    def handle_event(self, event: pygame.event.Event) -> None:
        if not self.enabled:
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            if self.hit_test(mx, my):
                self._pressed_inside = True
                self.state.is_down = True
                self.state.just_pressed = True

        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            mx, my = event.pos
            inside = self.hit_test(mx, my)
            if self.state.is_down:
                self.state.is_down = False
                self.state.just_released = True
                if self._pressed_inside and inside:
                    self.state.clicked = True
            self._pressed_inside = False

    def draw(self, surf: pygame.Surface, *, active: bool, slot_number: int, skill_id: Any, mouse_pos: Tuple[int, int]) -> None:
        fill = self.fill_down if self.state.is_down else self.fill
        pygame.draw.rect(surf, fill, self.rect, border_radius=8)
        pygame.draw.rect(
            surf,
            self.border_active if active else self.border,
            self.rect,
            4 if active else 2,
            border_radius=8
        )

        # slot number (top-left)
        tnum = self.font_num.render(str(slot_number), True, self.text_color)
        surf.blit(tnum, (self.rect.x + 6, self.rect.y + 4))

        # skill name (center) - BIG + WRAP
        name = _skill_id_to_name(skill_id)
        max_w = self.rect.w - 12
        lines = _wrap_text(self.font_name, name, max_w, max_lines=2)

        block_h = len(lines) * self.font_name.get_height()
        start_y = self.rect.centery - block_h // 2 + 6
        for i, ln in enumerate(lines):
            t = self.font_name.render(ln, True, self.text_color)
            surf.blit(t, (self.rect.centerx - t.get_width() // 2, start_y + i * self.font_name.get_height()))

        # hover tooltip (full name)
        mx, my = mouse_pos
        if self.rect.collidepoint(mx, my) and name:
            tip_font = self.font_name
            tip = name
            pad = 8
            tip_surf = tip_font.render(tip, True, (255, 255, 255))
            bw = tip_surf.get_width() + pad * 2
            bh = tip_surf.get_height() + pad * 2
            bx = max(8, min(surf.get_width() - bw - 8, self.rect.centerx - bw // 2))
            by = max(8, self.rect.y - bh - 8)
            bg = pygame.Surface((bw, bh), pygame.SRCALPHA)
            bg.fill((0, 0, 0, 180))
            surf.blit(bg, (bx, by))
            surf.blit(tip_surf, (bx + pad, by + pad))


class VirtualJoystick:
    def __init__(
        self,
        cx: int,
        cy: int,
        base_radius: int = 82,
        knob_radius: int = 34,
        deadzone: float = 0.10,
    ) -> None:
        self.cx = int(cx)
        self.cy = int(cy)
        self.base_radius = int(base_radius)
        self.knob_radius = int(knob_radius)
        self.deadzone = float(deadzone)

        self._dragging = False
        self._knob_x = float(cx)
        self._knob_y = float(cy)

        self._vx = 0.0
        self._vy = 0.0
        self._mag = 0.0

        self.base_fill = (25, 25, 25)
        self.base_ring = (200, 200, 200)
        self.knob_fill = (55, 55, 55)
        self.knob_ring = (230, 230, 230)

    def set_pos(self, cx: int, cy: int) -> None:
        self.cx = int(cx)
        self.cy = int(cy)
        if not self._dragging:
            self._knob_x = float(cx)
            self._knob_y = float(cy)

    def cancel(self) -> None:
        """Huỷ kéo joystick (đưa cần về giữa, vector = 0)."""
        self._dragging = False
        self._knob_x, self._knob_y = float(self.cx), float(self.cy)
        self._vx, self._vy, self._mag = 0.0, 0.0, 0.0

    def _inside_base(self, mx: int, my: int) -> bool:
        return _dist(mx, my, self.cx, self.cy) <= self.base_radius

    def _set_knob(self, mx: float, my: float) -> None:
        dx = mx - self.cx
        dy = my - self.cy
        d = math.hypot(dx, dy)

        if d <= 1e-9:
            self.cancel()
            return

        limit = self.base_radius - self.knob_radius * 0.35
        if d > limit:
            scale = limit / d
            dx *= scale
            dy *= scale

        self._knob_x = float(self.cx + dx)
        self._knob_y = float(self.cy + dy)

        nx = dx / limit
        ny = dy / limit
        mag = _clamp(math.hypot(nx, ny), 0.0, 1.0)

        if mag < self.deadzone:
            self._vx, self._vy, self._mag = 0.0, 0.0, 0.0
        else:
            mag2 = (mag - self.deadzone) / (1.0 - self.deadzone)
            mag2 = _clamp(mag2, 0.0, 1.0)
            ux, uy = _normalize(nx, ny)
            self._vx, self._vy, self._mag = ux, uy, mag2

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            if self._inside_base(mx, my):
                self._dragging = True
                self._set_knob(mx, my)

        elif event.type == pygame.MOUSEMOTION and self._dragging:
            mx, my = event.pos
            self._set_knob(mx, my)

        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self._dragging:
                self.cancel()

    def get_vector(self) -> Tuple[float, float, float]:
        return self._vx, self._vy, self._mag

    def draw(self, surf: pygame.Surface) -> None:
        pygame.draw.circle(surf, self.base_fill, (self.cx, self.cy), self.base_radius)
        pygame.draw.circle(surf, self.base_ring, (self.cx, self.cy), self.base_radius, 3)
        pygame.draw.circle(surf, self.knob_fill, (int(self._knob_x), int(self._knob_y)), self.knob_radius)
        pygame.draw.circle(surf, self.knob_ring, (int(self._knob_x), int(self._knob_y)), self.knob_radius, 3)


class GamepadUI:
    """
    Joystick + Punch + Bottom square skill slots.

    Link player_info:
      ui.draw(screen, player_info=info)   # easiest (auto-bind)
    Or:
      ui.bind_player_info(info)

    Hide when big UI open:
      ui.set_visible(False)
    """
    def __init__(
        self,
        screen_w: int,
        screen_h: int,
        *,
        margin: int = 22,
        base_radius: int = 82,
        knob_radius: int = 34,
        punch_radius: int = 60,
        slot_size: int = 72,     # bigger so name is visible
        slot_count: int = 5,
        slot_gap: int = 10,
    ) -> None:
        self.screen_w = int(screen_w)
        self.screen_h = int(screen_h)
        self.margin = int(margin)

        self.font_big = _get_font("arial", 20, bold=True)
        self.font_num = _get_font("arial", 16, bold=True)
        self.font_name = _get_font("arial", 14, bold=False)

        joy_cx = self.margin + base_radius
        joy_cy = self.screen_h - self.margin - base_radius
        self.joystick = VirtualJoystick(joy_cx, joy_cy, base_radius=base_radius, knob_radius=knob_radius)

        punch_cx = self.screen_w - self.margin - punch_radius
        punch_cy = self.screen_h - self.margin - punch_radius
        self.punch_button = CircleButton(punch_cx, punch_cy, punch_radius, label="ĐẤM", font=self.font_big)

        self.slot_count = int(slot_count)
        self.slot_size = int(slot_size)
        self.slot_gap = int(slot_gap)

        self.skill_slots: List[SquareButton] = []
        self._layout_skill_slots_bottom()

        self._player_info: Optional[Dict[str, Any]] = None
        self.active_skill_slot: int = 0
        self._punch_clicked = False
        self._skill_changed_to: Optional[int] = None

        self.skills_enabled = True
        self._visible = True

    def _layout_skill_slots_bottom(self) -> None:
        total_w = self.slot_count * self.slot_size + (self.slot_count - 1) * self.slot_gap
        start_x = (self.screen_w - total_w) // 2
        y = self.screen_h - self.margin - self.slot_size

        self.skill_slots = []
        for i in range(self.slot_count):
            x = start_x + i * (self.slot_size + self.slot_gap)
            self.skill_slots.append(SquareButton(x, y, self.slot_size, self.font_num, self.font_name))

    def set_visible(self, visible: bool) -> None:
        self._visible = bool(visible)
        if not self._visible:
            self.cancel_inputs()

    def cancel_inputs(self) -> None:
        self.joystick.cancel()
        self.punch_button.state.is_down = False
        try:
            self.punch_button._pressed_inside = False  # type: ignore[attr-defined]
        except Exception:
            pass
        for b in self.skill_slots:
            b.state.is_down = False
            try:
                b._pressed_inside = False  # type: ignore[attr-defined]
            except Exception:
                pass
        self._punch_clicked = False
        self._skill_changed_to = None

    def bind_player_info(self, player_info: Dict[str, Any]) -> None:
        self._player_info = player_info
        try:
            self.active_skill_slot = int(player_info.get("active_skill_slot", self.active_skill_slot))
        except Exception:
            pass

    def resize(self, screen_w: int, screen_h: int) -> None:
        self.screen_w = int(screen_w)
        self.screen_h = int(screen_h)

        self.joystick.set_pos(self.margin + self.joystick.base_radius,
                              self.screen_h - self.margin - self.joystick.base_radius)

        punch_r = self.punch_button.radius
        punch_cx = self.screen_w - self.margin - punch_r
        punch_cy = self.screen_h - self.margin - punch_r
        self.punch_button.set_pos(punch_cx, punch_cy)

        self._layout_skill_slots_bottom()

    def reset_frame_flags(self) -> None:
        self.punch_button.reset_frame_flags()
        for b in self.skill_slots:
            b.reset_frame_flags()
        self._punch_clicked = False
        self._skill_changed_to = None

    def handle_event(self, event: pygame.event.Event) -> None:
        if not self._visible:
            return

        self.joystick.handle_event(event)

        self.punch_button.handle_event(event)
        if self.punch_button.state.clicked:
            self._punch_clicked = True

        if self.skills_enabled:
            for i, btn in enumerate(self.skill_slots):
                btn.handle_event(event)
                if btn.state.clicked:
                    self.active_skill_slot = i
                    self._skill_changed_to = i
                    if self._player_info is not None:
                        try:
                            self._player_info["active_skill_slot"] = i
                        except Exception:
                            pass

    def get_move(self) -> Tuple[float, float, float]:
        return self.joystick.get_vector()

    def consume_punch(self) -> bool:
        if self._punch_clicked:
            self._punch_clicked = False
            return True
        return False

    def consume_skill_change(self) -> Optional[int]:
        if self._skill_changed_to is not None:
            v = self._skill_changed_to
            self._skill_changed_to = None
            return v
        return None

    def get_skill_slot_rects(self) -> List[pygame.Rect]:
        return [b.rect for b in self.skill_slots]

    def draw(self, surf: pygame.Surface, *args, **kwargs) -> None:
        """
        Draw controls. IMPORTANT: pass player_info to show skill names:
            ui.draw(screen, player_info=info)
        """
        if not self._visible:
            return

        pi = kwargs.get("player_info")
        if isinstance(pi, dict):
            self.bind_player_info(pi)

        self.joystick.draw(surf)
        self.punch_button.draw(surf)

        slots: List[Any] = []
        active = self.active_skill_slot

        if self._player_info is not None:
            try:
                slots = self._player_info.get("skill_slots", [])
                active = int(self._player_info.get("active_skill_slot", active))
            except Exception:
                pass

        mouse_pos = pygame.mouse.get_pos()
        if self.skills_enabled:
            for i, btn in enumerate(self.skill_slots):
                sid = None
                try:
                    if isinstance(slots, list) and i < len(slots):
                        sid = slots[i]
                except Exception:
                    sid = None
                btn.draw(surf, active=(i == active), slot_number=i + 1, skill_id=sid, mouse_pos=mouse_pos)


# Demo
if __name__ == "__main__":
    pygame.init()
    screen = pygame.display.set_mode((1100, 620))
    clock = pygame.time.Clock()

    ui = GamepadUI(screen.get_width(), screen.get_height())
    fake_info = {"skill_slots": [None, "kamejoko", "masenko", "atomic_gold", None], "active_skill_slot": 1}

    px, py = screen.get_width() // 2, screen.get_height() // 2
    speed = 260.0

    running = True
    while running:
        dt = clock.tick(60) / 1000.0

        ui.reset_frame_flags()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            ui.handle_event(event)

        vx, vy, mag = ui.get_move()
        px += int(vx * mag * speed * dt)
        py += int(vy * mag * speed * dt)

        if ui.consume_punch():
            print("PUNCH/FIRE!")

        slot = ui.consume_skill_change()
        if slot is not None:
            fake_info["active_skill_slot"] = slot
            print("ACTIVE SLOT:", slot + 1)

        screen.fill((12, 12, 18))
        pygame.draw.circle(screen, (230, 230, 230), (px, py), 16)
        ui.draw(screen, player_info=fake_info)
        pygame.display.flip()

    pygame.quit()
