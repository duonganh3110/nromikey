# game_modules/vang.py
import pygame
import sys
import os

# --- CẤU HÌNH & MÀU SẮC (Dùng từ main.py) ---
WHITE = (255, 255, 255)
C_VANG = (255, 215, 0)
C_DIAMOND = (0, 200, 255) # Màu kim cương xanh
BLACK = (0, 0, 0)

# Kích thước HUD tiền tệ
HUD_WIDTH = 150
HUD_HEIGHT = 40
ICON_SIZE = 16
MARGIN = 10

# Biến font để sử dụng
font_small = None
font_mini = None

def init_fonts():
    """Khởi tạo fonts nếu chưa được khởi tạo"""
    global font_small, font_mini
    if font_small is None or font_mini is None:
        try:
            pygame.init()
            if not pygame.font.get_init():
                pygame.font.init()
            font_small = pygame.font.SysFont("Arial", 16)
            font_mini = pygame.font.SysFont("Arial", 12)
        except:
            # Dùng font mặc định nếu Pygame chưa sẵn sàng
            font_small = lambda text, antialias, color: pygame.Surface((1, 1))
            font_mini = lambda text, antialias, color: pygame.Surface((1, 1))


def draw_currency_icon(surface, cx, cy, currency_type):
    """Vẽ icon Vàng hoặc Kim Cương"""
    init_fonts()
    
    if currency_type == "VANG":
        # Icon Vàng (Hình đồng xu màu vàng)
        pygame.draw.circle(surface, C_VANG, (cx, cy), ICON_SIZE // 2 + 1)
        pygame.draw.circle(surface, (200, 150, 0), (cx, cy), ICON_SIZE // 2, 1)
        # Chữ 'V' nhỏ ở giữa
        v_surf = font_mini.render("V", True, BLACK)
        surface.blit(v_surf, v_surf.get_rect(center=(cx, cy)))

    elif currency_type == "KIM_CUONG":
        # Icon Kim Cương (Hình viên kim cương màu xanh)
        pts = [(cx, cy - ICON_SIZE//2), 
               (cx + ICON_SIZE//4, cy - ICON_SIZE//4), 
               (cx, cy + ICON_SIZE//2), 
               (cx - ICON_SIZE//4, cy - ICON_SIZE//4)]
        pygame.draw.polygon(surface, C_DIAMOND, pts)
        pygame.draw.polygon(surface, BLACK, pts, 1)
        
def draw_currency_hud(screen, vang_amount, kim_cuong_amount, screen_width, screen_height):
    """Vẽ HUD tiền tệ ở góc dưới bên trái màn hình"""
    init_fonts()
    
    # Kích thước HUD
    HUD_RECT = pygame.Rect(MARGIN, screen_height - HUD_HEIGHT * 2 - MARGIN * 2, HUD_WIDTH, HUD_HEIGHT * 2)

    # 1. Vẽ nền chung (đen trong suốt)
    overlay = pygame.Surface((HUD_RECT.width, HUD_RECT.height), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180)) 
    screen.blit(overlay, HUD_RECT)
    pygame.draw.rect(screen, WHITE, HUD_RECT, 1)

    # 2. Dòng VÀNG
    vang_text = font_small.render(f"{vang_amount:,}", True, C_VANG)
    
    # Icon Vàng
    icon_vang_cx = HUD_RECT.x + MARGIN + ICON_SIZE // 2
    icon_vang_cy = HUD_RECT.y + HUD_HEIGHT // 2
    draw_currency_icon(screen, icon_vang_cx, icon_vang_cy, "VANG")
    
    # Vị trí chữ vàng
    screen.blit(vang_text, (HUD_RECT.x + ICON_SIZE + MARGIN * 2, icon_vang_cy - vang_text.get_height() // 2))

    # 3. Dòng KIM CƯƠNG
    kim_cuong_text = font_small.render(f"{kim_cuong_amount:,}", True, C_DIAMOND)
    
    # Icon Kim Cương
    icon_kc_cx = HUD_RECT.x + MARGIN + ICON_SIZE // 2
    icon_kc_cy = HUD_RECT.y + HUD_HEIGHT + HUD_HEIGHT // 2
    draw_currency_icon(screen, icon_kc_cx, icon_kc_cy, "KIM_CUONG")
    
    # Vị trí chữ kim cương
    screen.blit(kim_cuong_text, (HUD_RECT.x + ICON_SIZE + MARGIN * 2, icon_kc_cy - kim_cuong_text.get_height() // 2))

# =========================================================================
# HÀM LOGIC TIÊU DÙNG (CẦN LƯU VÀO FILE JSON)
# =========================================================================

def can_afford(player_data, cost_vang=0, cost_kc=0):
    """Kiểm tra người chơi có đủ tiền không"""
    return player_data.get("vang", 0) >= cost_vang and player_data.get("kim_cuong", 0) >= cost_kc

def deduct_currency(player_data, cost_vang=0, cost_kc=0):
    """Trừ tiền và trả về True nếu thành công, False nếu không đủ tiền"""
    if can_afford(player_data, cost_vang, cost_kc):
        player_data["vang"] = player_data.get("vang", 0) - cost_vang
        player_data["kim_cuong"] = player_data.get("kim_cuong", 0) - cost_kc
        
        # Đảm bảo tiền không âm
        player_data["vang"] = max(0, player_data["vang"])
        player_data["kim_cuong"] = max(0, player_data["kim_cuong"])
        
        return True
    return False

# Ví dụ sử dụng:
# player_data = {"vang": 100, "kim_cuong": 5}
# if deduct_currency(player_data, cost_kc=3):
#     # Logic thành công
# else:
#     # Logic thất bại