# superbroly.py
# Super Broly - inherit BossBroly
# - Stats stronger
# - Visual: gold hair + gold aura
# - Extra:
#   (1) despawn after 5 minutes if no target detected
#   (2) speed pressure: chase faster than player + short dash to close gap (harder to escape)

import pygame
import random

import bossbroly  # reuse base AI/physics from BossBroly

__BROLY_FIX__ = "CHASE_V3"


SUPER_BROLY_DAME_MIN = 20000
SUPER_BROLY_DAME_MAX = 25000
SUPER_BROLY_HP_MIN = 1_000_000
SUPER_BROLY_HP_MAX = 2_500_000

HAIR_COLOR_GOLD = (255, 215, 0)
AURA_COLOR_INNER = (255, 255, 180)
AURA_COLOR_OUTER = (255, 200, 0)


class BossSuperBroly(bossbroly.BossBroly):
    def __init__(self, x, y, ground_y, map_width, current_hp=None, max_hp=None):
        super().__init__(x, y, ground_y, map_width, current_hp=current_hp)

        # hp
        self.max_hp = int(max_hp) if max_hp is not None else random.randint(SUPER_BROLY_HP_MIN, SUPER_BROLY_HP_MAX)
        self.hp = int(current_hp) if current_hp is not None else self.max_hp

        # damage
        self.dame_min = SUPER_BROLY_DAME_MIN
        self.dame_max = SUPER_BROLY_DAME_MAX

        # identity
        self.name_display = "Super Broly"
        self.boss_type = "superbroly"


        # đảm bảo bảng thông báo / UI không bị hiện "Broly"
        self.name = "Super Broly"
        self.boss_name = "Super Broly"
        self.ten_boss = "Super Broly"
        # despawn config (IMPORTANT: must stay inside __init__)
        now = pygame.time.get_ticks()
        self._spawn_tick = now
        self._last_seen_tick = now
        self._despawn_ms = 5 * 60 * 1000  # 5 minutes
        self._detect_range_px = 900

        # ===== HARD CHASE TUNING =====
        # Make boss faster + dash to close distance.
        # Tune these numbers if too hard.
        self._chase_min_speed = 6.8
        self._chase_max_speed = 9.6
        self._attack_stop_px = 120  # stop pushing when this close (lets base attack happen)
        self._dash_speed = 12.5
        self._dash_ms = 240
        self._dash_cd = 950
        self._dash_trigger_min = 240
        self._dash_trigger_max = 650
        self._dash_until = 0
        self._dash_next = 0

    # ------------------ DESPAWN ------------------
    def _ensure_despawn_fields(self):
        if not hasattr(self, "_last_seen_tick"):
            now = pygame.time.get_ticks()
            self._spawn_tick = now
            self._last_seen_tick = now
            self._despawn_ms = 5 * 60 * 1000
            self._detect_range_px = 900

    def _parse_player_world_x(self, map_offset_x, *args):
        """
        Try to infer player_world_x from update(map_offset_x, *args)
        Common call patterns in your project:
          update(map_offset_x, player_rect)
          update(map_offset_x, player_rect, player_world_x)
          update(map_offset_x, player_world_x)
          update(map_offset_x, False) or other variants
        """
        player_world_x = None

        try:
            if len(args) >= 2 and isinstance(args[1], (int, float)):
                # (player_rect, player_world_x)
                player_world_x = float(args[1])

            elif len(args) >= 1 and isinstance(args[0], pygame.Rect):
                # (player_rect)
                r = args[0]
                player_world_x = float(r.centerx + map_offset_x)

            elif len(args) >= 1 and isinstance(args[0], (int, float)):
                # (player_world_x)
                player_world_x = float(args[0])

            elif len(args) >= 2 and isinstance(args[1], pygame.Rect):
                # (something, player_rect)
                r = args[1]
                player_world_x = float(r.centerx + map_offset_x)
        except Exception:
            player_world_x = None

        return player_world_x

    def _update_last_seen(self, map_offset_x, *args):
        player_world_x = self._parse_player_world_x(map_offset_x, *args)
        if player_world_x is None:
            return

        try:
            # NOTE: in bossbroly, rect.x is usually world-x
            boss_world_x = float(getattr(self, 'world_x', self.rect.x)) + float(self.rect.width) * 0.5
            dist = abs(player_world_x - boss_world_x)
            if dist <= float(self._detect_range_px):
                self._last_seen_tick = pygame.time.get_ticks()
        except Exception:
            pass

    # ------------------ SPEED PRESSURE ------------------
    def _apply_speed_pressure(self, map_offset_x, *args):
        if getattr(self, "is_dead", False):
            return

        player_world_x = self._parse_player_world_x(map_offset_x, *args)
        if player_world_x is None:
            return
        # cho base AI biết mục tiêu (tránh nó tự kéo về target cũ)
        try:
            self.target_world_x = float(player_world_x)
        except Exception:
            pass

        # If base AI is in special state, don't force-move.
        st = str(getattr(self, "state", "IDLE"))
        if st in ("HURT", "DEAD"):
            return

        try:
            boss_world_x = float(getattr(self, 'world_x', self.rect.x)) + float(self.rect.width) * 0.5
        except Exception:
            return

        dist = player_world_x - boss_world_x
        adist = abs(dist)
        if adist <= 1:
            return

        sign = 1.0 if dist > 0 else -1.0

        now = pygame.time.get_ticks()

        # Dash when target is in mid range (harder to kite)
        if (now >= self._dash_next) and (self._dash_trigger_min <= adist <= self._dash_trigger_max):
            self._dash_until = now + int(self._dash_ms)
            self._dash_next = now + int(self._dash_cd)

        if now < self._dash_until:
            try:
                self.vel_x = sign * float(self._dash_speed)
                self.facing_right = (sign > 0)
            except Exception:
                pass
            return

        # Normal pressure: clamp vel_x toward target
        if adist > float(self._attack_stop_px):
            try:
                # If base AI already moves, just scale it up.
                vx = float(getattr(self, "vel_x", 0.0))
                base = max(abs(vx), float(self._chase_min_speed))
                new_vx = sign * min(float(self._chase_max_speed), base * 1.20)
                self.vel_x = new_vx
                self.facing_right = (sign > 0)
            except Exception:
                pass

    def update(self, map_offset_x, *args):
        # ===== FIX v3: Super Broly truy đuổi khắp map (không đứng 1 chỗ) =====
        # - Áp chase (vel_x) TRƯỚC super().update() để base AI move được trong cùng frame
        # - Nếu base vẫn không dịch x, FORCE MOVE theo vel_x để boss luôn chạy theo người chơi
        # - Giữ despawn 5 phút nếu không thấy người chơi

        if getattr(self, "is_dead", False):
            return

        # despawn tracking
        self._ensure_despawn_fields()
        self._update_last_seen(map_offset_x, *args)

        now = pygame.time.get_ticks()
        if (now - self._last_seen_tick) >= self._despawn_ms:
            self.is_dead = True
            return

        player_world_x = self._parse_player_world_x(map_offset_x, *args)

        try:
            prev_x = int(self.rect.x)
        except Exception:
            prev_x = 0

        # áp chase trước để base có vel_x
        if player_world_x is not None:
            self._apply_speed_pressure(map_offset_x, *args)

        vx_before = float(getattr(self, "vel_x", 0.0))

        # giữ logic base (attack/gravity/anim)
        super().update(map_offset_x, *args)

        if player_world_x is None:
            return

        try:
            x_after = int(self.rect.x)
        except Exception:
            return

        st = str(getattr(self, "state", ""))
        if st in ("HURT", "DEAD"):
            return

        # nếu base không move theo x mà vel_x đang có -> ép move
        if abs(x_after - prev_x) < 1 and abs(vx_before) > 0.05:
            try:
                boss_world_x = float(getattr(self, 'world_x', self.rect.x)) + float(self.rect.width) * 0.5
                adist = abs(float(player_world_x) - boss_world_x)
            except Exception:
                adist = 99999.0

            if adist > float(self._attack_stop_px):
                new_x = prev_x + int(round(vx_before))

                mw = getattr(self, "map_width", None)
                if mw is None:
                    mw = getattr(self, "_map_width", None)

                try:
                    if mw is not None:
                        mw = float(mw)
                        new_x = max(0, min(int(mw - self.rect.width), new_x))
                except Exception:
                    pass

                try:
                    # FIX: BossBroly base dùng world_x là tọa độ thật => phải sync cả world_x và rect.x
                    if hasattr(self, "world_x"):
                        self.world_x = float(new_x)
                except Exception:
                    pass
                try:
                    self.rect.x = int(new_x)
                except Exception:
                    pass
                # anti-stuck: nếu bị kẹt do va chạm/tường vô hình, nhích nhẹ để thoát kẹt
                try:
                    now2 = pygame.time.get_ticks()
                    if not hasattr(self, "_unstuck_next"):
                        self._unstuck_next = 0
                        self._stuck_since = now2
                        self._stuck_last_x = int(getattr(self, "world_x", self.rect.x))
                    curx = int(getattr(self, "world_x", self.rect.x))
                    if abs(curx - int(self._stuck_last_x)) < 1:
                        if now2 - int(self._stuck_since) > 700 and now2 >= int(self._unstuck_next):
                            sign2 = 1 if float(player_world_x) > (curx + self.rect.width * 0.5) else -1
                            newx2 = curx + int(80 * sign2)
                            mw2 = getattr(self, "map_width", None)
                            if mw2 is None:
                                mw2 = getattr(self, "_map_width", None)
                            if mw2 is not None:
                                mw2 = float(mw2)
                                newx2 = max(0, min(int(mw2 - self.rect.width), newx2))
                            if hasattr(self, "world_x"):
                                self.world_x = float(newx2)
                            self.rect.x = int(newx2)
                            try:
                                self.create_impact_effect()
                            except Exception:
                                pass
                            self._unstuck_next = now2 + 1200
                            self._stuck_since = now2
                    else:
                        self._stuck_last_x = curx
                        self._stuck_since = now2
                except Exception:
                    pass


    # ------------------ VISUAL OVERRIDES ------------------
    def draw_aura_and_wind(self, screen, cx, cy):
        aura_surf = pygame.Surface((140, 140), pygame.SRCALPHA)
        pygame.draw.circle(aura_surf, (*AURA_COLOR_OUTER, 120), (70, 70), int(getattr(self, "aura_radius", 60)) + 5)
        pygame.draw.circle(aura_surf, (*AURA_COLOR_INNER, 170), (70, 70), int(getattr(self, "aura_radius", 60) * 0.75))
        screen.blit(aura_surf, (cx - 70, cy - 70))

        if abs(getattr(self, "vel_x", 0)) > 1 or getattr(self, "state", "") == "ATTACK_PREP":
            for _ in range(4):
                ox = random.randint(-45, 45)
                oy = random.randint(-55, 55)
                ln = random.randint(25, 60)
                pygame.draw.line(screen, (255, 240, 160), (cx + ox, cy + oy), (cx + ox, cy + oy - ln), 2)

    def draw_manual(self, screen, map_offset_x):
        if getattr(self, "is_dead", False):
            return

        sx = self.rect.x - map_offset_x
        sy = self.rect.y

        if sx < -100 or sx > 800 + 100:
            return

        cx = sx + 30
        cy = sy + 45
        d = 1 if getattr(self, "facing_right", True) else -1
        b = 2 if (getattr(self, "frame_index", 0) % 2 != 0 and getattr(self, "on_ground", True)) else 0

        # particles (same as base style)
        for p in getattr(self, "particles", []):
            px = p.x - map_offset_x
            if 0 <= px <= 800:
                pygame.draw.rect(screen, p.color, (px, p.y, p.size, p.size))

        # aura gold
        self.draw_aura_and_wind(screen, cx, cy)

        # legs/pants
        pygame.draw.rect(screen, bossbroly.PANTS_COLOR_Z, (cx - 15, sy + 60 - b, 12, 30))
        pygame.draw.rect(screen, bossbroly.PANTS_COLOR_Z, (cx + 3, sy + 60 - b, 12, 30))

        # body
        body_col = (255, 120, 120) if getattr(self, "state", "") == "ATTACK_PREP" else bossbroly.SKIN_COLOR
        pygame.draw.rect(screen, body_col, (cx - 22, sy + 25, 44, 40))

        # belt/sash
        pygame.draw.rect(screen, bossbroly.SASH_COLOR, (cx - 20, sy + 60 - b, 40, 8))
        pygame.draw.polygon(screen, (218, 165, 32), [(cx - 15, sy + 65), (cx + 15, sy + 65), (cx, sy + 85)])

        # head
        pygame.draw.circle(screen, body_col, (cx, sy + 15), 15)

        # hair (gold)
        h = [
            (cx, sy - 25), (cx - 20, sy - 10), (cx - 35, sy + 5), (cx - 28, sy + 30),
            (cx + 20, sy - 10), (cx + 35, sy + 5), (cx + 28, sy + 30)
        ]
        fh = [(cx + (hx - cx) * d, hy) for hx, hy in h]
        pygame.draw.polygon(screen, HAIR_COLOR_GOLD, fh)

        # eye
        pygame.draw.circle(screen, (255, 255, 255), (cx + 5 * d, sy + 13), 3)

        # attack fx (same logic)
        t = pygame.time.get_ticks()
        if getattr(self, "state", "") == "ATTACK_PREP":
            glow_s = pygame.Surface((34, 34), pygame.SRCALPHA)
            pygame.draw.circle(glow_s, (255, 200, 0, 160), (17, 17), 17)
            screen.blit(glow_s, (cx + 20 * d - 17, sy + 30 - 17))

        if getattr(self, "state", "") == "COOLDOWN" and t - int(getattr(self, "last_attack_time", 0)) < 200:
            fx = cx + 55 * d
            fy = sy + 40
            pygame.draw.line(screen, (255, 255, 200), (cx, sy + 35), (fx, fy), 15)
            pygame.draw.circle(screen, (255, 140, 0), (fx, fy), 25)
            for _ in range(4):
                lx = fx + random.randint(-20, 20)
                ly = fy + random.randint(-20, 20)
                pygame.draw.line(screen, (255, 255, 0), (fx, fy), (lx, ly), 2)

        self.draw_health_bar(screen, sx, sy)

    def draw_health_bar(self, screen, x, y):
        w = 80
        h = 10
        p = max(0.0, float(self.hp) / float(self.max_hp)) if getattr(self, "max_hp", 0) else 0.0
        pygame.draw.rect(screen, (100, 0, 0), (x - 10, y - 20, w, h))
        pygame.draw.rect(screen, (255, 200, 0), (x - 10, y - 20, w * p, h))
        pygame.draw.rect(screen, (0, 0, 0), (x - 10, y - 20, w, h), 1)
        try:
            font = pygame.font.SysFont("Arial", 14, bold=True)
        except Exception:
            font = pygame.font.Font(None, 20)
        s = font.render(f"Super Broly [{int(p * 100)}%]", True, (255, 140, 0))
        screen.blit(s, (x + 30 - s.get_width() // 2, y - 40))
