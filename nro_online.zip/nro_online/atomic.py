# atomic.py
# Hiệu ứng chiêu "Atomic GOLD" (Pygame) - dạng skill module để tích hợp vào game
# - Gồng ngắn (CAST_DELAY) rồi bắn beam ngắn (FIRING_DUR)
# - Hỗ trợ lock mục tiêu (target_obj có .rect world-coordinates)
#
# Gợi ý tích hợp (main loop):
#   from atomic import AtomicGoldSkill
#   atomic_skill = AtomicGoldSkill()
#   ...
#   if active_skill_id == "atomic_gold":
#       atomic_skill.set_ready(keys[pygame.K_j] and not is_ui_open and not is_stunned)
#       if mouse_left_click:
#           atomic_skill.request_cast(origin_world, target_obj=_proxy_or_target)
#   atomic_skill.update(dt, origin_world, aim_dir)
#   if atomic_skill.consume_fire():  # trả True đúng 1 lần lúc bắt đầu bắn
#       atomic_attack_now = True; should_attack = True; last_attack_time = current_time - ATTACK_COOLDOWN - 1
#   atomic_skill.draw(screen, cam_off=pygame.Vector2(-map_offset_x, 0))
#
# Lưu ý: atomic_skill không tự trừ KI hay tự gây damage; bạn có thể dùng logic attack_rect sẵn có như Kamejoko.

import math
import random
from dataclasses import dataclass
from typing import Optional, Any

import pygame


def clamp(x: float, a: float, b: float) -> float:
    return a if x < a else b if x > b else x


def vec_from_angle(rad: float) -> pygame.Vector2:
    return pygame.Vector2(math.cos(rad), math.sin(rad))


def rand_unit() -> pygame.Vector2:
    a = random.random() * math.tau
    return vec_from_angle(a)


def ease_out_quad(t: float) -> float:
    return 1 - (1 - t) * (1 - t)


@dataclass
class Particle:
    pos: pygame.Vector2
    vel: pygame.Vector2
    life: float
    size: float
    alpha: int = 200
    spin: float = 0.0
    warmth: float = 0.8
    ang: float = 0.0
    drag: float = 0.94

    def update(self, dt: float) -> None:
        self.life -= dt
        self.ang += self.spin * dt
        self.vel *= (self.drag ** (dt * 60.0))
        self.pos += self.vel * dt

    def alive(self) -> bool:
        return self.life > 0.0


def make_glow_stamp(radius: int, core: float = 0.35) -> pygame.Surface:
    r = int(max(2, radius))
    surf = pygame.Surface((r * 2 + 1, r * 2 + 1), pygame.SRCALPHA)
    cx, cy = r, r
    for y in range(-r, r + 1):
        for x in range(-r, r + 1):
            d = math.hypot(x, y) / r
            if d <= 1.0:
                # alpha gradient: core mạnh, ra ngoài mờ dần
                a = 1.0 - d
                a = (a ** (1.6 + (1.0 - core) * 1.2))
                alpha = int(255 * a)
                if alpha > 0:
                    surf.set_at((cx + x, cy + y), (255, 255, 255, alpha))
    return surf


class _GlowCache:
    """Cache stamp đã scale + tint để vẽ glow nhanh."""
    def __init__(self):
        self.base_small = make_glow_stamp(18, core=0.45)
        self.base_big = make_glow_stamp(64, core=0.28)
        self._scaled = {}   # (which, r_int) -> Surface
        self._tinted = {}   # (which, r_int, rgb, alpha) -> Surface

    def _get_scaled(self, which: str, radius: float) -> pygame.Surface:
        r_int = int(max(2, round(radius)))
        key = (which, r_int)
        if key in self._scaled:
            return self._scaled[key]
        base = self.base_small if which == "s" else self.base_big
        surf = pygame.transform.smoothscale(base, (r_int * 2 + 1, r_int * 2 + 1))
        self._scaled[key] = surf
        return surf

    def get(self, which: str, radius: float, rgb: tuple[int, int, int], alpha: int) -> pygame.Surface:
        r_int = int(max(2, round(radius)))
        key = (which, r_int, int(rgb[0]), int(rgb[1]), int(rgb[2]), int(alpha))
        if key in self._tinted:
            return self._tinted[key]
        base = self._get_scaled(which, r_int).copy()
        # tint màu bằng nhân RGB, giữ alpha gradient
        base.fill((rgb[0], rgb[1], rgb[2], 255), special_flags=pygame.BLEND_RGBA_MULT)
        base.set_alpha(alpha)
        self._tinted[key] = base
        return base


class AtomicFX:
    IDLE, CHARGING, FIRING, IMPACT = 0, 1, 2, 3

    def __init__(self):
        self.state = self.IDLE

        # Tuning giống demo (gồng nhanh + bắn ngắn)
        self.charge = 0.0
        self.charge_speed = 3.2  # tốc độ lên charge (để glow "nổ" nhanh)

        self.firing_t = 0.0
        self.firing_dur = 0.12

        self.impact_t = 0.0
        self.impact_dur = 0.55

        self.start = pygame.Vector2(0, 0)
        self.end = pygame.Vector2(0, 0)

        self.particles: list[Particle] = []

        # camera shake "nội bộ" (chỉ dùng để rung beam/impact, không đụng camera game)
        self.shake = 0.0

        # màu vàng kiểu NRO (core -> ring -> outer)
        self.gold_core = (255, 252, 220)
        self.gold_ring = (255, 235, 140)
        self.gold_outer = (255, 195, 60)

        self._glow = _GlowCache()

        # one-shot pulse cho consume_fire
        self._fire_pulse = False

    # ---- lifecycle ----
    def begin_charge(self, start_pos) -> None:
        self.state = self.CHARGING
        self.charge = 0.0
        self.start = pygame.Vector2(start_pos)
        self._fire_pulse = False

        # burst nhẹ
        for _ in range(18):
            v = rand_unit() * random.uniform(40, 190)
            life = random.uniform(0.12, 0.22)
            size = random.uniform(2.0, 4.0)
            warmth = random.uniform(0.65, 1.0)
            self.particles.append(Particle(self.start.copy(), v, life, size, alpha=190,
                                           spin=random.uniform(-9, 9), warmth=warmth))

    def release_fire(self, start_pos, end_pos) -> None:
        if self.state != self.CHARGING:
            return
        self.state = self.FIRING
        self.firing_t = 0.0
        self.start = pygame.Vector2(start_pos)
        self.end = pygame.Vector2(end_pos)

        self.shake = max(self.shake, 7.0 * (0.35 + 0.65 * self.charge))

        d = (self.end - self.start)
        dist = max(1.0, d.length())
        dirv = d / dist

        # particle trail dọc beam (rất ngắn)
        for i in range(44 + int(70 * self.charge)):
            t = random.random()
            pos = self.start + dirv * (t * dist) + rand_unit() * random.uniform(0, 9 + 22 * self.charge)
            vel = dirv * random.uniform(160, 520) + rand_unit() * random.uniform(40, 220)
            life = random.uniform(0.10, 0.22)
            size = random.uniform(1.9, 4.6) * (0.75 + 0.75 * self.charge)
            warmth = random.uniform(0.45, 0.95)
            self.particles.append(Particle(pos, vel, life, size, alpha=170,
                                           spin=random.uniform(-16, 16), warmth=warmth))

        self._fire_pulse = False  # sẽ set True ở frame update đầu tiên của FIRING

    def cancel(self) -> None:
        self.state = self.IDLE
        self.charge = 0.0
        self.firing_t = 0.0
        self.impact_t = 0.0
        self._fire_pulse = False

    def update(self, dt: float, start_pos, end_pos, charging: bool) -> None:
        self.start = pygame.Vector2(start_pos)
        self.end = pygame.Vector2(end_pos)
        self.shake = max(0.0, self.shake - dt * 18.0)

        for p in self.particles:
            p.update(dt)
        self.particles = [p for p in self.particles if p.alive()]

        if self.state == self.IDLE:
            if charging:
                self.begin_charge(self.start)

        elif self.state == self.CHARGING:
            if charging:
                self.charge = clamp(self.charge + dt * self.charge_speed, 0.0, 1.0)

                # hạt xoáy quanh tay
                for _ in range(2 + int(4 * self.charge)):
                    ang = random.random() * math.tau
                    r = random.uniform(7, 16 + 30 * self.charge)
                    pos = self.start + vec_from_angle(ang) * r
                    # kéo về tâm + chút nhiễu
                    to_c = (self.start - pos)
                    vel = to_c.normalize() * random.uniform(40, 160) + rand_unit() * 20
                    life = random.uniform(0.09, 0.18)
                    size = random.uniform(2.0, 4.0) * (0.85 + 0.9 * self.charge)
                    warmth = random.uniform(0.7, 1.0)
                    self.particles.append(Particle(pos, vel, life, size, alpha=150,
                                                   spin=random.uniform(-10, 10), warmth=warmth))
            else:
                # nếu ngắt charge (không bắn)
                self.cancel()

        elif self.state == self.FIRING:
            self.firing_t += dt

            # on-shot pulse: đúng 1 lần khi bắt đầu FIRING
            if not self._fire_pulse:
                self._fire_pulse = True

            # tia lửa dọc beam
            d = (self.end - self.start)
            dist = max(1.0, d.length())
            dirv = d / dist
            for _ in range(4 + int(6 * self.charge)):
                t = random.random()
                pos = self.start + dirv * (t * dist) + rand_unit() * random.uniform(0, 7 + 18 * self.charge)
                vel = dirv * random.uniform(140, 420) + rand_unit() * random.uniform(30, 160)
                life = random.uniform(0.08, 0.16)
                size = random.uniform(1.8, 4.2) * (0.75 + 0.75 * self.charge)
                warmth = random.uniform(0.4, 0.9)
                self.particles.append(Particle(pos, vel, life, size, alpha=150,
                                               spin=random.uniform(-16, 16), warmth=warmth))

            if self.firing_t >= self.firing_dur:
                self.state = self.IMPACT
                self.impact_t = 0.0
                self.shake = max(self.shake, 11.0 * (0.35 + 0.75 * self.charge))

                # nổ ở điểm end
                for _ in range(70 + int(110 * self.charge)):
                    v = rand_unit() * random.uniform(90, 470) * (0.6 + 0.85 * self.charge)
                    life = random.uniform(0.20, 0.52)
                    size = random.uniform(2.6, 8.0) * (0.8 + 0.9 * self.charge)
                    warmth = random.uniform(0.6, 1.0)
                    self.particles.append(Particle(self.end.copy(), v, life, size, alpha=220,
                                                   spin=random.uniform(-18, 18), warmth=warmth))

        elif self.state == self.IMPACT:
            self.impact_t += dt

            # rơi tàn
            for _ in range(3 + int(5 * (1.0 - min(1.0, self.impact_t / self.impact_dur)))):
                pos = self.end + rand_unit() * random.uniform(0, 10)
                vel = rand_unit() * random.uniform(50, 220) + pygame.Vector2(0, random.uniform(-40, 60))
                life = random.uniform(0.14, 0.28)
                size = random.uniform(2.2, 5.0)
                warmth = random.uniform(0.55, 1.0)
                self.particles.append(Particle(pos, vel, life, size, alpha=130,
                                               spin=random.uniform(-18, 18), warmth=warmth))

            if self.impact_t >= self.impact_dur:
                self.cancel()

    def consume_fire_pulse(self) -> bool:
        """True đúng 1 lần khi vừa bước vào FIRING."""
        if self.state == self.FIRING and self._fire_pulse:
            # chỉ trả True 1 lần
            self._fire_pulse = False
            return True
        return False

    def get_local_shake(self) -> pygame.Vector2:
        if self.shake <= 0.0:
            return pygame.Vector2(0, 0)
        return pygame.Vector2(random.uniform(-1, 1) * self.shake, random.uniform(-1, 1) * self.shake)

    # ---- draw helpers ----
    def _mix(self, a: tuple[int, int, int], b: tuple[int, int, int], t: float) -> tuple[int, int, int]:
        return (int(a[0] + (b[0] - a[0]) * t),
                int(a[1] + (b[1] - a[1]) * t),
                int(a[2] + (b[2] - a[2]) * t))

    def _blit_glow(self, fx: pygame.Surface, pos: pygame.Vector2, radius: float, alpha: int, rgb: tuple[int, int, int]) -> None:
        which = "s" if radius < 34 else "b"
        stamp = self._glow.get(which, radius, rgb, alpha)
        r = stamp.get_rect(center=(int(pos.x), int(pos.y)))
        fx.blit(stamp, r, special_flags=pygame.BLEND_RGBA_ADD)

    def _draw_beam(self, fx: pygame.Surface, a: pygame.Vector2, b: pygame.Vector2, strength: float) -> None:
        # Beam core + ring + outer, có "rung" nhẹ
        d = (b - a)
        dist = max(1.0, d.length())
        dirv = d / dist
        n = pygame.Vector2(-dirv.y, dirv.x)

        # rung
        jitter = (self.get_local_shake() * 0.25)
        a2 = a + jitter
        b2 = b + jitter

        # wiggle bằng cách chia đoạn
        segs = int(max(10, dist / 28))
        pts = []
        for i in range(segs + 1):
            t = i / segs
            w = math.sin((t * math.tau * 2.0) + pygame.time.get_ticks() * 0.02) * (1.5 + 4.5 * strength)
            pts.append(a2 + (b2 - a2) * t + n * w)

        # vẽ nhiều lớp line (trên fx, rồi fx blit ADD)
        # chú ý: pygame.draw.lines width tham số cuối (không có thickness=)
        outer_a = int(120 + 80 * strength)
        ring_a = int(160 + 70 * strength)
        core_a = int(220)

        pygame.draw.lines(fx, (*self.gold_outer, outer_a), False, [(p.x, p.y) for p in pts], width=int(12 + 12 * strength))
        pygame.draw.lines(fx, (*self.gold_ring, ring_a), False, [(p.x, p.y) for p in pts], width=int(6 + 8 * strength))
        pygame.draw.lines(fx, (*self.gold_core, core_a), False, [(p.x, p.y) for p in pts], width=int(2 + 3 * strength))

        # flare dọc beam
        for _ in range(3 + int(5 * strength)):
            t = random.random()
            p = a2 + (b2 - a2) * t
            self._blit_glow(fx, p, radius=10 + 18 * strength, alpha=int(140 + 90 * strength), rgb=self.gold_ring)

    def draw(self, surf: pygame.Surface, cam_off: pygame.Vector2) -> None:
        fx = pygame.Surface(surf.get_size(), pygame.SRCALPHA)

        # charge glow ở tay
        if self.state == self.CHARGING:
            c = self.charge
            pulse = 0.72 + 0.28 * math.sin(pygame.time.get_ticks() * 0.014)
            r = 10 + 32 * c * pulse
            pos = self.start + cam_off + self.get_local_shake() * 0.25

            self._blit_glow(fx, pos, r * 1.25, 185, self.gold_outer)
            self._blit_glow(fx, pos, r * 0.78, 220, self.gold_ring)
            self._blit_glow(fx, pos, r * 0.52, 235, self.gold_core)

            # 4 điểm xoay quanh
            for k in range(4):
                ang = pygame.time.get_ticks() * (0.006 + 0.004 * c) + k * (math.tau / 4)
                p = pos + vec_from_angle(ang) * (r * 0.84)
                self._blit_glow(fx, p, r * 0.18, 145, self.gold_ring)

        # firing beam
        if self.state == self.FIRING:
            c = max(0.12, self.charge)
            a = self.start + cam_off
            b = self.end + cam_off
            self._draw_beam(fx, a, b, strength=clamp(0.45 + 0.85 * c, 0.4, 1.35))

            # điểm end sáng mạnh
            self._blit_glow(fx, b, 34 + 30 * c, 215, self.gold_outer)
            self._blit_glow(fx, b, 22 + 18 * c, 235, self.gold_core)

        # impact flash
        if self.state == self.IMPACT:
            t = clamp(self.impact_t / max(1e-6, self.impact_dur), 0.0, 1.0)
            e = ease_out_quad(1.0 - t)
            pos = self.end + cam_off + self.get_local_shake() * 0.35
            r = 30 + 90 * e
            self._blit_glow(fx, pos, r * 1.20, int(150 * e), self.gold_outer)
            self._blit_glow(fx, pos, r * 0.74, int(200 * e), self.gold_ring)
            self._blit_glow(fx, pos, r * 0.48, int(230 * e), self.gold_core)

        # particles (vẽ bằng glow stamp)
        for p in self.particles:
            fade = int(clamp(p.life / 0.55, 0.0, 1.0) * p.alpha)
            if fade <= 0:
                continue
            s = p.size * (0.9 + 0.25 * math.sin(p.ang + pygame.time.get_ticks() * 0.006))
            pos = p.pos + cam_off
            col = self._mix(self.gold_core, self.gold_outer, p.warmth)
            self._blit_glow(fx, pos, radius=s * 2.2, alpha=fade, rgb=col)

        # blit add lên màn hình
        surf.blit(fx, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)


class AtomicGoldSkill:
    """
    Wrapper để tích hợp vào game:
    - set_ready(True) khi nhấn J (đang chọn skill atomic_gold)
    - request_cast(origin_world, target_obj=...) khi left click (READY)
    - update(dt, origin_world, aim_dir) mỗi frame
    - consume_fire() -> True đúng 1 lần khi bắt đầu bắn (để game tạo attack_rect/damage)
    - draw(screen, cam_off) để vẽ hiệu ứng
    """
    def __init__(self):
        self.fx = AtomicFX()

        # READY state (nhấn J)
        self.ready = False

        # cast timing
        self.CAST_DELAY = 0.16
        self._cast_t = 0.0
        self._casting = False

        # cooldown
        self.COOLDOWN = 0.40
        self._cd_t = 0.0

        # locked target (world coords rect)
        self._target_obj: Optional[Any] = None
        self._target_pos: Optional[pygame.Vector2] = None

        # fallback aiming
        self.range = 260.0

        # pulse storage
        self._fire = False

    def is_busy(self) -> bool:
        return self._casting or (self.fx.state != self.fx.IDLE) or (self._cd_t > 0.0)

    def set_ready(self, flag: bool) -> None:
        # chỉ set READY khi không bận
        if self.is_busy():
            self.ready = False
        else:
            self.ready = bool(flag)

    def request_cast(self, origin_world: pygame.Vector2, target_obj: Optional[Any] = None,
                     target_pos: Optional[pygame.Vector2] = None, aim_dir: Optional[pygame.Vector2] = None) -> bool:
        if self.is_busy():
            return False
        if not self.ready:
            return False

        self.ready = False
        self._casting = True
        self._cast_t = 0.0
        self._target_obj = target_obj
        self._target_pos = pygame.Vector2(target_pos) if target_pos is not None else None

        # start fx charging ngay
        self.fx.begin_charge(origin_world)
        self._fire = False
        return True

    def _compute_end_pos(self, origin_world: pygame.Vector2, aim_dir: Optional[pygame.Vector2]) -> pygame.Vector2:
        # ưu tiên target_obj (rect đã ở world coords)
        if self._target_obj is not None and hasattr(self._target_obj, "rect"):
            r = self._target_obj.rect
            return pygame.Vector2(r.centerx, r.centery)

        if self._target_pos is not None:
            return self._target_pos

        # fallback theo hướng aim_dir
        if aim_dir is None or aim_dir.length_squared() < 1e-6:
            aim_dir = pygame.Vector2(1, 0)
        d = aim_dir.normalize()
        return pygame.Vector2(origin_world) + d * self.range

    def update(self, dt: float, origin_world: pygame.Vector2, aim_dir: Optional[pygame.Vector2] = None) -> None:
        if self._cd_t > 0.0:
            self._cd_t = max(0.0, self._cd_t - dt)

        end_pos = self._compute_end_pos(origin_world, aim_dir)

        # casting phase: charge trong CAST_DELAY rồi auto bắn
        charging = False
        if self._casting:
            self._cast_t += dt
            charging = True
            if self._cast_t >= self.CAST_DELAY:
                # auto bắn
                self._casting = False
                self._cd_t = self.COOLDOWN
                self.fx.release_fire(origin_world, end_pos)

        self.fx.update(dt, origin_world, end_pos, charging=charging)

        # consume_fire_pulse đúng 1 lần
        if self.fx.consume_fire_pulse():
            self._fire = True

    def consume_fire(self) -> bool:
        if self._fire:
            self._fire = False
            return True
        return False

    def draw(self, screen: pygame.Surface, cam_off: pygame.Vector2) -> None:
        self.fx.draw(screen, cam_off)
