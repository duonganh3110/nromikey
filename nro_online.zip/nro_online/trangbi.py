import pygame

# --- CẤU HÌNH VỊ TRÍ & MÀU SẮC ---
SLOT_SIZE = 40
GAP = 10
COLOR_SLOT_BG = (50, 50, 60)
COLOR_BORDER = (200, 200, 200)
WHITE = (255, 255, 255)
GREEN_BTN = (0, 180, 0)
RED_BTN = (180, 50, 50)
BLUE_BTN = (0, 100, 255)

# Định nghĩa Index cho các ô
SLOT_AO = 0
SLOT_QUAN = 1
SLOT_GIAY = 2
SLOT_GANG = 3  # Găng tay/Vũ khí
SLOT_RADA = 4

# Tên hiển thị cho ô (để vẽ mờ mờ nếu ko có đồ)
SLOT_NAMES = ["AO", "QUAN", "GIAY", "VU KHI", "RADA"]


def init_equipment_data(info):
    """Đảm bảo dữ liệu nhân vật có trường 'equipment' đúng định dạng LIST"""
    if "equipment" not in info:
        info["equipment"] = [None] * 5
    elif not isinstance(info["equipment"], list):
        info["equipment"] = [None] * 5
    else:
        while len(info["equipment"]) < 5:
            info["equipment"].append(None)
        if len(info["equipment"]) > 5:
            info["equipment"] = info["equipment"][:5]


def get_slot_rects(ui_x, ui_y, ui_width, ui_height):
    """
    [CẬP NHẬT] Tính toán vị trí 5 ô trang bị.
    Căn giữa trong phần 70% BÊN PHẢI (để khớp với giao diện Túi Đồ mới).
    """
    SPLIT_RATIO = 0.3
    WIDTH_LEFT = int(ui_width * SPLIT_RATIO)
    WIDTH_RIGHT = ui_width - WIDTH_LEFT

    total_w = 5 * SLOT_SIZE + 4 * GAP
    start_x = (ui_x + WIDTH_LEFT) + (WIDTH_RIGHT - total_w) // 2
    start_y = ui_y + ui_height - 70

    rects = []
    for i in range(5):
        r = pygame.Rect(start_x + i * (SLOT_SIZE + GAP), start_y, SLOT_SIZE, SLOT_SIZE)
        rects.append(r)
    return rects


def check_item_type_for_slot(item_template, slot_index):
    """Kiểm tra xem item có lắp được vào ô này không"""
    if not item_template:
        return False

    i_type = item_template.get('type', '')
    name = item_template.get('name', '').lower()
    key = item_template.get('key', '').lower()

    # Ô áo: Ao / Giap
    if slot_index == SLOT_AO:
        return (i_type in ["Ao", "Giap"]) or ("ao" in name) or ("giap" in name) or ("armor" in key)

    # Ô quần
    if slot_index == SLOT_QUAN:
        return (i_type == "Quan") or ("quan" in name) or ("quan" in key)

    # Ô giày
    if slot_index == SLOT_GIAY:
        return (i_type == "Giay") or ("giay" in name) or ("giay" in key)

    # Ô găng / vũ khí
    if slot_index == SLOT_GANG:
        valid_types = ["Vu Khi", "Gang", "Kiem", "Sword", "Glove", "Phu Kien"]
        return (
            (i_type in valid_types) or
            ("kiem" in name) or ("sword" in key) or
            ("gang" in name) or ("glove" in key) or
            ("vu khi" in name) or ("weapon" in key)
        )

    # Ô rada
    if slot_index == SLOT_RADA:
        return (i_type == "Rada") or ("rada" in name) or ("radar" in name) or ("radar" in key) or ("rada" in key)

    return False


def get_target_slot_index(item_template):
    """Trả về index ô trang bị phù hợp với item này, trả về -1 nếu không phải trang bị"""
    if not item_template:
        return -1
    for i in range(5):
        if check_item_type_for_slot(item_template, i):
            return i
    return -1


def draw_equipment_slots(screen, info, ui_x, ui_y, ui_width, ui_height,
                         ITEM_TEMPLATES, font_tiny, dragging_slot_index=-1):
    """Vẽ 5 ô trang bị lên giao diện túi đồ"""
    rects = get_slot_rects(ui_x, ui_y, ui_width, ui_height)
    equipment = info.get("equipment", [None] * 5)

    for i, rect in enumerate(rects):
        pygame.draw.rect(screen, COLOR_SLOT_BG, rect)
        pygame.draw.rect(screen, COLOR_BORDER, rect, 1)

        # Vẽ item nếu có (và không đang bị kéo đi)
        if i < len(equipment):
            item_data = equipment[i]
            if item_data and i != dragging_slot_index:
                # Import cục bộ để tránh circular import
                import tuido

                if isinstance(item_data, str):
                    item_data = {"key": item_data, "count": 1}

                tuido.draw_item_icon_in_bag(screen, rect.x, rect.y, item_data, ITEM_TEMPLATES)

        # Vẽ tên ô mờ nếu trống hoặc đang kéo
        is_empty = (i >= len(equipment) or equipment[i] is None)
        if is_empty or i == dragging_slot_index:
            if font_tiny:
                lbl = font_tiny.render(SLOT_NAMES[i], True, (100, 100, 100))
                screen.blit(lbl, (rect.centerx - lbl.get_width() // 2, rect.centery - lbl.get_height() // 2))

    return rects


def handle_equip_action(info, inventory_index, ITEM_TEMPLATES):
    """Xử lý hành động: Mặc đồ từ hành trang vào ô trang bị"""
    try:
        item_data = info["inventory"][inventory_index]
    except Exception:
        return "Lỗi vị trí!", False

    if not item_data:
        return "Không có vật phẩm!", False

    if isinstance(item_data, str):
        item_data = {"key": item_data, "count": 1}
        info["inventory"][inventory_index] = item_data

    key = item_data.get('key')
    template = ITEM_TEMPLATES.get(key) if key else None

    target_slot = get_target_slot_index(template)
    if target_slot == -1:
        return "Đây không phải trang bị!", False

    init_equipment_data(info)

    current_equip = info["equipment"][target_slot]
    info["equipment"][target_slot] = item_data

    if current_equip:
        info["inventory"][inventory_index] = current_equip
    else:
        info["inventory"][inventory_index] = None

    return "Đã trang bị thành công!", True


def handle_unequip_action(info, equip_slot_index):
    """Xử lý hành động: Tháo đồ từ ô trang bị về hành trang"""
    if not isinstance(info.get("equipment"), list):
        return "Lỗi dữ liệu trang bị!", False

    item_data = info["equipment"][equip_slot_index]
    if not item_data:
        return "Không có gì để tháo!", False

    try:
        empty_idx = info["inventory"].index(None)
        info["inventory"][empty_idx] = item_data
        info["equipment"][equip_slot_index] = None
        return "Đã tháo trang bị!", True
    except ValueError:
        return "Hành trang đã đầy!", False


def _to_number(v):
    """Ép v về số (int/float). Hỗ trợ '30%', '30 %'."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    try:
        s = str(v).strip()
        if s.endswith('%'):
            s = s[:-1].strip()
        return float(s)
    except Exception:
        return None


def calculate_stats_bonus(info, ITEM_TEMPLATES, base_sd=None, base_hp=None, base_ki=None):
    """
    [FIXED FINAL + % SUPPORT]
    - Cộng chỉ số thẳng: suc_danh, hp, ki, giap, chi_mang, ne_tranh, hoi_mau, hoi_ki
    - Cộng chỉ số %: suc_danh_percent, max_hp_percent, max_ki_percent
    - Sao (pha lê): mỗi sao +5% (áp dụng cả chỉ số thẳng & chỉ số %)

    LƯU Ý:
    - Hàm vẫn trả về % ở key riêng.
    - Nếu em truyền base_sd/base_hp/base_ki (hoặc info có sẵn), hàm sẽ tự cộng phần % ra số thẳng vào suc_danh/hp/ki luôn cho tiện.
    """
    stats_bonus = {
        "suc_danh": 0,
        "hp": 0,
        "ki": 0,
        "chi_mang": 0,
        "giap": 0,
        "ne_tranh": 0,
        "hoi_mau": 0,
        "hoi_ki": 0,

        # NEW: % bonus
        "suc_danh_percent": 0.0,
        "max_hp_percent": 0.0,
        "max_ki_percent": 0.0,
    }

    equipment = info.get("equipment")
    if not isinstance(equipment, list):
        return stats_bonus

    # Mapping chỉ số thẳng
    MAP_FLAT = {
        "SD": "suc_danh", "SUC_DANH": "suc_danh", "suc_danh": "suc_danh",
        "HP": "hp", "MAX_HP": "hp", "hp": "hp", "max_hp": "hp",
        "KI": "ki", "MAX_KI": "ki", "ki": "ki", "max_ki": "ki",
        "CM": "chi_mang", "CHI_MANG": "chi_mang", "chi_mang": "chi_mang",
        "GIAP": "giap", "giap": "giap",
        "NE": "ne_tranh", "NE_TRANH": "ne_tranh", "ne_tranh": "ne_tranh",
        "HM": "hoi_mau", "HOI_MAU": "hoi_mau", "hoi_mau": "hoi_mau",
        "HK": "hoi_ki", "HOI_KI": "hoi_ki", "hoi_ki": "hoi_ki",
    }

    # Mapping chỉ số %
    MAP_PERCENT = {
        "SD_PERCENT": "suc_danh_percent",
        "SUC_DANH_PERCENT": "suc_danh_percent",
        "suc_danh_percent": "suc_danh_percent",
        "sd_percent": "suc_danh_percent",
        "SD%": "suc_danh_percent",

        "HP_PERCENT": "max_hp_percent",
        "MAX_HP_PERCENT": "max_hp_percent",
        "max_hp_percent": "max_hp_percent",
        "hp_percent": "max_hp_percent",
        "HP%": "max_hp_percent",

        "KI_PERCENT": "max_ki_percent",
        "MAX_KI_PERCENT": "max_ki_percent",
        "max_ki_percent": "max_ki_percent",
        "ki_percent": "max_ki_percent",
        "KI%": "max_ki_percent",
    }

    for item in equipment:
        if not item:
            continue

        key = item.get('key') if isinstance(item, dict) else item
        if not key:
            continue

        template = ITEM_TEMPLATES.get(key)
        if not template:
            continue

        # stats gốc
        final_item_stats = (template.get('stats') or {}).copy()

        # nếu item có stats riêng (đã đập sao/pha lê/roll)
        if isinstance(item, dict) and item.get('stats'):
            for k, v in item['stats'].items():
                final_item_stats[k] = v

        stars = item.get('stars', 0) if isinstance(item, dict) else 0
        star_multiplier = 1.0 + (stars * 0.05) if stars > 0 else 1.0

        for stat_name, stat_value in final_item_stats.items():
            clean = str(stat_name).strip()
            up = clean.upper()

            # Nếu user ghi kiểu "SD%" / "HP%" / "KI%"
            if clean.endswith('%') and up in ["SD%", "HP%", "KI%"]:
                up = up

            # Ưu tiên map % trước (để không bị lẫn max_hp -> hp)
            target_percent = MAP_PERCENT.get(clean) or MAP_PERCENT.get(up)
            if target_percent:
                num = _to_number(stat_value)
                if num is None:
                    continue
                stats_bonus[target_percent] += float(num) * star_multiplier
                continue

            # Map chỉ số thẳng
            target_flat = MAP_FLAT.get(clean) or MAP_FLAT.get(up)
            if target_flat and target_flat in stats_bonus:
                num = _to_number(stat_value)
                if num is None:
                    continue
                stats_bonus[target_flat] += int(float(num) * star_multiplier)

    # --- TỰ CỘNG % RA SỐ THẲNG (nếu có base) ---
    # ưu tiên base truyền vào, nếu không có thì thử lấy từ info
    if base_sd is None:
        base_sd = info.get("suc_danh", None)
    if base_hp is None:
        # FIX: %HP phải tính theo MAX_HP (không phụ thuộc HP hiện tại)
        base_hp = info.get("max_hp", None) or info.get("hp", None)
    if base_ki is None:
        # FIX: %KI phải tính theo MAX_KI (không phụ thuộc KI hiện tại)
        base_ki = info.get("max_ki", None) or info.get("ki", None)

    try:
        if base_sd is not None:
            stats_bonus["suc_danh"] += int(float(base_sd) * stats_bonus["suc_danh_percent"] / 100.0)
    except Exception:
        pass

    try:
        if base_hp is not None:
            stats_bonus["hp"] += int(float(base_hp) * stats_bonus["max_hp_percent"] / 100.0)
    except Exception:
        pass

    try:
        if base_ki is not None:
            stats_bonus["ki"] += int(float(base_ki) * stats_bonus["max_ki_percent"] / 100.0)
    except Exception:
        pass

    return stats_bonus


def ve_nut_custom_local(screen, rect, mau, text, text_color, font):
    """Vẽ nút tùy chỉnh"""
    pygame.draw.rect(screen, mau, rect, border_radius=5)
    pygame.draw.rect(screen, WHITE, rect, 2, border_radius=5)
    text_surf = font.render(text, True, text_color)
    text_rect = text_surf.get_rect(center=rect.center)
    screen.blit(text_surf, text_rect)
