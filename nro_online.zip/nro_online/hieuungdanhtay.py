import pygame
import random
import math
import sys
import os

# --- IMPORT CONFIG TỪ MAIN ---
try:
    current_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(os.path.join(current_dir, '..'))
    import main 
    SCREEN_WIDTH = main.SCREEN_WIDTH
    WHITE = main.WHITE
    BLACK = main.BLACK
    RED = main.RED_ERROR
    ORANGE = (255, 165, 0)
    YELLOW = (255, 255, 0)
    DARK_GRAY = (50, 50, 50)
except:
    SCREEN_WIDTH = 800
    pygame.init()
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    RED = (255, 0, 0)
    ORANGE = (255, 165, 0)
    YELLOW = (255, 255, 0)
    DARK_GRAY = (50, 50, 50)


# --- CẤU HÌNH MÀU SẮC NÂNG CẤP (NEON STYLE) ---
# Màu nắm đấm (Ki Attack)
FIST_CORE = WHITE            # Lõi trắng tinh
FIST_GLOW = (255, 140, 0, 150)   # Viền cam phát sáng (có độ trong suốt)
FIST_TRAIL = (255, 69, 0, 100)   # Vệt đuôi cam đậm

# Màu vết cắt (Slash)
SLASH_CORE = WHITE               # Lõi trắng
SLASH_GLOW = (0, 255, 255)       # Viền xanh Cyan sáng
SLASH_GLOW_ALT = YELLOW          # Viền vàng chanh

# Màu hiệu ứng cắn/vuốt của Quái vật
MONSTER_HIT_COLOR = (150, 0, 0)      # Đỏ sẫm (máu/nanh vuốt)
MONSTER_HIT_GLOW = (255, 100, 0, 150) # Hào quang cam/đỏ mờ


# --- BASE EFFECT CLASS ---
class BaseEffect:
    def __init__(self, x, y, duration=15): 
        self.x = x
        self.y = y
        self.start_time = pygame.time.get_ticks()
        self.duration = duration
        self.max_timer = duration
        self.timer = duration
        self.is_active = True

    def update(self):
        self.timer -= 1
        if self.timer <= 0:
            self.is_active = False

    def draw(self, screen, map_offset_x):
        pass

# --- 1. HIỆU ỨNG ĐÁNH TAY/VÕ THUẬT (Fist) ---
class FistEffect(BaseEffect):
    def __init__(self, x_world, y, is_facing_right, duration=8):
        super().__init__(x_world, y, duration=duration)
        self.facing_right = is_facing_right

    def draw(self, screen, map_offset_x):
        if not self.is_active: return
        
        progress = 1 - (self.timer / self.max_timer) 
        reach = 35 * math.sin(progress * 3.14) 
        
        draw_x = self.x - map_offset_x
        offset_dir = 1 if self.facing_right else -1
        
        fist_x = draw_x + 15 + (reach * offset_dir)
        fist_y = self.y + 25
        
        # 1. Vẽ Cánh tay (Tốc độ cao tạo vệt mờ)
        shoulder_x = (self.x - map_offset_x) + 15
        
        # Lớp giữa (Tay áo/Da)
        pygame.draw.line(screen, (255, 100, 0), (shoulder_x, fist_y), (fist_x, fist_y), 6)

        # 2. Vẽ Nắm Đấm (Hiệu ứng tụ lực phát sáng)
        glow_radius = 12 + (self.timer % 3)
        
        # Vẽ quầng sáng (Glow Aura)
        glow_surf = pygame.Surface((glow_radius*2, glow_radius*2), pygame.SRCALPHA)
        pygame.draw.circle(glow_surf, FIST_GLOW, (glow_radius, glow_radius), glow_radius)
        screen.blit(glow_surf, (fist_x - glow_radius, fist_y - glow_radius))

        # Vẽ lõi trắng (Core)
        pygame.draw.circle(screen, FIST_CORE, (fist_x, fist_y), 6)

# --- 2. HIỆU ỨNG CẮT/CHÉM (Slash) ---
class SlashEffect(BaseEffect):
    def __init__(self, x_world, y, width, height, color_glow):
        super().__init__(x_world, y, duration=12)
        self.target_width = width
        self.target_height = height
        self.color_glow = color_glow
        
        # Tạo ngẫu nhiên 3 đường cắt
        self.lines = []
        for _ in range(3):
            if random.choice([True, False]):
                sx, sy = -10, random.randint(-10, self.target_height)
                ex, ey = self.target_width + 10, random.randint(0, self.target_height + 10)
            else:
                sx, sy = self.target_width + 10, random.randint(-10, self.target_height)
                ex, ey = -10, random.randint(0, self.target_height + 10)
                
            width = random.randint(2, 5) 
            self.lines.append((sx, sy, ex, ey, width))

    def draw(self, screen, map_offset_x):
        if not self.is_active: return
        
        draw_x = self.x - map_offset_x
        draw_y = self.y
        
        # Hiệu ứng mờ dần theo thời gian
        alpha = int((self.timer / self.max_timer) * 255)
        
        for sx, sy, ex, ey, w in self.lines:
            start_pos = (draw_x + sx, draw_y + sy)
            end_pos = (draw_x + ex, draw_y + ey)
            
            # Vẽ màu nền (Glow) - Dày hơn
            pygame.draw.line(screen, self.color_glow, start_pos, end_pos, w + 4)
            
            # Vẽ Lõi Trắng (Core) - Mỏng hơn, tạo độ sắc
            pygame.draw.line(screen, SLASH_CORE, start_pos, end_pos, max(1, w - 2))


# --- 3. HIỆU ỨNG TẤN CÔNG QUÁI VẬT LÊN NGƯỜI CHƠI (Monster Hit) ---
class MonsterHitEffect(BaseEffect):
    def __init__(self, x_screen, y_screen, duration=10):
        # x, y là tọa độ màn hình
        super().__init__(x_screen, y_screen, duration=duration) 
        self.angle = random.randint(0, 360)
        self.hit_core = MONSTER_HIT_COLOR
        self.hit_glow = MONSTER_HIT_GLOW

    def draw(self, screen, map_offset_x):
        if not self.is_active: return
        
        progress = 1 - (self.timer / self.max_timer)
        
        # Vị trí trên màn hình (đã được lưu)
        sx = self.x 
        sy = self.y 
        
        # Kích thước tối đa
        max_size = 15
        
        # Animation: Hiệu ứng co lại và mờ dần
        size = max_size * (1 - progress) + 3
        alpha = int((self.timer / self.max_timer) * 255)
        
        # Tạo bề mặt tạm thời để điều chỉnh alpha
        temp_surf = pygame.Surface((max_size * 2, max_size * 2), pygame.SRCALPHA)
        temp_surf.set_alpha(alpha)

        # Vẽ hình dạng vuốt/cắn (3 đường cắn chụm vào trung tâm)
        center = (max_size, max_size)
        
        # 1. Lớp Glow
        for i in range(3):
             # Tạo các đường vuốt/cắn
            angle = self.angle + i * 120
            
            # Đường line màu cam (Glow)
            end_x = int(size * math.cos(math.radians(angle)))
            end_y = int(size * math.sin(math.radians(angle)))
            
            pygame.draw.line(temp_surf, self.hit_glow, center, (center[0] + end_x, center[1] + end_y), 5)
        
        # 2. Lớp Core
        for i in range(3):
            angle = self.angle + i * 120
            
            # Đường line màu đỏ sẫm (Core)
            end_x = int((size - 2) * math.cos(math.radians(angle)))
            end_y = int((size - 2) * math.sin(math.radians(angle)))
            
            pygame.draw.line(temp_surf, self.hit_core, center, (center[0] + end_x, center[1] + end_y), 3)

        # Blit lên màn hình, căn chỉnh vị trí
        screen.blit(temp_surf, (sx - max_size, sy - max_size))


# --- EFFECT MANAGER ---
class EffectManager:
    """Quản lý và cập nhật tất cả các hiệu ứng hình ảnh trong game."""
    def __init__(self):
        self.effects = []

    def add_fist(self, x_world, y, huong_phai):
        self.effects.append(FistEffect(x_world, y, huong_phai))

    def add_slash(self, x_world, y, width, height):
        color_glow = random.choice([SLASH_GLOW, SLASH_GLOW_ALT])
        self.effects.append(SlashEffect(x_world, y, width, height, color_glow))

    def add_monster_hit(self, x_screen, y_screen):
        """Thêm hiệu ứng va chạm lên vị trí người chơi (dùng tọa độ màn hình)"""
        self.effects.append(MonsterHitEffect(x_screen, y_screen))


    def update(self):
        # Cập nhật và xóa các effect đã hết hạn
        self.effects = [e for e in self.effects if e.is_active]
        for e in self.effects:
            e.update()

    def draw(self, screen, map_offset_x):
        for e in self.effects:
            # MonsterHitEffect dùng tọa độ màn hình, nên không offset
            if isinstance(e, MonsterHitEffect):
                e.draw(screen, 0) 
            else:
                # Các effect khác dùng map_offset_x (tọa độ thế giới)
                e.draw(screen, map_offset_x)