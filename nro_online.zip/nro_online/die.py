import pygame

# --- CẤU HÌNH ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED_ERROR = (255, 50, 50)
BLUE_UI = (0, 100, 200)

SCREEN_WIDTH = 800 # Giả định, sẽ được gán lại từ main
SCREEN_HEIGHT = 600 # Giả định

font_large = None
font_small = None
font_tiny = None

def init_fonts():
    global font_large, font_small, font_tiny
    if not font_large:
        pygame.font.init()
        font_large = pygame.font.SysFont("Arial", 30, bold=True)
        font_small = pygame.font.SysFont("Arial", 18)
        font_tiny = pygame.font.SysFont("Arial", 14)


class DieScreen:
    def __init__(self, screen_width, screen_height):
        init_fonts()
        self.SCREEN_WIDTH = screen_width
        self.SCREEN_HEIGHT = screen_height
        self.is_open = False
        
        self.btn_revive_rect = None
        self.btn_home_rect = None

    def draw(self, screen):
        if not self.is_open:
            return

        # 1. Vẽ nền tối mờ
        s = pygame.Surface((self.SCREEN_WIDTH, self.SCREEN_HEIGHT), pygame.SRCALPHA)
        s.fill((0, 0, 0, 180)) # Nền đen 70% trong suốt
        screen.blit(s, (0, 0))

        # 2. Vẽ hộp thông báo chính
        BOX_W = 450
        BOX_H = 200
        BOX_X = (self.SCREEN_WIDTH - BOX_W) // 2
        BOX_Y = (self.SCREEN_HEIGHT - BOX_H) // 2
        box_rect = pygame.Rect(BOX_X, BOX_Y, BOX_W, BOX_H)
        pygame.draw.rect(screen, BLACK, box_rect, border_radius=10)
        pygame.draw.rect(screen, RED_ERROR, box_rect, 3, border_radius=10)

        # 3. Vẽ tiêu đề
        title_text = "BAN DA BI HA"
        title_surf = font_large.render(title_text, True, RED_ERROR)
        screen.blit(title_surf, (BOX_X + (BOX_W - title_surf.get_width()) // 2, BOX_Y + 20))
        
        # 4. Vẽ câu hỏi
        question_text = "Ban co muon hoi sinh khong?"
        question_surf = font_small.render(question_text, True, WHITE)
        screen.blit(question_surf, (BOX_X + (BOX_W - question_surf.get_width()) // 2, BOX_Y + 70))

        # 5. Vẽ các nút
        
        # Nút 1: Hồi sinh 2 Kim Cương
        BTN1_W, BTN1_H = 180, 40
        BTN1_X = BOX_X + 30
        BTN1_Y = BOX_Y + 120
        self.btn_revive_rect = pygame.Rect(BTN1_X, BTN1_Y, BTN1_W, BTN1_H)
        
        text_revive = "Hoi sinh (2 KC)"
        text_color = WHITE if font_small else BLACK # Đảm bảo có màu
        
        # Hàm vẽ nút custom
        def draw_button(rect, color, text, screen):
            pygame.draw.rect(screen, color, rect, border_radius=5)
            pygame.draw.rect(screen, WHITE, rect, 2, border_radius=5)
            text_surf = font_small.render(text, True, WHITE)
            screen.blit(text_surf, (rect.x + (rect.width - text_surf.get_width()) // 2, rect.y + (rect.height - text_surf.get_height()) // 2))

        draw_button(self.btn_revive_rect, (0, 150, 0), text_revive, screen)


        # Nút 2: Về nhà (Map 1)
        BTN2_W, BTN2_H = 180, 40
        BTN2_X = BOX_X + BOX_W - BTN2_W - 30
        BTN2_Y = BOX_Y + 120
        self.btn_home_rect = pygame.Rect(BTN2_X, BTN2_Y, BTN2_W, BTN2_H)
        
        text_home = "Ve Nha"
        draw_button(self.btn_home_rect, (200, 100, 0), text_home, screen)
        

    def handle_click(self, pos):
        """Xử lý click vào các nút. Trả về action: 'revive', 'home', hoặc None"""
        if not self.is_open:
            return None
            
        mx, my = pos
        
        if self.btn_revive_rect and self.btn_revive_rect.collidepoint(mx, my):
            return 'revive'
        
        if self.btn_home_rect and self.btn_home_rect.collidepoint(mx, my):
            return 'home'
            
        return None

# --- VẼ HỒN MA (Dựa trên lớp Player/Character của bạn) ---
def draw_ghost(screen, player_rect, huong_phai, animation_frame):
    """Vẽ nhân vật ở trạng thái hồn ma (chỉ có đầu)"""
    
    x = player_rect.x
    y = player_rect.y
    width = player_rect.width
    height = player_rect.height
    
    # 1. Vẽ hiệu ứng mờ/trong suốt (tương tự như NRO)
    s = pygame.Surface((width * 1.5, height), pygame.SRCALPHA)
    s.fill((200, 200, 255, 120)) # Màu xanh nhạt bán trong suốt
    screen.blit(s, (x - width // 4, y))
    
    # 2. Vẽ đầu (Vị trí đầu tương đối ở trên cùng)
    head_radius = width // 2
    head_x = x + width // 2
    head_y = y + head_radius
    
    # Vẽ đầu tròn màu trắng/xanh nhạt
    pygame.draw.circle(screen, WHITE, (head_x, head_y), head_radius)
    
    # Vẽ mắt (đơn giản hóa)
    eye_size = 3
    eye_offset_x = head_radius // 2
    
    # Mắt trái
    pygame.draw.circle(screen, BLACK, (head_x - eye_offset_x, head_y), eye_size)
    # Mắt phải
    pygame.draw.circle(screen, BLACK, (head_x + eye_offset_x, head_y), eye_size)