import pygame
import random
import math

# --- CẤU HÌNH ---
DROP_SIZE = 20
PICKUP_RANGE = 40 
GRAVITY = 0.5
BOUNCE_FACTOR = -0.6

# MÀU SẮC
VANG_COLOR = (255, 215, 0)
VANG_LIGHT = (255, 255, 150)
KC_COLOR = (0, 191, 255)
KC_LIGHT = (200, 255, 255)
GLOW_COLOR_VANG = (255, 215, 0, 100)
GLOW_COLOR_KC = (0, 191, 255, 100)
GLOW_COLOR_ITEM = (255, 0, 0, 100) # Màu hào quang cho trang bị

# --- TỈ LỆ RƠI (GIỮ NGUYÊN CẤU HÌNH CỦA BẠN) ---
MOC_NHAN_DROP_RATES = {
    "VANG": [(0.001, 20), (0.005, 8), (0.01, 6), (0.05, 4), (0.1, 2)],
    "KIM_CUONG": [(0.0001, 10), (0.001, 2), (0.01, 1)]
}

QUAI_MAP2_DROP_RATES = {
    "VANG": [
        (0.00001, 10000), (0.0001, 500), (0.001, 167), (0.005, 145), (0.01, 121),
        (0.05, 100), (0.1, 85), (0.2, 60), (0.5, 45), (0.7, 30)
    ],
    "KIM_CUONG": [(0.0001, 15), (0.001, 5), (0.01, 2)]
}

def calculate_drop(drop_type, monster_type_key):
    if monster_type_key == "MOC_NHAN": rates = MOC_NHAN_DROP_RATES.get(drop_type, [])
    else: rates = QUAI_MAP2_DROP_RATES.get(drop_type, [])
    
    sorted_rates = sorted(rates, key=lambda x: x[1], reverse=True)
    roll_percent = random.uniform(0, 100)
    
    for chance, value in sorted_rates:
        if roll_percent <= (chance * 100): return value
    return 0

class DropItem:
    def __init__(self, x, y, item_type, amount=0, data=None):
        self.rect = pygame.Rect(x, y, DROP_SIZE, DROP_SIZE)
        self.type = item_type # "VANG", "KIM_CUONG", "ITEM", "VND"
        self.amount = amount
        self.data = data      # Dữ liệu trang bị (quan trọng cho add_item)
        
        # Vật lý rơi nảy (Physics)
        self.x = float(x)
        self.y = float(y)
        self.ground_y = float(y) # Điểm chạm đất
        self.vy = -6 # Nảy lên khi rơi ra
        self.vx = random.uniform(-2, 2) # Bay ngang nhẹ
        self.timer = pygame.time.get_ticks()
        self.exist_time = 30000 # Tồn tại 30s
        self.hover_offset = 0

    def update(self):
        # Logic rơi tự do và nảy
        if self.y < self.ground_y:
            self.vy += GRAVITY
            self.y += self.vy
            self.x += self.vx
            if self.y >= self.ground_y:
                self.y = self.ground_y
                self.vy *= BOUNCE_FACTOR
                self.vx *= 0.8 # Ma sát làm chậm bay ngang
                if abs(self.vy) < 1: self.vy = 0
        else:
            # Hiệu ứng bay nhẹ tại chỗ khi đã nằm đất
            self.hover_offset += 0.1
            self.rect.y = int(self.y + math.sin(self.hover_offset) * 3)
            return

        self.rect.x = int(self.x)
        self.rect.y = int(self.y)

    def draw(self, screen, map_offset_x):
        draw_x = self.rect.centerx - map_offset_x
        draw_y = self.rect.centery
        
        if -50 < draw_x < 850:
            # 1. Vẽ Hào Quang
            glow_surf = pygame.Surface((40, 40), pygame.SRCALPHA)
            if self.type == "ITEM": c_glow = GLOW_COLOR_ITEM
            elif self.type == "KIM_CUONG": c_glow = GLOW_COLOR_KC
            else: c_glow = GLOW_COLOR_VANG
            
            pygame.draw.circle(glow_surf, c_glow, (20, 20), 12 + abs(math.sin(pygame.time.get_ticks()*0.005)*3))
            screen.blit(glow_surf, (draw_x - 20, draw_y - 20))

            # 2. Vẽ Vật Phẩm
            if self.type == "ITEM":
                # Vẽ Túi Đồ (Màu đỏ nâu)
                pygame.draw.rect(screen, (165, 42, 42), (draw_x-8, draw_y-8, 16, 16), border_radius=3)
                pygame.draw.rect(screen, (255, 215, 0), (draw_x-2, draw_y-6, 4, 12)) # Dây buộc
                pygame.draw.rect(screen, (255, 255, 255), (draw_x-8, draw_y-8, 16, 16), 1, border_radius=3)
                # Sao lấp lánh nếu là đồ xịn
                if self.data and self.data.get('star', 0) > 0:
                    if (pygame.time.get_ticks() // 200) % 2 == 0:
                        pygame.draw.circle(screen, (255, 255, 0), (draw_x+6, draw_y-6), 2)

            elif self.type == "VANG":
                pygame.draw.circle(screen, (200, 150, 0), (draw_x, draw_y), 8)
                pygame.draw.circle(screen, VANG_COLOR, (draw_x, draw_y), 6)
                pygame.draw.circle(screen, VANG_LIGHT, (draw_x - 2, draw_y - 2), 2)
            
            elif self.type == "KIM_CUONG":
                pts = [(draw_x, draw_y - 8), (draw_x + 6, draw_y), (draw_x, draw_y + 8), (draw_x - 6, draw_y)]
                pygame.draw.polygon(screen, KC_COLOR, pts)
                pygame.draw.polygon(screen, KC_LIGHT, [(draw_x, draw_y-8), (draw_x+3, draw_y-3), (draw_x, draw_y)], 0)
            
            elif self.type == "VND":
                pygame.draw.rect(screen, (0, 150, 0), (draw_x-10, draw_y-6, 20, 12))
                # Chữ $ nhỏ
                # (Bỏ qua font để tránh lag, vẽ ký hiệu đơn giản)
                pygame.draw.line(screen, (200, 255, 200), (draw_x, draw_y-4), (draw_x, draw_y+4), 1)

class DropManager:
    def __init__(self):
        self.drops = []
        
    def generate_drop(self, x, y, monster_type_key="QUAI_MAP2"):
        """Tạo drop cho quái thường"""
        # Vàng
        vang_amt = calculate_drop("VANG", monster_type_key)
        if vang_amt > 0:
            self.drops.append(DropItem(x, y, "VANG", vang_amt))

        # Kim Cương
        kc_amt = calculate_drop("KIM_CUONG", monster_type_key)
        if kc_amt > 0:
            self.drops.append(DropItem(x, y, "KIM_CUONG", kc_amt))

    # --- [QUAN TRỌNG] HÀM NÀY ĐỂ FIX LỖI CRASH ---
    def add_item(self, x, y, item_data):
        """Thêm item rơi ra (Dùng cho Boss)"""
        drop = DropItem(x, y, "ITEM", 1, data=item_data)
        self.drops.append(drop)

    # --- [QUAN TRỌNG] HÀM NÀY ĐỂ BOSS RƠI VÀNG ---
    def add_gold(self, x, y, amount):
        self.drops.append(DropItem(x, y, "VANG", amount))

    def add_vnd(self, x, y, amount):
        self.drops.append(DropItem(x, y, "VND", amount))

    def update(self):
        current_time = pygame.time.get_ticks()
        # Update và xóa item hết hạn
        self.drops = [d for d in self.drops if current_time - d.timer < d.exist_time]
        for item in self.drops:
            item.update()

    def check_pickup(self, player_rect, player_world_x):
        collected = []
        # Rect nhặt đồ (dùng tọa độ world)
        p_rect_world = pygame.Rect(player_world_x, player_rect.y, player_rect.width, player_rect.height)
        pickup_area = p_rect_world.inflate(PICKUP_RANGE, PICKUP_RANGE)
        
        remaining = []
        for item in self.drops:
            item_rect_world = pygame.Rect(item.x, item.y, DROP_SIZE, DROP_SIZE)
            if pickup_area.colliderect(item_rect_world):
                collected.append({
                    "type": item.type,
                    "amount": item.amount,
                    "data": item.data # Trả về data để main.py xử lý trang bị
                })
            else:
                remaining.append(item)
        
        self.drops = remaining
        return collected

    def draw(self, screen, map_offset_x):
        for item in self.drops:
            item.draw(screen, map_offset_x)