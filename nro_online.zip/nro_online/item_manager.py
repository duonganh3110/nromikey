# File: item_manager.py (Đã sửa: Thêm item cơ bản + quần/giày vải + rada)

import json
import os
import random

THU_MUC_GAME = os.path.dirname(os.path.abspath(__file__))
DATA_ITEM_FILE = os.path.join(THU_MUC_GAME, "du_lieu_vat_pham.json")

# [CẬP NHẬT] Thêm Giáp, HP Potion, KI Potion + Quần vải + Giày vải + Rada cấp 1
DEFAULT_ITEM_TEMPLATES = {
    "sword_1": {
        "name": "Kiem Go",
        "type": "Vu Khi",
        "desc": "Vu khi tap luyen co ban.",
        "rarity": (200, 200, 200),  # Màu xám
        "item_id": 1,
        "stats": {
            "suc_danh": 5
        }
    },
    "armor_1": {
        "name": "Ao Vai",
        "type": "Giap",
        "desc": "Giap cap thap nhat.",
        "rarity": (200, 200, 200),  # Màu xám
        "item_id": 2,
        "stats": {
            "giap": 3,
            "max_hp": 10
        }
    },
    "hp_potion_1": {
        "name": "Thuoc HP nho",
        "type": "Tieu Hao",
        "desc": "Hoi phuc 100 HP.",
        "rarity": (255, 0, 0),  # Màu đỏ
        "item_id": 3,
        "stats": {
            "hoi_mau": 100
        }
    },
    "ki_potion_1": {
        "name": "Thuoc KI nho",
        "type": "Tieu Hao",
        "desc": "Hoi phuc 100 KI.",
        "rarity": (0, 120, 255),  # Màu xanh dương
        "item_id": 4,
        "stats": {
            "hoi_ki": 100
        }
    },

    # --- [NEW] QUẦN VẢI: +2 giáp, +10 HP ---
    "pants_1": {
        "name": "Quan Vai",
        "type": "Quan",
        "desc": "Quan vai co ban. Tang it giap va HP.",
        "rarity": (200, 200, 200),
        "item_id": 5,
        "stats": {
            "giap": 2,
            "max_hp": 10
        }
    },

    # --- [NEW] GIÀY VẢI: +2 giáp, +10 HP ---
    "shoes_1": {
        "name": "Giay Vai",
        "type": "Giay",
        "desc": "Giay vai co ban. Tang it giap va HP.",
        "rarity": (200, 200, 200),
        "item_id": 6,
        "stats": {
            "giap": 2,
            "max_hp": 10
        }
    },

    # --- [NEW] RADA CẤP 1: +1 chí mạng ---
    "rada_1": {
        "name": "Rada Cap 1",
        "type": "Phu Kien",
        "desc": "Rada co ban. Tang chi mang.",
        "rarity": (255, 215, 0),  # vàng nhẹ cho nhìn nổi
        "item_id": 7,
        "stats": {
            "chi_mang": 1
        }
    }
}


class ItemManager:
    def __init__(self):
        self.item_file_path = DATA_ITEM_FILE
        self.ITEM_TEMPLATES = self._load_item_templates()

    def _load_item_templates(self):
        # Luôn load default để đảm bảo item chuẩn
        return DEFAULT_ITEM_TEMPLATES.copy()

    def save_item_templates(self):
        try:
            with open(self.item_file_path, "w") as f:
                json.dump(self.ITEM_TEMPLATES, f, indent=4)
        except Exception as e:
            print(e)

    def create_random_item_stack(self, count):
        # Tạo stack item cho người mới (mặc định: count cái kiếm gỗ)
        return [{"key": "sword_1", "count": 1} for _ in range(count)]


ITEM_MANAGER = ItemManager()
ITEM_TEMPLATES = ITEM_MANAGER.ITEM_TEMPLATES

def save_item_data():
    ITEM_MANAGER.save_item_templates()

def create_random_item_stack(count):
    return ITEM_MANAGER.create_random_item_stack(count)
